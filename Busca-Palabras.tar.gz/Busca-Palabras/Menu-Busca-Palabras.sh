#!/bin/bash
#
# Created by: Robert_Nissan
#
# VARIABLES
#
# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
# Ignorar Ctrl+Z en todo el script de menú
trap '' SIGTSTP
trap 'handler_SIGINT' SIGINT

rm -rf ~/Install-Busca-Palabras.sh >/dev/null 2>&1
rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1
sudo rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1
#
PWD=$(pwd)
source ${PWD}/config/Colors.sh >/dev/null 2>&1
source ${PWD}/config/Termux >/dev/null 2>&1
#
# CODIGO
#
sleep 0.1
clear
Termux
: '
echo -e -n "${verde}
+---------------------------------------+
# ["$blanco"01"$verde"] | "$blanco"Busca-Palabras       ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}02${verde}] | ${blanco}Palabras-Tildadas    ${verde}| ${rojo}(ROOT)  ${verde}#
#---------------------------------------#
# [${blanco}03${verde}] | ${blanco}Busca-Correos        ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}04${verde}] | ${blanco}Contar-Palabras      ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}05${verde}] | ${blanco}Contar-Palabras      ${verde}| ${rojo}(ROOT)  ${verde}#
#---------------------------------------#
# [${blanco}06${verde}] | ${blanco}Busca-Ver-Ficheros   ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}07${verde}] | ${blanco}Acceso-Local-Remoto  ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}08${verde}] | ${blanco}Acceso-Remoto-ssh    ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}09${verde}] | ${blanco}Aplicaciones Premium ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}10${verde}] | ${blanco}Registro d encendido ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}11${verde}] | ${blanco}Codigo de registro   ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}12${verde}] | ${blanco}Adivino tu numero    ${verde}| ${blanco}NO ROOT ${verde}#
#---------------------------------------#
# [${blanco}13${verde}] | ${blanco}Actualizar-Script    ${verde}| ${blanco}NO ROOT ${verde}#
+---------------------------------------+         
'
echo -e -n "${reset}"
printf '%b' '\033[0m'
#### caja principal ####
function count_printable_chars {
  # Elimina los codigos de escape ANSI para que no se cuenten
  stripped_string=$(echo -en "$1" | sed 's/\x1B\[[0-9;]*[mG]//g')
  # Convierte la cadena a una sucesion de caracteres hexadecimales
  hex_chars=$(echo -n "$stripped_string" | xxd -p -c 256)
  # Filtra solo los caracteres imprimibles en la secuencia hexa
  filtered_hex_chars=$(echo "$hex_chars" | sed 's/[[:xdigit:]]\{2\}/\\x&/g' | tr -d '\n' | grep -o '[[:print:]]')
  # Cuenta la cantidad de caracteres imprimibles presentes
  count=$(echo -n "$filtered_hex_chars" | wc -m)
  echo "$count"
}

# Definimos los colores
GREEN='\033[32m' # Verde
WHITE='\033[37m' # Blanco
NC='\033[0m' # No Color
# Definimos la cadena
ID="${WHITE}[01]${GREEN}"
CLI="${WHITE}Busca Palabras${GREEN}"
DEU="${WHITE}NO ROOT${GREEN}"
# array de code
data=( '[02]' 'Adb y optimizar android '       'NO ROOT' 
       '[03]' 'Busca-Correos'            'NO ROOT'
       '[04]' 'Contar-Palabras'          'NO ROOT'
       '[05]' 'Ver conectados a wifi - scan-port'          'NO ROOT'
       '[06]' 'Busca-Ver-Ficheros'       'NO ROOT'
       '[07]' 'Acceso-Local-Remoto'      'NO ROOT'
       '[08]' 'Acceso-Remoto-ssh'        'NO ROOT'
       '[09]' 'Aplicaciones Premium'     'NO ROOT'
       '[10]' 'Emuladores y juegos'    'NO ROOT'
       '[11]' 'Ubuntu ollama (AI) offline'       'NO ROOT'
       '[12]' 'Adivino tu numero'        'NO ROOT'
       '[13]' 'Actualizar-Script'        'NO ROOT'
     )
# Contar el numero de filas
# El calculo se haya dividiendo entre laa 3 columnas
num_filas=$(( ${#data[@]} / 3 ))
# Calculamos los valores para imprimir correctamente
columns=$(tput cols)
col=$(($columns - 1))
mul=$(($columns*07/100))
mul2=$(($columns*78/100))
mul3=$(($columns*15/100))
# Definimos la cadena resultante
printf_result="${restet}${GREEN}# %-${mul}s | %-${mul2}s | % ${mul3}s #${NC}\n"
RESULT=$(printf "$printf_result" "$ID" "$CLI" "$DEU")
# Calculamos la longitud de la cadena imprimible, excluyendo los caracteres de escape
char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
#char_count=$(printf count_printable_chars "$RESULT" | wc -m)
#echo -e "\n$RESULT"
# Imprimimos la cantidad de caracteres imprimibles
#echo "La cantidad de caracteres imprimibles es: $char_count"
#echo "Aplicando ajuste resposive"
# aqui va el ajuste resposive a encabezado
for i in {1..301}; do
    medida=$(($char_count + $i))
    if [[ "$medida" -eq "$columns" ]]; then
        #echo "$char_count + $i = $columns"
        mul2=$(($mul2 + $i))
        break 
    fi
    medida=$(($char_count - $i))
    if [[ "$medida" -eq "$columns" ]]; then
        #echo "$char_count - $i = $columns"
        mul2=$(($mul2 - $i))
        break
    fi
done
printf_result="${GREEN}█ %-${mul}s | %-${mul2}s | % ${mul3}s █${NC}\n"
RESULT=$(printf "$printf_result" "$ID" "$CLI" "$DEU")
printf "${GREEN}┌%s┐\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
echo -e "$RESULT"
iter=0
for ((i=0;i<${#data[@]};i+=3)); do
    id="${WHITE}${data[i]}${GREEN}"
    cli="${WHITE}${data[i+1]}${GREEN}"
    deu="${WHITE}${data[i+2]}${GREEN}"
    #read
    printf "${GREEN}█%s█\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
    # contar caracteres
    printf_result="${NC}${GREEN}# %-${mul}s | %-${mul2}s | % ${mul3}s #${NC}\n"
    RESULT=$(printf "$printf_result" "$id" "$cli" "$deu")
    char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
    #echo -e "fchar_count $char_count"

    # ajustar resposive a cada columna
    for j in {1..301}; do
        medida=$(($char_count + $j))
        if [[ "$medida" -eq "$columns" ]]; then
            #echo -e "$mul3 + $j"
            # mul3=$((mul3 + $j))
            # Anadir los espacios al inicio para alinear a la derecha
            #deu=$(printf "%${j}s$deu")
            deu=$(printf  "%s%*s" "$deu" $j "")

            printf_result="${NC}${GREEN}█ %-${mul}s | %-${mul2}s | % ${mul3}s █${NC}\n"
            RESULT=$(printf "$printf_result" "$id" "$cli" "$deu")
            #echo -e "$RESULT"
            char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
            #echo -e "fchar_count $char_count"

            break
        fi
        medida=$(($char_count - $j))
        if [[ "$medida" -eq "$columns" ]]; then
            #echo -e "$mul3 - $j"
            mul3=$(($mul3 - $j))
            printf_result="${NC}${GREEN}█ %-${mul}s | %-${mul2}s | % ${mul3}s █${NC}\n"
            RESULT=$(printf "$printf_result" "$id" "$cli" "$deu")
            #echo -e "$RESULT"
            char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
            #echo -e "fchar_count $char_count"
            break
        fi 
    done
    printf_result="${NC}${GREEN}█ %-${mul}s | %-${mul2}s | % ${mul3}s █${NC}\n"
    RESULT=$(printf "$printf_result" "$id" "$cli" "$deu")
    echo -e "$RESULT"
    char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
    #echo -e "fchar_count $char_count"
done
printf "${GREEN}└%s┘\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
echo -en "┃
└>>> "${blanco}
# Restaurar los colores predeterminados
printf '%b' '\033[0m'
#### caja principal fin ####

# opción de selección
read -r TOOL
cd ${HOME}/Busca-Palabras/opc/
if [[ $TOOL == 0 || $TOOL == 00 ]]; then
    echo -e ""
    pkill -f acceso_local_remoto.sh || true
    kill=$(ps aux | grep 'acceso_local_remoto.sh' | sed -n "1p" | awk '{print $2}')
    kill ${kill} >/dev/null 2>&1
    exit
elif [[ $TOOL == 1 || $TOOL == 01 ]]; then
    python Busca_Palabras.py
elif [[ $TOOL == 2 || $TOOL == 02 ]]; then
    bash deshabiltar_habiltar_apps_adb_v3.sh
elif [[ $TOOL == 3 || $TOOL == 03 ]]; then
    bash Busca-Correos.sh
elif [[ $TOOL == 4 || $TOOL == 04 ]]; then
    bash Contar-Palabras.sh
elif [[ $TOOL == 5 || $TOOL == 05 ]]; then
    python scan_port_open.py
elif [[ $TOOL == 6 || $TOOL == 06 ]]; then
    bash Busca-Visualiza.sh
elif [[ $TOOL == 7 || $TOOL == 07 ]]; then
    bash acceso_local_remoto.sh
    #Matar el script http.server 8024 en segundo plano
    kill=$(ps aux | grep 'http.server 8024' | sed -n "1p" | awk '{print $2}')
    kill ${kill} >/dev/null 2>&1
    pkill -f acceso_local_remoto.sh || true
elif [[ $TOOL == 8 || $TOOL == 08 ]]; then
    bash ssh_remote.sh
elif [[ $TOOL == 9 || $TOOL == 09 ]]; then
    bash team-droid.sh
elif [[ $TOOL == 10 || $TOOL == 10 ]]; then
    bash games_clasic.sh
elif [[ $TOOL == 11 || $TOOL == 11 ]]; then
    bash descaragar_ubuntu_ollama.sh
elif [[ $TOOL == 12 || $TOOL == 12 ]]; then
    bash Adivinado-21.sh
elif [[ $TOOL == 13 || $TOOL == 13 ]]; then
    bash Actualizar-Busca-Palabras.sh
elif [[ $TOOL == sw || $TOOL == sw ]]; then
    bash soundwire.sh
elif [[ $TOOL == hack || $TOOL == phishing ]]; then
    bash hack.sh
elif [[ $TOOL == tcl || $TOOL == tcl ]]; then
    bash KeyBoard.sh
elif [[ $TOOL == fecha || $TOOL == date ]]; then
    bash fecha.sh
elif [[ $TOOL == gd || $TOOL == gdrive ]]; then
    bash gdrive.sh
else
    echo -e "${rojo}
+---------------------+
# ${blanco}!OPCION INCORRECTA! ${rojo}#
+---------------------+
    "${blanco}
    sleep 1
    cd ..
    source ${PWD}/Menu-Busca-Palabras.sh
    rm -r ${HOME}/Install-Busca-Palabras.sh >/dev/null 2>&1
fi
echo -e ""
