#!/bin/bash
# Mapa explícito de dependencias plugin -> host (o grupos de plugins para un host)
# Ahora mapeamos el PAQUETE DEL PLUGIN directamente al PAQUETE DEL HOST.
# Esta estructura soporta N plugins -> 1 host de forma natural.

declare -gA PLUGIN_MAP

# Registro: PLUGIN_MAP["paquete.del.plugin"]="paquete.host.apk"

# --- PYDROID ---
PLUGIN_MAP["ru.iiec.pydroidpermissionsplugin"]="ru.iiec.pydroid3"
# Añade más plugins de pydroid así:
# PLUGIN_MAP["ru.iiec.pydroidpermissionsplugin"]="ru.iiec.pydroid3"
PLUGIN_MAP["ru.iiec.pydroid3.quickinstallrepo"]="ru.iiec.pydroid3"

# --- TASKER ---
PLUGIN_MAP["com.joaomgcd.autoinput"]="net.dinglisch.android.taskerm"
PLUGIN_MAP["com.joaomgcd.autonotification"]="net.dinglisch.android.taskerm"
PLUGIN_MAP["com.joaomgcd.autotools"]="net.dinglisch.android.taskerm"
PLUGIN_MAP["com.intangibleobject.securesettings.plugin"]="net.dinglisch.android.taskerm"

# --- YOUTUBE ---
PLUGIN_MAP["app.revanced.android.gms"]="anddea.youtube"

# --- Para añadir nuevos ---
# Simplemente añade la línea:
# PLUGIN_MAP["tu.paquete.plugin"]="paquete.host.principal"
