#!/usr/bin/env bash
set -euo pipefail

# ══════════════════════════════════════════════════════
# Instalador multifuncional con recuadro único y bloqueo total del teclado
# Soporta: pip, pkg, apt, apt-get
# Oculta el cursor y lo restaura al finalizar o con Ctrl+C / Ctrl+Z
# ══════════════════════════════════════════════════════

STTY_STATE=""
bloquear_teclado() {
  STTY_STATE="$(stty -g 2>/dev/null || true)"
  stty -icanon -echo min 0 time 0 2>/dev/null || true
}

restaurar_teclado() {
  [ -n "${STTY_STATE:-}" ] && stty "$STTY_STATE" 2>/dev/null || true
  printf '\033[?25h'
}

ocultar_cursor() {
  printf '\033[?25l'
}

trap restaurar_teclado EXIT INT TERM TSTP
bloquear_teclado
ocultar_cursor

python3 - <<'PY'
# -*- coding: utf-8 -*-
import sys, shutil, subprocess, signal, time, re, unicodedata, os, pty, select, threading

raw_packages = [
    "pip: opencv-python colorama requests",
    "pkg:git wget",
    "apt:curl",
    "apt-get:expect"
]

def expand_packages(raw_list):
    result = []
    for entry in raw_list:
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            tipo, pkgs = entry.split(":", 1)
            tipo = tipo.strip()
            for pkg in pkgs.split():
                result.append((tipo, pkg.strip()))
        else:
            for pkg in entry.split():
                result.append(("pip", pkg.strip()))
    return result

packages = expand_packages(raw_packages)

ANSI_RE = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]|\x1b\[[0-9;?]*[a-zA-Z]')
def clean_raw(s: str) -> str:
    if not s:
        return ""
    s = ANSI_RE.sub('', s)
    s = s.replace('\t', '    ').replace('\r', '').replace('\b', '')
    s = ''.join(ch for ch in s if (ch == '\n' or (ord(ch) >= 32 and ord(ch) != 127)))
    return s.rstrip("\n")

try:
    from wcwidth import wcwidth
except Exception:
    def wcwidth(ch):
        if unicodedata.combining(ch):
            return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F', 'W') else 1

def visible_len(s: str) -> int:
    return sum(max(0, wcwidth(c)) for c in s)

BORDER = "\033[1;35m"
RESET = "\033[0m"
TITLE_COLOR = "\033[1;34m"
PKG_COLOR = "\033[1;32m"
OK_COLOR = "\033[1;32m"
ERR_COLOR = "\033[1;31m"
MAX_VISIBLE = 15
PADDING = 2

def term_size():
    return shutil.get_terminal_size((80, 24))

def draw_panel(lines, title="", messages_above=None, last_height=[0], _last_draw=[None]):
    if messages_above is None:
        messages_above = []
    term_w, _ = term_size()
    content_width = max(10, term_w - 2 - 2 * PADDING)
    horizontal = "─" * (content_width + 2 * PADDING)
    top = f"{BORDER}╭{horizontal}╮{RESET}"
    bottom = f"{BORDER}╰{horizontal}╯{RESET}"

    def wrap_and_clean(all_lines):
        wrapped = []
        for L in all_lines:
            Lc = clean_raw(L)
            cur, cur_len = "", 0
            for ch in Lc:
                w = max(1, wcwidth(ch))
                if cur_len + w > content_width:
                    wrapped.append(cur)
                    cur, cur_len = ch, w
                else:
                    cur += ch
                    cur_len += w
            if cur:
                wrapped.append(cur)
        return wrapped

    wrapped = wrap_and_clean(lines)
    visible = wrapped[-MAX_VISIBLE:]
    frame_key = "\n".join(messages_above + [title] + visible)
    if _last_draw[0] == frame_key:
        return
    _last_draw[0] = frame_key

    total_prev = last_height[0]
    if total_prev > 0:
        sys.stdout.write("\033[F" * total_prev)
        sys.stdout.flush()

    for m in messages_above:
        sys.stdout.write(clean_raw(m) + "\n")
    sys.stdout.write(top + "\n")

    if title:
        t_clean = clean_raw(title)
        tv = visible_len(t_clean)
        title_padded = title + " " * (content_width - tv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{title_padded}{' ' * PADDING}{BORDER}│{RESET}\n")
    else:
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    empty = MAX_VISIBLE - len(visible)
    for _ in range(empty):
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    for L in visible:
        Lc = clean_raw(L)
        lv = visible_len(Lc)
        if lv < content_width:
            Lc += " " * (content_width - lv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{Lc}{' ' * PADDING}{BORDER}│{RESET}\n")

    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()
    last_height[0] = len(messages_above) + 2 + MAX_VISIBLE + 1

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
def spinner_thread(stop_event, spinner_state):
    i = 0
    while not stop_event.is_set():
        spinner_state[0] = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
        i += 1
        time.sleep(0.08)

def run_install(tipo, pkg, messages_above, last_height):
    if tipo == "pip":
        cmd = ["pip", "install", "--progress-bar=on", pkg]
    elif tipo == "pkg":
        cmd = ["pkg", "install", "-y", pkg]
    elif tipo == "apt":
        cmd = ["apt", "install", "-y", pkg]
    elif tipo == "apt-get":
        cmd = ["apt-get", "install", "-y", pkg]
    else:
        messages_above.append(f"{ERR_COLOR}❌ Tipo desconocido: {tipo}{RESET}")
        draw_panel([], title=f"{pkg} no ejecutado", messages_above=messages_above, last_height=last_height)
        return 1

    spinner_state = ["⠋"]
    stop_event = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(stop_event, spinner_state))
    t.daemon = True
    t.start()

    pkg_lines = []
    spinner_line = None        # "  Installing build dependencies ..."
    spinner_active = False
    progress_idx = None        # índice absoluto dentro de pkg_lines donde está la barra de progreso
    progress_active = False

    try:
        master_fd, slave_fd = pty.openpty()
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        proc = subprocess.Popen(cmd, stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, close_fds=True, env=env)
        os.close(slave_fd)

        SPINNER_INSIDE_RE = re.compile(
            r'^(?P<prefix>\s*.*?(?:Installing build dependencies|Building wheel|Preparing metadata).*?\.\.\.)'
            r'(?P<spinner>[\s\-\|/\\●◐◓◑◒◔◕◖◗◡◑\u2800-\u28FF\u25A0-\u25FF]*)?'
            r'(?P<done>\bdone\b.*)?$',
            flags=re.IGNORECASE
        )

        # barra de progreso y helpers
        PROGRESS_PATTERN = re.compile(r"[━═─]+╺[━═─]+|[0-9]+(?:\.[0-9]+)?\/[0-9]+(?:\.[0-9]+)?\s*MB", re.IGNORECASE)
        CURSOR_HIDE_RE = re.compile(r'\x1b\[\?25[lh]')  # show/hide cursor escapes
        PIP_SPINNER_RE = re.compile(r'[\s\-\|/\\●◐◓◑◒◔◕◖◗◡◑\u2800-\u28FF\u25A0-\u25FF]+$')

        current_line = ""
        while True:
            TITLE_LINE = f"{spinner_state[0]} {TITLE_COLOR}📦 Instalando {tipo}: {PKG_COLOR}{pkg}{TITLE_COLOR}...{RESET}"
            r, _, _ = select.select([master_fd], [], [], 0.05)
            if r:
                try:
                    chunk = os.read(master_fd, 512)
                except OSError:
                    break
                if not chunk:
                    break

                text = chunk.decode(errors="ignore")
                parts = re.split('(\r|\n)', text)

                for part in parts:
                    if part == '\r':
                        # pip sobrescribe con carriage return → reiniciar parcial
                        current_line = ""
                        continue

                    if part == '\n':
                        raw_line = CURSOR_HIDE_RE.sub('', current_line)  # quitar secuencias cursor
                        current_line = ""

                        if raw_line.strip():
                            # 1) si es la linea tipo "Installing build dependencies ... - \ /"
                            m = SPINNER_INSIDE_RE.match(raw_line)
                            if m:
                                prefix = m.group('prefix') or ""
                                base = prefix.rstrip()
                                spinner_line = base
                                spinner_active = True
                                progress_active = False
                                # Asegurar que la base esté en pkg_lines (no se borra hasta que deba)
                                if not pkg_lines or pkg_lines[-1] != base:
                                    pkg_lines.append(base)
                                continue

                            # 2) limpiar spinner pip colgado al final de la línea
                            cleaned = PIP_SPINNER_RE.sub("", raw_line).rstrip()

                            # 3) Detectar líneas importantes que deben conservarse (Downloading, Using cached, Collecting, Extracting)
                            if re.search(r"\b(Downloading|Collecting|Extracting|Using cached)\b", cleaned, re.IGNORECASE):
                                dl_line = cleaned.rstrip()
                                # Insertar encima del slot de progreso si existe, si no, añadir y crear placeholder
                                if progress_idx is not None and 0 <= progress_idx <= len(pkg_lines):
                                    insert_at = max(0, progress_idx)
                                    pkg_lines.insert(insert_at, dl_line)
                                    # si insertamos antes del progress slot, desplazamos progress_idx
                                    if insert_at <= progress_idx:
                                        progress_idx += 1
                                else:
                                    pkg_lines.append(dl_line)
                                    pkg_lines.append("")  # placeholder para la barra de progreso
                                    progress_idx = len(pkg_lines) - 1
                                spinner_active = False
                                progress_active = False
                                continue

                            # 4) barra de progreso completa en una línea
                            if PROGRESS_PATTERN.search(cleaned):
                                progress_line = cleaned.rstrip()
                                progress_active = True
                                spinner_active = False
                                # asignar o crear slot único para progreso, sin duplicarlo
                                if progress_idx is None:
                                    # si hay líneas previas, usar la última como slot; si no, crear uno
                                    if pkg_lines:
                                        pkg_lines.append(progress_line)
                                        progress_idx = len(pkg_lines) - 1
                                    else:
                                        pkg_lines.append(progress_line)
                                        progress_idx = 0
                                else:
                                    pkg_lines[progress_idx] = progress_line
                                continue

                            # 5) línea normal (mantener indentación/espacios iniciales)
                            line_to_store = cleaned.rstrip()
                            spinner_active = False
                            progress_active = False
                            progress_idx = None
                            if not pkg_lines or pkg_lines[-1] != line_to_store:
                                pkg_lines.append(line_to_store)
                        continue

                    # parte de línea (no terminó en \n)
                    current_line += part
                    raw_peek = CURSOR_HIDE_RE.sub('', current_line)
                    peek_no_pip_spinner = PIP_SPINNER_RE.sub("", raw_peek)

                    # a) detectar inside-spinner en parcial
                    mpeek = SPINNER_INSIDE_RE.match(raw_peek)
                    if mpeek:
                        pref = mpeek.group('prefix') or ""
                        spinner_line = pref.rstrip()
                        spinner_active = True
                        progress_active = False
                        # aseguramos que base exista (pero sin duplicar)
                        if not pkg_lines or pkg_lines[-1] != spinner_line:
                            pkg_lines.append(spinner_line)
                        continue

                    # b) parciales de Downloading/Collecting/Using cached -> crear/actualizar slot arriba del progreso
                    if re.search(r"\b(Downloading|Collecting|Extracting|Using cached)\b", peek_no_pip_spinner, re.IGNORECASE):
                        partial_line = clean_raw(peek_no_pip_spinner).rstrip()
                        if progress_idx is not None and 0 <= progress_idx <= len(pkg_lines):
                            # insertar justo antes del slot de progreso si no coincide exactamente
                            insert_at = max(0, progress_idx)
                            if not (pkg_lines and pkg_lines[insert_at] == partial_line):
                                pkg_lines.insert(insert_at, partial_line)
                                progress_idx += 1
                        else:
                            if not pkg_lines or pkg_lines[-1] != partial_line:
                                pkg_lines.append(partial_line)
                            if progress_idx is None:
                                pkg_lines.append("")
                                progress_idx = len(pkg_lines) - 1
                        spinner_active = False
                        progress_active = False
                        continue

                    # c) parcial de progreso (por ejemplo la barra y números que se actualizan rápido)
                    if PROGRESS_PATTERN.search(peek_no_pip_spinner):
                        progress_line = clean_raw(peek_no_pip_spinner).rstrip()
                        progress_active = True
                        spinner_active = False
                        if progress_idx is None:
                            # si no hay slot, crear al final (no duplicar)
                            if pkg_lines and pkg_lines[-1].strip() == progress_line:
                                progress_idx = len(pkg_lines) - 1
                            else:
                                pkg_lines.append(progress_line)
                                progress_idx = len(pkg_lines) - 1
                        else:
                            pkg_lines[progress_idx] = progress_line
                        continue

                    # d) parcial normal: actualizar última línea en construcción (mantener indentación)
                    cleaned_peek = clean_raw(raw_peek)
                    if cleaned_peek.strip():
                        live = cleaned_peek.rstrip()
                        if pkg_lines:
                            pkg_lines[-1] = live
                        else:
                            pkg_lines.append(live)

                # --- preparar display_lines respetando el slot absoluto progress_idx ---
                total = len(pkg_lines)
                start_idx = max(0, total - MAX_VISIBLE)
                display_lines = pkg_lines[start_idx:total]

                # si el progress slot está fuera del rango mostrado, traer su contenido a la vista
                if progress_active and progress_idx is not None:
                    rel = progress_idx - start_idx
                    inline = pkg_lines[progress_idx]
                    if 0 <= rel < len(display_lines):
                        display_lines[rel] = inline
                    else:
                        # si no cabe en la ventana actual, reemplazar la última línea visible por la barra de progreso
                        if display_lines:
                            display_lines[-1] = inline
                        else:
                            display_lines = [inline]

                elif spinner_active and spinner_line:
                    m = re.match(r'^(\s*)(.*)$', spinner_line)
                    if m:
                        leading, text_base = m.groups()
                    else:
                        leading, text_base = "", spinner_line
                    inline = f"{leading}{text_base} {spinner_state[0]}"
                    # reemplazar la última visible con el spinner inline
                    if display_lines:
                        display_lines[-1] = inline
                    else:
                        display_lines = [inline]

                draw_panel(display_lines, title=TITLE_LINE, messages_above=messages_above, last_height=last_height)

            if proc.poll() is not None:
                break

        proc.wait()

        # cerrar spinner si quedó colgado
        if spinner_active and spinner_line:
            final = spinner_line
            if not any(re.search(r'\bdone\b', l, re.IGNORECASE) for l in pkg_lines):
                pkg_lines.append(final + " done")

        display_lines = pkg_lines[-MAX_VISIBLE:]
        final_title = f"✔ {PKG_COLOR}{pkg}{RESET}"
        draw_panel(display_lines, title=final_title, messages_above=messages_above, last_height=last_height)

        return proc.returncode

    finally:
        stop_event.set()
        t.join()
        try:
            os.close(master_fd)
        except Exception:
            pass

def install_all(packages):
    messages_above, last_height = [], [0]
    draw_panel([], title="Iniciando instalación múltiple...", messages_above=messages_above, last_height=last_height)
    for tipo, pkg in packages:
        code = run_install(tipo, pkg, messages_above, last_height)
        if code == 0:
            messages_above.append(f"{OK_COLOR}☑️  {pkg} instalado correctamente ({tipo}).{RESET}")
        else:
            messages_above.append(f"{ERR_COLOR}❌ Error instalando {pkg} con {tipo} (código {code}).{RESET}")
        draw_panel([], title=f"{pkg} completado.", messages_above=messages_above, last_height=last_height)
        time.sleep(0.4)
    messages_above.append(f"{OK_COLOR}✅ Instalación de todos los paquetes completada.{RESET}")
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()
    print("\n".join(messages_above))

try:
    install_all(packages)
except KeyboardInterrupt:
    print("\n\033[1;33m⏹ Instalación cancelada por el usuario.\033[0m")
    sys.exit(130)
PY

restaurar_teclado