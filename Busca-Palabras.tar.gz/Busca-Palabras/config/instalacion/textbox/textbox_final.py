#!/usr/bin/env python3
import os
import sys
import re
from prompt_toolkit import Application
from prompt_toolkit.application.current import get_app
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl

# ----------------- Estado -----------------
text = ""    # texto completo
cursor = 0   # índice en text

ESC = "\033"

def ocultar_cursor():
    sys.stdout.write(f"{ESC}[?25l"); sys.stdout.flush()

def mostrar_cursor():
    sys.stdout.write(f"{ESC}[?25h"); sys.stdout.flush()

# ----------------- Utilidades de terminal -----------------
def terminal_width():
    try:
        return get_app().output.get_size().columns
    except Exception:
        try:
            return os.get_terminal_size().columns
        except OSError:
            return 80

def tokens_with_spans(line):
    return [(m.group(0), m.start()) for m in re.finditer(r'\S+\s*', line)]

def wrap_segments_with_positions(text, width, first_prefix_len=2, other_prefix_len=2, right_margin=1):
    if width < 1:
        width = 1
    segments = []
    logical_lines = text.split('\n')
    global_pos = 0

    for li, line in enumerate(logical_lines):
        tokens = list(tokens_with_spans(line))
        if not tokens:
            segments.append({'text': '', 'start': global_pos, 'length': 0})
        else:
            content_width = max(1, width - 2)
            first_avail = max(1, content_width - first_prefix_len - right_margin)
            idx = 0
            cur_tokens = []
            cur_len = 0
            while idx < len(tokens):
                tok_text, tok_rel = tokens[idx]
                tok_len = len(tok_text)
                if cur_len + tok_len <= first_avail or cur_len == 0:
                    cur_tokens.append((tok_text, tok_rel))
                    cur_len += tok_len
                    idx += 1
                else:
                    break
            if cur_tokens:
                seg_text = ''.join(t[0] for t in cur_tokens)
                seg_start = global_pos + cur_tokens[0][1]
                segments.append({'text': seg_text, 'start': seg_start, 'length': len(seg_text)})

            other_avail = max(1, content_width - other_prefix_len - right_margin)
            while idx < len(tokens):
                cur_tokens = []
                cur_len = 0
                while idx < len(tokens):
                    tok_text, tok_rel = tokens[idx]
                    tok_len = len(tok_text)
                    if cur_len + tok_len <= other_avail or cur_len == 0:
                        cur_tokens.append((tok_text, tok_rel))
                        cur_len += tok_len
                        idx += 1
                    else:
                        break
                seg_text = ''.join(t[0] for t in cur_tokens)
                seg_start = global_pos + cur_tokens[0][1]
                segments.append({'text': seg_text, 'start': seg_start, 'length': len(seg_text)})

        global_pos += len(line)
        if li < len(logical_lines) - 1:
            global_pos += 1

    return segments

def find_segment_for_index(segments, idx, text_len):
    if not segments:
        return (0, 0)
    if idx >= text_len:
        last = len(segments) - 1
        return (last, segments[last]['length'])
    for si, seg in enumerate(segments):
        s = seg['start']; e = s + seg['length']
        if s <= idx < e:
            return (si, idx - s)
        if idx < s:
            return (si, 0)
    last = len(segments) - 1
    return (last, segments[last]['length'])

def build_fragments():
    global text, cursor
    term_w = terminal_width()
    inner_w = max(20, term_w - 4)
    content_width = max(1, inner_w - 2)
    right_margin = 1

    segments = wrap_segments_with_positions(text, width=inner_w,
                                            first_prefix_len=2,
                                            other_prefix_len=2,
                                            right_margin=right_margin)
    seg_idx, seg_off = find_segment_for_index(segments, cursor, len(text))

    frags = []
    frags.append(('', "╭" + "─" * inner_w + "╮\n"))

    for i, seg in enumerate(segments):
        prefix = "> " if i == 0 else "  "
        avail = content_width - len(prefix) - right_margin
        seg_text = seg['text'][:avail].ljust(avail) + " " * right_margin

        frags.append(('', "│ "))
        frags.append(('', prefix))

        if i == seg_idx:
            left = seg_text[:seg_off]
            if seg_off < len(seg_text):
                cur_char = seg_text[seg_off]
                right = seg_text[seg_off+1:]
                frags.append(('', left))
                frags.append(('reverse', cur_char))
                frags.append(('', right))
            else:
                frags.append(('', left))
                frags.append(('reverse', ' '))
        else:
            frags.append(('', seg_text))
        frags.append(('', " │\n"))

    if not segments:
        empty = " " * content_width
        frags = [('', "╭" + "─" * inner_w + "╮\n"),
                 ('', "│ " + "> " + empty[2:] + " │\n"),
                 ('', "╰" + "─" * inner_w + "╯")]
        return frags

    frags.append(('', "╰" + "─" * inner_w + "╯"))
    return frags

# ----------------- Movimiento y edición -----------------
def insert_char(ch):
    global text, cursor
    text = text[:cursor] + ch + text[cursor:]
    cursor += len(ch)

def backspace():
    global text, cursor
    if cursor > 0:
        text = text[:cursor-1] + text[cursor:]
        cursor -= 1

def delete():
    global text, cursor
    if cursor < len(text):
        text = text[:cursor] + text[cursor+1:]

def move_left():
    global cursor
    if cursor > 0:
        cursor -= 1

def move_right():
    global cursor
    if cursor < len(text):
        cursor += 1

def move_up():
    global cursor
    inner_w = max(20, terminal_width() - 4)
    segs = wrap_segments_with_positions(text, width=inner_w)
    si, off = find_segment_for_index(segs, cursor, len(text))
    if si == 0: return
    prev = segs[si-1]
    cursor = prev['start'] + min(off, prev['length'])

def move_down():
    global cursor
    inner_w = max(20, terminal_width() - 4)
    segs = wrap_segments_with_positions(text, width=inner_w)
    si, off = find_segment_for_index(segs, cursor, len(text))
    if si >= len(segs)-1: return
    nxt = segs[si+1]
    cursor = nxt['start'] + min(off, nxt['length'])

# ----------------- prompt_toolkit setup -----------------
display = FormattedTextControl(lambda: build_fragments(), focusable=False, show_cursor=False)
window = Window(content=display, dont_extend_height=True)
layout = Layout(HSplit([window]))

kb = KeyBindings()

@kb.add('left')
def _(e): move_left()

@kb.add('right')
def _(e): move_right()

@kb.add('up')
def _(e): move_up()

@kb.add('down')
def _(e): move_down()

@kb.add('backspace')
def _(e): backspace()

@kb.add('delete')
def _(e): delete()

@kb.add('c-j')  # Ctrl+J = salto de línea
def _(e): insert_char('\n')

@kb.add('enter')  # Enter = mostrar texto y salir
def _(e): e.app.exit(result=text)

@kb.add('c-c')
@kb.add('c-z')
@kb.add('c-d')
def _(e): e.app.exit(result=text)

@kb.add('<any>')
def _(e):
    k = e.key_sequence[0].key
    if isinstance(k, str) and len(k) == 1 and k.isprintable():
        insert_char(k)

app = Application(layout=layout, key_bindings=kb, full_screen=False)

# ----------------- Main -----------------
if __name__ == "__main__":
    os.system("clear")
    ocultar_cursor()
    try:
        result = app.run()
    finally:
        mostrar_cursor()

    print("\nTexto final:\n---\n" + (result or "") + "\n---")
