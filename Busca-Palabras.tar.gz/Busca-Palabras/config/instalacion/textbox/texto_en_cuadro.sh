#!/usr/bin/env bash
set -u

# ----------------- Colores (ESC real) -----------------
ESC=$'\033'
amarillo="${ESC}[1;33m"
rojo="${ESC}[1;31m"
verde="${ESC}[1;32m"
azul="${ESC}[1;34m"
blanco="${ESC}[1;37m"
magenta="${ESC}[1;35m"
cian="${ESC}[1;36m"
reset="${ESC}[0m"

#######FUNCIONES_DE_JUSTICACION_TEXTO#######
source ~/Busca-Palabras/config/texto_ajust_just
#######FIN_FUNCIONES_DE_JUSTICACION_TEXTO#######

echo "" # Espacio hacia abajo inicial, (opcional)
NC="${reset}"; CYAN="${cian}"

# ----------------- Source seguro (si existe) -----------------
nounset_was_set=0
if (set -o | grep -q 'nounset.*on'); then
    nounset_was_set=1
    set +u
fi
[ -f "$HOME/Busca-Palabras/config/texto_ajust_just" ] && source "$HOME/Busca-Palabras/config/texto_ajust_just"
if [[ "$nounset_was_set" -eq 1 ]]; then set -u; fi

# ----------------- Helpers para cursor -----------------
restore_cursor() {
    if command -v tput >/dev/null 2>&1; then tput cnorm 2>/dev/null || true
    else printf "${ESC}[?25h" 2>/dev/null || true; fi
}
hide_cursor() {
    if command -v tput >/dev/null 2>&1; then tput civis 2>/dev/null || true
    else printf "${ESC}[?25l" 2>/dev/null || true; fi
}

# ----------------- limpieza y señales -----------------
detener_demo() {
    restore_cursor
    # printf "${reset}\r\n\r\n\r\n\r\n"
    printf "${reset}" # cuando presionas Enter genera unos espacios hacia abajo
    exit 0
}

ANIMATION_DONE=0

_on_interrupt() {
    if [[ "${ANIMATION_DONE:-0}" -eq 0 ]]; then
        printf "\n${rojo}⛔ Conexión finalizada por el usuario.${reset}\n"
        exit 130
    else
        printf "${reset}\r\n\r\n"
        detener_demo
    fi
}

_on_sigtstp() {
    if [[ "${ANIMATION_DONE:-0}" -eq 0 ]]; then
        printf "\n${amarillo}⚠️  Proceso suspendido (Ctrl+Z).${reset}\n"
        trap - SIGTSTP
        kill -s SIGTSTP "$$"
    else
        printf "${reset}\r\n\r\n"
        detener_demo
    fi
}

_on_sigcont() { hide_cursor; }

trap _on_interrupt SIGINT SIGTERM
trap _on_sigtstp SIGTSTP
trap _on_sigcont SIGCONT

# ----------------- Mensaje DEMO -----------------
usr=$(whoami)
now=$(date '+%Y-%m-%d %H:%M:%S')
demo_pid=$$

mensaje_box="${cian}PANEL INFORMATIVO - DEMO${reset}
${magenta}----------------------------------------${reset}
${amarillo}Usuario${reset} : ${verde}$usr${reset}
${amarillo}Fecha${reset}  : ${verde}$now${reset}
${amarillo}PID${reset}    : ${verde}$demo_pid${reset}

${cian}Estado${reset}   : ${verde}Sistema operativo listo${reset}
${cian}Servicio${reset} : ${verde}Demo display (sin ngrok)${reset}

${cian}Sugerencia${reset} : ${blanco}Presiona ENTER para cerrar este panel.${reset}

${magenta}----------------------------------------${reset}
${magenta}Atajo: Ctrl+C para salir, Ctrl+Z para suspender.${reset}
"

if type -t justify_text >/dev/null 2>&1; then
    if type -t print_color >/dev/null 2>&1; then
        extra="$(print_color cyan "$(justify_text "Consejo: usa este panel como ejemplo de animación en terminal.")")"
    else
        extra="$(justify_text "Consejo: usa este panel como ejemplo de animación en terminal.")"
    fi
    MENSAJE_FINAL="${mensaje_box}"$'\n\n'"${extra}"
else
    MENSAJE_FINAL="$mensaje_box"
fi
export MENSAJE_BOX="$MENSAJE_FINAL"

# ----------------- Ocultar cursor antes de animar -----------------
hide_cursor

# Guardar stty actual y configurar tty para que no haga echo y no sea canonical
if [ -t 0 ]; then
    old_stty="$(stty -g)"
    trap 'stty "$old_stty" 2>/dev/null || true' EXIT
    stty -echo -icanon min 0 time 0
fi

# Mientras Python corre, el shell ignora SIGINT/SIGTSTP para que sólo Python las reciba.
trap '' SIGINT SIGTSTP


# ----------------- Ejecutar animación (Python unbuffered) -----------------
python3 -u <<'PY'
import os, textwrap, shutil, re, sys, time, signal, unicodedata

# ---------- wcwidth (fallback) ----------
try:
    from wcwidth import wcwidth
except Exception:
    def wcwidth(ch):
        if ch == '\t': return 4
        if unicodedata.combining(ch): return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F','W') else 1

ansi_re = re.compile(r'\x1b\[[0-9;]*m')

def strip_ansi(s): return ansi_re.sub('', s)
def visible_len(s): return sum(max(0, wcwidth(c)) for c in strip_ansi(s))

def split_ansi_tokens(s):
    return [m.group(0) for m in re.finditer(r'\x1b\[[0-9;]*m|.', s, flags=re.DOTALL)]

def wrap_with_ansi(text, width):
    out = []
    words = re.split(r'(\s+)', text)
    line = ""
    for w in words:
        if visible_len(line + w) > width and line:
            out.append(line.rstrip()); line = ""
        line += w
    if line != "" or line.strip():
        out.append(line.rstrip())
    return out

def truncate_tokens_to_width(tokens, width):
    out = []; vis = 0
    for tok in tokens:
        if ansi_re.match(tok):
            out.append(tok)
        else:
            for ch in tok:
                w = wcwidth(ch)
                if w < 0: continue
                if vis + w > width:
                    out.append("\033[0m"); return out
                out.append(ch); vis += w
    out.append("\033[0m"); return out

def build_line_text(tokens, content_width):
    text = "".join(tokens); vis = visible_len(text)
    if vis > content_width:
        out = []; vis2 = 0
        for t in tokens:
            if ansi_re.match(t):
                out.append(t)
            else:
                for ch in t:
                    w = wcwidth(ch)
                    if w < 0: continue
                    if vis2 + w > content_width: break
                    out.append(ch); vis2 += w
                if vis2 >= content_width: break
        out.append("\033[0m"); return "".join(out)
    return text + (" " * (content_width - vis))

# ----------------- Función principal corregida -----------------
def animate_panel(lines, padding=2, char_delay=0.008, line_delay=0.02):
    # traps simples para terminar correctamente
    signal.signal(signal.SIGINT, lambda s,f: sys.exit(130))
    signal.signal(signal.SIGTSTP, lambda s,f: sys.exit(146))

    try:
        term_w, term_h = shutil.get_terminal_size()
    except Exception:
        term_w, term_h = (80, 24)

    content_width = max(5, term_w - 2 - (2 * padding))

    # preparar las líneas envueltas y tokenizadas
    wrapped_lines = []
    for L in lines:
        wrapped_lines += wrap_with_ansi(L, content_width)
    token_lines = [truncate_tokens_to_width(split_ansi_tokens(r), content_width) for r in wrapped_lines]

    max_visible = max(1, min(5, term_h - 2)) # aquí puedes ajustar el primer o segundo valor para ajustar el ancho vertical del recuadro.
    border_color = "\033[1;35m"; reset = "\033[0m"
    horizontal = "─" * (content_width + (2 * padding))
    top = f"{border_color}╭{horizontal}╮{reset}"
    bottom = f"{border_color}╰{horizontal}╯{reset}"

    # --- Dibujar marco inicial (una sola vez) ---
    sys.stdout.write(top + "\n")
    for _ in range(max_visible):
        sys.stdout.write(f"{border_color}│{reset}{' '*(content_width + 2*padding)}{border_color}│{reset}\n")
    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()

    box_height = 1 + max_visible + 1  # top + interior + bottom

    visible_buffer = []
    for tokens in token_lines:
        visible_buffer.append(tokens)
        if len(visible_buffer) > max_visible:
            visible_buffer.pop(0)

        # preparar las líneas interiores (sin la última, que animaremos)
        interior_lines = []
        empty_slots = max(0, max_visible - len(visible_buffer))
        for _ in range(empty_slots):
            interior_lines.append(" " * (content_width + 2 * padding))
        for toklist in visible_buffer[:-1]:
            interior_lines.append(" " * padding + build_line_text(toklist, content_width) + " " * padding)

        last_toklist = visible_buffer[-1]

        # SUBIR desde el cursor (que está después del bottom) hasta la PRIMERA línea interior
        sys.stdout.write(f"\033[{box_height-1}A")
        sys.stdout.flush()

        # AHORA ESTAMOS en la primera línea interior. 
        # Reescribimos *todas* las líneas interiores como LÍNEAS completas,
        # incluyendo ambos bordes. Esto evita borrar o desalinear la columna derecha.
        for i in range(max_visible - 1):
            if i < len(interior_lines):
                content = interior_lines[i]
            else:
                content = " " * (content_width + 2 * padding)
            # Sobreescribimos la línea completa incluyendo ambos bordes.
            # Usamos padding/truncado exacto: content tiene longitud EXACTA (visualmente)
            sys.stdout.write(f"\r{border_color}│{reset}{content:<{content_width + 2*padding}}{border_color}│{reset}\n")
            sys.stdout.flush()

        # Ahora nos posicionamos en la última línea interior: la limpiamos y animamos.
        # (No usamos \033[2K global; solo hacemos '\r' y sobreescribimos el contenido)
        # Clear current line area by writing left border + spaces for content
        sys.stdout.write(f"\r{border_color}│{reset}" + " " * (content_width + 2 * padding) + f"{border_color}│{reset}\n")
        # mover cursor una línea arriba para posicionar al inicio de la última interior
        sys.stdout.write("\033[1A")
        sys.stdout.flush()

        # escribir borde izquierdo + padding (posición para animar)
        sys.stdout.write(f"\r{border_color}│{reset}" + " " * padding)
        sys.stdout.flush()

        # animar la última línea carácter a carácter respetando wcwidth
        vis = 0
        for t in last_toklist:
            if ansi_re.match(t):
                sys.stdout.write(t); sys.stdout.flush()
            else:
                for ch in t:
                    w = wcwidth(ch)
                    if w < 0: continue
                    if vis + w > content_width:
                        break
                    sys.stdout.write(ch); sys.stdout.flush()
                    vis += w
                    time.sleep(char_delay)

        # rellenar lo que falte y cerrar con padding + borde derecho
        remaining = max(0, content_width - vis)
        sys.stdout.write(" " * remaining)
        sys.stdout.write(" " * padding + f"{border_color}│{reset}\n")
        sys.stdout.flush()

        # reescribir bottom (asegurar que sigue intacto)
        sys.stdout.write(f"\r\033[2K{bottom}\n")
        sys.stdout.flush()

        time.sleep(line_delay)

    # al terminar, reset y salto de línea para que el prompt quede en su sitio
    sys.stdout.write("\033[0m\n")
    sys.stdout.flush()

# ---------- Preparación de párrafos (igual que antes) ----------
msg = os.environ.get("MENSAJE_BOX", "")
if not msg:
    msg = "No hay mensaje disponible."

text = textwrap.dedent(msg).strip('\n')
raw_lines = text.splitlines()

def is_separator_line(s):
    t = strip_ansi(s).strip()
    return len(t) > 3 and all(ch in "-─━═_" for ch in t)

paragraphs = []
buf = []
for L in raw_lines:
    if L.strip() == "":
        if buf:
            paragraphs.append(" ".join(s.strip() for s in buf))
            buf = []
        paragraphs.append("")
    elif is_separator_line(L):
        if buf:
            paragraphs.append(" ".join(s.strip() for s in buf))
            buf = []
        paragraphs.append(L)
    else:
        buf.append(L)
if buf:
    paragraphs.append(" ".join(s.strip() for s in buf))

# ejecutar animación: puedes ajustar la velocidad de la animación de escritura en estos parámetros: char_delay=0.05, line_delay=0.1
animate_panel(paragraphs, padding=2, char_delay=0.05, line_delay=0.1)
PY

# Recuperar código de salida
py_code=$?

# Restaurar traps del shell y marcar animación completada
ANIMATION_DONE=1
trap _on_interrupt SIGINT SIGTERM
trap _on_sigtstp SIGTSTP
trap _on_sigcont SIGCONT

# ----------------- Consumir cualquier entrada tecleada DURANTE la animación --
# (modo non-canonical aún activo; consumimos buffer)
if [ -t 0 ]; then
    while IFS= read -r -t 0.01 -n 4096 _ 2>/dev/null; do :; done < /dev/tty
    if [[ -n "${old_stty:-}" ]]; then stty "$old_stty" 2>/dev/null || true; fi
fi

# Si la animación fue interrumpida, restaurar cursor y actuar acorde
if [[ $py_code -eq 130 ]]; then
    restore_cursor
    printf "${reset}\r\n\r\n"
    detener_demo
elif [[ $py_code -eq 146 ]]; then
    restore_cursor
    printf "${reset}\r\n\r\n"
    trap - SIGTSTP
    kill -s SIGTSTP "$$"
fi

# ----------------- Ahora esperamos ENTER válido (cursor oculto hasta ENTER) --
# El cursor ya está colocado debajo del recuadro (por el "\r\n" que imprimió Python),
# así que cualquier texto que escribas aparecerá correctamente abajo.
read -r
detener_demo
