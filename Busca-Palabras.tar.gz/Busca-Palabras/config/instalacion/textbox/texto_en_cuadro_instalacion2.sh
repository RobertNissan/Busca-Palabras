#!/usr/bin/env bash
set -euo pipefail

# ══════════════════════════════════════════════════════
# Instalador multifuncional con recuadro único y progreso pip en tiempo real
# Soporta: pip, pkg, apt, apt-get
# ══════════════════════════════════════════════════════

STTY_STATE=""
bloquear_teclado() {
  STTY_STATE="$(stty -g 2>/dev/null || true)"
  stty -icanon -echo min 0 time 0 2>/dev/null || true
}
restaurar_teclado() {
  [ -n "${STTY_STATE:-}" ] && stty "$STTY_STATE" 2>/dev/null || true
}
trap restaurar_teclado EXIT INT TERM
bloquear_teclado

python3 - <<'PY'
import sys, shutil, subprocess, time, re, unicodedata, pty, select, os

# ══════════════════════════════════════════════════════
# Configuración
# ══════════════════════════════════════════════════════
raw_packages = [
    "pip:opencv-python",
    "pip:requests colorama",
    "pkg:git wget",
    "apt:curl",
    "apt-get:expect"
]

# ────────────── Funciones auxiliares ──────────────
def expand_packages(raw_list):
    result = []
    for entry in raw_list:
        if ":" in entry:
            tipo, pkgs = entry.split(":", 1)
            for pkg in pkgs.split():
                result.append((tipo.strip(), pkg.strip()))
        else:
            for pkg in entry.split():
                result.append(("pip", pkg.strip()))
    return result

packages = expand_packages(raw_packages)

try:
    from wcwidth import wcwidth
except ImportError:
    def wcwidth(ch):
        if ch == '\t': return 4
        if unicodedata.combining(ch): return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F','W') else 1

ansi_re = re.compile(r'\x1b\[[0-9;]*m')
def strip_ansi(s): return ansi_re.sub('', s)
def visible_len(s): return sum(max(0, wcwidth(c)) for c in strip_ansi(s))

def wrap_line(L, width):
    tokens = re.findall(r'\x1b\[[0-9;]*m|.', L)
    lines, current, vis_count = [], [], 0
    for t in tokens:
        if ansi_re.match(t):
            current.append(t)
        else:
            w = wcwidth(t)
            if vis_count + w > width:
                lines.append(''.join(current))
                current, vis_count = [], 0
            current.append(t)
            vis_count += w
    if current: lines.append(''.join(current))
    return lines

def build_line(L, content_width):
    vis = visible_len(L)
    if vis < content_width:
        L += " " * (content_width - vis)
    if not L.endswith("\033[0m"):
        L += "\033[0m"
    return L

# ══════════════════════════════════════════════════════
# Recuadro visual
# ══════════════════════════════════════════════════════
def draw_panel(lines, title="", padding=2, last_height=[0], messages_above=[]):
    term_w, _ = shutil.get_terminal_size((80,24))
    content_width = max(5, term_w - 2 - 2*padding)
    border_color, reset = "\033[1;35m", "\033[0m"
    horizontal = "─" * (content_width + 2*padding)
    top = f"{border_color}╭{horizontal}╮{reset}"
    bottom = f"{border_color}╰{horizontal}╯{reset}"
    max_visible = 15

    wrapped = []
    for L in lines:
        wrapped.extend(wrap_line(L, content_width))
    visible = wrapped[-max_visible:]

    # Borrar el recuadro anterior
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()

    # Mostrar mensajes previos
    for msg in messages_above:
        print(msg)
    msg_height = len(messages_above)

    # Recuadro principal
    sys.stdout.write(top + "\n")
    title_line = build_line(title, content_width)
    sys.stdout.write(f"{border_color}│{reset}" + " "*padding + title_line + " "*padding + f"{border_color}│{reset}\n")

    empty_lines = max_visible - len(visible)
    for _ in range(empty_lines):
        sys.stdout.write(f"{border_color}│{reset}" + " "*(content_width+2*padding) + f"{border_color}│{reset}\n")

    for L in visible:
        L_disp = build_line(L, content_width)
        sys.stdout.write(f"{border_color}│{reset}" + " "*padding + L_disp + " "*padding + f"{border_color}│{reset}\n")

    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()
    last_height[0] = msg_height + 3 + max_visible

# ══════════════════════════════════════════════════════
# Instalador en tiempo real (con soporte pip)
# ══════════════════════════════════════════════════════
import os, pty, select, re, subprocess, time

def run_install(tipo, pkg, messages_above, last_height):
    if tipo == "pip":
        cmd = ["pip", "install", "--progress-bar=on", pkg]
    elif tipo == "pkg":
        cmd = ["pkg", "install", "-y", pkg]
    elif tipo == "apt":
        cmd = ["apt", "install", "-y", pkg]
    elif tipo == "apt-get":
        cmd = ["apt-get", "install", "-y", pkg]
    else:
        messages_above.append(f"\033[1;31m❌ Tipo desconocido: {tipo} para {pkg}\033[0m")
        draw_panel([], title=f"{pkg} no ejecutado", last_height=last_height, messages_above=messages_above)
        return 1

    pkg_lines = [f"\033[1;36m📦 Instalando {tipo}:{pkg}...\033[0m"]
    draw_panel(pkg_lines, title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)

    master_fd, slave_fd = pty.openpty()
    process = subprocess.Popen(
        cmd, stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, text=True
    )
    os.close(slave_fd)

    buffer = ""
    spinner_last = ""  # para detectar si solo cambió el spinner

    try:
        while True:
            r, _, _ = select.select([master_fd], [], [], 0.05)
            if master_fd in r:
                try:
                    data = os.read(master_fd, 1024).decode(errors="ignore")
                except OSError:
                    break
                if not data:
                    break

                buffer += data
                # Divide por retornos de carro o nueva línea
                parts = re.split(r'(\r|\n)', buffer)
                new_buf = ""

                for p in parts:
                    if p in ("\r", "\n"):
                        continue
                    if not p.strip():
                        continue

                    # Limpia secuencias ANSI
                    clean = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', p.strip())

                    # Detecta si es solo actualización de spinner
                    if re.fullmatch(r"[\|/\\\-]+", clean):
                        spinner_last = clean
                        if pkg_lines:
                            pkg_lines[-1] = f"{spinner_last}"
                            draw_panel(pkg_lines[-10:], title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)
                        continue

                    # Si es barra de progreso (línea que contiene ━ o %)
                    if re.search(r'[━=]+|[0-9]+%|eta', clean, re.I):
                        if pkg_lines:
                            pkg_lines[-1] = f"{clean}"
                        else:
                            pkg_lines.append(f"{clean}")
                        draw_panel(pkg_lines[-10:], title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)
                        continue

                    # Línea normal
                    pkg_lines.append(f"{clean}")
                    draw_panel(pkg_lines[-10:], title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)

                buffer = new_buf

            if process.poll() is not None:
                break

    finally:
        try:
            os.close(master_fd)
        except OSError:
            pass

    process.wait()
    return process.returncode

# ══════════════════════════════════════════════════════
# Ejecución general
# ══════════════════════════════════════════════════════
def install_all(packages):
    messages_above, last_height = [], [0]
    draw_panel([], title="Preparando instalación...", last_height=last_height, messages_above=messages_above)

    for tipo, pkg in packages:
        code = run_install(tipo, pkg, messages_above, last_height)
        if code == 0:
            messages_above.append(f"\033[1;32m✅ {pkg} instalado correctamente ({tipo}).\033[0m")
        else:
            messages_above.append(f"\033[1;31m❌ Error instalando {pkg} con {tipo}.\033[0m")
        draw_panel([], title=f"{pkg} completado.", last_height=last_height, messages_above=messages_above)
        time.sleep(0.4)

    # Limpiar cuadro
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()
    print("\n".join(messages_above))

try:
    install_all(packages)
except KeyboardInterrupt:
    print("\n\033[1;33m⏹ Instalación cancelada por el usuario.\033[0m")
    sys.exit(130)
PY

restaurar_teclado
