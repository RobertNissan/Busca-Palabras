#!/usr/bin/env bash
set -euo pipefail

# ══════════════════════════════════════════════════════
# Instalador multifuncional con recuadro único y bloqueo total del teclado
# Soporta: pip, pkg, apt, apt-get (prefijo opcional)
# ══════════════════════════════════════════════════════

# ---------- Bloquear teclado ----------
STTY_STATE=""
bloquear_teclado() {
  STTY_STATE="$(stty -g 2>/dev/null || true)"
  stty -icanon -echo min 0 time 0 2>/dev/null || true
}

# ---------- Restaurar teclado ----------
restaurar_teclado() {
  [ -n "${STTY_STATE:-}" ] && stty "$STTY_STATE" 2>/dev/null || true
}

trap restaurar_teclado EXIT INT TERM
bloquear_teclado

# ───────────────────────────────────────────────
# Parte Python
# ───────────────────────────────────────────────
python3 - <<'PY'
import sys, shutil, subprocess, signal, time, re, unicodedata

# 🔹 Grupos de paquetes
raw_packages = [
    "pip:colorama requests",
    "pkg:git wget",
    "apt:curl",
    "apt-get:expect"
]

# ========= Normalización =========
def expand_packages(raw_list):
    result = []
    for entry in raw_list:
        if ":" in entry:
            tipo, pkgs = entry.split(":", 1)
            tipo = tipo.strip()
            for pkg in pkgs.split():
                result.append((tipo, pkg.strip()))
        else:
            for pkg in entry.split():
                result.append(("pip", pkg.strip()))
    return result

packages = expand_packages(raw_packages)

# ========= Utilidades de texto =========
try:
    from wcwidth import wcwidth
except ImportError:
    def wcwidth(ch):
        if ch == '\t': return 4
        if unicodedata.combining(ch): return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F','W') else 1

ansi_re = re.compile(r'\x1b\[[0-9;]*m')
def strip_ansi(s): return ansi_re.sub('', s)
def visible_len(s): return sum(max(0, wcwidth(c)) for c in strip_ansi(s))

def wrap_line(L, width):
    tokens = re.findall(r'\x1b\[[0-9;]*m|.', L)
    lines, current, vis_count = [], [], 0
    for t in tokens:
        if ansi_re.match(t):
            current.append(t)
        else:
            w = wcwidth(t)
            if vis_count + w > width:
                lines.append(''.join(current))
                current, vis_count = [], 0
            current.append(t)
            vis_count += w
    if current:
        lines.append(''.join(current))
    return lines

def build_line(L, content_width):
    vis = visible_len(L)
    if vis < content_width:
        L += " " * (content_width - vis)
    if not L.endswith("\033[0m"):
        L += "\033[0m"
    return L

# ========= Dibujar recuadro =========
def draw_panel(lines, title="", padding=2, last_height=[0], messages_above=[]):
    term_w, _ = shutil.get_terminal_size((80,24))
    content_width = max(5, term_w - 2 - 2*padding)
    border_color, reset = "\033[1;35m", "\033[0m"
    horizontal = "─" * (content_width + 2*padding)
    top = f"{border_color}╭{horizontal}╮{reset}"
    bottom = f"{border_color}╰{horizontal}╯{reset}"
    max_visible = 15

    wrapped = []
    for L in lines:
        wrapped.extend(wrap_line(L, content_width))
    visible = wrapped[-max_visible:]

    # Borrar el recuadro anterior
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()

    # Mostrar mensajes previos
    for msg in messages_above:
        print(msg)
    msg_height = len(messages_above)

    # Recuadro principal
    sys.stdout.write(top + "\n")
    if title:
        title_disp = build_line(title, content_width)
        sys.stdout.write(f"{border_color}│{reset}" + " "*padding + title_disp + " "*padding + f"{border_color}│{reset}\n")
    else:
        sys.stdout.write(f"{border_color}│{reset}" + " "*(content_width+2*padding) + f"{border_color}│{reset}\n")

    empty_lines = max_visible - len(visible)
    for _ in range(empty_lines):
        sys.stdout.write(f"{border_color}│{reset}" + " "*(content_width+2*padding) + f"{border_color}│{reset}\n")

    for L in visible:
        L_disp = build_line(L, content_width)
        sys.stdout.write(f"{border_color}│{reset}" + " "*padding + L_disp + " "*padding + f"{border_color}│{reset}\n")

    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()
    last_height[0] = msg_height + 3 + max_visible

# ========= Instalación =========
def run_install(tipo, pkg, messages_above, last_height):
    if tipo == "pip":
        cmd = f"pip install {pkg}"
    elif tipo == "pkg":
        cmd = f"pkg install -y {pkg}"
    elif tipo == "apt":
        cmd = f"apt install -y {pkg}"
    elif tipo == "apt-get":
        cmd = f"apt-get install -y {pkg}"
    else:
        messages_above.append(f"\033[1;31m❌ Tipo desconocido: {tipo} para {pkg}\033[0m")
        draw_panel([], title=f"{pkg} no ejecutado", last_height=last_height, messages_above=messages_above)
        return 1

    pkg_lines = [f"\033[1;36m📦 Instalando {tipo}:{pkg}...\033[0m"]
    draw_panel(pkg_lines, title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)

    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for raw_line in process.stdout:
        line = raw_line.rstrip()
        pkg_lines.append(f"{pkg}: {line}")
        draw_panel(pkg_lines, title=f"Instalando {tipo}:{pkg}...", last_height=last_height, messages_above=messages_above)
        time.sleep(0.03)
    process.wait()
    return process.returncode

def install_all(packages):
    messages_above = []
    last_height = [0]
    draw_panel([], title="Iniciando instalación múltiple...", last_height=last_height, messages_above=messages_above)

    for tipo, pkg in packages:
        code = run_install(tipo, pkg, messages_above, last_height)
        if code == 0:
            messages_above.append(f"\033[1;32m☑️  {pkg} instalado correctamente ({tipo}).\033[0m")
        else:
            messages_above.append(f"\033[1;31m❌ Error instalando {pkg} con {tipo} (código {code}).\033[0m")
        draw_panel([], title=f"{pkg} completado.", last_height=last_height, messages_above=messages_above)
        time.sleep(0.4)

    # Mensaje final
    messages_above.append("\033[1;32m✅ Instalación de todos los paquetes completada.\033[0m")

    # 🔹 Limpiar el recuadro dejando solo el historial visible
    # Se sube el cursor para borrar el cuadro y dejar los mensajes
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()

    # Mostrar solo los mensajes finales (sin el recuadro)
    print("\n".join(messages_above))

try:
    install_all(packages)
except KeyboardInterrupt:
    print("\n\033[1;33m⏹ Instalación cancelada por el usuario.\033[0m")
    sys.exit(130)
PY

# ───────────────────────────────────────────────
# Restaurar teclado
# ───────────────────────────────────────────────
restaurar_teclado
