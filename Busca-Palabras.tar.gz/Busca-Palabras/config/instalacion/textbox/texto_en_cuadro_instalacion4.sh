#!/usr/bin/env bash
set -euo pipefail

# ══════════════════════════════════════════════════════
# Instalador multifuncional con recuadro único y bloqueo total del teclado
# Soporta: pip, pkg, apt, apt-get
# Oculta el cursor y lo restaura al finalizar o con Ctrl+C / Ctrl+Z
# ══════════════════════════════════════════════════════

STTY_STATE=""
bloquear_teclado() {
  STTY_STATE="$(stty -g 2>/dev/null || true)"
  stty -icanon -echo min 0 time 0 2>/dev/null || true
}

restaurar_teclado() {
  [ -n "${STTY_STATE:-}" ] && stty "$STTY_STATE" 2>/dev/null || true
  printf '\033[?25h'
}

ocultar_cursor() {
  printf '\033[?25l'
}

trap restaurar_teclado EXIT INT TERM TSTP
bloquear_teclado
ocultar_cursor

python3 - <<'PY'
# -*- coding: utf-8 -*-
import sys, shutil, subprocess, signal, time, re, unicodedata, os, pty, select, threading

raw_packages = [
    "pip: opencv-python colorama requests",
    "pkg:git wget",
    "apt:curl",
    "apt-get:expect"
]

def expand_packages(raw_list):
    result = []
    for entry in raw_list:
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            tipo, pkgs = entry.split(":", 1)
            tipo = tipo.strip()
            for pkg in pkgs.split():
                result.append((tipo, pkg.strip()))
        else:
            for pkg in entry.split():
                result.append(("pip", pkg.strip()))
    return result

packages = expand_packages(raw_packages)

ANSI_RE = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]|\x1b\[[0-9;?]*[a-zA-Z]')
def clean_raw(s: str) -> str:
    if not s:
        return ""
    s = ANSI_RE.sub('', s)
    s = s.replace('\t', '    ').replace('\r', '').replace('\b', '')
    s = ''.join(ch for ch in s if (ch == '\n' or (ord(ch) >= 32 and ord(ch) != 127)))
    return s.rstrip("\n")

try:
    from wcwidth import wcwidth
except Exception:
    def wcwidth(ch):
        if unicodedata.combining(ch):
            return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F', 'W') else 1

def visible_len(s: str) -> int:
    return sum(max(0, wcwidth(c)) for c in s)

BORDER = "\033[1;35m"
RESET = "\033[0m"
TITLE_COLOR = "\033[1;34m"
PKG_COLOR = "\033[1;32m"
OK_COLOR = "\033[1;32m"
ERR_COLOR = "\033[1;31m"
MAX_VISIBLE = 15
PADDING = 2

def term_size():
    return shutil.get_terminal_size((80, 24))

def draw_panel(lines, title="", messages_above=None, last_height=[0], _last_draw=[None]):
    if messages_above is None:
        messages_above = []
    term_w, _ = term_size()
    content_width = max(10, term_w - 2 - 2 * PADDING)
    horizontal = "─" * (content_width + 2 * PADDING)
    top = f"{BORDER}╭{horizontal}╮{RESET}"
    bottom = f"{BORDER}╰{horizontal}╯{RESET}"

    def wrap_and_clean(all_lines):
        wrapped = []
        for L in all_lines:
            Lc = clean_raw(L)
            cur, cur_len = "", 0
            for ch in Lc:
                w = max(1, wcwidth(ch))
                if cur_len + w > content_width:
                    wrapped.append(cur)
                    cur, cur_len = ch, w
                else:
                    cur += ch
                    cur_len += w
            if cur:
                wrapped.append(cur)
        return wrapped

    wrapped = wrap_and_clean(lines)
    visible = wrapped[-MAX_VISIBLE:]
    frame_key = "\n".join(messages_above + [title] + visible)
    if _last_draw[0] == frame_key:
        return
    _last_draw[0] = frame_key

    total_prev = last_height[0]
    if total_prev > 0:
        sys.stdout.write("\033[F" * total_prev)
        sys.stdout.flush()

    for m in messages_above:
        sys.stdout.write(clean_raw(m) + "\n")
    sys.stdout.write(top + "\n")

    if title:
        t_clean = clean_raw(title)
        tv = visible_len(t_clean)
        title_padded = title + " " * (content_width - tv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{title_padded}{' ' * PADDING}{BORDER}│{RESET}\n")
    else:
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    empty = MAX_VISIBLE - len(visible)
    for _ in range(empty):
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    for L in visible:
        Lc = clean_raw(L)
        lv = visible_len(Lc)
        if lv < content_width:
            Lc += " " * (content_width - lv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{Lc}{' ' * PADDING}{BORDER}│{RESET}\n")

    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()
    last_height[0] = len(messages_above) + 2 + MAX_VISIBLE + 1

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
def spinner_thread(stop_event, spinner_state):
    i = 0
    while not stop_event.is_set():
        spinner_state[0] = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
        i += 1
        time.sleep(0.08)

def run_install(tipo, pkg, messages_above, last_height):
    if tipo == "pip":
        cmd = ["pip", "install", "--progress-bar=on", pkg]
    elif tipo == "pkg":
        cmd = ["pkg", "install", "-y", pkg]
    elif tipo == "apt":
        cmd = ["apt", "install", "-y", pkg]
    elif tipo == "apt-get":
        cmd = ["apt-get", "install", "-y", pkg]
    else:
        messages_above.append(f"{ERR_COLOR}❌ Tipo desconocido: {tipo}{RESET}")
        draw_panel([], title=f"{pkg} no ejecutado", messages_above=messages_above, last_height=last_height)
        return 1

    spinner_state = ["⠋"]
    stop_event = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(stop_event, spinner_state))
    t.daemon = True
    t.start()

    pkg_lines = []
    spinner_line = None        # línea base tipo "  Installing build dependencies ..."
    spinner_active = False
    progress_idx = None        # índice donde está la barra de progreso
    progress_active = False

    try:
        master_fd, slave_fd = pty.openpty()
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        proc = subprocess.Popen(cmd, stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, close_fds=True, env=env)
        os.close(slave_fd)

        # Patrón legado que capturaba la línea base + posible spinner interno
        SPINNER_INSIDE_RE = re.compile(
            r'^(?P<prefix>\s*.*?(?:Installing build dependencies|Building wheel|Preparing metadata).*?\.\.\.)'
            r'(?P<spinner>[\s\-\|/\\●◐◓◑◒◔◕◖◗◡◑\u2800-\u28FF\u25A0-\u25FF]*)?'
            r'(?P<done>\bdone\b.*)?$',
            flags=re.IGNORECASE
        )

        # Patrones adicionales
        SPINNER_KEYWORDS = re.compile(r"(Installing build dependencies|Building wheel|Preparing metadata|Collecting|Downloading|Extracting)", re.IGNORECASE)
        PROGRESS_PATTERN = re.compile(r"[━═─]+╺[━═─]+|[0-9]+(?:\.[0-9]+)?\/[0-9]+(?:\.[0-9]+)?\s*MB", re.IGNORECASE)
        CURSOR_HIDE_RE = re.compile(r'\x1b\[\?25[lh]')  # secuencias show/hide cursor
        PIP_SPINNER_RE = re.compile(r'[\s\-\|/\\●◐◓◑◒◔◕◖◗◡◑\u2800-\u28FF\u25A0-\u25FF]+$')

        current_line = ""
        while True:
            TITLE_LINE = f"{spinner_state[0]} {TITLE_COLOR}📦 Instalando {tipo}: {PKG_COLOR}{pkg}{TITLE_COLOR}...{RESET}"
            r, _, _ = select.select([master_fd], [], [], 0.05)
            if r:
                try:
                    chunk = os.read(master_fd, 512)
                except OSError:
                    break
                if not chunk:
                    break

                text = chunk.decode(errors="ignore")
                parts = re.split('(\r|\n)', text)

                for part in parts:
                    if part == '\r':
                        # pip reescribe la misma línea por carriage return: reset parcial
                        current_line = ""
                        continue

                    if part == '\n':
                        raw_line = CURSOR_HIDE_RE.sub('', current_line)  # quitamos secuencias de cursor
                        current_line = ""

                        if raw_line.strip():
                            # Primero probar la regex que captura línea base + spinner interno
                            m = SPINNER_INSIDE_RE.match(raw_line)
                            if m:
                                prefix = m.group('prefix') or ""
                                # Guardamos la base tal cual (sin eliminar indentación)
                                base = prefix.rstrip()
                                # Marcar spinner activo y mantenemos base en spinner_line
                                spinner_line = base
                                spinner_active = True
                                progress_active = False
                                # No añadir a pkg_lines; lo mostramos con nuestro spinner
                                continue

                            # si no matchea la inside-regex, limpiamos spinner pip final si lo tiene
                            cleaned = PIP_SPINNER_RE.sub("", raw_line).rstrip()

                            # Detectar Downloading/Collecting/Extracting: deben mostrarse arriba del progreso
                            if re.search(r"\bDownloading\b", cleaned, re.IGNORECASE) or re.search(r"\bCollecting\b", cleaned, re.IGNORECASE) or re.search(r"\bExtracting\b", cleaned, re.IGNORECASE):
                                dl_line = cleaned.rstrip()
                                # insertar dl_line por encima de progress slot (si existe)
                                if progress_idx is not None:
                                    if progress_idx >= len(pkg_lines):
                                        pkg_lines.append(dl_line)
                                        pkg_lines.append("")
                                        progress_idx = len(pkg_lines) - 1
                                    else:
                                        pkg_lines.insert(progress_idx, dl_line)
                                        progress_idx += 1
                                else:
                                    pkg_lines.append(dl_line)
                                    pkg_lines.append("")  # placeholder para barra de progreso
                                    progress_idx = len(pkg_lines) - 1
                                spinner_active = False
                                progress_active = False
                                continue

                            # Barra de progreso (actualizar slot)
                            if PROGRESS_PATTERN.search(cleaned):
                                progress_line = cleaned.rstrip()
                                progress_active = True
                                spinner_active = False
                                if progress_idx is None:
                                    if pkg_lines:
                                        progress_idx = len(pkg_lines) - 1
                                    else:
                                        pkg_lines.append(progress_line)
                                        progress_idx = len(pkg_lines) - 1
                                pkg_lines[progress_idx] = progress_line
                                continue

                            # línea normal (mantener indentación)
                            line_to_store = cleaned.rstrip()
                            spinner_active = False
                            progress_active = False
                            progress_idx = None
                            if not pkg_lines or pkg_lines[-1] != line_to_store:
                                pkg_lines.append(line_to_store)
                        continue

                    # texto parcial (sin final de línea)
                    current_line += part
                    raw_peek = CURSOR_HIDE_RE.sub('', current_line)
                    # eliminar posibles spinners pip al final para análisis
                    peek_no_pip_spinner = PIP_SPINNER_RE.sub("", raw_peek)

                    # Primero intentar capturar la inside-spinner en parcial
                    mpeek = SPINNER_INSIDE_RE.match(raw_peek)
                    if mpeek:
                        pref = mpeek.group('prefix') or ""
                        spinner_line = pref.rstrip()
                        spinner_active = True
                        progress_active = False
                        continue

                    # Priorizar parciales de Downloading/Collecting/Extracting
                    if re.search(r"\bDownloading\b", peek_no_pip_spinner, re.IGNORECASE) or re.search(r"\bCollecting\b", peek_no_pip_spinner, re.IGNORECASE) or re.search(r"\bExtracting\b", peek_no_pip_spinner, re.IGNORECASE):
                        partial_line = clean_raw(peek_no_pip_spinner).rstrip()
                        if progress_idx is not None:
                            if progress_idx >= len(pkg_lines):
                                pkg_lines.append(partial_line)
                                pkg_lines.append("")
                                progress_idx = len(pkg_lines) - 1
                            else:
                                if pkg_lines and pkg_lines[-1].strip().startswith(partial_line.strip()):
                                    pkg_lines[-1] = partial_line
                                else:
                                    pkg_lines.insert(progress_idx, partial_line)
                                    progress_idx += 1
                        else:
                            if pkg_lines:
                                if pkg_lines[-1].strip().startswith(partial_line.strip()):
                                    pkg_lines[-1] = partial_line
                                else:
                                    pkg_lines.append(partial_line)
                            else:
                                pkg_lines.append(partial_line)
                            if progress_idx is None:
                                pkg_lines.append("")
                                progress_idx = len(pkg_lines) - 1
                        progress_active = False
                        spinner_active = False
                        continue

                    # parcial de barra de progreso
                    if PROGRESS_PATTERN.search(peek_no_pip_spinner):
                        progress_line = clean_raw(peek_no_pip_spinner).rstrip()
                        progress_active = True
                        spinner_active = False
                        if progress_idx is None:
                            progress_idx = len(pkg_lines) - 1 if pkg_lines else None
                            if progress_idx is None:
                                pkg_lines.append(progress_line)
                                progress_idx = len(pkg_lines) - 1
                        pkg_lines[progress_idx] = progress_line
                        continue

                    # parcial normal: actualizar última línea en construcción (mantener indent)
                    cleaned_peek = clean_raw(raw_peek)
                    if cleaned_peek.strip():
                        live = cleaned_peek.rstrip()
                        if pkg_lines:
                            pkg_lines[-1] = live
                        else:
                            pkg_lines.append(live)

                # preparar líneas a mostrar; ahora mantenemos todo el historial y solo mostramos las últimas MAX_VISIBLE
                if len(pkg_lines) > MAX_VISIBLE:
                    start_idx = len(pkg_lines) - MAX_VISIBLE
                    display_lines = pkg_lines[start_idx:]
                else:
                    display_lines = pkg_lines[:]

                # si hay progreso activo lo mostramos en su slot
                if progress_active and progress_idx is not None:
                    inline = pkg_lines[progress_idx]
                    if display_lines:
                        display_lines[-1] = inline
                    else:
                        display_lines = [inline]
                elif spinner_active and spinner_line:
                    # preservamos indentación y mostramos el spinner nuestro (sin spinner pip)
                    m = re.match(r'^(\s*)(.*)$', spinner_line)
                    if m:
                        leading, text_base = m.groups()
                    else:
                        leading, text_base = "", spinner_line
                    inline = f"{leading}{text_base} {spinner_state[0]}"
                    if display_lines:
                        display_lines[-1] = inline
                    else:
                        display_lines = [inline]

                draw_panel(display_lines, title=TITLE_LINE, messages_above=messages_above, last_height=last_height)

            if proc.poll() is not None:
                break

        proc.wait()

        # Si spinner activo y no llegó 'done', lo cerramos con 'done'
        if spinner_active and spinner_line:
            final = spinner_line
            if not any(re.search(r'\bdone\b', l, re.IGNORECASE) for l in pkg_lines):
                pkg_lines.append(final + " done")

        display_lines = pkg_lines[-MAX_VISIBLE:]
        final_title = f"✔ {PKG_COLOR}{pkg}{RESET}"
        draw_panel(display_lines, title=final_title, messages_above=messages_above, last_height=last_height)

        return proc.returncode

    finally:
        stop_event.set()
        t.join()
        try:
            os.close(master_fd)
        except Exception:
            pass

def install_all(packages):
    messages_above, last_height = [], [0]
    draw_panel([], title="Iniciando instalación múltiple...", messages_above=messages_above, last_height=last_height)
    for tipo, pkg in packages:
        code = run_install(tipo, pkg, messages_above, last_height)
        if code == 0:
            messages_above.append(f"{OK_COLOR}☑️  {pkg} instalado correctamente ({tipo}).{RESET}")
        else:
            messages_above.append(f"{ERR_COLOR}❌ Error instalando {pkg} con {tipo} (código {code}).{RESET}")
        draw_panel([], title=f"{pkg} completado.", messages_above=messages_above, last_height=last_height)
        time.sleep(0.4)
    messages_above.append(f"{OK_COLOR}✅ Instalación de todos los paquetes completada.{RESET}")
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()
    print("\n".join(messages_above))

try:
    install_all(packages)
except KeyboardInterrupt:
    print("\n\033[1;33m⏹ Instalación cancelada por el usuario.\033[0m")
    sys.exit(130)
PY

restaurar_teclado