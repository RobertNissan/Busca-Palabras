#!/usr/bin/env bash
set -euo pipefail

# ══════════════════════════════════════════════════════
# Instalador multifuncional con recuadro único y bloqueo total del teclado
# Soporta: pip, pkg, apt, apt-get
# Oculta el cursor y lo restaura al finalizar o con Ctrl+C / Ctrl+Z
# ══════════════════════════════════════════════════════

STTY_STATE=""
bloquear_teclado() {
  STTY_STATE="$(stty -g 2>/dev/null || true)"
  stty -icanon -echo min 0 time 0 2>/dev/null || true
}

restaurar_teclado() {
  [ -n "${STTY_STATE:-}" ] && stty "$STTY_STATE" 2>/dev/null || true
  printf '\033[?25h'
}

ocultar_cursor() {
  printf '\033[?25l'
}

trap restaurar_teclado EXIT INT TERM TSTP
bloquear_teclado
ocultar_cursor

python3 - <<'PY'
# -*- coding: utf-8 -*-
import sys, shutil, subprocess, signal, time, re, unicodedata, os, pty, select, threading

raw_packages = [
    "pip:numpy colorama requests",
    "pkg:git wget",
    "apt:curl",
    "apt-get:expect"
]

def expand_packages(raw_list):
    result = []
    for entry in raw_list:
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            tipo, pkgs = entry.split(":", 1)
            tipo = tipo.strip()
            for pkg in pkgs.split():
                result.append((tipo, pkg.strip()))
        else:
            for pkg in entry.split():
                result.append(("pip", pkg.strip()))
    return result

packages = expand_packages(raw_packages)

ANSI_RE = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]|\x1b\[[0-9;?]*[a-zA-Z]')
def clean_raw(s: str) -> str:
    if not s:
        return ""
    s = ANSI_RE.sub('', s)
    s = s.replace('\t', '    ').replace('\r', '').replace('\b', '')
    s = ''.join(ch for ch in s if (ch == '\n' or (ord(ch) >= 32 and ord(ch) != 127)))
    return s.rstrip("\n")

try:
    from wcwidth import wcwidth
except Exception:
    def wcwidth(ch):
        if unicodedata.combining(ch):
            return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F', 'W') else 1

def visible_len(s: str) -> int:
    return sum(max(0, wcwidth(c)) for c in s)

BORDER = "\033[1;35m"
RESET = "\033[0m"
TITLE_COLOR = "\033[1;34m"
PKG_COLOR = "\033[1;32m"
OK_COLOR = "\033[1;32m"
ERR_COLOR = "\033[1;31m"
MAX_VISIBLE = 15
PADDING = 2

def term_size():
    return shutil.get_terminal_size((80, 24))

def draw_panel(lines, title="", messages_above=None, last_height=[0], _last_draw=[None]):
    if messages_above is None:
        messages_above = []
    term_w, _ = term_size()
    content_width = max(10, term_w - 2 - 2 * PADDING)
    horizontal = "─" * (content_width + 2 * PADDING)
    top = f"{BORDER}╭{horizontal}╮{RESET}"
    bottom = f"{BORDER}╰{horizontal}╯{RESET}"

    def wrap_and_clean(all_lines):
        wrapped = []
        for L in all_lines:
            Lc = clean_raw(L)
            cur, cur_len = "", 0
            for ch in Lc:
                w = max(1, wcwidth(ch))
                if cur_len + w > content_width:
                    wrapped.append(cur)
                    cur, cur_len = ch, w
                else:
                    cur += ch
                    cur_len += w
            if cur:
                wrapped.append(cur)
        return wrapped

    wrapped = wrap_and_clean(lines)
    visible = wrapped[-MAX_VISIBLE:]
    frame_key = "\n".join(messages_above + [title] + visible)
    if _last_draw[0] == frame_key:
        return
    _last_draw[0] = frame_key

    total_prev = last_height[0]
    if total_prev > 0:
        sys.stdout.write("\033[F" * total_prev)
        sys.stdout.flush()

    for m in messages_above:
        sys.stdout.write(clean_raw(m) + "\n")
    sys.stdout.write(top + "\n")

    if title:
        t_clean = clean_raw(title)
        tv = visible_len(t_clean)
        title_padded = title + " " * (content_width - tv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{title_padded}{' ' * PADDING}{BORDER}│{RESET}\n")
    else:
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    empty = MAX_VISIBLE - len(visible)
    for _ in range(empty):
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * (content_width + 2 * PADDING)}{BORDER}│{RESET}\n")

    for L in visible:
        Lc = clean_raw(L)
        lv = visible_len(Lc)
        if lv < content_width:
            Lc += " " * (content_width - lv)
        sys.stdout.write(f"{BORDER}│{RESET}{' ' * PADDING}{Lc}{' ' * PADDING}{BORDER}│{RESET}\n")

    sys.stdout.write(bottom + "\n")
    sys.stdout.flush()
    last_height[0] = len(messages_above) + 2 + MAX_VISIBLE + 1

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
def spinner_thread(stop_event, spinner_state):
    i = 0
    while not stop_event.is_set():
        spinner_state[0] = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
        i += 1
        time.sleep(0.08)

def run_install(tipo, pkg, messages_above, last_height):
    if tipo == "pip":
        cmd = ["pip", "install", "--progress-bar=on", pkg]
    elif tipo == "pkg":
        cmd = ["pkg", "install", "-y", pkg]
    elif tipo == "apt":
        cmd = ["apt", "install", "-y", pkg]
    elif tipo == "apt-get":
        cmd = ["apt-get", "install", "-y", pkg] 
    else:
        messages_above.append(f"{ERR_COLOR}❌ Tipo desconocido: {tipo}{RESET}")
        draw_panel([], title=f"{pkg} no ejecutado", messages_above=messages_above, last_height=last_height)
        return 1

    spinner_state = ["⠋"]
    stop_event = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(stop_event, spinner_state))
    t.daemon = True
    t.start()

    pkg_lines = []
    try:
        master_fd, slave_fd = pty.openpty()
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        proc = subprocess.Popen(cmd, stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, close_fds=True, env=env)
        os.close(slave_fd)
        buf = b""
        last_progress = ""

        SPINNER_INSIDE_RE = re.compile(
            r'^(?P<prefix>.*?(?:Installing build dependencies|Building wheel|Preparing metadata).*?\.\.\.)'
            r'(?P<spinner>[\s\-\\|/●◐◓◑◒◔\u2800-\u28FF\u25A0-\u25FF]*)?'
            r'(?P<done>\bdone\b.*)?$',
            flags=re.IGNORECASE
        )

        while True:
            TITLE_LINE = f"{spinner_state[0]} {TITLE_COLOR}📦 Instalando {tipo}: {PKG_COLOR}{pkg}{TITLE_COLOR}...{RESET}"
            r, _, _ = select.select([master_fd], [], [], 0.05)
            if r:
                try:
                    chunk = os.read(master_fd, 4096)
                except OSError:
                    break
                if not chunk:
                    break

                buf += chunk
                text = buf.decode(errors="ignore")
                parts = re.split(r'[\r\n]+', text)
                incomplete = "" if text.endswith(("\n", "\r")) else parts.pop()

                for p in parts:
                    p = clean_raw(p)
                    if not p:
                        continue
                    m = SPINNER_INSIDE_RE.match(p)
                    if m:
                        prefix = m.group('prefix') or ''
                        done_part = m.group('done') or ''
                        done_part = re.sub(r'[-\\|/]+\s*', '', done_part)
                        normalized = (prefix + ((' ' + done_part.strip()) if done_part.strip() else '')).strip()
                        pkg_lines.append(normalized)
                        continue
                    if any(x in p for x in ("━", "╸", "MB/s", "eta")):
                        last_progress = p
                        if pkg_lines and any(x in pkg_lines[-1] for x in ("━", "╸", "MB/s", "eta")):
                            pkg_lines[-1] = last_progress
                        else:
                            pkg_lines.append(last_progress)
                        continue
                    if re.search(r'^[\s\-\\|/]+(?:done)?\s*$', p):
                        continue
                    pkg_lines.append(p)

                draw_panel(pkg_lines, title=TITLE_LINE, messages_above=messages_above, last_height=last_height)
                buf = incomplete.encode(errors="ignore")

            if proc.poll() is not None:
                break

        proc.wait()
        return proc.returncode
    finally:
        stop_event.set()
        t.join()
        try:
            os.close(master_fd)
        except:
            pass

def install_all(packages):
    messages_above, last_height = [], [0]
    draw_panel([], title="Iniciando instalación múltiple...", messages_above=messages_above, last_height=last_height)
    for tipo, pkg in packages:
        code = run_install(tipo, pkg, messages_above, last_height)
        if code == 0:
            messages_above.append(f"{OK_COLOR}☑️  {pkg} instalado correctamente ({tipo}).{RESET}")
        else:
            messages_above.append(f"{ERR_COLOR}❌ Error instalando {pkg} con {tipo} (código {code}).{RESET}")
        draw_panel([], title=f"{pkg} completado.", messages_above=messages_above, last_height=last_height)
        time.sleep(0.4)
    messages_above.append(f"{OK_COLOR}✅ Instalación de todos los paquetes completada.{RESET}")
    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()
    print("\n".join(messages_above))

try:
    install_all(packages)
except KeyboardInterrupt:
    print("\n\033[1;33m⏹ Instalación cancelada por el usuario.\033[0m")
    sys.exit(130)
PY

restaurar_teclado