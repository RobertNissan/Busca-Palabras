#!/bin/bash

source textbox_install.sh
instalar_paquetes LDFLAGS_PIP:scikit-learn scipy pip:colorama opencv-python pkg:git wget apt:curl apt-get:termux-api

# Arreglar el error: $'\r':
# sed -i 's/\r$//' install.sh
# sed 's/\r$//' install.sh > install_fixed.sh
# mv install_fixed.sh install.sh
