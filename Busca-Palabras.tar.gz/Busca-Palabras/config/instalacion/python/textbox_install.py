import sys
import shutil
import subprocess
import time
import re
import unicodedata
import os
import pty
import select
import threading
import termios
from collections import deque

try:
    from wcwidth import wcwidth
except ImportError:
    def wcwidth(ch):
        if ch == '\t': return 4
        if unicodedata.combining(ch): return 0
        ea = unicodedata.east_asian_width(ch)
        return 2 if ea in ('F', 'W') else 1

ANSI_RE = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
PROGRESS_KEYWORDS = ("Downloading", "MB/s", "Progress", "eta", "ETA", "saved", "━", "%", "Collecting", "Installing", "Building")
MAX_BOX_CONTENT_LINES = 15
SIDE_PADDING = 1
RIGHT_PADDING = 2
MARGIN_RIGHT = 0

def expand_packages(raw_list):
    result = []
    current_manager = "pkg"
    
    for entry in raw_list:
        entry = entry.strip()
        if not entry:
            continue
            
        if ":" in entry:
            manager, pkgs = entry.split(":", 1)
            current_manager = manager.strip()
            for pkg in pkgs.split():
                if pkg.strip():
                    result.append((current_manager, pkg.strip()))
        else:
            for pkg in entry.split():
                if pkg.strip():
                    result.append((current_manager, pkg.strip()))
    return result

def clean_output(s: str) -> str:
    if not s: return ""
    s = ANSI_RE.sub("", s)
    s = s.replace("\t", "    ")
    return s

def escape_line_for_box(line: str) -> str:
    return line if line else ""

def process_backspaces(s: str) -> str:
    out = []
    for ch in s:
        if ch == '\b':
            if out: out.pop()
        else:
            out.append(ch)
    return "".join(out)

def is_progress_line(s: str) -> bool:
    if not s: return False
    return any(k.lower() in s.lower() for k in PROGRESS_KEYWORDS)

def get_terminal_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80

def get_content_width(term_w):
    return max(term_w - MARGIN_RIGHT - 2 - SIDE_PADDING - RIGHT_PADDING, 2)

ansi_re = re.compile(r'\x1b\[[0-9;]*m')
def strip_ansi(s): return ansi_re.sub('', s)
def visible_len(s): return sum(max(0, wcwidth(c)) for c in strip_ansi(s))

def wrap_line_ansi(text, width):
    lines = []
    current_line = ""
    current_len = 0
    
    for text_part in text.splitlines():
        words = re.split(r'(\s+)', text_part)
        for word in words:
            vis_len = visible_len(word)
            if current_len + vis_len > width:
                if current_len > 0:
                    lines.append(current_line)
                    current_line = ""
                    current_len = 0
                
                if vis_len > width:
                    temp_word = ""
                    temp_len = 0
                    for char in word:
                        char_len = visible_len(char)
                        if temp_len + char_len > width:
                            lines.append(current_line + temp_word)
                            current_line = ""
                            current_len = 0
                            temp_word = char
                            temp_len = char_len
                        else:
                            temp_word += char
                            temp_len += char_len
                    word = temp_word
                    vis_len = temp_len

            current_line += word
            current_len += vis_len
        
        if current_line:
            lines.append(current_line)
            current_line = ""
            current_len = 0
            
    return lines if lines else [""]

def draw_panel(lines, title="", messages_above=None, last_height=[0]):
    if messages_above is None: messages_above = []

    term_w, _ = shutil.get_terminal_size((80,24))
    content_width = get_content_width(term_w)
    
    border_color, reset = "\033[1;35m", "\033[0m"
    padding_total = SIDE_PADDING + RIGHT_PADDING
    horizontal = "─" * (content_width + padding_total)
    top = f"{border_color}╭{horizontal}╮{reset}"
    bottom = f"{border_color}╰{horizontal}╯{reset}"

    wrapped = []
    for L in lines:
        cleaned_line = clean_output(L)
        wrapped.extend(wrap_line_ansi(cleaned_line, content_width))
    
    visible = wrapped[-MAX_BOX_CONTENT_LINES:]

    if last_height[0] > 0:
        sys.stdout.write(f"\033[{last_height[0]}A\r")

    output = []
    for msg in messages_above: output.append("\033[2K" + msg)
    
    output.append("\033[2K" + top)
    
    title_line_content = ' ' * (content_width + padding_total)
    if title:
        clean_title = clean_output(title)
        vis_title_len = visible_len(clean_title)
        padding_needed = content_width - vis_title_len
        title_disp = clean_title + " " * max(0, padding_needed)
        title_line_content = ' ' * SIDE_PADDING + title_disp + ' ' * RIGHT_PADDING
    output.append(f"\033[2K{border_color}│{reset}" + title_line_content + f"{border_color}│{reset}")

    empty_lines = MAX_BOX_CONTENT_LINES - len(visible)
    for _ in range(empty_lines):
        output.append(f"\033[2K{border_color}│{reset}" + ' ' * (content_width + padding_total) + f"{border_color}│{reset}")

    for L in visible:
        vis_L_len = visible_len(L)
        padding_needed = content_width - vis_L_len
        L_disp = L + " " * max(0, padding_needed)
        output.append(f"\033[2K{border_color}│{reset}" + ' ' * SIDE_PADDING + L_disp + ' ' * RIGHT_PADDING + f"{border_color}│{reset}")

    output.append("\033[2K" + bottom)
    
    sys.stdout.write('\n'.join(output) + '\n')
    sys.stdout.flush()
    last_height[0] = len(output)

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
def spinner_thread(stop_event, spinner_state):
    i = 0
    while not stop_event.is_set():
        spinner_state[0] = SPINNER_FRAMES[i % len(SPINNER_FRAMES)]
        i += 1
        time.sleep(0.08)

def is_package_installed(manager, package):
    try:
        if manager in ("pip", "LDFLAGS_PIP"):
            result = subprocess.run(["pip", "show", package], capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        elif manager == "pkg":
            try:
                result = subprocess.run(["pkg", "list-installed"], capture_output=True, text=True, timeout=5)
                if result.returncode == 0 and f"{package}/" in result.stdout: return True
                result = subprocess.run(["dpkg", "-s", package], capture_output=True, text=True, timeout=5)
                return result.returncode == 0 and "Status: install ok installed" in result.stdout
            except Exception:
                return False
        elif manager in ["apt", "apt-get"]:
            result = subprocess.run(["dpkg", "-s", package], capture_output=True, text=True, timeout=5)
            return result.returncode == 0 and "Status: install ok installed" in result.stdout
    except Exception:
        return False
    return False

def run_install_for(manager, package, messages_above, last_height):
    if is_package_installed(manager, package):
        return True
    
    display_buffer = deque(maxlen=MAX_BOX_CONTENT_LINES)
    spinner_state = ["⠋"]
    stop_event = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(stop_event, spinner_state))
    t.daemon = True
    t.start()

    # Usar sys.version_info en lugar de subprocess (más rápido y limpio en Python)
    python_version = f"python{sys.version_info.major}.{sys.version_info.minor}"
    
    # Preparamos el entorno para no causar un FileNotFoundError al pasar LDFLAGS
    custom_env = os.environ.copy()

    if manager == "pip":
        cmd = ["pip", "install", package, "--progress-bar=on"]
    elif manager == "LDFLAGS_PIP":
        custom_env["LDFLAGS"] = python_version
        cmd = ["pip", "install", "--no-build-isolation", "--no-cache-dir", package, "--progress-bar=on"]
    elif manager == "pkg":
        cmd = ["pkg", "install", "-y", package]
    elif manager == "apt":
        cmd = ["apt", "install", "-y", package]
    else:
        cmd = ["apt-get", "install", "-y", package]

    master, slave = pty.openpty()
    proc = subprocess.Popen(cmd, stdin=slave, stdout=slave, stderr=slave, close_fds=True, env=custom_env)
    os.close(slave)
    buf = b""

    try:
        while proc.poll() is None:
            title = f"{spinner_state[0]} 🔧 Instalando {package} con {manager}..."
            r, _, _ = select.select([master], [], [], 0.05)
            if r:
                try: chunk = os.read(master, 4096)
                except OSError: break
                if not chunk: break
                buf += chunk

            while True:
                cr_pos = buf.find(b'\r')
                lf_pos = buf.find(b'\n')
                if cr_pos == -1 and lf_pos == -1: break
                pos = min(p for p in [cr_pos, lf_pos] if p != -1)
                is_cr = (pos == cr_pos)
                line_bytes = buf[:pos]
                buf = buf[pos + 1:]
                line = line_bytes.decode('utf-8', 'ignore')

                if is_cr:
                    if display_buffer: display_buffer[-1] = escape_line_for_box(process_backspaces(line))
                    else: display_buffer.append(escape_line_for_box(process_backspaces(line)))
                else:
                    display_buffer.append(escape_line_for_box(process_backspaces(line.rstrip())))

            render_buffer = list(display_buffer)
            if buf and render_buffer:
                remains_str = buf.decode('utf-8', 'ignore')
                if is_progress_line(remains_str):
                    render_buffer[-1] = escape_line_for_box(process_backspaces(remains_str))

            draw_panel(render_buffer, title=title, messages_above=[], last_height=last_height)
        proc.wait()
    finally:
        stop_event.set()
        t.join()
        try: os.close(master)
        except: pass

    for _ in range(last_height[0]):
        sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()
    last_height[0] = 0

    if proc.returncode == 0:
        print(f"\033[1;32m✅ {package} instalado correctamente ({manager}).\033[0m")
    else:
        print(f"\033[1;31m❌ Error instalando {package} con {manager}.\033[0m")

    return proc.returncode == 0

# --- Reemplazos puros de Python para las utilidades de Bash ---

def ocultar_cursor():
    sys.stdout.write('\033[?25l')
    sys.stdout.flush()

def mostrar_cursor():
    sys.stdout.write('\033[?25h')
    sys.stdout.flush()

class TerminalBlocker:
    def __init__(self):
        self.fd = sys.stdin.fileno()
        self.old_settings = None

    def bloquear(self):
        try:
            self.old_settings = termios.tcgetattr(self.fd)
            new = termios.tcgetattr(self.fd)
            # stty -icanon -echo min 0 time 0
            new[3] = new[3] & ~termios.ECHO & ~termios.ICANON
            new[6][termios.VMIN] = 0
            new[6][termios.VTIME] = 0
            termios.tcsetattr(self.fd, termios.TCSANOW, new)
        except Exception:
            pass

    def restaurar(self):
        if self.old_settings:
            try: termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old_settings)
            except Exception: pass

def instalar_paquetes(*args):
    if not args:
        print("Uso: instalar_paquetes('paquete1', '[paquete2]', ...)")
        return False
        
    packages = expand_packages(args)
    term_blocker = TerminalBlocker()
    
    term_blocker.bloquear()
    ocultar_cursor()

    try:
        messages_above = []
        last_height = [0]
        for manager, pkg in packages:
            run_install_for(manager, pkg, messages_above, last_height)
    finally:
        # Asegura que el teclado/cursor vuelvan a la normalidad aunque el script falle o se cierre con Ctrl+C
        term_blocker.restaurar()
        mostrar_cursor()
