import sys
import os

# 1. Definimos la CARPETA donde están los archivos (sin el nombre del archivo al final)
dir_path = "/data/data/com.termux/files/home/Busca-Palabras/config/instalacion/python"

# 2. Verificamos si la carpeta existe y la añadimos al path
if os.path.isdir(dir_path):
    sys.path.append(dir_path)
else:
    print(f"❌ Error: No se encontró el directorio {dir_path}")
    sys.exit(1)

# 3. Importamos usando el nombre del ARCHIVO (textbox_install)
try:
    from textbox_install import instalar_paquetes
except ImportError as e:
    print(f"❌ Error de importación: {e}")
    print("Asegúrate de que el archivo se llame exactamente 'textbox_install.py'")
    sys.exit(1)

if __name__ == "__main__":
    # Ejecución
    instalar_paquetes(
        "LDFLAGS_PIP:scikit-learn", 
        "pip:colorama scipy opencv-python", 
        "pkg:git wget", 
        "apt:curl", 
        "apt-get:termux-api"
    )
