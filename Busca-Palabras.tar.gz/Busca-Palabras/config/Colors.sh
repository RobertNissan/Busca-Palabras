# Colores Bash
#

# Colores
export NC='\033[0m'            # Sin color
export RED='\033[1;31m'        # Rojo brillante
export BLUE='\033[1;34m'       # Azul brillante
export CYAN='\033[1;36m'       # Cian brillante
export WHITE='\033[1;37m'      # Blanco brillante
export GREEN='\033[1;32m'      # Verde brillante
export YELLOW='\033[1;33m'     # Amarillo brillante
export MAGENTA='\033[1;35m'    # Magenta brillante

export rosa="\033[38;5;207m"
export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export azul='\033[34m'
export morado='\033[35m'
export blanco='\033[37m'
export cyan='\033[1;36m'
export magenta='\033[1;35m'
export reset_color='\033[0m'