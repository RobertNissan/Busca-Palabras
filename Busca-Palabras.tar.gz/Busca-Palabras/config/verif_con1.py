import subprocess
import re
import requests
import socket
import time
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

# Servicios para obtener IP (priorizados)
IP_SERVICES = [
    'ipinfo.io/ip',
    'https://icanhazip.com',        # Muy rápido y confiable
    'https://api.ipify.org',        # Popular y estable
    'https://ident.me',             # Ligero
    'https://ifconfig.me/ip',       # Alternativa
    'https://checkip.amazonaws.com'  # Servicio de AWS
]

TIMEOUT = 3  # Tiempo máximo por solicitud

def is_valid_ip(ip_str):
    """Verifica si es una IPv4 válida"""
    try:
        socket.inet_aton(ip_str)
        return ip_str.count('.') == 3
    except (socket.error, ValueError):
        return False

def get_ip_from_service(service_url):
    """Obtiene IP de un servicio con verificación HTTPS"""
    try:
        parsed = urlparse(service_url)
        if not parsed.scheme == 'https':
            return None
            
        response = requests.get(service_url, timeout=TIMEOUT)
        ip = response.text.strip()
        return ip if is_valid_ip(ip) else None
    except:
        return None

def get_external_ip():
    """Obtiene IP pública con múltiples intentos"""
    ips = set()
    
    # Probamos servicios en paralelo
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(get_ip_from_service, url): url for url in IP_SERVICES}
        
        for future in as_completed(futures):
            if len(ips) >= 2:  # Con 2 coincidencias ya es confiable
                break
                
            ip = future.result()
            if ip:
                ips.add(ip)
    
    return ips.pop() if ips else None

def has_internet():
    """Verifica conectividad básica de forma más robusta"""
    try:
        # 1. Intento rápido con DNS (no requiere HTTP)
        socket.create_connection(("1.1.1.1", 53), timeout=2)
        
        # 2. Si hay portal cautivo, algunos servicios de IP igual funcionan
        #    así que omitimos la verificación estricta del portal cautivo
        
        return True
    except:
        return False

def verify_connection():
    """Versión final mejorada"""
    start_time = time.time()
    
    if not has_internet():
        return False, "No hay conectividad de red", 0
    
    external_ip = get_external_ip()
    elapsed = time.time() - start_time
    
    if external_ip:
        return True, external_ip, elapsed
    else:
        return False, "No se pudo obtener IP (pero hay conectividad)", elapsed

# Ejemplo de uso
if __name__ == "__main__":
    connected, result, elapsed = verify_connection()
    
    if connected:
        print(f"✅ Conectado | IP: {result} | Tiempo: {elapsed:.2f}s")
    else:
        print(f"⚠️ Estado: {result} | Tiempo: {elapsed:.2f}s")
        

# Definición de colores ANSI
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[0;33m'
CYAN = '\033[0;36m'
NC = '\033[0m'  # No Color


def verificar_conexion_internet():
    """Verifica la conexión a internet similar al código bash original"""
    TIMEOUT = 5
    captive_portal_response = '<html><head><title>302 Found</title></head><body><h1>302 Found</h1><p>The document has moved <a href="https://mi.tigo.com.co/assets/captive.html?utm_source=captiveportal">here</a></p></body></html>'
    
    try:
        proceso = subprocess.Popen(
            ["curl", "-s", "--max-time", str(TIMEOUT), "ipinfo.io/ip"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        inicio = time.time()
        
        while proceso.poll() is None:
            if time.time() - inicio >= TIMEOUT:
                proceso.kill()
                return False, ""
        
        salida = proceso.stdout.read().strip()
        if salida and salida != captive_portal_response:
            return True, salida
        return False, salida
    except Exception:
        return False, ""

def obtener_ip_local():
    """Obtiene la IP local de manera similar al código bash original"""
    interfaces = ["wlan0", "eth0", "usb0"]
    ip_pattern = r'inet (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    
    for interfaz in interfaces:
        try:
            resultado = subprocess.run(
                ["ifconfig", interfaz],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )
            if resultado.returncode == 0:
                match = re.search(ip_pattern, resultado.stdout)
                if match:
                    return match.group(1), interfaz
        except Exception:
            continue
    
    # Buscar en todas las interfaces si no se encontró en las comunes
    try:
        resultado = subprocess.run(
            ["ifconfig"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        if resultado.returncode == 0:
            for line in resultado.stdout.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    match = re.search(ip_pattern, line)
                    if match:
                        return match.group(1), "desconocida"
    except Exception:
        pass
    
    return "127.0.0.1", ""

def verificar_wlan0_activa():
    """Verifica si wlan0 está activa y tiene IP"""
    try:
        resultado = subprocess.run(
            ["ifconfig", "wlan0"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        if resultado.returncode == 0:
            if "RUNNING" in resultado.stdout and "inet " in resultado.stdout:
                return True
        return False
    except Exception:
        return False

def verif_tipo_con():
    """Determina el tipo de conexión simplificando las actualizaciones de estado."""
    # 1. Estado base
    base = {
        "disponible_adb": False,
        "conect_internet": False,
        "disponible_modem": False,
        "estado_con": "",
        "dir_ip": "",
        "mi_ip_ex": "",
        # siempre incluimos datos locales sin cambios
        "ip_local": None,
        "interfaz": None,
    }
    
    # 2. Obtener datos
    iplocal, interfaz = obtener_ip_local()
    internet, ipexterna = verificar_conexion_internet()
    iplocalc = iplocal.split('.')[0] if iplocal != "127.0.0.1" else "127"
    wlan0_activa = verificar_wlan0_activa()

    # 3. Helper para generar el resultado
    def build_net(**kwargs):
        net = base.copy()
        net.update({
            "ip_local": iplocal,
            "interfaz": interfaz,
        })
        net.update(kwargs)
        return net

    # 4. Lista de (condición, kwargs) en el orden de chequeo original
    cases = [
        # 1er bloque
        (
            iplocal == "127.0.0.1"
            and iplocalc == "127"
            and (not ipexterna or "html" in ipexterna),
            {
                "disponible_modem": True,
                "estado_con": f"\n{RED}No hay conexión wi-fi, datos ni {NC}({RED}zona wi-fi{NC}){NC}...\n",
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
            }
        ),
        # 2.º bloque
        (
            internet and iplocalc != "192" and not wlan0_activa,
            {
                "disponible_modem": True,
                "conect_internet": True,
                "estado_con": f"\n{GREEN}Tienes internet para compartir datos por {NC}({GREEN}zona wi-fi{NC}).\n",
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
                "mi_ip_ex": f"{CYAN}Dirección ip externa{NC}: {ipexterna}",
            }
        ),
        # 3.º bloque
        (
            (not internet or "html" in ipexterna) and iplocalc in ["192", "10"] and not wlan0_activa,
            {
                "disponible_modem": True,
                "estado_con": (
                    f"\n{GREEN}Activada la {NC}({GREEN}Zona WI-FI{NC}) "
                    f"{GREEN}y no tienes internet,\npero puedes otorgar conexión{NC}.\n"
                ),
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
            }
        ),
        # 4.º bloque
        (
            internet and iplocalc == "192" and not wlan0_activa,
            {
                "disponible_modem": True,
                "conect_internet": True,
                "estado_con": (
                    f"\n{GREEN}Tienes datos de internet y la {NC}({GREEN}zona wi-fi{NC}) "
                    f"{GREEN}activa{NC}.\n({GREEN}Compartiendo datos{NC})\n"
                ),
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
                "mi_ip_ex": f"{CYAN}Dirección ip externa{NC}: {ipexterna}",
            }
        ),
        # 5.º bloque
        (
            internet,
            {
                "disponible_adb": True,
                "conect_internet": True,
                "estado_con": f"\n{GREEN}Tienes internet wi-fi del Módem{NC}.\n",
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
                "mi_ip_ex": f"{CYAN}Dirección ip externa{NC}: {ipexterna}",
            }
        ),
        # 6.º bloque
        (
            (not internet or "html" in ipexterna) and iplocalc in ["192", "10"] and wlan0_activa,
            {
                "disponible_modem": True,
                "disponible_adb": True,
                "estado_con": f"\n{GREEN}No hay internet pero estás conectado al Módem{NC}.\n",
                "dir_ip": f"{YELLOW}Dirección ip: {NC}{iplocal}{NC}",
            }
        ),
    ]

    # 5. Iteramos por los casos y devolvemos el primero que cumpla
    for cond, updates in cases:
        if cond:
            return build_net(**updates)

    # 6. Si ningún caso coincide, devolvemos el estado base con datos locales
    return build_net()
    
    

# Ejemplo de uso
if __name__ == "__main__":
    resultado = verif_tipo_con()
    print("Resultado del análisis de conexión:")
    print(f"Estado: {resultado['estado_con']}")
    print(f"IP Local: {resultado['dir_ip']}")
    if resultado['mi_ip_ex']:
        print(f"IP Externa: {resultado['mi_ip_ex']}")
    print(f"ADB disponible: {resultado['disponible_adb']}")
    print(f"Conexión a internet: {resultado['conect_internet']}")
    print(f"Modem disponible: {resultado['disponible_modem']}")
