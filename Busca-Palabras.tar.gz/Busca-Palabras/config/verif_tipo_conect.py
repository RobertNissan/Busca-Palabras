#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket
import subprocess
import re
import time
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

TIMEOUT = 5
IP_SERVICES = [
    "https://ipinfo.io/ip",
    "https://api.ipify.org",
    "https://ifconfig.me/ip",
    "https://icanhazip.com",
]

def is_valid_ip(ip_str):
    """Verifica si es una IPv4 válida"""
    try:
        socket.inet_aton(ip_str)
        return ip_str.count('.') == 3
    except (socket.error, ValueError):
        return False

def get_ip_from_service(service_url):
    """Obtiene IP desde un servicio HTTPS"""
    try:
        parsed = urlparse(service_url)
        if parsed.scheme != "https":
            return None
        r = requests.get(service_url, timeout=TIMEOUT)
        ip = r.text.strip()
        return ip if is_valid_ip(ip) else None
    except:
        return None

def get_external_ip():
    """Obtiene IP pública consultando varios servicios en paralelo"""
    ips = set()
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(get_ip_from_service, url): url for url in IP_SERVICES}
        for future in as_completed(futures):
            ip = future.result()
            if ip:
                ips.add(ip)
            if len(ips) >= 2:  # confiable si coincide en al menos 2 servicios
                break
    return ips.pop() if ips else None

def obtener_interfaces():
    """Obtiene un dict con {interfaz: ip} usando ifconfig."""
    try:
        salida = subprocess.check_output(["ifconfig"], text=True)
    except:
        return {}
    interfaces = {}
    actual = None
    for linea in salida.splitlines():
        if not linea.startswith(" ") and ":" in linea:
            actual = linea.split(":")[0]
        elif "inet " in linea and actual:
            m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", linea)
            if m:
                interfaces[actual] = m.group(1)
    return interfaces

def clasificar_conexion(ifaces, ip_externa):
    """Clasifica el tipo de conexión basado en las interfaces y la IP externa."""
    tipo = "Desconocido"
    detalles = []

    # Flag VPN
    if any(name.startswith(("tun", "tap")) for name in ifaces):
        detalles.append("VPN activa")

    # IP concreta de wlan0 (si existe)
    wlan_ip = ifaces.get("wlan0")

    # Hotspot Android: rango típico 10.* o 192.168.43.*
    if any(ip.startswith("192.168.") for ip in ifaces.values()) and (wlan_ip and wlan_ip.startswith("10.")):
        tipo = "Hotspot Android"

    # Hotspot iPhone: rango típico 172.20.10.*
    elif any(ip.startswith("172.20.10.") for ip in ifaces.values()):
        tipo = "Hotspot iPhone"

    # Router Wi-Fi: aseguramos que haya 192.168.* en wlan0 y NO exista ningún 10.* en cualquier interfaz
    elif (
        ("wlan0" in ifaces)
        and (any(ip.startswith("192.168.") for ip in ifaces.values()))
        and not any(ip.startswith("10.") for ip in ifaces.values())
    ):
        tipo = "Router Wi-Fi"

    # Si wlan0 existe y tiene 192.168.* y no hay 10.* tampoco (versión más estricta sobre wlan0)
    # elif wlan_ip and wlan_ip.startswith("192.168.") and not any(ip.startswith("10.") for ip in ifaces.values()):
    #     tipo = "Router Wi-Fi"

    # Si sigue sin clasificarse pero hay wlan0, favicon: asumir router salvo que sea 10.*
    elif wlan_ip:
        if wlan_ip.startswith("10."):
            tipo = "Hotspot Android"
        else:
            tipo = "Router Wi-Fi"

    # Datos móviles (interfaces tipo seth/rmnet/usb/wwan)
    elif any(name.startswith(("seth", "rmnet", "wwan", "usb")) for name in ifaces):
        tipo = "Datos móviles directos"

    # fallback
    else:
        tipo = "Desconocido"

    # Internet según IP externa
    if ip_externa:
        detalles.append("con Internet")
    else:
        detalles.append("sin Internet")

    return f"{tipo} ({', '.join(detalles)})"

if __name__ == "__main__":
    start = time.time()
    ip_externa = get_external_ip()
    ifaces = obtener_interfaces()
    estado = clasificar_conexion(ifaces, ip_externa)

    print("📡 Estado:", estado)
    for iface, ip in ifaces.items():
        print(f"💻 {iface}: {ip}")
    if ip_externa:
        print(f"🌎 IP externa: {ip_externa}")
    print(f"⏱ Tiempo de verificación: {time.time() - start:.2f}s")
