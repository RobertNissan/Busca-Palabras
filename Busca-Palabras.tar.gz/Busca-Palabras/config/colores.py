# Colores ANSI brillantes y con negrita fuerte
negro      = '\033[1;30m'       # Negro brillante
rojo       = '\033[1;31m'       # Rojo brillante e intenso
verde      = '\033[1;32m'       # Verde brillante
amarillo   = '\033[1;33m'       # Amarillo fuerte
azul       = '\033[1;34m'       # Azul brillante
morado     = '\033[1;35m'       # Magenta brillante (morado)
cian       = '\033[1;36m'       # Cian brillante
blanco     = '\033[1;37m'       # Blanco brillante

# Versiones con fondos llamativos (para avisos o títulos)
fondo_rojo      = '\033[1;41m'  # Fondo rojo brillante
fondo_verde     = '\033[1;42m'  # Fondo verde brillante
fondo_amarillo  = '\033[1;43m'  # Fondo amarillo fuerte
fondo_azul      = '\033[1;44m'  # Fondo azul brillante
fondo_morado    = '\033[1;45m'  # Fondo magenta brillante
fondo_cian      = '\033[1;46m'  # Fondo cian brillante
fondo_blanco    = '\033[1;47m'  # Fondo blanco brillante
fondo_negro     = '\033[1;40m'  # Fondo negro sólido

# Formatos
bold        = '\033[1m'         # Negrita
reset       = '\033[0m'         # Reset de color y formato
reset_bold  = '\033[22m'        # Reset solo de negrita
verde_bold  = '\033[1;32m'      # Verde brillante con negrita

# Ejemplos de uso
if __name__ == "__main__":
    print(f"{verde_bold}✔ Éxito:{reset} Aplicación instalada correctamente.")
    print(f"{fondo_rojo}{blanco} ✖ Error:{reset} No se pudo completar la instalación.")
    print(f"{fondo_amarillo}{negro} ⚠ Advertencia:{reset} Versión desactualizada.")
    print(f"{fondo_azul}{blanco}{bold} ℹ Info:{reset} Revisa las dependencias.")
