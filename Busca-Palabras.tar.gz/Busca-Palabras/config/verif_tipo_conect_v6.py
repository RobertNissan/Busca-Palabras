#!/usr/bin/env python3
import subprocess
import time
import re
import ipaddress
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
from typing import Optional

try:
    import requests
except Exception:
    requests = None

# --------------------- Config ---------------------
IP_SERVICES = [
    "https://ipinfo.io/ip",
    "https://icanhazip.com",
    "https://api.ipify.org",
    "https://ident.me",
    "https://ifconfig.me/ip",
    "https://checkip.amazonaws.com",
]

POLL_INTERVAL = 1.0
WINDOW_SIZE = 3
WINDOW_REQUIRED = 2
DEBUG = True

# --------------------- Funciones de red ---------------------
def is_valid_ip(ip_str: str) -> bool:
    try:
        ipaddress.ip_address(ip_str)
        return True
    except ValueError:
        return False

def get_ip_from_service(service_url: str, timeout: float) -> Optional[str]:
    if requests is None:
        return None
    try:
        parsed = urlparse(service_url)
        if parsed.scheme != "https":
            return None
        r = requests.get(service_url, timeout=timeout)
        ip = r.text.strip()
        return ip if is_valid_ip(ip) else None
    except Exception:
        return None

def get_external_ip_all(ifaces: dict) -> Optional[str]:
    """Consulta varios servicios en paralelo. 
       Más paciencia si hay solo VPN sin router.
       Respuesta rápida si hay router con/sin VPN.
    """
    if requests is None:
        return None

    has_vpn = any(name.startswith(("tun", "tap")) for name in ifaces)
    has_router = "wlan0" in ifaces and any(
        ifaces["wlan0"].startswith(p) for p in ("192.168.", "10.")
    )

    # --- Ajuste dinámico ---
    if has_vpn and not has_router:
        timeout = 5.0   # más paciencia (solo VPN)
        retries = 3
    else:
        timeout = 1.0   # más rápido (router presente)
        retries = 1

    for attempt in range(retries):
        ips = []
        with ThreadPoolExecutor(max_workers=len(IP_SERVICES)) as executor:
            futures = {executor.submit(get_ip_from_service, url, timeout): url for url in IP_SERVICES}
            for future in futures:  # <--- no timeout aquí
                try:
                    ip = future.result()  # ya tiene timeout interno
                    if ip:
                        ips.append(ip)
                except Exception:
                    continue

        if ips:
            return ips[0]

        if attempt < retries - 1:
            time.sleep(1.0)

    return None

def obtener_interfaces() -> dict:
    try:
        salida = subprocess.check_output(["ifconfig"], text=True)
    except:
        return {}
    interfaces = {}
    actual = None
    for linea in salida.splitlines():
        if not linea.startswith(" ") and ":" in linea:
            actual = linea.split(":")[0]
        elif "inet " in linea and actual:
            m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", linea)
            if m:
                interfaces[actual] = m.group(1)
    return interfaces

def clasificar_conexion(ifaces: dict, ip_externa: Optional[str]) -> str:
    tipo = "Desconocido"
    detalles = []

    if any(name.startswith(("tun", "tap")) for name in ifaces):
        detalles.append("VPN activa")

    wlan_ip = ifaces.get("wlan0")

    if any(ip.startswith("192.168.") for ip in ifaces.values()) and (wlan_ip and wlan_ip.startswith("10.")):
        tipo = "Hotspot Android"
    elif any(ip.startswith("172.20.10.") for ip in ifaces.values()):
        tipo = "Hotspot iPhone"
    elif ("wlan0" in ifaces) and any(ip.startswith("192.168.") for ip in ifaces.values()) and not any(ip.startswith("10.") for ip in ifaces.values()):
        tipo = "Router Wi-Fi"
    elif wlan_ip:
        tipo = "Hotspot Android" if wlan_ip.startswith("10.") else "Router Wi-Fi"
    elif any(name.startswith(("seth", "rmnet", "wwan", "usb")) for name in ifaces):
        tipo = "Datos móviles"

    detalles.append("con Internet" if ip_externa else "sin Internet")

    return f"{tipo} ({', '.join(detalles)})"


def generar_info_red(state) -> str:
    """
    Genera un texto formateado mostrando:
    - Estado de la red
    - Interfaces y sus IPs
    - IP externa (solo si existe)
    """
    lines = []

    ifaces = state.get("ifaces", {})
    ip_externa = state.get("ip_externa")

    # Estado de la red
    estado = clasificar_conexion(ifaces, ip_externa)
    lines.append(f"\n📡 Estado: {estado}\n")

    # Interfaces
    for iface, ip in ifaces.items():
        lines.append(f"💻 {iface}: {ip}\n")

    # Solo agregar IP externa si existe
    if ip_externa:
        lines.append(f"🌐 IP externa: {ip_externa}\n")

    return "".join(lines)  # devuelve todo en multilinea
    
# --------------------- Monitor de Internet ---------------------
def monitor_internet():
    window = deque(maxlen=WINDOW_SIZE)
    reported_state = None
    state = {}  # <-- Estado que guardará ifaces e ip_externa

    while True:
        ifaces = obtener_interfaces()
        ip_externa = get_external_ip_all(ifaces)
        ok = bool(ip_externa)
        window.append(ok)

        # Estado real basado en IP externa
        estado_real = "Con Internet" if ok else "Sin Internet"

        # Más exigente si hay VPN sin router (solo para detectar cambios)
        stable_window_required = WINDOW_REQUIRED
        if any(name.startswith(("tun", "tap")) for name in ifaces) and "wlan0" not in ifaces:
            stable_window_required = max(WINDOW_REQUIRED, 4)

        true_count = sum(window)
        stable = true_count >= stable_window_required

        # Actualizamos el estado
        state["ifaces"] = ifaces
        state["ip_externa"] = ip_externa

        ts = time.strftime("%Y-%m-%d %H:%M:%S")

        # Generar texto de info de red
        info_red = generar_info_red(state)

        if DEBUG:
            print(f"{ts} {estado_real} {info_red}")
        else:
            print(f"{ts} {estado_real}")

        # Solo notificamos cambios usando la ventana
        if reported_state is None or reported_state != stable:
            reported_state = stable
            print(f"*** Estado cambiado: {estado_real} ***")

        time.sleep(POLL_INTERVAL)

# --------------------- Main ---------------------
if __name__ == "__main__":
    try:
        monitor_internet()
    except KeyboardInterrupt:
        print("Monitor detenido por usuario.")