# 🎨 Colores intensos con negrita forzada (versión más gruesa posible)

negro      = '\033[1;90m'   # Negro intenso
rojo       = '\033[1;91m'   # Rojo neón
verde      = '\033[1;92m'   # Verde neón
amarillo   = '\033[1;93m'   # Amarillo neón
azul       = '\033[1;94m'   # Azul neón
morado     = '\033[1;95m'   # Magenta neón
cian       = '\033[1;96m'   # Cian neón
blanco     = '\033[1;97m'   # Blanco brillante puro

# Fondos brillantes (para destacar aún más)
fondo_rojo      = '\033[1;101m'
fondo_verde     = '\033[1;102m'
fondo_amarillo  = '\033[1;103m'
fondo_azul      = '\033[1;104m'
fondo_morado    = '\033[1;105m'
fondo_cian      = '\033[1;106m'
fondo_blanco    = '\033[1;107m'
fondo_negro     = '\033[1;100m'

# Formatos
bold        = '\033[1m'      # Negrita
bold_max    = '\033[1;97m'   # Negrita blanca pura (para simular mayor grosor)
reset       = '\033[0m'      # Reset total
reset_bold  = '\033[22m'     # Quita solo negrita
verde_bold  = '\033[1;92m'   # Verde neón con negrita

# 💡 Ejemplo de demostración visual
if __name__ == "__main__":
    print(f"{verde_bold}✔ Aplicación instalada correctamente{reset}")
    print(f"{rojo}{bold}✖ Error crítico: instalación fallida{reset}")
    print(f"{amarillo}{bold}⚠ Advertencia: versión antigua detectada{reset}")
    print(f"{azul}{bold}ℹ Info: actualización disponible{reset}")
    print(f"{morado}{bold}☉ Actualización importante disponible{reset}")
    print(f"{bold_max}Texto con negrita máxima (blanco intenso){reset}")
