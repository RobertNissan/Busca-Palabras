#!/bin/bash
#apt update
#apt upgrade
#apt install tsu
#pkg install fish -y
# fish
#codigo busca correo: "[0-Z._]+@[0-Z]+\.[a-Z]+"
#codigo busca la hora: [0-9]{2}:[0-9]{2}:[0-9]{2}
# [0-9]{2} esta expresion le dice al motor de busqueda que encuentre dos digitos contiguos.
#Un caracter que no sea ninguno de los incluidos: [^A-Z]
#busca todos los parrafos que comiencen con un numero: ^[0-9]
#Mostrara en pantalla todas las lineas que/comiencen con las vocales en minusculas  ^[aeiou] (Puedes cambiar a mayusculas o ambas 
#Busca todas las lineas que terminen en algun numero dado en el intervalo de 0 a 3  [0-3]$
#Este codigo te busca una palabra en un archivo y te la reemplaza por la segunda grep -rl 'bultico' /sdcard/backups/apps/ | xargs sed -i 's/bultico/palabra2/g'
# \?  Este signo nos permitira especificar que parte de la busqueda es opcional: jali\?o\?s (busca jalis o jalos)
# Este codigo hace tabulacion de espacios echo -e "\t Hello World!"

#Cambiar de Mayuscula a Minusculas
#w="$(echo $exacta | sed 's/[a-z]/\U&/g')"
#w="$(echo $exacta | tr [:upper:] [:lower:])"

#termux-open https://www.facebook.com/speed.robert
#clean cache
#du -had1

#Cambiar el  numero en for y asi cambia de color "nota: no funciona como super usuario este codigo, error tput
#B=`tput bold` #BOLD
#D=`tput dim` #DIM
#U=`tput sgr 0 1` #UNDERLINE
#U2=`tput smul` #UNDERLINE2
#NU=`tput rmul` #NO UNDERLINE H=`tput smso` #HIGHLIGHT
X=`tput sgr0` #RESET
#C='tput setaf ' #COLOR
#for i in 2; do c=`$C$i`;
#color=$(echo $c${B}${U}$NU$D${U2}$NU$c${H})
#uselo asi $color"Palabra a colorear"$X


#Codigo para centrar texto "nota: no funciona como super usuario este codigo, error tput
print_center(){
    local x
    local y
    text="$*"
    #x=$(( ($(`tput cols`) - ${#text}) / 2))
    echo -ne "\E[6n";read -sdR y; y=$(echo -ne "${y#*[}" | cut -d';' -f1)
    echo -ne "\033[${y};${x}f$*"
}

# main()

# Color del texto que imprimira 
echo -ne "\\033[2J\033[0;1f\e[32m"

#fin Codigo para centrar texto
#print_center 'Aqui texto a centrar'

choice=1
rojo='\e[1m\e[31m'
azul="\e[34m\e[0m"
verde='\e[1m\e[32m'
verde2='\033[32m'
white="\e[1;37m\e[0m"
azulluz="\e[1;34m\e[0m"
azulcielo='\e[1m\e[36m'
#mezcla color
mzv=$(echo -e ${white}${verde2})
mza=$(echo -e ${azulcielo}${blanco})
rosa="\033[38;5;207m"
#rojo='\033[30.1m'
#amarillo='\033[33m'
#azul='\033[34m'
#morado='\033[35m'
#blanco='\033[37m'
#cyan='\033[0.1;36m'
#magenta='\033[0.1;35m'

# El uso del colo azul luz los estoy usando asi con la palabra dentro "\e[1;34m"palabra"\e[0m"
# cuando se usa con un echo -e "--palabra--"
# debes anadir quitar las comillas al principio y al final de este codigo color
# Quedaria asi!!! 
# echo -e "--\e[1;34m"palabra"\e[0m--"

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE"
	
sudo rm -r /data/data/com.termux/files/home/091184.sh


else

clear

fi

clear

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE"
	

rm -r /data/data/com.termux/files/home/091184.sh

fi

rm -r /data/data/com.termux/files/home/Install-Busca-Palabras.sh

clear
# Mensaje a la salida estandard
clear
#bus=$(dialog --title 'Busca-Palabras' --stdout --inputbox "     Escribe la palabra a buscar:" 7 40)
echo -e ""
#print_center 'Robert Nissan'
echo -e " \t    Autor: Robert Nissan"
echo -e "\t +------------------------+"
echo -en "$white"
echo -e '\t #-----BUSCA_PALABRAS-----#'
echo -en "$verde2"
echo -e "\t +------------------------+"

echo -en "${verde2}+---------------------------------------+
#"$white" Para encontrar varias palabras        ${verde2}#
#"$white" puedes hacer asi!!!                   ${verde2}#
#"$azulcielo""$rojo" palabra1"$azulcielo"|"$rojo"palabra2"$azulcielo"|"$rojo"palabra3 "$azulcielo"etc.       ${mzv}#
#"$white" puedes seguir insertando mas palabras "$verde2"#
#"$white" siempre y cuando agregues esto: "$azulcielo"|     ${mzv}#
#"$white" despues de cada palabra!!!            "$verde2"#
+---------------------------------------+
+------------------------+
#---$white"ESCRIBA LA PALABRA"${verde2}---#
+------------------------+
+->>> "${mza}
read -r bus
clear
echo -e ""
int="$(echo -e "\e[4;4m>>\e[0m")"
#metiendo los colores en otra variable para que funcionen en este "for" #Nota: la opcion -n es la clave para eso!
r=$(echo -ne "$rojo")
b=$(echo -ne "$white")
a=$(echo -ne "$azulcielo")
sub="\e[4;1mW\e[0m"
srn=$(echo -en "$sub")
ent="\e[4;1mE N T E R\e[0m"
enter=$(echo -en "$ent")
for x in "$a"1")""$b"E s c r i b a" "l a" "l e t r a" ${r}"$srn""$b" "p a r a" "p a l a b r a" "e x a c t a; do
echo -n $x
sleep .00
done
echo -e "  "
echo -e ""
for a in "$a"2")""$b"$color O p c i o n - r e c o m e n d a d a$X; do
echo -n $a
sleep .00
done
echo -e " "
for z in P r e s i o n a" "$r""$enter""$b" "p a r a" "r e l l e n a r" "l o s" "c a r a c t e r e s; do
echo -n $z
sleep .00
done
echo -e " "
for x in f a l t a n t e s" "d e" "l a" "p a l a b r a . . . ; do
echo -n $x
sleep .00
done
echo -e " "
echo -e "$rojo$bus$azulcielo+"$white"caracteres" 
echo -e "$azulcielo"

#read -p "Escribe el segundo argumento:" 'dos'
#echo -e "Escriba la letra"$rojo "w "$white" para palabra exacta"
exacta="a"
echo -e "              +-------------+           |
+----------<<<# ["$white"W"$verde2"] | "$rojo"ENTER "$verde2"#<<<--------+
|             +-------------+
|"
read -p "+->>> " "exacta"
echo -e "$white"

w="$(echo -e "$exacta" | tr [:upper:] [:lower:])" &> /dev/null 2>&1


if [ "$w" = "w" ]; then

exa=$(echo -e "Espere mientras buscamos la palabra exacta:")
pal=$(echo -e "$rojo""$bus")

else
#var='abc def'
#echo "$var"
#abc def
## Note: flussence's original expression was "${var/ /}", which only replaced the *first* space char., wherever it appeared.
#echo -n "$ {var//[[:space:]]/}"
#if [ $w != w ]; then

#transforma cualquier caracter a n
w="$(echo -e '$exacta' | xargs sed -i 's/$exacta/"n"/g')" >/dev/null 2>&1

car="$(echo -e "Espere mientras buscamos la palabra:")"
pal="$(echo -e "$rojo$bus$azulcielo+"$white"caracteres")"
fi
#fi



echo "________________________________________________"
echo -e ""
echo -e "${mzv}"
echo Escribe cuantas lineas quieres que aparezcan
echo -e "antes y despues de la palabra que se encuentren en el texto:"
echo -e ""
echo -e "$white"
echo -e "Elija un numero:"
echo -e "$azulcielo"[0]$b"Recomendado" 
echo -e "$azulcielo"[1]$b"O mayor opcional"
echo -e ""

read -p ""$int" " nl
while [[ -n "$nl" && "${nl//[0-9]}" ]]; do
if [ "$nl" == [[:blank:]] ]; then
# si nl es igual a espacio entonces transformalos en 0
nl="$(echo -e '$nl' | xargs sed -i 's/$nl/"0"/g')" >/dev/null 2>&1
else
    echo -e ""
    echo "Ingrese solo numeros enteros:"
    echo -e "Elija un numero:"
echo -e "$azulcielo"[0]$b"Recomendado" 
echo -e "$azulcielo"[1]$b"O mayor opcional"
echo -e ""
    read -p ""$int" " nl
    if [ "$nl" == [[:blank:]] ]; then
    # si nl es igual a espacio entonces transformalos en 0
nl="$(echo -e '$nl' | xargs sed -i 's/$nl/"0"/g')" >/dev/null 2>&1
    fi
    fi
done


echo -e ""
echo -n "Selecciona la ruta que desees!!!"
echo -e  ""
echo -e  ""
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""
# Bucle while 
while [ $choice = "1" ]; do

read -p "$int " choice
clear
if [[ $choice == r || $choice == R ]]; then
echo -e "" 
echo "Elegiste la raiz del dispositivo"
echo -e "$exa""$car"
echo -e "$pal"

echo -e "\e[1;37m\e[0m"
echo -e  ""
# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo
echo -e "\t ""$azulcielo"\Busqueda Recursiva De Ficheros""
echo -e "$white"
echo -e "find -type f | time xargs grep -EIHrins"$w" '"$bus"' --color --context=$nl /data/misc/wifi/" >> /data/data/com.termux/files/home/091184.sh
#la palabra debe estar protegida por token 
#       ' "$bus" '      los token deben estar pegados, asi de esta forma se creara el archivo reconociendo los simbolos \|

#grep -- 'foo*'\''bar' *.txt

if [ -e "$fichero" ];
then

su -c bash /data/data/com.termux/files/home/091184.sh
su -c rm -r /data/data/com.termux/files/home/091184.sh
fi

if [ -e "$fichero" ] ; then
bash /data/data/com.termux/files/home/091184.sh
rm -r /data/data/com.termux/files/home/091184.sh
fi

else

if [[ $choice == i || $choice == I ]]; then
echo -e ""
echo "Elegiste la interna sdcard"
echo -e "$exa""$car"
echo -e "$pal"
echo -e "\e[1;37m\e[0m"

# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo
#bash /sdcard/091184.sh;su;bash /sdcard/091184.sh;
#sudo bash /sdcard/091184.sh
#sudo rm -r /sdcard/091184.sh
#exit
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
UserDir="$(echo /sdcard/)"
eval cd "$UserDir"
time find -type f | grep -EIHrins"$w" "$bus"  --color --context=$nl "$PWD"/

else
if [[ $choice == e || $choice == E ]]; then

# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo en los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo


echo -e "\e[1;37m\e[0m"

clear
#cd /mnt/media_rw/;su;cd /mnt/media_rw/;
misd=$(ls /mnt/media_rw/)
misd=$(su -c ls /mnt/media_rw/)
echo -e ""
clear
echo -e ""Elegiste la externa sdcard-"\e[1;34m"$misd"\e[0m"
echo -en "$white"
echo -e "$exa""$car"
echo -e "$pal"
echo -e "\e[1;37m\e[0m"
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
time find  -type f | xargs grep -IEHrins"$w" "$bus" --color --context=$nl /mnt/media_rw/$misd/

else
clear
echo -n "Selecciona la ruta que desees!!!"
echo -e ""
echo "Usa las letras "
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""

choice=1

fi
fi
fi
done;
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit