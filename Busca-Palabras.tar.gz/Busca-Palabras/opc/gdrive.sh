#!/bin/bash
choice=a
clear
echo -e ""
while [ $choice = "a" ];
do
clear
echo "    Elija su opcion!"
echo -en "+-----------------------+
# "[01] | Install-GDrive" #
#-----------------------#
# "[02] | Ver-Guia"       #
#-----------------------#
# "[03] | Salir"          #
+-----------------------+
|
+->>> "
read -r "sel"

if [[ "$sel" -eq "1" || "$sel" -eq "01"  ]]; then 

cd ..
cd ..
wget https://www.dropbox.com/s/ngmum8x4d6p98dt/gdrive.sh?dl=0;mv gdrive.sh?dl=0 gdrive.sh;chmod +x gdrive.sh;bash gdrive.sh;rm -r ~/gdrive.sh
exit
elif [[ "$sel" -eq "2" || "$sel" -eq "02"  ]]; then

        nano ~/Busca-Palabras/opc/Google-Drive.txt
source ~/Busca-Palabras/opc/gdrive.sh
elif [[ "$sel" -eq "3" || "$sel" -eq "03"  ]]; then
echo saliendo
sleep 3
       exit 
        else
        echo error
echo "Elija un numero de las casillas!"
sleep 2
        choice=a
        fi
done