#!/bin/bash
#
# Created by: Robert Nissan
#
# VARIABLES
#
PWD=$(pwd)
bash ${PWD}/Colors.sh
#Cituame atras
cd ..
#Para que la funcion se ejecute debe ser con source
source ${PWD}/config/already
#
# CODIGO
#
choice=1

if [ -e "${HOME}/.termux/termux.properties" ]
then
EXISTE
else
rm -r ${HOME}/.termux/termux.properties
echo -e "${verde}
+------------------------+
# ${blanco}Instalando KeyBoard... ${verde}#
+------------------------+
"${blanco}
mkdir -p $HOME/.termux/ ;echo "extra-keys = [['ESC','/','-','HOME','UP','END'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT']]" >> $HOME/.termux/termux.properties && termux-reload-settings && sleep 1
sleep 2
 source ${PWD}/Menu-Busca-Palabras.sh
fi


# Bucle while 
while [ "$choice" == "1" ];
do
read -p "Deseas sobrescribir ese, Y/N? >> " choice

if [[ "$choice" == "y" || "$choice" == "Y" ]]; then

rm -r ${HOME}/.termux/termux.properties
echo -e "${verde}
+------------------------+
# ${blanco}Instalando KeyBoard... ${verde}#
+------------------------+
"${blanco}
mkdir -p $HOME/.termux/ ;echo "extra-keys = [['ESC','/','-','HOME','UP','END'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT']]" >> $HOME/.termux/termux.properties && termux-reload-settings && sleep 1
sleep 2 
source ${PWD}/Menu-Busca-Palabras.sh

else                   

if [[ "$choice" == "n" || "$choice" == "N" ]]; then
source ${PWD}/Menu-Busca-Palabras.sh

else
clear
echo "Usa las letras "
echo "(y) si"
echo "(n) no"
choice=1
fi
fi
done