#quitar caracteres especiales de archivos
#elimina todo lo que no empiece con A-Za-z0-9._-
#sed -e 's/[^A-Za-z0-9._-]/ /g' 
IFS='
'
for file in $(ls -p | grep -v /);
	do
	file=$(echo "$file")
	mv "$file" $(echo "$file" | sed -e 's/_/ /g' | xargs echo -n | sed -e 's/[^A-Za-z0-9._-]/ /g' | xargs echo -n)
	done
	ls
	
	
	
	
opcion 2



screenfetch >> adq.txt
ndc=$(sed -n "5p" adq.txt | cut -c 94- | sed "s/....$//g") 
#eliminar estos simbolos ()[]^,.:;\* 
ndc=$(echo "${ndc//[()\[\]\^,.:;\\*]/}")
#reemplaza los espacio entre palabras por guion _
ndc=$(echo "${ndc//[ ]/_}")
echo $ndc