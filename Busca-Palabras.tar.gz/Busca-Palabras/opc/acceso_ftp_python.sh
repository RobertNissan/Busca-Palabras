#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep -w 'Servidor_FTP.py' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1
pkill -f Servidor_FTP.py || true

cx=connection
awh=wifihost

PWD=$(pwd)
connection=wifihost

if [ -x ${PREFIX}/bin/python ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando python"
    apt install python -y
fi
if [ -x ${PREFIX}/bin/python3 ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando python3"
    apt install python3 -y
fi
if [ -x ${PREFIX}/lib/*/*/pyftpdlib ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando pyftpdlib"
    pip install pyftpdlib
fi
if [ -x ${PREFIX}/lib/*/*/netaddr ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando netaddr"
    pip install netaddr
fi

#---------------------------------------------------------------------------#
# Buscar $cx=$awh en el archivo acceso_ftp_python.sh
wh=$(grep -E "$cx=" ~/Busca-Palabras/opc/acceso_ftp_python.sh | head -n 1)
# Si esta eso en ese archivo entonces listo ok
if [ "$wh" = ""$cx"="$awh"" ]; then
    echo -e "wifihost existe" >/dev/null 2>&1
else
    #Si no se encuentra escribelo
    sed -i "s%$wh%$cx=$awh%g" ~/Busca-Palabras/opc/acceso_ftp_python.sh
    connection=wifihost
fi

#Si esta escrito entonces activa el archivo $connection para verificar si hay conexion wifi o hostpot
if [ -f ${PWD}/config/$connection ]; then 
    source ${PWD}/config/$connection 
    $connection
fi
#Si no hagas nada
#--------------------------------------------------------------------------#
esd=a
while [ "$esd" == "a" ]; do
    clear 
    echo -e ""
    echo -e -n "   ${verde} Elija la ruta a compartir"
echo -e -n "${verde}
+--------------------------------+
# ["$blanco"01"$verde"] | "$blanco"termux /home/           ${verde}#
#--------------------------------#
# ["$blanco"02"$verde"] | "$blanco"Interna /sdcard/        ${verde}#
#--------------------------------#
# [${blanco}03${verde}] | ${blanco}Externa /sdcard/        ${verde}#
#--------------------------------#
# [${blanco}04${verde}] | ${blanco}Menu anterior           ${verde}#
+--------------------------------+
|
+->>> "${blanco}
    read -p "> " esd
    case $esd in

        1|01)
            disco="'/data/data/com.termux/files/home/'"
            A=$(grep -EIris 'RUTA =' ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py)
            B=$(echo "$A" | cut -d' ' -f3)
            sed -i "s%$B%$disco%g" ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py
            echo -e ""
            clear
            echo -e ""Directorio compartido "\e[1;34m"$disco"\e[0m"
            cd ~/Busca-Palabras/opc/Servidor_FTP_Python/
            python Servidor_FTP.py
            pkill -f Servidor_FTP.py
            esd=a
            ;;
            
        2|02)
            disco="'/sdcard/'"
            A=$(grep -EIris 'RUTA =' ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py)
            B=$(echo "$A" | cut -d' ' -f3)
            sed -i "s%$B%$disco%g" ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py
            echo -e ""
            clear
            echo -e ""Directorio compartido "\e[1;34m"$disco"\e[0m"
            cd ~/Busca-Palabras/opc/Servidor_FTP_Python/
            python Servidor_FTP.py
            pkill -f Servidor_FTP.py
            esd=a 
            ;;
            
        3|03)
            if [ -f /storage/sdext/.micro ]; then
                disco=sdext
            else
                echo -e "\e[1;37m\e[0m"
                cambio=1
                clear
                echo -e ""
echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
                read -r disco
                clear
                while [ -z "$disco" ]; do
                    clear
                    echo -e ""
echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
                    read -r disco
                done
            fi

            UserDir="$(echo /storage/${disco}/)"
            eval cd "$UserDir"
            x="$(echo $PWD)"
            tez=/storage/$disco

            if [ "$x" == "$tez" ]; then
                UserDir="$(echo /storage/${disco}/)"
                eval cd "$UserDir"
                touch /storage/$disco/.$disco
                
                #-------------------------------------------------------------------------
                # Buscar está línea en el archivo acceso_ftp_python.sh la primera en el archivo. sería esto: if [ -f /storage/sdext/.micro ]; then
                A=$(grep -EIris "/storage/sdext/.micro" ~/Busca-Palabras/opc/acceso_ftp_python.sh | head -n 1)
                # Obtenemos su posición que está a 16 espacio en blancos en la fila de este archivo sería esto: /storage/sdext/.micro
                B=$(echo "$A" | cut -d' ' -f16)
                # Reemplaza por esto según la sdexterna
                sed -i "s%$B%/storage/$disco/.$disco%g" ~/Busca-Palabras/opc/acceso_ftp_python.sh
                #-------------------------------------------------------------------------

                #-------------------------------------------------------------------------
                # Buscar está línea en el archivo acceso_ftp_python.sh la primera en el archivo. sería esto: disco=sdext
                C=$(grep -EIris "disco=sdext" ~/Busca-Palabras/opc/acceso_ftp_python.sh | head -n 1) 
                # Obtenemos su posición que está a 17 espacio en blancos en la fila de este archivo
                D=$(echo "$C" | cut -d' ' -f17)
                # # Reemplaza por esto según la sdexterna
                sed -i "s%$D%disco=$disco%g" ~/Busca-Palabras/opc/acceso_ftp_python.sh
                # Buscamos la línea donde diga Ruta del archivo
                E=$(grep -EIris 'RUTA =' ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py) 
                disco="'/storage/$disco/'"
                # obtener su posición en la fila: caso normal sería RUTA = '/sdcard/' pero se obtiene solo: '/sdcard/'
                F=$(echo "$E" | cut -d' ' -f3)
                # Escribimos la ruta directamente en el archivo Servidor_FTP.py
                # Se remplaza 'sdcard' por la sdexterna si acaso existen, en mi ejemplo es: '/storage/A60E-06CA/'
                sed -i "s%$F%$disco%g" ~/Busca-Palabras/opc/Servidor_FTP_Python/Servidor_FTP.py
                #---------------------------------------------------------------------

                echo -e ""
                clear
                echo -e ""Directorio compartido "\e[1;34m"$disco"\e[0m"
                cd ~/Busca-Palabras/opc/Servidor_FTP_Python/
                python Servidor_FTP.py

                #-----borrar wifihost de acceso_ftp_python.sh------#
                bwh=$(grep -EIrisn ""$cx"="$awh"" ~/Busca-Palabras/opc/acceso_ftp_python.sh | head -n 1)
                hwb=$(echo "${bwh%:*}")
                #echo $hwb
                hw=$(sed -n "${hwb}p" ~/Busca-Palabras/opc/acceso_ftp_python.sh)
                # echo $hw
                if [ "$hw" = ""$cx"="$awh"" ]; then
                    sed -i "s%$hw%$cx=%g" ~/Busca-Palabras/opc/acceso_ftp_python.sh
                fi 

                cd  ~/Busca-Palabras/opc/
                bash acceso_ftp_python.sh
            else
                clear
                echo -e ""
                echo "SDCARD EXTERNA NO ENCONTRADA"
                echo "INSERTA UNA MICROSDCARD"
                echo -e "O INSERTE BIEN EL NOMBRE!!!\n"
                read -n 1 -p "Presione cualquier tecla para ir regresar"
                pkill -f Servidor_FTP.py
                esd=a
            fi
            ;;
            
        4|04)
            cd ${HOME}/Busca-Palabras/opc
            bash acceso_local_remoto.sh
            break
            ;;
            
        *) echo "opcion invalida";sleep 1;clear;esd=a
            ;;
    esac
done
exit
# A60E-06CA