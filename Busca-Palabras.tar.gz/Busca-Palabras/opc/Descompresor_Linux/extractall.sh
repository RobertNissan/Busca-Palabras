extract() {
  for archive in *; do
   read -p "ingresa archivo a descomprimir > " archive
    if [ -f $archive ]; then
      case $archive in
        *.tar.bz2)
	  tar xvjf $archive
	;;

        *.tar.gz)
	  tar xvzf $archive
	;;

        *.bz2)
	  bunzip2 $archive
	;;

        *.rar)
	  rar x $archive
	;;

        *.gz)
	  gunzip $archive
	;;

        *.tar)
	  tar xvf $archive
	;;

        *.tbz2)
	  tar xvjf $archive
	;;

        *.tgz)
	  tar xvzf $archive
	;;

        *.zip)
	  unzip $archive
	;;

        *.Z)
	  uncompress $archive
	;;

        *.7z)
	 b7z x $archive
	;;

        *)
	  echo "don't know how to extract $archive..."
	;;
      esac
    else
      echo "$archive is not a valid file!"
    fi
   exit
  done
}

extract
