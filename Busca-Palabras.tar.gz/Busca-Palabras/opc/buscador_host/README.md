#Nombre del script: Irparpayana

#Significado: Acompanar a uno hasta ponerlo en camino 

#Lengua: Aymara - Peru

#NAME SCRIPT: Irparpayana

#Irparpayana meaning = Accompany one to put it on the road.

#Language: Aymara - Peru 

#Domingo 09/12/2018
#Martes 15/01/2019
#by: real strategy / rwam
#Edit: 01/03/2022 / Todo Real

#Script disenado para la extraccion de url de paginas web, Mostrar los estatus que arrojan cada uno de dichos host y analizar los servicios que brinda con un scan usando nmap 

LISTA DE SERVICIOS:

- SCAN DE HOST (HTTP/SSL)
- MUESTRA EL STATUS WEB (200/301)
- OPCION DE CAMBIAR IDIOMA ESPANOL Y INGLES
- GENERADOR DE PAYLOAD AVANZADOS
- MUESTRA PUERTOS DE CUALQUIER DOMINIO
- MUESTRA INFORMACION DE IP Y PROXYS
- RASTREO DE IP Y GEOLOCALIZACION

PASO Ndeg1

#Instalar paquetes para el buen inicio del script

apt update && apt upgrade -y

pkg install nmap

pkg install wget

pkg install curl

pkg install git


PASO Ndeg2

#Instalar el script host-extractor-v2

git clone https://github.com/HackeRStrategy/Irparpaya-a.git

cd Irparpaya-a

chmod +x real-host-v2.sh

bash real-host-v2.sh



DATOS:

CANAL TELEGRAM:

https://t.me/RealHackRWAM

GRUPO TELEGRAM:

https://t.me/RealStrategyRS

CANAL YOUTUBE:

https://youtube.com/RealHackRWAM

GRUPO FACEBOOK:

https://web.facebook.com/groups/nuncadejesdeaprender


PRESIONA UNA ENTER PARA CONTINUAR...
