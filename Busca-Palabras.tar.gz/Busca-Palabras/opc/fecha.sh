#!/bin/bash
#date +"Hoy %A, %d de %B"
        dia=$(date +"%A")
        #echo "$dia"
if [ $dia = Monday ]; then
       d=$(echo Lunes)
fi
if [ $dia = Tuesday ]; then
       d=$(echo Martes)
fi
if [ $dia = Wednesday ]; then
       d=$(echo Miercoles)
fi
if [ $dia = Thursday ]; then
       d=$(echo Jueves)
fi
if [ $dia = Friday ]; then
       d=$(echo Viernes)
fi
if [ $dia = Saturday ]; then
       echo Sabado
fi
if [ $dia = Sunday ]; then
       d=$(echo Domingo)
fi
mes=$(date +"%B")
if [ $mes = January ]; then
       m=$(echo Enero)
fi
if [ $mes = February ]; then
       m=$(echo Febrero)
fi
if [ $mes = March ]; then
       m=$(echo Marzo)
fi
if [ $mes = April ]; then
       m=$(echo Abril)
fi
if [ $mes = May ]; then
       m=$(echo Mayo)
fi
if [ $mes = June ]; then
       m=$(echo Junio)
fi
if [ $mes = July ]; then
       m=$(echo Julio)
fi
if [ $mes = August ]; then
       m=$(echo Agosto)
fi
if [ $mes = September ]; then
       m=$(echo Septiembre)
fi
if [ $mes = October ]; then
       m=$(echo Octubre)
fi
if [ $mes = November ]; then
       m=$(echo Noviembre)
fi
if [ $mes = December ]; then
       m=$(echo Diciembre)
fi
echo -e ""
date +"Hoy es $d, %d de $m"
echo -e ""
read -s -n 1
cd ..
source ${PWD}/Menu-Busca-Palabras.sh
