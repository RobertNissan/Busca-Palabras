#!/bin/bash

R='\033[1;31m'
G='\033[1;32m'
Gok='\033[92m'
Gli='\e[1;32m'
Y='\033[1;33m'
B='\033[1;34m'
M='\033[1;35m'
C='\033[1;36m'
W='\033[0m'

#El code en variable
cod=Um9iZXJ0Tmlzc2Fu
#El decode en variable
dec="base64 -d"
#Creando variable de archivo temporal
file=$(mktemp)
#Crea un archivo con la codificacion
echo "$cod" > $file
#Aqui se decodifica en una variable
oculta=$($dec $file)
#echo "${file%/*}" #Este solo toma la ruta
x=$(echo "${file##*/}") #Toma el nombre del archivo
rm -rf $file

if [ -e ${PWD}/.ca ]; then
eca=$(sed -n '$p' .ca) #>/dev/null 2>&1)
fi
if [ "$cod" != "$eca" ]; then
clear
echo -e "${G}+------------------------+
# ${W}Si actualizo el script ${G}#
# ${W}recomiendo guardar!    ${G}#
+------------------------+"
rm -rf .ca
read
fi

while true
do
clear
echo -e ""
echo -e " ${M}  SCRIPT CONTRASENA BY ROBERT NISSAN"
echo -en "${G}+-------------------------------------+
# "[${W}01${G}] | ${W}Entrar al script"             ${G}#
#-------------------------------------#
# "[${W}02${G}] | ${W}Guardar contrasena actual"    ${G}#
#-------------------------------------#
# "[${W}03${G}] | ${W}Ver contrasena actual"        ${G}#
#-------------------------------------#
# "[${W}04${G}] | ${W}Cambiar contrasena"           ${G}#
#-------------------------------------#
# "[${W}05${G}] | ${W}Volver al menu principal"     ${G}#
+-------------------------------------+
|
+->>> "${W}
read -r "sn"
clear
echo -e ""
case $sn in
		
     1|01)
#Codigo para centrar texto "nota: no funciona como super usuario este codigo, error tput
print_center(){
    local x
    local y
    text="$*"
    x=$(( ($(tput cols) - ${#text}) / 2))
    echo -ne "\E[6n";read -sdR y; y=$(echo -ne "${y#*[}" | cut -d';' -f1)
    echo -ne "\033[${y};${x}f$*"
}
#main()
# Color del texto que imprimira print_center
echo -ne "\\033[2J\033[10;1f\e[1;35m"


for a in $(seq 1 5); do
clear
echo -en "$M"
#fin Codigo para centrar texto
print_center "ROBERT NISSAN\n"
echo -e ""
        printf "$Y[ESCRIBA LA CONTRASENA PARA INGRESAR]\n\t"
read -s -p " -------> " seguridad

if [ "$seguridad" = "$oculta" ]; then
for i in I N G R E S O" "C O M P L E T A D O; do
         sleep .00
         echo -n $i
    done
echo -e ""
echo -e ""
if [[ -e $file ]]; then
        rm -rf $file
        echo -e "$x fue eliminado\n"
        exit 0
fi
        #echo -e "$x No encontrado\n"
        cd ..
        source config/android
        android
exit
fi

if [ $a = 5 ]; then
       cd ${PWD}
       echo -e "$R"CAMBIAR LA CONTRASENA"\n"
       printf "$C[ESCRIBA LA ANTIGUA CONTRASENA]\n\t"
       if [ -e ${PWD}/.ca ]; then
       dcode=$(base64 -d .ca)
       pxv=$(echo "$dcode" | sed -n '$p')
       sdec=$(sed -n '$p' .ca)
       vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p') 
       fi
       #sdec=$(sed -n '$p' .ca)
       #echo $pxv
       read -s -p " -------> " seguridad
       echo "$seguridad" > .seg
       enc=$(base64 .seg) && rm -rf .seg
       #vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p')
       #echo $vsc
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       int=$(echo "${antigua##*cod=}")
       #echo $int
       echo "$int" > .sec
       sa=$(base64 -d .sec) && rm -rf .sec
       
       if [[ "$seguridad" == "$sa" || "$enc" == "$int" ]]; then
       echo -en "$M"CORRECTO""
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       rm -rf .pass
       echo -e "\n"
       printf "$Gok[ESCRIBA LA NUEVA CONTRASENA]\n\t"
       echo -en " -------> $M"
       read new
       echo "$new" > .pass
       ecod=$(base64 .pass) && rm -rf .pass
       sed -i 's|'$antigua'|'cod=$ecod'|g' contrasena-cod.sh
       
       ext=$(head -n 1 .ca)
       echo "$ext" > .ca
       echo "$ecod" >> .ca
       
       if [ -z "$new" ]; then
       echo -e ""
       echo -e "$B"ESTADO ACTUAL - SIN CONTRASENA!!!"\n"
       vac=$(grep -o "Cg==" .ca)
       va=$(echo "U0lOIENPTlRSQVNFw5FBCg==" | cut -d' ' -f2-)
       echo "$va" >> .ca
       echo "$vac" >> .ca
       read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
       fi
#subir la clave a ftp nube
#o bajar el script que me cambien el code
      echo -e ""
      echo -e "$B"CONTRASENA MODIFICADA"\n"
     read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
    fi
  echo -e "$R"CONTRASENA INCORRECTA"\n"
 sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
fi
 
echo -e "$R"REPITA LA CONTRASENA$W""
    #echo test >> $a.txt;
       printf "$R\t -------> INTENTO NUMERO $a$W\n"
     sleep 0.9900
done
;;

       2|02) 
      if [ -e ${PWD}/.ca ]; then
      echo -e "$M   YA EXISTE UNA COPIA DE SEGURIDAD!"
      echo -en "${G}+-------------------------------------+
# "[${W}01${G}] | ${W}Borrar la contrasena"         ${G}#
#-------------------------------------#
# "[${W}02${G}] | ${W}Borrar la copia"              ${G}#
#-------------------------------------#
# "[${W}03${G}] | ${W}Cambiar la respuesta secreta" ${G}#
#-------------------------------------#
# "[${W}04${G}] | ${W}Volver al menu principal"     ${G}#
#-------------------------------------#
# "[${W}05${G}] | ${W}Volver al menu app premium"   ${G}#
#-------------------------------------#
# "[${W}06${G}] | ${W}Salir"                        ${G}#
+-------------------------------------+
|
+->>> "${W}
      read sel
      
      
     if [[ "$sel" == "1" || "$sel" == "01" ]]; then
      clear
      cd ${PWD}
      echo -e "$R\t"SOBRESCRIBIR COPIA"\n"
      echo -e "$R\t"BORRAR LA CONTRASENA"\n"
      printf "$C[Nombre de tu maestr@ favorito:]\n\t"
      read -s -p " -------> " maes
      echo -en "$W"
      mast=$(base64 -d .ca) #listo
      prx=$(sed -n '1 p' .ca)
      mast=$(echo -e "$mast" | cut -d' ' -f1- | head -n 1)
      sob=$(sed -n '1 p' .ca)
      #echo $ini
      antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
      sr=$(sed 's|Cg==|SIN RESPUESTA|g' .ca | sed -n '1 p')
       xpr=$(echo -e "$prx$sr")
       echo "$maes" > .resca
       codr=$(base64 .resca) && rm -rf .resca
      rm -rf .pass
      if [[ "$codr" == "$sob" || "$sr" == "$xpr" ]]; then
      echo -en "$M"CORRECTO""
      rm -rf .pass
      echo -e "\n"
      cd ${PWD}
      echo Ok
      pri=$(tail -n 1 .ca)
      #echo $pri
      echo "$new" > .pass
      ecod=$(base64 .pass) && rm -rf .pass
       sed -i 's|'$antigua'|'cod=$ecod'|g' contrasena-cod.sh
       if [ -e ${PWD}/.ca ]; then
       ext=$(sed -n '1 p' .ca)
       echo "$ext" > .ca
       echo "$ecod" >> .ca
       fi
      # if [ -z "$maes" ]; then
       echo -e ""
       echo -e "$B"ESTADO ACTUAL - SIN CONTRASENA!!!"\n"
       vac=$(grep -o "Cg==" .ca)
       va=$(echo "U0lOIENPTlRSQVNFw5FB" | cut -d' ' -f2-)
      # echo "$ext" >> .ca
      # echo "$va" >> .ca
       read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
      # fi
       
     # exit
      fi  
    fi
      if [[ "$sel" == "2" || "$sel" == "02" ]]; then
      printf "$C[ESCRIBA LA ANTIGUA CONTRASENA]\n\t"
       if [ -e ${PWD}/.ca ]; then
       dcode=$(base64 -d .ca)
       pxv=$(echo "$dcode" | sed -n '$p')
       sdec=$(sed -n '$p' .ca)
       vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p') 
       fi
       #sdec=$(sed -n '$p' .ca)
       #echo $pxv
       read -s -p " -------> " seguridad
       echo "$seguridad" > .seg
       enc=$(base64 .seg) && rm -rf .seg
       #vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p')
       #echo $vsc
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       int=$(echo "${antigua##*cod=}")
       #echo $int
       echo "$int" > .sec
       sa=$(base64 -d .sec) && rm -rf .sec
       
       if [[ "$seguridad" == "$sa" || "$enc" == "$int" ]]; then
      rm -rf ${PWD}/.ca
      echo -e "Copia de seguridad borrada\n"
      read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
fi
fi
###############################
# ESTA OPCION HAY QUE ARREGLARLA
#Ya esta lista

       if [[ "$sel" == "3" || "$sel" == "03" ]]; then
       echo -e "${R}CAMBIAR LA RESPUESTA SECRETA\n"
       cd ${PWD}
       printf "$C[ESCRIBA LA ANTIGUA CONTRASENA]\n\t"
       if [ -e ${PWD}/.ca ]; then
       dcode=$(base64 -d .ca)
       pxv=$(echo "$dcode" | sed -n '$p')
       sdec=$(sed -n '$p' .ca)
       vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p') 
       fi
       #sdec=$(sed -n '$p' .ca)
       #echo $pxv
       read -s -p " -------> " seguridad
       echo "$seguridad" > .seg
       enc=$(base64 .seg) && rm -rf .seg
       #vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p')
       #echo $vsc
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       int=$(echo "${antigua##*cod=}")
       #echo $int
       echo "$int" > .sec
       sa=$(base64 -d .sec) && rm -rf .sec
       
       if [[ "$seguridad" == "$sa" || "$enc" == "$int" ]]; then
       echo -e ""
       echo -e ""
       printf "$C[ESCRIBA LA ACTUAL RESPUESTA]\n\t"
       if [ -e ${PWD}/.ca ]; then
       # decodifica ese archivo .ca
       secret=$(base64 -d .ca)
       #muestra la linea 1 decodificada
       sx=$(echo -e "$secret" | sed -n '1 p')
       #muestra la linea 1 codificada
       px=$(sed -n '1 p' .ca)
       #muestra la ultima linea codificada
       pxv=$(sed -n '$P' .ca)
       sr=$(sed 's|Cg==|SIN RESPUESTA|g' .ca | sed -n '1 p')
       xpr=$(echo -e "$px$sr") 
       #echo $px
       fi
       #echo $pxv
       read -s -p " -------> " res
       echo "$res" > .resca
       codr=$(base64 .resca) && rm -rf .resca
       
       if [[ "$codr" == "$px" || "$sr" == "$xpr" ]]; then
       echo -en "$M"CORRECTO""
       echo -e "\n"
       printf "$Gok[ESCRIBA LA NUEVA RESPUETA]\n\t"
       echo -en " -------> $M"
       read nr
       #Lo que escribas se guarda en .pass
       echo "$nr" > .pass
  #Codifica el archivo .pass y luego borralo
       ecod=$(base64 .pass) && rm -rf .pass
       sx=$(echo -e "$ecod" | sed -n '1 p')
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       cint=$(echo "${antigua##*cod=}")
       fib=$(echo $cint)
       echo "$ecod" > .ca
       echo $fib >> .ca
     #  if [ -e ${PWD}/.ca ]; then
      # ext=$(head -n 1 .ca) >/dev/null 2>&1
   #    echo "$ecod" > .ca
   #    fi
     #  echo "$pxv" >> .ca
       ext=$(awk 'FNR <= 1' .ca)
       if [ -z "$nr" ]; then
       echo -e ""
       echo -e "$B"ESTADO ACTUAL - SIN RESPUESTA SECRETA!!!"\n"
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       cint=$(echo "${antigua##*cod=}")
       vac=$(grep -o "Cg==" .ca)
       va=$(echo "U0lOIENPTlRSQVNFw5FBCg==" | cut -d' ' -f2-)
       fib=$(echo $cint)
       echo "$ecod" > .ca
       echo $fib >> .ca
       read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
       fi
#subir la clave a ftp nube
#o bajar el script que me cambien el code
       
      echo -e ""
      echo -e "$B"RESPUESTA MODIFICADA"$W\n"
     read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
    fi
  echo -e "$R"RESPUESTA INCORRECTA"\n"
 sleep 2 
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit

 
echo -e "$R"REPITA LA RESPUESTA$W""
    #echo test >> $a.txt;
       printf "$R\t -------> INTENTO NUMERO $a$W\n"
     sleep 0.9900
       if [ "$seguridad" != "$oculta" ]; then
       echo error
       sleep 2
       exit
       fi
     ECHO -e "${R}AUN NO TIENE CONTRASENA GUARDADA"
 fi
 fi
 # fin
###############################

  
   
   if [[ "$sel" == "4" || "$sel" == "04" ]]; then 
   cd ${HOME}/Busca-Palabras/opc/;bash contrasena-cod.sh
   exit
   fi
   
   if [[ "$sel" == "5" || "$sel" == "05" ]]; then 
   cd ${HOME}/Busca-Palabras;bash Menu-Busca-Palabras.sh
   exit
   fi
   
   if [[ "$sel" == "6" || "$sel" == "06" ]]; then 
   echo opcion 6
   sleep 2
   exit
   fi
   
   if [ -e ${PWD}/.ca ]; then
   if [ -z "$sel" ]; then
   echo -e "invalido 1\n"
      sleep 1
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
      fi
      fi
      
      if [ -e ${PWD}/.ca ]; then
      if [[ "$sel" != "1" || "$sel" != "01" || "$sel" != "2" || "$sel" != "02" || "$sel" != "3" || "$sel" != "4" || "$sel" != "04" || "$sel" != "5" || "$sel" != "05" ]]; then
      echo -e "invalido 2\n"
      sleep 1
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
      fi
   fi
fi

 #RobertNissan
 # aqui debo exigir la contrasena para tener seguridad de restablecimiento
      echo -e "${M}    Guardar contrasena actual$C\n"
      echo -e "    Anadir respuesta secreta"
      printf "$C[Nombre de tu maestr@ favorito:]$G\n\t"
      read -p " -------> " cor
      #debo guardar una respuesta secreta en este script para luego hacer comparacion con la variable $cor
      if [ -z "$cor" ]; then
      echo -e "${R}invalido final\n"
      sleep 2
      else
      #sed -n '11 p' archivo.txt | cut -d '=' -f2
      #aqui debes es guardar la contrasena
      echo -e "${G}OK , GUARDADA"
      echo -e ""
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       xvf=$(echo "${antigua##*cod=}")
       #vac=$(tail "Cg==" .ca)
       va=$(echo "U0lOIENPTlRSQVNFw5FBCg==" | cut -d' ' -f2-)
       
       #echo "$va" >> .ca
       echo "$xvf" >> .ca
       
      echo "$cor" > .ca && codI=$(base64 .ca) && echo "$codI" > .ca && echo "$xvf" >> .ca
      read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
      
fi
      #echo invalido
;;


       3|03)
       if [ -e ${PWD}/.ca ]; then
       read -p "Nombre de tu maestr@ favorito " "cor"
       nada=$(cat .ca)
       dcod=$(base64 -d .ca)
       md=$(echo "$dcod")
       ini=$(echo -e "$dcod" | cut -d' ' -f1- | head -n 1)
       #vac=$(grep -o "Cg==" .ca)
       #va=$(echo "$vac SIN CONTRASENA" | cut -d' ' -f2-)
       if [ "$cor" == "$ini" ]; then
       echo -e ""
       echo -e "La contrastena es:"
       #echo -e "$dcod" | grep -zoP "(?s)(?<="$ini").*"
       #echo -e "hi ro\nRobertNissan" | cut -d' ' -f1 | tail -n 1
       #cat -n fich2 | sed -n '2,3 p'
       print=$(echo -e "$dcod" | sed -n '$p')
       pri=$(echo -e "$dcod" | sed -n '$p' | cut -d ';' -f1)
       prin=$(sed -n '$p' .ca)
       # vac=$(grep -o "Cg==" .ca)
       vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p')
       join=$(echo -e "$print$vsc")
       #echo $join
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       int=$(echo "${antigua##*cod=}")
########################
       if [[ "$int"  == "Cg==" ]]; then
      scon=$(echo -e "$print""SIN CONTRASENA")               #
      scont=$(echo -e "SIN CONTRASENA")
      echo $scont
     read
fi
########################
   sc=$(sed -n '$p' .ca)                #
      sco=$(cut -d ';' -f1 .ca)                #
if [ "$int" != "Cg==" ]; then
       echo "$print" #$sil"
     read
fi

      # if [ "$int" != "Cg==" ]; then
      # echo "$pri"
     #  read
#fi
       sed -n '$p' .ca >/dev/null 2>&1
       #echo -e "$dcod" | cut -d' ' -f1 | tail -n 1
       else
       echo -e "Respuesta incorrecta\n"
       sleep 0.9900
       fi
fi
       if [ -z "$nada" ]; then
echo -e " ${M}  SCRIPT CONTRASENA BY ROBERT NISSAN"
echo -en "${G}+-------------------------------------+
# "[${W}01${G}] | ${W}Entrar al script"             ${G}#
#-------------------------------------#
# "[${W}02${G}] | ${W}Guardar contrasena actual"    ${G}#
#-------------------------------------#
# "[${W}03${G}] | ${W}Ver contrasena actual"        ${G}#
#-------------------------------------#
# "[${W}04${G}] | ${W}Cambiar contrasena"           ${G}#
#-------------------------------------#
# "[${W}05${G}] | ${W}Volver al menu principal"     ${G}#
+-------------------------------------+
|
+->>> "${W}
echo -e "$R"Aun no tiene contrasena guardada""
sleep 2
fi

;;

       4|04) echo -e ""
       cd ${PWD}
       echo -e "$R"CAMBIAR LA CONTRASENA"\n"
       printf "$C[ESCRIBA LA ANTIGUA CONTRASENA]\n\t"
       if [ -e ${PWD}/.ca ]; then
       dcode=$(base64 -d .ca)
       pxv=$(echo "$dcode" | sed -n '$p')
       sdec=$(sed -n '$p' .ca)
       vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p') 
       fi
       #sdec=$(sed -n '$p' .ca)
       #echo $pxv
       read -s -p " -------> " seguridad
       echo "$seguridad" > .seg
       enc=$(base64 .seg) && rm -rf .seg
       #vsc=$(sed 's|Cg==|SIN CONTRASENA|g' .ca | sed -n '$p')
       #echo $vsc
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       int=$(echo "${antigua##*cod=}")
       #echo $int
       echo "$int" > .sec
       sa=$(base64 -d .sec) && rm -rf .sec
       
       if [[ "$seguridad" == "$sa" || "$enc" == "$int" ]]; then
       echo -en "$M"CORRECTO""
       antigua=$(grep -E "cod=" contrasena-cod.sh | head -n 1)
       rm -rf .pass
       echo -e "\n"
       printf "$Gok[ESCRIBA LA NUEVA CONTRASENA]\n\t"
       echo -en " -------> $M"
       read new
       echo "$new" > .pass
       ecod=$(base64 .pass) && rm -rf .pass
       sed -i 's|'$antigua'|'cod=$ecod'|g' contrasena-cod.sh
       if [ -e ${PWD}/.ca ]; then
       ext=$(head -n 1 .ca) >/dev/null 2>&1
       echo "$ext" > .ca
       fi
       echo "$ecod" >> .ca
       
       if [ -z "$new" ]; then
       echo -e ""
       echo -e "$B"ESTADO ACTUAL - SIN CONTRASENA!!!"\n"
       vac=$(grep -o "Cg==" .ca)
       va=$(echo "U0lOIENPTlRSQVNFw5FBCg==" | cut -d' ' -f2-)
       echo "$va" >> .ca
       echo "$vac" >> .ca
       read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
       fi
#subir la clave a ftp nube
#o bajar el script que me cambien el code
      echo -e ""
      echo -e "$B"CONTRASENA MODIFICADA"\n"
     read -n 1 -p "Presione cualquier tecla para continuar..."
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
    fi
  echo -e "$R"CONTRASENA INCORRECTA"\n"
 sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit

 
echo -e "$R"REPITA LA CONTRASENA$W""
    #echo test >> $a.txt;
       printf "$R\t -------> INTENTO NUMERO $a$W\n"
     sleep 0.9900
       if [ "$seguridad" != "$oculta" ]; then
       echo error
       sleep 2
       exit
       fi
       echo Guardar contrasena actual
      usr=$(whoami)
      read -p "Nombre de tu maestr@ favorito " cor
#roc="[^0-Z._]+@[0-Z]+\.[a-Z]+"
      if [ -z "$cor" ]; then
      echo invalido
      else
      #aqui debes es guardar la contrasena
      echo Ok
      echo "$cor" > .ca && codI=$(base64 .ca) && echo "$codI" > .ca && echo "$cod" >> .ca
      sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
   fi
       
       echo Guardar contrasena actual
      usr=$(whoami)
      read -p "Nombre de tu maestr@ favorito " cor
#roc="[^0-Z._]+@[0-Z]+\.[a-Z]+"
      if [ -z "$cor" ]; then
      echo invalido
      else
      #aqui debes es guardar la contrasena
      echo Ok
      echo "$cor" > .ca && codI=$(base64 .ca) && echo "$codI" > .ca && echo "$cod" >> .ca
      sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
   fi
  echo -e "$R"CONTRASENA INCORRECTA"\n"
 sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash contrasena-cod.sh
exit
;;

       5|05) cd ${HOME}/Busca-Palabras/
bash Menu-Busca-Palabras.sh
exit
;;

*) echo -e " ${M}  SCRIPT CONTRASENA BY ROBERT NISSAN"
echo -en "${G}+-------------------------------------+
# "[${W}01${G}] | ${W}Entrar al script"             ${G}#
#-------------------------------------#
# "[${W}02${G}] | ${W}Guardar contrasena actual"    ${G}#
#-------------------------------------#
# "[${W}03${G}] | ${W}Ver contrasena actual"        ${G}#
#-------------------------------------#
# "[${W}04${G}] | ${W}Cambiar contrasena"           ${G}#
#-------------------------------------#
# "[${W}05${G}] | ${W}Volver al menu principal"     ${G}#
+-------------------------------------+
|
+->>> "${W};echo -en "$R"Opcion invalida"";sleep 1;clear;sn=1
;;

esac
done
#RobertNissan
