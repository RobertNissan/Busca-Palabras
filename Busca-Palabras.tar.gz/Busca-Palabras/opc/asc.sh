if [ -e ~/Busca-Palabras/opc/.usr ]; then
clear 
echo -e ""
#no usamos >/dev/null 2>&1 sino /dev/null 2>&1
#para guardar el error en archivo 
ifconfig > ip-error.txt /dev/null 2>&1
#cat adri.txt
#echo 'Warning: cannot open /proc/net/dev (Permission denied). Limited output.' > ip-error.txt
err='Warning: cannot open /proc/net/dev (Permission denied). Limited output.'
com=$(sed -n "1p" ip-error.txt)
rm -r ip-error.txt >/dev/null 2>&1
if [ "$com" == "$err" ]; then
usr=$(whoami)
#echo 'Mensaje de error!'
#echo 'Otra alternativa es iproute2!'
#read
if [ -x $PREFIX/share/doc/iproute2 ]; then
echo Existe >/dev/null 2>&1
x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
#echo "Esta es la IP de tu android ${x%%/*}"
ip=$(echo "${x%%/*}")
else 
usr=$(whoami)
echo "Instalando iproute2"
pkg install iproute2
x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
#echo "Esta es la IP de tu android ${x%%/*}"
ip=$(echo "${x%%/*}")
fi
fi

if [ "$com" != "$err" ]; then
usr=$(whoami)
#ifconfig >> ip.txt
#Me cituas en la ip moto g5 plus:
str="$(ifconfig | grep -owE 'inet 192\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)')"
echo -e ""
ip="$(echo -e ${str:4:16})"
#rm -r ip.txt >/dev/null 2>&1
fi
str="$(echo "@$ip")"
sleep 1
# Si existe esa letra @, entonces haz esto primero
# Si no esta conectado a wifi, no subir el archivo
if [ "$str" == "@" ]; then
#
clear
echo -e ""
echo -e "No tiene conexion wifi o hostpot!
Por favor active el ${rojo}wifi ${blanco}o la
${rojo}zona wifi (hostpot)${blanco}" 
echo "vuelva a intentar!"
echo -e ""
read -n 1 -p "Presione cualquier tecla para volver al menu"
bash ~/Busca-Palabras/opc/lista-server.sh
str=a
exit
#read
else
nu=$(grep -En "*" ~/Busca-Palabras/opc/.usr | tail -n 1)
num=$(echo "${nu%%:*}")
echo -e "Crear acceso sin contrasenas\n"
echo "Actualmente tiene "$num" servidores en la lista"
echo -e ""
grep -En "*" ~/Busca-Palabras/opc/.usr
echo -e ""
read -p "Elija el servidor donde va a crear el acceso! > " pc
#if [[ "$pc" =~ ^[0-9]+$ ]]; then
if [[ "$pc" =~ ^[0-9]+$ ]] && (("$pc" >= 1 && "$pc" <= "$num")); then
#selecciona una linea especifica
port=$(sed -n ""$pc"p" ~/Busca-Palabras/opc/.usr | cut -d' ' -f3)
echo "$active"
active=$(sed -n ""$pc"p" ~/Busca-Palabras/opc/.usr | cut -d' ' -f4-)
ip=$(sed -n ""$pc"p" ~/Busca-Palabras/opc/.usr)
ip=$(echo "${ip##*@}")
clear
echo -e ""
#echo "Transferir archivos al servidor"
#echo -e "scp -P "$port" "$new" "$active":"
#echo "Se transferiran todos los archivo de la ruta"
#echo -e "$ruta\n"
#echo -e "A este servidor:"
#echo -e ""$active":\n"
#rut=$(echo "${ruta}"  | xargs echo -n)
  #echo $rut 
 # rut="${rut// /_}"
  #echo "$rut"
 # rut=$(echo $rut | sed 's/'\""//g')
 fi
fi
fi

if [ -e ~/.ssh/known_hosts ]; then
echo "existe" >/dev/null 2>&1
#clear
nu=$(grep -En "*" ~/.ssh/known_hosts | tail -n 1)
num=$(echo "${nu%%:*}")
#echo ""$num" Llaves de los servidores en la lista" 
ipkh=$(grep -o "$ip" ~/.ssh/known_hosts | tail -n 1) 
#ipkh=$(grep -o "$ip" ~/Busca-Palabras/opc/.usr | tail -n 1) 
if [ "$ip" == "$ipkh" ]; then
for var in $(seq 1 "$num"); do
ik=$(sed -n "${var}p" ~/.ssh/known_hosts | grep -o "$ip")
#echo "si $ip = $ik" 
#read 
if [ "$ip" == "$ik" ]; then
#echo "var $var"
#sed -n "${var}p" ~/.ssh/known_hosts
#ni=$(sed -n "${var}p" ~/.ssh/known_hosts | grep -o "$ip" ~/.ssh/known_hosts)
#borrar las lineas que tengan esa ip  
#echo "grep"
#read 
#grep "$ni" ~/.ssh/known_hosts | xargs sed -i "s|"$ni"||g"
sed -i "/$ik/d" ~/.ssh/known_hosts
#echo "Borrada la linea $var"
#read
fi
done
sed -i '/^$/d' ~/.ssh/known_hosts  
fi
#else
#echo "No hay similitud de llaves"
#sleep 3
fi


if [ "$port" == "8022" ]; then
 clear
 echo "$active"
echo -e 'Si el acceso de Termux esta restringido,
te pedira la contrasena de usuario!!!'
echo -e 'Si no le tiene contrasena al usuario,
entonces abra termux remoto, y escriba
el siguiente comando para crear una:\n'
echo -e 'passwd\n'
read -n 1 -p 'Presione cualquier tecla para continuar!!!'
echo -e ""
#Android
cat ~/.ssh/id_rsa.pub | ssh -p "$port" "$active" 'mkdir -p ~/.ssh && touch ~/.ssh/authorized_keys && chmod -R go= ~/.ssh && cat >> ~/.ssh/authorized_keys'
echo -e ""
echo -e 'Se a completado el acceso sin contrasenas!!!'
echo -e ""
fi

if [ "$port" == "22" ]; then
clear
#Aqui estamos trayendo el archivo del PC al Android, hacia una ruta especifica.
echo "$active"
echo -e 'Si el acceso de la Computadora esta restringido,
te pedira la contrasena de usuario!!!'
echo -e 'Si no le tiene contrasena al computador,
entonces abra simbolo del sistema
como administrador, y escriba el
siguiente comando para crear una:\n'
echo -e 'net user %username% *\n'
echo -e 'Para quitar la contrasena de usuario escriba el mismo
comando seguido de dos veces la tecla ENTER\n'
read -n 1 -p 'Presione cualquier tecla para continuar!!!'
echo -e ""
scp -P "$port" "$active"":"C:/programdata/ssh/sshd_config ~/.ssh
#
kp=$(grep -o '#PubkeyAuthentication' ~/.ssh/sshd_config)
#echo "$kp"
if [ "$kp" == "#PubkeyAuthentication" ]; then
echo "Abriendo acceso sin contrasena"
sed -i 's/#PubkeyAuthentication/PubkeyAuthentication/g' ~/.ssh/sshd_config
#Windows
cd ~/.ssh
echo -e "Transfiriendo la llave publica para el pc\n"
scp -P $port "id_rsa.pub" "sshd_config" $active":" && ssh -p "$port" "$active" 'type nul >> C:/programdata/ssh/Administrators_authorized_keys && type id_rsa.pub >> C:/programdata/ssh/Administrators_authorized_keys && type sshd_config > C:/programdata/ssh/sshd_config &&  icacls C:/programdata/ssh/Administrators_authorized_keys /inheritance:r /grant "%username%:F" /grant "SYSTEM:F"'
cho -e ""
echo -e 'Se a completado el acceso sin contrasenas!!!'
echo -e ""
sleep 2
else
cd ~/.ssh
echo "acceso abierto"
echo -e ""
echo -e "Transfiriendo la llave publica para el pc"
scp -P $port "id_rsa.pub" $active":" && echo -e "" && ssh -p "$port" "$active" 'type nul >> C:/programdata/ssh/Administrators_authorized_keys && type id_rsa.pub >> C:/programdata/ssh/Administrators_authorized_keys &&  icacls C:/programdata/ssh/Administrators_authorized_keys /inheritance:r /grant "%username%:F" /grant "SYSTEM:F"'
echo -e ""
echo -e 'Se a completado el acceso sin contrasenas!!!'
echo -e ""
fi
fi
