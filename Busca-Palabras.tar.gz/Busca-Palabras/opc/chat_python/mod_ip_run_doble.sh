kill=$(ps aux | grep 'servidor.py' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1


IP=$(ifconfig | grep -F 192.168 | awk '{print $2}')

      #-----mod IPSERVIDOR de cliente2.py------#
bwh=$(grep -En "SERVER_HOST" ~/Busca-Palabras/opc/chat_python/cliente2/cliente2.py | head -n 1 | awk '{print $3}')
IP="'$IP'"
if [ "$bwh" = "$IP" ]; then
echo Ok >/dev/null 2>&1
else
sed -i "s%$bwh%"$IP"%g" ~/Busca-Palabras/opc/chat_python/cliente2/cliente2.py
fi

#Ejecutar doble script 
cd ~/Busca-Palabras/opc/chat_python
python servidor.py & python cliente.py

#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep 'servidor.py' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1
