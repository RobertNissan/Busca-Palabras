#!/bin/bash
termux-wake-lock
cd ~/Busca-Palabras/opc/chat_python/cliente2/bajaftp/
python -m http.server 8024 >/dev/null 2>&1