#!/bin/sh
# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl -s ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
exit
fi
fi 

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo -n "No tiene conexion wifi!" >/dev/null 2>&1
echo -e ""
sleep 2 

# Si esta conectado a wifi, haz esto segundo
else
esd=a
secret=$(echo "TGxhdmU4NFNlY3JldGEK" | base64 -d)
while [ "$esd" == "a" ]; do
clear
bwhs=$(grep -En "$secret" ~/Busca-Palabras/opc/chat_python/subeftp.sh | tail -n 1 | awk '{print $4}')
if [[ "$bwhs" = "$secret" ]]; then
disco=sdext
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${mzv}+------------------------+
# $white"Ingrese su contrasena:" ${mzv}#
+------------------------+
+->>> "${mza}
read -r disco
clear
#verificar si hay algo escrito 
while [ -z "$disco" ]; do
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${mzv}+------------------------+
# $white"Ingrese su contrasena:" ${mzv}#
+------------------------+
+->>> "${mza}
read -r disco
done
fi

if [ "$disco" == "$secret" ]; then
#-------------------------------------------------------------------------
A=$(grep -EIris 'user' ~/Busca-Palabras/opc/chat_python/subeftp.sh | head -n 1 | awk '{print $3}') 
if [ "$A" = '\$llave' ]; then 
sed -i "s%$A%$disco%g" ~/Busca-Palabras/opc/chat_python/subeftp.sh
fi
#-------------------------------------------------------------------------
B=$(grep -EIris 'user' ~/Busca-Palabras/opc/chat_python/subeftp.sh | tail -n 1 | awk '{print $3}')
if [ "$B" != "$secret" ]; then 
sed -i "s%$B%$disco%g" ~/Busca-Palabras/opc/chat_python/subeftp.sh 
fi
#-------------------------------------------------------------------------
C=$(grep -EIris "disco=sdext" ~/Busca-Palabras/opc/chat_python/subeftp.sh  | head -n 1) 

D=$(echo "$C" | cut -d' ' -f4)
sed -i "s%$D%disco=$disco%g" ~/Busca-Palabras/opc/chat_python/subeftp.sh 
#-------------------------------------------------------------------------
echo -e ""
clear
echo -e ""Contrasena correcta "\e[1;34m"$disco"\e[0m"
llave="$disco"

ftp -inv files.000webhost.com<<FINFTP
       user robertomeza $llave
       binary
       lcd ~/Busca-Palabras/opc/chat_python/cliente2/
       cd /chat_local/
       send cliente2.py
       bye
FINFTP

clear 
echo -e ""
IP=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
IP=$(echo "${IP%/*}")
curl qrcode.show/http://${IP}:8024/
#echo -e ""
#echo -e "     DESCARGAR SCRIPT CLIENTE"
#echo -e "    http://${IP}:8024/\n"
exit
 
else
clear
echo -e ""
echo "Contrasena incorrecta"
read
esd=a
fi
done
fi