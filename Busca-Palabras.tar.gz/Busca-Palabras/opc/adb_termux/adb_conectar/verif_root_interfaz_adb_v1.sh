#!/bin/bash

# Definir códigos de color
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante
COLOR_CIAN='\033[36m'
COLOR_RESET='\033[0m'
COLOR_AZUL='\033[34m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_NEGRO='\033[30m'
COLOR_BLANCO='\033[37m'
COLOR_AMARILLO='\033[33m'
COLOR_MAGENTA='\033[35m'

echo -e "${YELLOW}versión script 0.1 ${NC}"

# =================== Spinner / Cargando ===================
spinpid=""
iniciar_spinner() {
    local frames=("cargando" "cargando." "cargando.." "cargando...")
    tput civis -- invisible 2>/dev/null # Ocultar cursor
    (
        while true; do
            for frame in "${frames[@]}"; do
                printf "\r\033[K%s" "$frame"
                sleep 0.2
            done
        done
    ) &
    spinpid=$!
}

detener_spinner() {
    if [[ -n "$spinpid" ]]; then
        kill "$spinpid" >/dev/null 2>&1
        wait "$spinpid" 2>/dev/null
        printf "\r\033[K" # Limpiar la línea del spinner
    fi
    tput cnorm -- normal 2>/dev/null # Restaurar cursor
}

# Iniciamos el spinner visual mientras carga todo el bloque pesado
iniciar_spinner

### VERIFICAR SI EL DISPOSITIVO TIENE ROOT ###
if su -c "id" > /dev/null 2>&1; then
    root_msg="️‍🎯 ️Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    ROOT_PERMISSIONS="false"
fi


######FUNCIONES_CONEXION_INTERNET######
source ~/Busca-Palabras/config/verif_conex_internet
source ~/Busca-Palabras/config/verif_internet_full
verif_internet=$(verif_tipo_con && echo "${conect_internet}")


# =================== Obtener IP principal ===================
get_primary_local_ip() {
    declare -A ifaces
    while IFS=: read -r iface ip; do
        [[ -n $iface && -n $ip ]] && ifaces["$iface"]="$ip"
    done < <(obtener_interfaces)

    [[ -n ${ifaces[wlan0]} && ${ifaces[wlan0]} != "127.0.0.1" ]] && { echo "${ifaces[wlan0]}"; return; }
    [[ -n ${ifaces[seth_lte0]} && ${ifaces[seth_lte0]} != "127.0.0.1" ]] && { echo "${ifaces[seth_lte0]}"; return; }
    [[ -n ${ifaces[tun0]} && ${ifaces[tun0]} != "127.0.0.1" ]] && { echo "${ifaces[tun0]}"; return; }

    for ip in "${ifaces[@]}"; do
        [[ $ip != "127.0.0.1" ]] && { echo "$ip"; return; }
    done

    ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7; exit}' || echo "127.0.0.1"
}


# =================== Verificar ADB ===================
export_var() {
    export ip
    export ip_device
    export adb_estado
    export disponible_adb
    export adb_conectado_ip_device
}

verif_adb_conect_echo() {
    local ip=$(get_primary_local_ip) 
    local adb_output connected_devices adb_estado ip_device

    adb_output=$(adb devices -l 2>/dev/null)
    connected_devices=$(echo "$adb_output" | awk '$2 == "device" {print $1}')

    ip_device=$(echo "$connected_devices" | grep -E "^emulator")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        echo -e "$ip_device"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi
    
    ip_device=$(echo "$connected_devices" | grep -E "^${ip}:[0-9]+$")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        echo -e "${ip_device}"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi

    adb_estado="false"
    echo "$adb_estado"
    echo "🔴 ADB desconectado"
    adb_conectado_ip_device=""
    return 1
}


# =================== Obtener interfaces e IPs ===================
obtener_interfaces() {
    declare -A interfaces
    local actual linea ip

    while IFS= read -r linea; do
        if [[ $linea != " "* && $linea == *:* ]]; then
            actual="${linea%%:*}"
        elif [[ $linea == *"inet "* && -n $actual ]]; then
            ip=$(echo "$linea" | grep -oE 'inet (addr:)?([0-9]{1,3}\.){3}[0-9]{1,3}' | awk '{print $2}' | sed 's/addr://')
            interfaces["$actual"]="$ip"
        fi
    done < <(ifconfig 2>/dev/null)

    for iface in "${!interfaces[@]}"; do
        echo "$iface:${interfaces[$iface]}"
    done
}


# =================== Clasificar conexión ===================
clasificar_conexion() {
    local ifaces verif_internet tipo="Modo avión" detalles=() wlan_ip=""

    mapfile -t ifaces < <(obtener_interfaces)
    verif_internet="$1"

    declare -A iface_map
    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        iface_map["$iface"]="$ip"
    done

    for k in "${!iface_map[@]}"; do
        [[ $k == tun* || $k == tap* ]] && detalles+=("VPN activa")
    done

    wlan_ip="${iface_map[wlan0]}"

    local dispositivo=$(verif_adb_conect_echo | tail -n1)
    local mobile_data_enabled="0"
    local airplane_mode_on="0"
    if [[ -n "$dispositivo" ]]; then
        mobile_data_enabled=$(adb -s "$dispositivo" shell settings get global mobile_data 2>/dev/null | tr -d '\r')
        airplane_mode_on=$(adb -s "$dispositivo" shell settings get global airplane_mode_on 2>/dev/null | tr -d '\r')
    fi

    if [[ -n $wlan_ip && ($wlan_ip =~ ^192\.168\.43\. || $wlan_ip =~ ^172\.(1[6-9]|2[0-9]|3[0-1])\.) ]]; then
        tipo="Hotspot Android"
    elif [[ -n $wlan_ip && $wlan_ip == 192.168.* ]]; then
        tipo="Router Wi-Fi"
    elif [[ -n $wlan_ip && $wlan_ip == 10.* ]] || grep -q "172\.(1[6-9]|2[0-9]|3[0-1])\." <<<"${iface_map[@]}"; then
        tipo="Hotspot Android"
    elif grep -q "172\.20\.10\." <<<"${iface_map[@]}"; then
        tipo="Hotspot iPhone"
    elif [[ -n $wlan_ip ]]; then
        tipo="Router Wi-Fi"
    elif printf '%s\n' "${!iface_map[@]}" | grep -Eq "^(seth|rmnet|wwan|usb)"; then
        tipo="Datos móviles"
    elif [[ "$mobile_data_enabled" == "1" && "$airplane_mode_on" == "0" ]]; then
        tipo="Red telefónica"
    elif [[ "$airplane_mode_on" == "1" ]]; then
        tipo="Modo avión"
    fi

    detalles+=($( [[ $verif_internet == "true" ]] && echo -e "${GREEN}con Internet${NC}" || echo -e "${RED}sin Internet${NC}" ))
    echo "$tipo ${NC}(${detalles[*]})"
}


# =================== Recopilar salidas en variables antes de mostrar ===================
output_buffer=""

if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
    output_buffer+="$root_msg"$'\n'
fi

estado_conexion=$(clasificar_conexion "$verif_internet")
case "$estado_conexion" in
    *"Router Wi-Fi"*) tipo_icon="📡";;
    *"Datos móviles"*) tipo_icon="📶";;
    *"Hotspot"*) tipo_icon="🔥";;
    *"Modo avión"*) tipo_icon="✈️";;
    *) tipo_icon="🌐";;
esac

output_buffer+="${tipo_icon} ${MAGENTA}$estado_conexion"$'\n'

mapfile -t ifaces_final < <(obtener_interfaces)
for line in "${ifaces_final[@]}"; do
    iface="${line%%:*}"
    ip_val="${line#*:}"
    output_buffer+="💻 ${CYAN}$iface${NC}: $ip_val"$'\n'
done

ip_principal=$(get_primary_local_ip)
adb_result_full=$(verif_adb_conect_echo "${ip_principal}")
adb_status=$(echo "$adb_result_full" | head -n1)
dispositivo=$(echo "$adb_result_full" | tail -n1)

if [[ "$adb_status" == "true" ]]; then
    output_buffer+="🔌 $dispositivo"$'\n'
    output_buffer+="🟢 estado adb: $adb_status"
else
    output_buffer+="$dispositivo"$'\n'
    output_buffer+="🔴 estado adb: $adb_status"
fi

# =================== Fin de proceso: Apagar spinner y mostrar resultado ===================
detener_spinner

# Imprimir todo el bloque ordenado y limpio de un solo golpe
echo -e "$output_buffer"
