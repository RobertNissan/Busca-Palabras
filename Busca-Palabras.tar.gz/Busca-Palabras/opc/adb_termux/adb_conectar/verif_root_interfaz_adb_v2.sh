#!/bin/bash

# Definir códigos de color
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante
COLOR_CIAN='\033[36m'
COLOR_RESET='\033[0m'
COLOR_AZUL='\033[34m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_NEGRO='\033[30m'
COLOR_BLANCO='\033[37m'
COLOR_AMARILLO='\033[33m'
COLOR_MAGENTA='\033[35m'

# echo -e "${YELLOW}versión script 0.2 ${NC}(Optimizado con Spinner)"

# =================== Spinner / Cargando ===================
spinpid=""
iniciar_spinner() {
    local frames=("cargando" "cargando." "cargando.." "cargando...")
    tput civis -- invisible 2>/dev/null # Ocultar cursor
    (
        while true; do
            for frame in "${frames[@]}"; do
                printf "\r\033[K%s" "$frame"
                sleep 0.2
            done
        done
    ) &
    spinpid=$!
}

detener_spinner() {
    if [[ -n "$spinpid" ]]; then
        kill "$spinpid" >/dev/null 2>&1
        wait "$spinpid" 2>/dev/null
        printf "\r\033[K" # Limpiar la línea del spinner
    fi
    tput cnorm -- normal 2>/dev/null # Restaurar cursor
}

# Iniciamos el spinner visual mientras carga todo el bloque pesado
iniciar_spinner

### VERIFICAR SI EL DISPOSITIVO TIENE ROOT ###
if su -c "id" > /dev/null 2>&1; then
    root_msg="️‍🎯 ️Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    root_msg="🛑 No tienes acceso root" 2>/dev/null
    ROOT_PERMISSIONS="false"
fi



######FUNCIONES_CONEXION_INTERNET######
# SCRIPT PYTHON
source "$HOME/Busca-Palabras/config/verif_conex_internet"
verif_internet=$(verif_tipo_con && echo "${conect_internet}")
ip_externa=$(verif_tipo_con && echo "${mi_ip_ex}")
# SCRIPT BASH
# source "$HOME/Busca-Palabras/config/verif_internet_full"





# =================== Obtener interfaces e IPs (Lectura en tiempo real) ===================
obtener_interfaces() {
    declare -A interfaces
    local orden_interfaces=() 
    local actual linea ip

    while IFS= read -r linea; do
        if [[ $linea != " "* && $linea == *:* ]]; then
            actual="${linea%%:*}"
        elif [[ $linea == *"inet "* && -n $actual ]]; then
            ip=$(echo "$linea" | grep -oE 'inet (addr:)?([0-9]{1,3}\.){3}[0-9]{1,3}' | awk '{print $2}' | sed 's/addr://')
            if [[ -z "${interfaces[$actual]}" ]]; then
                orden_interfaces+=("$actual") # Solo lo guardamos si no estaba ya
            fi
            interfaces["$actual"]="$ip"
        fi
    done < <(ifconfig 2>/dev/null)

    # 1. Forzamos imprimir 'lo' de primero
    [[ -n "${interfaces[lo]}" ]] && echo "lo:${interfaces[lo]}"
    
    # 2. Buscamos cualquier interfaz que empiece con "tun" (tun0, tun1, etc.) y la imprimimos
    for iface in "${orden_interfaces[@]}"; do
        if [[ "$iface" == tun* ]]; then
            echo "$iface:${interfaces[$iface]}"
        fi
    done
    
    # 3. Forzamos imprimir 'wlan0' después
    [[ -n "${interfaces[wlan0]}" ]] && echo "wlan0:${interfaces[wlan0]}"

    # 4. Imprimimos el resto de las interfaces (omitiendo lo, wlan0 y cualquier tun)
    for iface in "${orden_interfaces[@]}"; do
        if [[ "$iface" != "lo" && "$iface" != "wlan0" && "$iface" != tun* ]]; then
            echo "$iface:${interfaces[$iface]}"
        fi
    done
}

# =================== Obtener IP principal ===================
get_primary_local_ip() {
    declare -A ifaces
    while IFS=: read -r iface ip; do
        [[ -n $iface && -n $ip ]] && ifaces["$iface"]="$ip"
    done < <(obtener_interfaces)

    [[ -n ${ifaces[wlan0]} && ${ifaces[wlan0]} != "127.0.0.1" ]] && { echo "${ifaces[wlan0]}"; return; }
    [[ -n ${ifaces[seth_lte0]} && ${ifaces[seth_lte0]} != "127.0.0.1" ]] && { echo "${ifaces[seth_lte0]}"; return; }
    
    # Para la IP principal intentamos ver si existe algún tun registrado
    for iface in "${!ifaces[@]}"; do
        if [[ "$iface" == tun* && "${ifaces[$iface]}" != "127.0.0.1" ]]; then
            echo "${ifaces[$iface]}"
            return
        fi
    done

    for ip in "${ifaces[@]}"; do
        [[ $ip != "127.0.0.1" ]] && { echo "$ip"; return; }
    done

    ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7; exit}' || echo "127.0.0.1"
}


# =================== Verificar ADB (Tiempo Real) ===================
get_adb_devices() {
    adb devices -l 2>/dev/null
}

export_var() {
    export ip
    export ip_device
    export adb_estado
    export disponible_adb
    export adb_conectado_ip_device
}

verif_adb_conect_echo() {
    local ip="$1"
    local adb_output connected_devices adb_estado ip_device

    adb_output=$(get_adb_devices)
    connected_devices=$(echo "$adb_output" | awk '$2 == "device" {print $1}')

    ip_device=$(echo "$connected_devices" | grep -E "^emulator")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        echo -e "$ip_device"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi
    
    ip_device=$(echo "$connected_devices" | grep -E "^${ip}:[0-9]+$")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        echo -e "${ip_device}"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi

    adb_estado="false"
    echo "$adb_estado"
    echo "🔴 ADB desconectado"
    adb_conectado_ip_device=""
    return 1
}


# =================== Clasificar conexión ===================
clasificar_conexion() {
    local verif_internet="$1"
    local dispositivo="$2"
    local tipo="Sin conexión" detalles=() wlan_ip=""

    mapfile -t ifaces < <(obtener_interfaces)
    
    declare -A iface_map
    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        iface_map["$iface"]="$ip"
    done

    for k in "${!iface_map[@]}"; do
        [[ $k == tun* || $k == tap* ]] && detalles+=("VPN activa")
    done

    wlan_ip="${iface_map[wlan0]}"

    local mobile_data_enabled="0"
    local airplane_mode_on="0"

    # Si ADB está conectado usa ADB; si no, lee los ajustes directamente en el dispositivo local
    if [[ -n "$dispositivo" && "$dispositivo" != "🔴 ADB desconectado" ]]; then
        local settings_out
        settings_out=$(adb -s "$dispositivo" shell "settings get global mobile_data; settings get global airplane_mode_on" 2>/dev/null)
        mobile_data_enabled=$(echo "$settings_out" | sed -n '1p' | tr -d '\r')
        airplane_mode_on=$(echo "$settings_out" | sed -n '2p' | tr -d '\r')
    fi

    if [[ -n $wlan_ip && ($wlan_ip =~ ^192\.168\.43\. || $wlan_ip =~ ^172\.(1[6-9]|2[0-9]|3[0-1])\.) ]]; then
        tipo="Hotspot Android"
    elif [[ -n $wlan_ip && $wlan_ip == 192.168.* ]]; then
        tipo="Router Wi-Fi"
    elif [[ -n $wlan_ip && $wlan_ip == 10.* ]] || grep -q "172\.(1[6-9]|2[0-9]|3[0-1])\." <<<"${iface_map[@]}"; then
        tipo="Hotspot Android"
    elif grep -q "172\.20\.10\." <<<"${iface_map[@]}"; then
        tipo="Hotspot iPhone"
    elif [[ -n $wlan_ip ]]; then
        tipo="Router Wi-Fi"
    elif printf '%s\n' "${!iface_map[@]}" | grep -Eq "^(seth|rmnet|wwan|usb|ccmni|pdp|pdn)"; then
        tipo="Datos móviles"
    elif [[ "$mobile_data_enabled" == "1" && "$airplane_mode_on" == "0" ]]; then
        tipo="Red telefónica"
    elif [[ "$airplane_mode_on" == "1" ]]; then
        tipo="Modo avión"
    fi

    detalles+=($( [[ $verif_internet == "true" ]] && echo -e "${GREEN}con Internet${NC}" || echo -e "${RED}sin Internet${NC}" ))
    echo "$tipo ${NC}(${detalles[*]})"
}



# =================== Mostrar estado ===================
build_status_info() {
    local verif_internet="$1"
    local dispositivo="$2"
    local estado tipo_icon ifaces iface ip

    mapfile -t ifaces < <(obtener_interfaces)
    estado=$(clasificar_conexion "$verif_internet" "$dispositivo")
    
    case "$estado" in
        *"Router Wi-Fi"*) tipo_icon="📡";;
        *"Datos móviles"*) tipo_icon="📶";;
        *"Hotspot"*) tipo_icon="🔥";;
        *"Modo avión"*) tipo_icon="✈️";;
        *) tipo_icon="🌐";;
    esac

    echo -e "${tipo_icon} ${MAGENTA}$estado"

    # Imprime en el orden forzado por obtener_interfaces
    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        echo -e "💻 ${CYAN}$iface${NC}: $ip"
    done
}

mi_dispositivo() {
    echo -e "${GREEN}Brand ID${NC}: $(getprop ro.product.system.brand)"
    echo -e "${GREEN}Modelo${NC}: $(getprop ro.product.model)"
    echo -e "${GREEN}Version de Android${NC}: $(getprop ro.build.version.release)"
    echo -e "${GREEN}Model ID${NC}: $(getprop ro.build.product)"
    echo -e "${GREEN}Kernel ID${NC}: $(uname -r)"
    echo -e "${GREEN}Chipset ID${NC}: $(getprop ro.product.board)"
    echo -e "${GREEN}Architecture${NC}: $(uname -m)"
}

# =================== Bucle Principal Oculto ===================
generar_salida() {
    echo "$root_msg"
    ip_principal=$(get_primary_local_ip)
    # 2. Ejecutar la función UNA SOLA VEZ en la shell principal (sin $(...))
    # Esto procede a brindar el estado de internet y la IP Externa
    verif_tipo_con
    # 3. Asignar las variables globales resultantes directamente
    verif_internet="${conect_internet}"
    ip_externa="${mi_ip_ex}"
        
    
    adb_result=$(verif_adb_conect_echo "${ip_principal}")
    adb_status=$(echo "$adb_result" | head -n1)
    dispositivo=$(echo "$adb_result" | tail -n1)
    # echo -e "🔰 ${MAGENTA}verif_internet${NC}: ${verif_internet}" 
    interfaces=$(build_status_info "${verif_internet}" "${dispositivo}")
    _wlan_line=$(echo -e "${interfaces}" | grep -i "wlan")
    if [[ -n "$_wlan_line" ]]; then
        echo -e "${interfaces}"
        _wlan_ip=$(echo -e "${_wlan_line}" | sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2})?)?[mGK]//g" | awk '{print $NF}')
        echo "[WLAN_IP:${_wlan_ip}]"
    else
        echo -e "${interfaces}"
        echo "[WLAN_IP:]"
    fi
    
    if [[ -n "${ip_externa}" && "${ip_externa}" != "html" ]]; then
        echo "💻 ${CYAN}ip_externa${NC}: ${ip_externa}"
    fi

    if [[ "${adb_status}" == "true" ]]; then
        echo -e "🔌 ${GREEN}dispositivo adb${NC}: ${dispositivo}"
        # echo -e "🟢 ${GREEN}estado adb${NC}: ${adb_status}" 2>/dev/null
        # Marca invisible para consumo interno (NO se mostrará en pantalla)
        echo "[ESTADO_ADB:true]"
    else
        echo -e "${dispositivo}"
        # Marca invisible para consumo interno (NO se mostrará en pantalla)
        echo "[ESTADO_ADB:false]"
        # echo "🔴 ${RED}estado adb${NC}: ${adb_status}"
    fi
}




# Ejecutar y guardar el bloque
salida_final=$(generar_salida)


# Extraer ip_wlan y adb_status de salida_final para exportarlas a Python
ip_wlan=$(echo "${salida_final}" | grep -o 'WLAN_IP:[^]]*' | cut -d: -f2)
if echo "${salida_final}" | grep -q "ESTADO_ADB:true"; then
    adb_status="true"
else
    adb_status="false"
fi

        
 
if echo "${salida_final}" | grep -q "WLAN_IP:.\+"; then
    ip_wlan=$(echo "${salida_final}" | grep -o 'WLAN_IP:[^]]*' | cut -d: -f2)
else
    ip_wlan=""
fi
        
# ¡AQUÍ ESTÁ LA SOLUCIÓN!
# Rescatamos el estado de adb leyendo el texto impreso, ya que la variable 
# original se perdió en el subshell.
# Capturamos si la marca decía "true" o "false"
if echo "${salida_final}" | grep -q "ESTADO_ADB:true"; then
    adb_status="true"
else
    adb_status="false"
fi
        


# SI ESTÁ LA WLAN, PERO TAMBIÉN YA ESTAS CONECTADO A ADB, ENTONCES YA NO ES NECESARIO QUE TE PIDA CONECTAR, POR ESA RAZON ES FALSE
if [[ "${adb_status}" == "true" ]]; then # NO está la wlan pero SI ya está adb conectado 
    # echo -e "${ip_wlan}"
    # echo -e "Conexión adb ya establecida"
    disponible_adb="adbfull"
elif [[ -n "${ip_wlan}" && "${adb_status}" == "true" ]]; then # SI está la wlan Y SI ya está adb conectado
    # echo -e "${ip_wlan}"
    # echo -e "Conexión adb ya establecida"
    disponible_adb="adbfull"
elif [[ -n "${ip_wlan}" && "${adb_status}" == "false" ]]; then # SI está la wlan Y NO está adb conectado
    # te pedirá que hagas conexión adb 
    # echo -e "Listo para realizar la conexión adb"
    disponible_adb="routernadb"
elif [[ -z "${ip_wlan}" && "${adb_status}" == "false" ]]; then # NO está la wlan Y NO está adb conectado
    # echo -e "No hay router para realizar la conexión adb1"
    disponible_adb="nrouternadb"
else
    # CASO EXTRA: No hay wlan y no hay ADB conectado
    # echo -e "No hay router para realizar la conexión adb2"
    disponible_adb="nrouternadb"
fi

# Detenemos el spinner
detener_spinner
# echo -e "${salida_final}"
# 'sed /ESTADO_ADB/d; /WLAN_IP/d' BORRA completamente cualquier línea que contenga la palabra ESTADO_ADB y WLAN_IP
echo -e "${salida_final}" | sed '/ESTADO_ADB/d; /WLAN_IP/d'


# =================================================================

# =================================================================

: '
# Ejecutar y guardar el bloque principal
salida_final=$(generar_salida)
Ese símbolo de dólar con paréntesis $( ... ) se llama Sustitución de Comando (Command Substitution), y en Bash hace algo muy particular: crea un Subshell (un subproceso o proceso hijo).
Esto es exactamente lo que sucede paso a paso en la memoria de Bash:
Se crea un "Clon" (Subshell): Al ver el $(...), tu script crea un mini-entorno temporal (un proceso hijo) y manda a ejecutar generar_salida allí adentro.
Las variables cobran vida en el hijo: Dentro de esa burbuja temporal, adb_status efectivamente vale true o false. Tu función hace todo el trabajo perfectamente.
Se captura el texto: El proceso padre (tu script principal) está esperando afuera con un "micrófono". Todo lo que la función imprima con echo (el texto, los colores, los emojis) el script principal lo graba y lo guarda en la variable salida_final.
La burbuja explota (El subproceso muere): Cuando la función termina, ese entorno hijo se destruye. Y aquí está la trampa: se destruye llevándose consigo todas sus variables, incluyendo adb_status, ip_principal y dispositivo.
El resultado final: Tu script principal se queda con una variable gigante de texto (salida_final), pero de las variables que se usaron para generar ese texto... no sabe nada, para él no existen.
¿Cómo se vería si SÍ fuera global?
Si en tu script llamaras a la función de manera normal, sin el $(...), así:
generar_salida # Llamada normal sin capturar
Ahí el texto se imprimiría directamente en la pantalla de inmediato, no habría subshell, y tu variable adb_status sí conservaría su valor global de true o false para usarla después.
En resumen: Como necesitamos usar el $(...) para retener todo el texto oculto mientras el Spinner da vueltas (y luego imprimir todo el bloque de golpe al final), estamos obligados a ejecutarlo en un subshell. Por esa razón, la única forma de saber si ADB estaba en true o false en el script principal, es "leyendo" el texto que nos dejó grabado en salida_final.
: '
