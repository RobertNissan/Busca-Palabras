#!/bin/bash

echo "versión script 0.1"

### VERIFICAR SI EL DISPOSITIVO TIENE ROOT ###
if su -c "id" > /dev/null 2>&1; then
    echo "️‍🎯 ️Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    echo "🛑 No tienes acceso root" >/dev/null 2>&1
    ROOT_PERMISSIONS="false"
fi
### FIN VERIFICAR SI EL DISPOSITIVO TIENE ROOT ###







######FUNCIONES_CONEXION_INTERNET######
# importar la función python para verificar internet
#######  VERIFICA_INTERNET  #######
source ~/Busca-Palabras/config/verif_conex_internet
# bash
#######FUNCION_VERIFICAR_INTERNET#######
source ~/Busca-Palabras/config/verif_internet_full
#######FIN_FUNCION_VERIFICAR_INTERNET#######
#######FIN_VERIFICA_INTERNET#######
verif_internet=$(verif_tipo_con && echo "${conect_internet}") # OBTENER EL ESTADO DEL INTERNET


# =================== Detectar Hotspot / Conexión de Red ===================
detectar_hotspot_local() {
    local wlan_ip="$1"
    local hotspot_activo="false"

    # Si tienes una IP en wlan0 pero pertenece a rangos típicos de compartición
    # o si el sistema maneja el tethering levantando un rango específico:
    if [[ -n "$wlan_ip" ]]; then
        # Rangos habituales que asigna Android al hacer tethering Wi-Fi (Hotspot)
        if [[ "$wlan_ip" =~ ^192\.168\.43\. ]] || [[ "$wlan_ip" =~ ^172\.(1[6-9]|2[0-9]|3[0-1])\. ]]; then
            hotspot_activo="true"
        fi
    fi

    echo "$hotspot_activo"
}



# =================== Obtener IP principal ===================
get_primary_local_ip() {
    declare -A ifaces
    while IFS=: read -r iface ip; do
        if [[ -n $iface && -n $ip ]]; then
            ifaces["$iface"]="$ip"
        fi
    done < <(obtener_interfaces)

    # Prioridad: wlan0 → seth_lte0 → tun0 (VPN) → cualquier válida → fallback
    if [[ -n ${ifaces[wlan0]} && ${ifaces[wlan0]} != "127.0.0.1" ]]; then
        echo "${ifaces[wlan0]}"
        return
    fi
    
    if [[ -n ${ifaces[seth_lte0]} && ${ifaces[seth_lte0]} != "127.0.0.1" ]]; then
        echo "${ifaces[seth_lte0]}"
        return
    fi

    if [[ -n ${ifaces[tun0]} && ${ifaces[tun0]} != "127.0.0.1" ]]; then
        echo "${ifaces[tun0]}"
        return
    fi

    # Cualquier otra IP válida (excepto loopback)
    for ip in "${ifaces[@]}"; do
        if [[ $ip != "127.0.0.1" ]]; then
            echo "$ip"
            return
        fi
    done

    # Fallback: tratar de obtener por socket (ruta hacia 8.8.8.8)
    ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7; exit}' || echo "127.0.0.1"
}

# =================== Obtener IP principal ===================






# Verificar si un dispositivo está conectado a adb en mi Android prioridad emulator-5554
# =================== Verificar ADB conectado (prioridad emulator-5554) ===================
export_var() {
    # Pasar las variables de bash() {disponible_adb, adb_conectado, adb_conectado_ip_device} al script de Python
    export ip
    export ip_device
    export adb_estado
    export disponible_adb
    export adb_conectado_ip_device
}
verif_adb_conect_echo() {
    # Obtener la ip principal
    local ip=$(get_primary_local_ip) 
    local adb_output connected_devices adb_estado ip_device

    # Obtener lista de dispositivos conectados por ADB
    adb_output=$(adb devices -l 2>/dev/null)
    connected_devices=$(echo "$adb_output" | awk '$2 == "device" {print $1}')

    # --- PRIORIDAD ---
    # 1️⃣ Si está el emulator-5554 → tomar ese
    ip_device=$(echo "$connected_devices" | grep -E "^emulator")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        # echo -e "🔌 ${GREEN}ADB conectado${NC}: emulator-5554"
        echo -e "$ip_device"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi
    

    # 2️⃣ Si no, buscar por mi IP con CUALQUIER puerto (ej: 192.168.1.27:5555, :1234, etc.)
    ip_device=$(echo "$connected_devices" | grep -E "^${ip}:[0-9]+$")
    if [[ -n "$ip_device" ]]; then
        disponible_adb='false'
        adb_estado="true"
        echo "$adb_estado"
        echo -e "${ip_device}"
        ip_device="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        export_var
        return 0
    fi

    # 🟢 🔴
    # 3️⃣ Si no hay ninguno de los anteriores → desconectado
    adb_estado="false"
    echo "$adb_estado"
    echo "🔴 ADB desconectado"
    adb_conectado_ip_device=""
    return 1
}
#uso
: '
# =================== MAIN ===================
verif_internet=$(verificar_internet)
ip=$(get_primary_local_ip)
echo "🌐 IP principal: $ip"
build_status_info "$verif_internet"

verif_adb=$(verif_adb_conect "${ip}")
# echo "$verif_adb"
echo ""
# obtener el dispositivo adb conectado
dispositivo=$(verif_adb_conect_echo "${ip}" | tail -n1)
echo "$dispositivo"
# obtener su estado true o false
adb_status=$(verif_adb_conect "${ip}" | head -n1)
echo "estado adb: $adb_status"
: '






# =================== Obtener interfaces e IPs ===================
obtener_interfaces() {
    declare -A interfaces
    local actual linea ip

    while IFS= read -r linea; do
        # Detecta inicio de interfaz
        if [[ $linea != " "* && $linea == *:* ]]; then
            actual="${linea%%:*}"
        # Detecta IPv4 en la interfaz actual
        elif [[ $linea == *"inet "* && -n $actual ]]; then
            ip=$(echo "$linea" | grep -oE 'inet (addr:)?([0-9]{1,3}\.){3}[0-9]{1,3}' | awk '{print $2}' | sed 's/addr://')
            interfaces["$actual"]="$ip"
        fi
    done < <(ifconfig 2>/dev/null)

    # Imprimir en formato iface:ip
    for iface in "${!interfaces[@]}"; do
        echo "$iface:${interfaces[$iface]}"
    done
}


# =================== Clasificar conexión ===================
# =================== Clasificar conexión ===================
clasificar_conexion() {
    local ifaces verif_internet tipo="Modo avión" detalles=() wlan_ip=""

    mapfile -t ifaces < <(obtener_interfaces)
    verif_internet="$1"

    # Convertir a diccionario
    declare -A iface_map
    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        iface_map["$iface"]="$ip"
    done

    # VPN
    for k in "${!iface_map[@]}"; do
        [[ $k == tun* || $k == tap* ]] && detalles+=("VPN activa")
    done

    wlan_ip="${iface_map[wlan0]}"

    # Obtener el dispositivo ADB (necesario para consultar ajustes del sistema)
    local dispositivo=$(verif_adb_conect_echo | tail -n1)
    local mobile_data_enabled="0"
    local airplane_mode_on="0"
    if [[ -n "$dispositivo" ]]; then
        mobile_data_enabled=$(adb -s "$dispositivo" shell settings get global mobile_data 2>/dev/null | tr -d '\r')
        airplane_mode_on=$(adb -s "$dispositivo" shell settings get global airplane_mode_on 2>/dev/null | tr -d '\r')
    fi

    # Detección del tipo de red (Priorizando Hotspot por rangos IP locales y ADB)
    if [[ -n $wlan_ip && ($wlan_ip =~ ^192\.168\.43\. || $wlan_ip =~ ^172\.(1[6-9]|2[0-9]|3[0-1])\.) ]]; then
        tipo="Hotspot Android"
    elif [[ -n $wlan_ip && $wlan_ip == 192.168.* ]]; then
        tipo="Router Wi-Fi"
    elif [[ -n $wlan_ip && $wlan_ip == 10.* ]] || grep -q "172\.(1[6-9]|2[0-9]|3[0-1])\." <<<"${iface_map[@]}"; then
        tipo="Hotspot Android"
    elif grep -q "172\.20\.10\." <<<"${iface_map[@]}"; then
        tipo="Hotspot iPhone"
    elif [[ -n $wlan_ip ]]; then
        tipo="Router Wi-Fi"
    elif printf '%s\n' "${!iface_map[@]}" | grep -Eq "^(seth|rmnet|wwan|usb)"; then
        tipo="Datos móviles"
    elif [[ "$mobile_data_enabled" == "1" && "$airplane_mode_on" == "0" ]]; then
        tipo="Red telefónica"
    elif [[ "$airplane_mode_on" == "1" ]]; then
        tipo="Modo avión"
    fi

    detalles+=($( [[ $verif_internet == "true" ]] && echo -e "${GREEN}con Internet${NC}" || echo -e "${RED}sin Internet${NC}" ))
    echo "$tipo ${NC}(${detalles[*]})"
}


# =================== Mostrar estado ===================
build_status_info() {
    local verif_internet="$1"
    local estado tipo_icon ifaces iface ip

    mapfile -t ifaces < <(obtener_interfaces)
    estado=$(clasificar_conexion "$verif_internet")
    
    # Elegir el ícono según el tipo de conexión.
    case "$estado" in
        *"Router Wi-Fi"*) tipo_icon="📡";;     # Wi-Fi / router
        *"Datos móviles"*) tipo_icon="📶";; # teléfono / datos móviles
        *"Hotspot"*) tipo_icon="🔥";;            # hotspot / tethering
        *"Modo avión"*) tipo_icon="✈️";;      # modo avión
        *) tipo_icon="🌐";;                              # genérico / desconocido
    esac

    echo -e "${tipo_icon} ${MAGENTA}$estado"

    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        echo -e "💻 ${CYAN}$iface${NC}: $ip"
    done
}





# obtener la IP 
ip=$(get_primary_local_ip)

# obtener las interfaces y verifica internet
build_status_info "$verif_internet"

# Verificar estado adb
# obtener el dispositivo adb conectado
dispositivo=$(verif_adb_conect_echo "${ip}" | tail -n1)
# obtener su estado true o false
adb_status=$(verif_adb_conect_echo "${ip}" | head -n1)
if [[ "$adb_status" == "true" ]]; then
    echo "🔌 $dispositivo"
    echo "🟢 estado adb: $adb_status"
else
    echo "$dispositivo"
    echo "🔴 estado adb: $adb_status"
fi