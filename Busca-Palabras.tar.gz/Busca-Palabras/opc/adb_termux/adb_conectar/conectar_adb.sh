#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si Python está instalado
if [ -x ${PREFIX}/bin/python ]; then
    echo "Python ya está instalado." >/dev/null 2>&1
else 
    echo "Instalando python..."
    apt install python -y
fi

# Verificar si adb está instalado
if [ -x "$PREFIX/bin/adb" ]; then
    echo "adb instalado." >/dev/null 2>&1
    adb start-server
else
    echo "Instalando adb..."
    pkg install android-tools -y >/dev/null 2>&1
    echo "adb instalado correctamente."
fi

# Verificar si nmap está instalado
if [ -x "$PREFIX/bin/nmap" ]; then
    echo "nmap instalado." >/dev/null 2>&1
else
    echo "Instalando nmap..."
    pkg install nmap -y >/dev/null 2>&1
    echo "nmap instalado correctamente."
fi
if [ -x $PREFIX/share/doc/termux-api ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando termux-api"
    pkg install termux-api
fi

str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
ip=$(echo "${str%%/*}")


#######FUNCIONES_DE_CONECCION#######
disponible_adb='false'

mi_dispositivo() {
    echo ""
    echo "Brand ID: $(getprop ro.product.system.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Version de Android: $(getprop ro.build.version.release)"
    echo "Model ID: $(getprop ro.build.product)"
    echo "Kernel ID: $(uname -r)"
    echo "Chipset ID: $(getprop ro.product.board)"
    echo "Architecture: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        # seleccionar_dispositivo "$ip_objetivo"
        disponible_adb='true'
    fi
    
    conn=$(adb connect "$ip:5555")
    if [[ "$conn" == "failed"* ]]; then
        echo "ok" >/dev/null 2>&1
    else
        echo "Conexion a Internet a traves del enrutador WiFi1"
        conn=$(adb connect "${ip0}:5555")
        sleep 3
        # seleccionar_dispositivo
    fi
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos1() {
    encabezado_tabla='false'
    mi_dispositivo
    my_device="$1"
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col*7/100))
    mul2=$(($col*47/100))
    mul3=$(($col*27/100))
    mul4=$(($col*9/100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 
      
    dispositivos=()
    # variable de conteo de cantidad de dispositivos a mostrar en la tabla
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    # offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}')
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}' | grep -v "$my_device")
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')
    
    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            if [ "$encabezado_tabla" == 'false' ]; then
                echo ""
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                encabezado_tabla='true'
            fi
            dispositivos+=("$device")
            # Formatear el id con 2 dígitos
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | v%-${mul4}s#\n" " $id_fortmat" "$device" "$model" "$version"
            printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
            id=$((id+1))
        done
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo "Dispositivos OFFLINE:"
        echo "$offline_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo "Dispositivos NO AUTORIZADOS:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
}


# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    mostrar_dispositivos1
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    echo -en "Ingrese el número del dispositivo o 'q+enter' para salir: "
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
    
}

# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    echo ""
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ]"
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell echo "[ DEVICE: \$(getprop ro.product.model) ]"
    adb -s "$dispositivo" shell echo "[ BRAND: \$(getprop ro.product.system.brand) ]"
    adb -s "$dispositivo" shell echo "[ MODEL: \$(getprop ro.build.product) ]"
    adb -s "$dispositivo" shell echo "[ KERNEL: \$(uname -r) ]"
    
    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell echo "[ GPU: \$(getprop ro.hardware.gpu) ]"
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell echo "[ GPU: $gpu_info ]"
    fi

    adb -s "$dispositivo" shell echo "[ CPU: \$(getprop ro.hardware) ]"
    adb -s "$dispositivo" shell echo "[ ANDROID VERSION: \$(getprop ro.build.version.release) ]"
    adb -s "$dispositivo" shell echo "[ Android ID: \$(getprop ro.serialno) ]"
    
}

function connect {
    capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        echo -e "${GREEN}Conectando al puerto principal adb.\nPor favor, espere...${NC}"
    fi
    
    ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import multiprocessing
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

ip_objetivo = "$ip_objetivo"
num_processes = 10  # Puedes ajustar este valor segun tus necesidades

# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

def scan_ports(ip, start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    result = nm.scan(ip, arguments=f'-p {port_range} -Pn -T4')

    if 'scan' not in result or ip not in result['scan']:
        print(f"\nError al obtener los resultados del escaneo para la IP {ip} en el rango de puertos {port_range}")
        print("Asegúrate de que la IP sea válida y responda a los escaneos de puertos.")
    else:
        if nm[ip].all_protocols():
            for protocol in nm[ip].all_protocols():
                lport = sorted(nm[ip][protocol].keys())
                for port in lport:
                    print("Puerto", port, ":", nm[ip][protocol][port]['state'])
        else:
            print(f"\nNo se encontraron puertos abiertos para la IP {ip} en el rango de puertos {port_range}")

# Dividir el rango de puertos para escanear en varios subconjuntos
port_ranges = [(i, i + 65535//num_processes) for i in range(1, 65536, 65535//num_processes)]

# Crear procesos para escanear los puertos en paralelo
processes = []
for start, end in port_ranges:
    process = multiprocessing.Process(target=scan_ports, args=(ip_objetivo, start, end))
    processes.append(process)
    process.start()

# Esperar a que todos los procesos terminen
for process in processes:
    process.join()
EOF
)

    ports_output=$(python -c "$python_script")

    if echo "$ports_output" | grep -q "open"; then
        num_ports=$(echo "$ports_output" | grep "open" | awk '{print $2}')
        
        for port in $num_ports; do
            echo -e "${YELLOW}Probando puerto${NC}: $port"
            # adb start-server >/dev/null 2>&1
            verif_con=$(adb connect "${ip_objetivo}:${port}")

            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}La conexión fue exitosa.${NC}"
                adb -s "${ip_objetivo}:${port}" tcpip 5555
                sleep 5
                # Esperar hasta que el dispositivo esté listo en el puerto 5555
                while ! adb connect "${ip_objetivo}:5555" >/dev/null 2>&1; do
                    echo -e "${YELLOW}Esperando a que ADB esté listo en el puerto 5555...${NC}"
                    sleep 1  # Esperar un segundo antes de intentar de nuevo
                done
                
                puerto="5555"
                # Conección permanente
                adb -s "${ip_objetivo}:5555" tcpip "${puerto}"
                sleep 5
                ip=$(echo "${ip_objetivo}:5555" | cut -d: -f1)
                DISPOSITIVO="${ip_objetivo}:5555"
                # echo "${DISPOSITIVO}" 
                adb connect "${DISPOSITIVO}" 
                # adb devices
                adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
                
                seleccionar_dispositivo "$ip_objetivo"
                exit
            # Si los puerto fallan, prueba de inmediato con otro.
            elif [[ "$verif_con" == *"offline"* || "$verif_con" == *"not found"* || "$verif_con" == *"failed"* ]]; then
                continue  # No es necesario matar el servidor aquí
            else
                echo -e "${RED}La conexión falló. Mensaje: $verif_con${NC}"
            fi
        done
    fi
    connect
    capp_adb='true'
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$ip_objetivo"
    fi

    #sleep 3
    echo -e "\n${RED}Servidor adb, no encendido${NC}!!!"
    echo -e "${YELLOW}Siga las instrucciones${NC}:\n"
    echo "Habilitar la depuracion USB en Android, para hacer conexion adb:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB'."
    echo ""
    echo 'Si solo necesitas que se active en tu android, activa "Depuracion inalambirca"'
    echo '6. Selecciona donde dice: "Vincular dispositivo con codigo de sincronizacion"'
    echo -e  'En esa parte se mostrara una pequeña ventana que dice:'
    echo -e "Vincular con disposivo\n${YELLOW}Codigo de vinculacion de WI-FI\n${RED}123456\n${YELLOW}Direccion IP y PUERTO\n${YELLOW}${ip}${NC}:${BLUE}12345${NC}"
    echo '7. Habilitar la pantalla dividida entre "Vincular dispositivo con codigo de sincronizacion" y "Termux"' 

    echo -e "\nIngresa el puerto:"
    echo -en "$ip:"
    read puerto
    while [ -z "$puerto" ]; do
        # echo -en "${YELLOW}$ip:${BLUE}"
        read puerto
    done
    
    echo -en "Ingrese código de vinculación WI-FI: "
    read code
    while [ -z "${code}" ]; do
        echo -en "Ingrese código de vinculación WI-FI: "
        read code
    done
    
    echo -e "${YELLOW}Ejecutando: ${NC}adb pair ${YELLOW}${ip0}:${BLUE}${puerto} ${RED}${code}${NC}"
    adb pair ${ip0}:${puerto} ${code} 2>/dev/null
    # Si se conecta entonces: connect!!!
    # if [[ "${resultado}" == *"Failed"* || "${resultado}" == *"error"* ]]; then
    if [ $? -eq 0 ]; then
        echo -e "${YELLOW}Código correcto!!!.${NC}"
        connect
    else
        echo -e "${YELLOW}La conexion adb fallo. Mensaje:\n${RED}puerto o código erroneo...${NC}"
        return
    fi    
}

wlan0() {
    
    # Obtener la IP de wlan0, si está disponible
    ip0=$(ip addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)

    # Si no se encuentra IP en wlan0, buscar una IP distinta de 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
    fi
    # Mostrar la IP de wlan0 si está disponible
    if [ "$ip0" ]; then
        disponible_adb='true'
        return
    fi
    # Mostrar otra IP si no se encontró en wlan0
    if [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1" >/dev/null 2>&1
        disponible_adb='false'
        return
    fi
    echo "$disponible_adb"
}
#######FUNCIONES_FIN_CONECCION#######
# verif_adb_conect #

verif_adb_conect() {
    # Obtener la IP local
    str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
    ip=$(echo "${str%%/*}")

    # Obtener los dispositivos conectados por ADB
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')

    # Mostrar la IP local
    echo -e "\nIP local: $ip"

    # Buscar si hay un dispositivo con la IP o el emulador
    ip_device=$(echo "$connected_devices" | grep -Ei "$ip:5555|emulator-5554" | head -n 1)

    # Verificar si se encontró algún dispositivo
    if [[ -n "$ip_device" ]]; then
        echo -e "${GREEN}Dispositivo conectado a adb${NC}: $ip_device"
        disponible_adb='true'
        conectado_adb='true'
        return
    else
        # disponible_adb='false'
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0
        return
    fi
    echo "$disponible_adb"
}

menu_principal() {
    while true; do
        verif_adb_conect
        
        # Obtener la IP local
        str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
        ip=$(echo "${str%%/*}")        
        # Obtener los dispositivos conectados por ADB
        adb_output=$(adb devices -l)
        connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
        # Buscar si hay un dispositivo con la IP o el emulador
        ip_device=$(echo "$connected_devices" | grep -Ei "$ip:5555|emulator-5554" | head -n 1)

        # Verificar si se encontró algún dispositivo
        if [[ -n "$ip_device" ]]; then
            seleccionar_dispositivo
        fi
        if [ "$disponible_adb" == 'false' ]; then
            echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            echo -e "\n${CYAN}Menú Principal${NC}"
            # echo -e "00. ${GREEN}Conectar adb${NC}"
            break
        elif [ "$disponible_adb" == 'true' ]; then     
            echo -e "\n${YELLOW}La dirección IP de wlan0 es${NC}: $ip0"
            echo -e "${GREEN}Disponible para conectar adb${NC}"
            # echo -e "\n${CYAN}Menú Principal${NC}"
            echo -e "${YELLOW}01. ${GREEN}Conectar adb${NC}"
            echo -e "${YELLOW}02. ${GREEN}Salir${NC}"
            echo -e "|"
        fi
        read -p "--> " eleccion
        case $eleccion in
            # descargar_y_descomprimir "$1"   "$2"                  "$3"                    "$4"              "$5"            "$6"                            "$7"               "$8"                             "$9"            "$10"
            # descargar_y_descomprimir "$url" "$archivo.zip" "$ruta_destino" "$ruta_apk" "$url_apk" "$ruta_destino_apk" "$ruta_obb" "$ruta_destino_obb" "$apk_zip" "$adb_conectado" 
        1|01)
             if [ "$disponible_adb" == 'true' ]; then
                 solicitar_emparejamiento
             fi
             ;;
        2|02)
            echo "Saliendo..."
            exit 0
             ;;
        *)
            echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
            ;;
        esac
    done
}

menu_principal