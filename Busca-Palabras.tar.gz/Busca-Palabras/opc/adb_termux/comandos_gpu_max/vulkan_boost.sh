#!/bin/bash

# Verifica si adb está instalado
if ! command -v adb &>/dev/null; then
    echo "ADB no está instalado o no está en el PATH. Instálalo primero."
    exit 1
fi

# Verifica si hay un dispositivo conectado
if ! adb devices | grep -w "device" &>/dev/null; then
    echo "No se detecta ningún dispositivo conectado. Conéctalo y asegúrate de que ADB esté habilitado."
    exit 1
fi

# Función para aplicar configuraciones
aplicar_configuraciones() {
    echo "Aplicando configuraciones avanzadas de Vulkan..."
    
    # Activar Vulkan globalmente
    adb shell setprop debug.hwui.use_vulkan true
    adb shell su -c setprop persist.hwui.use_vulkan true
    adb shell su -c setprop persist.vulkan.enable true
    adb shell setprop debug.graphics.vulkan 1
    adb shell setprop debug.vulkan.experimental 1

    # Optimización de memoria
    adb shell setprop debug.vulkan.buffer_size 4096MB
    adb shell setprop debug.vulkan.memory_cache_size 4096
    adb shell setprop debug.vulkan.memory_optimization aggressive
    adb shell setprop debug.vulkan.large_heap_allocation 1
    adb shell setprop debug.vulkan.remove_memory_limits true

    # Rendimiento y latencia
    adb shell setprop debug.vulkan.low_latency_mode 1
    adb shell setprop debug.vulkan.enable_latency_reduction true
    adb shell setprop debug.vulkan.async_compute 1
    adb shell setprop debug.vulkan.preload_pipelines true
    adb shell setprop debug.vulkan.precompiled_shaders true
    adb shell setprop debug.vulkan.max_frames_in_flight 10
    adb shell setprop debug.vulkan.swap_chain.max_fps 60

    # Compilación y caché de shaders
    adb shell setprop debug.vulkan.pipeline_cache_enable_all 1
    adb shell setprop debug.vulkan.pipeline_cache_size 1048576000
    adb shell setprop debug.vulkan.precompile_shaders 1
    adb shell setprop debug.vulkan.shader_optimizer true
    adb shell setprop debug.vulkan.preload_shaders true
    adb shell setprop debug.vulkan.shadercache.enable true
    adb shell setprop debug.vulkan.shader_optimization_level 3 # Nivel máximo de optimización


    # Hilos y paralelismo
    adb shell setprop debug.vulkan.multi_threaded_rendering true
    adb shell setprop debug.vulkan.render_threads 8
    adb shell setprop debug.vulkan.threading_enable 1
    adb shell setprop debug.vulkan.thread_priority 3

    # Presentación y sincronización
    adb shell setprop debug.vulkan.frame_present_mode immediate
    adb shell setprop debug.vulkan.present_mode immediate
    adb shell setprop debug.vulkan.vsync false
    adb shell setprop debug.vulkan.swap_chain.image_count 5 # Aumentar imágenes en la cadena

    # Extensiones avanzadas
    adb shell setprop debug.vulkan.enable_advanced_extensions 1
    adb shell setprop debug.vulkan.use_vk12_extensions 1
    adb shell setprop debug.vulkan.extension_vk_khr_swapchain true
    adb shell setprop debug.vulkan.extension_vk_ext_memory_budget true
    adb shell setprop debug.vulkan.extension_vk_ext_descriptor_indexing true

    # Configuraciones específicas de GPU (Adreno/Mali)
    adb shell setprop debug.vulkan.adreno.dynamic.gfxboost 1
    adb shell setprop debug.vulkan.adreno.lowlatency 1
    adb shell setprop debug.vulkan.adreno.shaders_priority 1
    adb shell setprop debug.vulkan.mali.dynamic_rendering 1
    adb shell setprop debug.vulkan.mali.performance_tuning 1
    adb shell setprop debug.vulkan.mali.power_optimize 1
    adb shell setprop debug.vulkan.mali.shader_compilation 1

    echo "Configuraciones aplicadas con éxito. Reinicia el dispositivo para que los cambios surtan efecto."
}

# Función para revertir configuraciones
revertir_configuraciones() {
    echo "Revirtiendo configuraciones a valores predeterminados..."
    adb shell setprop debug.hwui.use_vulkan false
    adb shell su -c setprop persist.hwui.use_vulkan false
    adb shell su -c setprop persist.vulkan.enable false
    adb shell setprop debug.graphics.vulkan 0
    adb shell setprop debug.vulkan.vsync true
    adb shell setprop debug.vulkan.enable_latency_reduction false
    adb shell setprop debug.vulkan.async_compute 0
    adb shell setprop debug.vulkan.low_latency_mode 0
    echo "Configuraciones revertidas. Reinicia el dispositivo para que los cambios surtan efecto."
}

# Menú principal
echo "=== Script de Optimización Vulkan ==="
echo "1. Aplicar configuraciones avanzadas"
echo "2. Revertir configuraciones a valores predeterminados"
echo "3. Salir"
read -p "Selecciona una opción: " opcion

case $opcion in
1)
    aplicar_configuraciones
    ;;
2)
    revertir_configuraciones
    ;;
3)
    echo "Saliendo del script."
    exit 0
    ;;
*)
    echo "Opción inválida. Saliendo."
    exit 1
    ;;
esac
