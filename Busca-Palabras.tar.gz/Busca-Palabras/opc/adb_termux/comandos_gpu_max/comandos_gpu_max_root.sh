#!/bin/bash

# Ejecutar asi:
# su -c sh /sdcard/comandos_gpu_max

echo "Forzar el uso de Vulkan en lugar de OpenGL (si tu dispositivo lo soporta):"
setprop debug.vulkan.enable 1
setprop debug.vulkan.sampler_optimize 1
setprop debug.vulkan.dyn_swapchain 1
setprop debug.vulkan.multiview 1
setprop debug.vulkan.dynamic_rendering 1
# Deshabilitar la sincronización vertical (si se busca un rendimiento más alto a costa de la suavidad visual):
setprop debug.sf.vsync_mode 0

# Comandos para maximizar la GPU
echo -e "\nHabilitar modo de alto rendimiento para gráficos"
setprop sys.gpu_performance 1
setprop debug.performance.tuning 1
setprop debug.hwui.drop_shadow_cache_size 16
setprop debug.hwui.gradient_cache_size 4
setprop debug.hwui.layer_cache_size 64
setprop debug.hwui.r_buffer_cache_size 16
setprop debug.hwui.text_large_cache_height 4096
setprop debug.hwui.text_large_cache_width 4096
setprop debug.hwui.text_small_cache_height 1024
setprop debug.hwui.text_small_cache_width 1024

echo -e "\nOptimizar el consumo de memoria GPU"
setprop debug.hwui.memory_usage 768
setprop debug.hwui.layer_cache_size 96
setprop debug.hwui.texture_cache_size 256
setprop debug.sf.texture_cache_size 512
setprop debug.hwui.texture_filter_quality 4
setprop debug.hwui.fbo_cache_size 128

echo -e "\nHabilitar Vulkan agresivo"
setprop debug.vulkan.multiview 1
setprop debug.vulkan.swapchain 3
setprop debug.vulkan.experimental 1

echo -e "\nForzar GPU para renderizado completo"
setprop sys.ui.hw true
setprop debug.hwui.renderer skiavk
setprop sys.force_gpu_rendering true

echo -e "\nReducir interrupciones de gráficos"
setprop debug.sf.triplebuffer 1
setprop debug.sf.trip_buffer 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.display_refresh_rate 1
setprop sys.display.low_latency_mode 1
setprop debug.sf.vsync 1

# Comandos para una respuesta táctil extrema
echo -e "\nReducir latencia táctil"
setprop sys.touch.sampling_rate 240
setprop debug.touch.resampling 0
setprop debug.touch.prediction 1
setprop debug.touch.trace 1

echo -e "\nOptimizar el procesamiento táctil"
setprop debug.touch.average_filter 0
setprop debug.touch.fps_rate 240
setprop debug.touch.max_rate 1000

# Comandos para CPU y memoria (agresivo)
echo -e "\nConfigurar CPU para alto rendimiento"
setprop sys.perf.cpu.boost 1
setprop sys.use_cpu_boost 1
setprop sys.cpufreq.boost 1
setprop sys.perf.max_freq 1
setprop sys.perf.high_load 90
setprop sys.cpu.overclock 1

echo -e "\nAumentar uso de RAM"
setprop dalvik.vm.heapgrowthlimit 384m
setprop dalvik.vm.heapsize 768m
setprop dalvik.vm.heapstartsize 24m
# setprop ro.sys.fw.bg_apps_limit 25

# Configuración sugerida para mayor fluidez:
# Si priorizas la fluidez por encima del ahorro de batería:
# Este valor es agresivo, permitiendo que la CPU baje la frecuencia rápidamente cuando la carga disminuye. Esto puede ser beneficioso para la batería, pero si baja demasiado rápido, podrías experimentar pequeños retrasos al volver a aumentar la carga.
setprop schedutil.down_rate_limit_us 500
# Este valor es excelente para fluidez porque permite que la CPU suba de frecuencia rápidamente. Sin embargo, si el dispositivo genera demasiado calor o consume más batería, podrías probar un valor como 300-500.
setprop schedutil.up_rate_limit_us 250
# Este valor está bien ajustado para fluidez, ya que permite cambios rápidos sin sobrepasar las frecuencias objetivo. Reducirlo por debajo de 5 podría generar inestabilidad en el rendimiento, mientras que valores mayores (como 7 o 10) harían los cambios más conservadores.
setprop schedutil.freq_margin 5
# Este valor es un poco bajo. Si se reduce aún más, como en tu configuración (5000 o menos), el sistema podría estar recalculando frecuencias constantemente, lo que aumenta la carga sobre el scheduler y puede hacer que la CPU trabaje más de lo necesario. Optimización posible: Probar con 7500-10000 para evitar cambios excesivos en tareas ligeras.
setprop schedutil.timer_slack_val_us 7500

echo -e "\nComandos para juegos intensivos"
setprop debug.performance.mode 1
setprop debug.performance.game_mode 1
setprop debug.performance.gfx_quality 3
setprop debug.performance.render_distance 5
setprop sys.gameboost 1
setprop sys.gaming_performance_mode 1

echo -e "\nAjustes gráficos dinámicos"
setprop debug.sf.dynamic_display_quality 1
setprop debug.hwui.texture_filter_anisotropic 16
setprop sys.display.adaptive_quality 1

# Optimizar el almacenamiento
# Activar la compresión de ZRAM (si está disponible):
setprop persist.sys.zram_enabled 1
# Optimizar el escalado de la CPU y GPU
# Activar el modo de alto rendimiento:
cmd power set-mode 2
pm trim-caches 1G
# Optimizar la memoria RAM: Reducir el número de procesos en caché
# Forzar que las aplicaciones en segundo plano se cierren más agresivamente:
settings put global activity_manager_constants max_cached_processes=8
# Optimizar el almacenamiento
# Activar la compresión de ZRAM (si está disponible):
setprop persist.sys.zram_enabled 1
# Activa ciertas optimizaciones gráficas que usan hardware acelerado:
setprop ro.hardware.gpu.enable 1
# Priorizar procesos de GPU en el sistema
# Este comando prioriza los procesos relacionados con la GPU:
setprop persist.gpu.priority 1
setprop debug.sf.limit_fps 0
setprop persist.gpu.priority 3
setprop persist.sys.thermal.config.disable true
setprop persist.sys.turbo.enabled 1
setprop debug.vulkan.priority 1
# Activar angle (OpenGL sobre Vulkan)
# ANGLE (Almost Native Graphics Layer Engine) permite ejecutar OpenGL ES sobre Vulkan, lo que puede mejorar el rendimiento en dispositivos sin soporte directo de controladores de juegos:
settings put global angle_debug_package org.chromium.angle
setprop debug.angle.force_angle vulkan
setprop debug.angle.force_angle skiavk
setprop debug.angle.use_angle 1
# Activando angle driver
setprop debug.angle.enable true
setprop debug.angle.vulkan true
# Mejorar el manejo de caché de disco
# Activa ajustes de lectura/escritura para almacenamiento más rápido.
setprop ro.sys.fw.dex2oat_thread_count 6
setprop persist.sys.use_dex2oat_threads 6

settings put global gfx_flush 1
setprop debug.sf.showfps 1


# Configuraciones Específicas para Vulkan con GPU Adreno
# Si tu dispositivo tiene una GPU Adreno (Snapdragon), estas configuraciones son muy útiles:
# 1. Habilitar optimizaciones específicas
setprop debug.vulkan.adreno.dynamic.gfxboost 1
setprop debug.vulkan.adreno.lowlatency 1
# 2. Reducir el tiempo de compilación de shaders
# Esto puede mejorar los tiempos de carga en juegos pesados:
setprop debug.vulkan.adreno.shader_compilation 1
# 3. Forzar GPU Boost para Vulkan
# Maximiza el rendimiento de la GPU mientras usa Vulkan:
setprop debug.vulkan.adreno.gpufreq_boost 1

# Configuraciones Específicas para GPU Mali
# Si usas una GPU Mali (Exynos, Kirin), estos ajustes son ideales:
# 1. Optimizar consumo de energía
setprop debug.vulkan.mali.power_optimize 1
# 2. Ajustar el tamaño de cuadros de renderizado
setprop debug.vulkan.mali.render_frame_size 48


# Forzar Modo de Carga de Texturas GPU
# Esto mejora la velocidad de renderizado en juegos al usar memoria de GPU para cargar texturas:
setprop persist.sys.enable_gpu_overlay 1


#----
# Ajustar el Pipeline de gráficos (Triple Buffering):
# Activa el Triple Buffering para reducir el "tearing" en gráficos. En dispositivos compatibles:
setprop debug.hwui.render_buffer 3   
setprop debug.hwui.vulkan true
setprop debug.vulkan.enable_low_latency true
# Habilitar optimizaciones avanzadas de Vulkan
# Permite optimizaciones específicas del driver gráfico para Vulkan:
setprop debug.vulkan.adreno.dynamic.gfxboost 1
setprop debug.vulkan.adreno.lowlatency 1
# Aumentar el tamaño del búfer de la GPU
# Este ajuste permite manejar más cuadros simultáneamente para evitar cuellos de botella:
setprop debug.hwui.render_buffer_size 64
# Ajustar el tiempo de espera del renderizado
# Reduce el tiempo que la GPU espera antes de descartar un cuadro:
setprop debug.vulkan.timeout 250
# Optimizar el preprocesamiento de Vulkan
# Forzar a Vulkan a precompilar shaders, mejorando el rendimiento en la ejecución:
setprop debug.vulkan.shadercache.enable true
# Configurar la prioridad de los shaders
# Ajusta la prioridad para optimizar la carga de shaders en dispositivos con GPUs Adreno:
setprop debug.vulkan.adreno.shaders_priority 1
 # Activar Tiling en Vulkan
# Mejora el rendimiento en dispositivos que soporten GPU Tiling (especialmente Mali o Adreno):
setprop debug.vulkan.enable_tiling 1
# Reducir latencia de la GPU
# Minimiza el tiempo de espera de la GPU para renderizar cuadros:
setprop debug.gpu.reduce_latency 1
# Aumentar tamaño de buffer de gráficos
# Esto ayuda en juegos con texturas o gráficos intensivos:
setprop debug.gpu.graphics_buffer_size 128
# Habilitar optimización para juegos 3D
# Activa un modo especial para priorizar gráficos 3D:
setprop debug.gpu.game_3d_optimizations 1
# Habilitar Renderizado Multihilo
# Asegura que el renderizado de Vulkan aproveche múltiples hilos de la CPU:
setprop debug.vulkan.multithread_rendering 1
# Reducir la Latencia de la GPU
# Optimiza el tiempo entre el procesamiento del cuadro y su presentación:
setprop debug.vulkan.low_latency_mode 1
# Forzar la Prioridad Alta del Hilo de Renderizado
# Aumenta la prioridad del hilo principal de renderizado Vulkan:
setprop debug.hwui.render_thread_priority 1
# Activar Triple Buffering (Buffer Triple)
# Incrementa la fluidez al permitir que Vulkan maneje tres cuadros en paralelo:
# Habilitar buffer triple
# Incrementa la fluidez del renderizado en juegos y aplicaciones gráficamente intensivas:
setprop debug.hwui.triple_buffering 1
# Configurar Sincronización de Presentación
# Reduce la latencia al optimizar el manejo del V-Sync en Vulkan:
setprop debug.vulkan.presentation_mode fifo_relaxed
# Activar Soporte Extendido de Extensiones Vulkan
# Permite que Vulkan utilice extensiones avanzadas si el hardware las soporta:
setprop debug.vulkan.enable_extensions 1
# Configurar el Modo de Presentación
# Controla cómo se presentan los fotogramas al display para reducir latencia:
setprop debug.vulkan.present_mode mailbox
setprop debug.vulkan.present_mode immediate
# Habilitar optimizaciones de rendimiento en Vulkan:
# Activar la reducción de latencia en Vulkan:
setprop debug.vulkan.enable_latency_reduction true
# Ajuste del uso de CPU y GPU:
# Ajustar la prioridad de los hilos de Vulkan:
setprop debug.vulkan.thread_priority 2
# Optimizar el uso de la memoria de Vulkan:
# Ajustar la memoria de caché de Vulkan:
setprop debug.vulkan.memory_cache_size 512
# Habilitar la extensión de Vulkan de uso avanzado:
# Habilitar la extensión VK_KHR_display:
setprop debug.vulkan.extension_vk_khr_display true
# Habilitar la extensión VK_KHR_swapchain:
setprop debug.vulkan.extension_vk_khr_swapchain true
# Ajustar la compilación de shaders de Vulkan:
setprop debug.vulkan.shader_optimizer true
# Ajustar el uso de shaders precompilados:
setprop debug.vulkan.precompiled_shaders true
# Ajustar el tamaño de los buffers de Vulkan:
setprop debug.vulkan.buffer_size 512MB
# Habilitar validación de capas para Vulkan:
setprop debug.vulkan.enable_validation_layers true
# Habilitar optimización de texturas grandes:
setprop debug.vulkan.large_texture_optimization true
# Forzar el almacenamiento en caché de objetos Vulkan:
setprop debug.vulkan.force_cache_objects true
# Habilitar extensiones para renderizado avanzado:
# VK_EXT_memory_priority:
setprop debug.vulkan.extension_vk_ext_memory_priority true
setprop debug.vulkan.extension_vk_ext_pipeline_cache_control true
setprop debug.vulkan.extension_vk_ext_descriptor_indexing true
# Aumentar la cantidad máxima de frames en la cola:
setprop debug.vulkan.max_frames_in_flight 3
# Habilitar frame pacing para Vulkan:
# Esto asegura que los frames se presenten a intervalos constantes, mejorando la estabilidad de los FPS.
setprop debug.vulkan.frame_pacing true
# Forzar el modo de pantalla de alta frecuencia de actualización:
setprop debug.vulkan.force_high_refresh_rate true
setprop debug.vulkan.remove_memory_limits true
setprop debug.vulkan.multi_threaded_rendering true
# Aumentar la cantidad máxima de threads de renderizado:
setprop debug.vulkan.render_threads 6
# Cargar pipelines previamente para evitar retrasos en ejecución:
setprop debug.vulkan.preload_pipelines true
# Aumentar el tamaño de la caché de pipelines (tuberías de renderizado):
setprop debug.vulkan.pipeline_cache_size 512MB
# Aumentar el número máximo de frames en la cola de procesamiento:
setprop debug.vulkan.max_frames_in_flight 5
# Habilitar presentación en un hilo dedicado (mejora fluidez):
setprop debug.vulkan.present_thread true
# VK_EXT_memory_budget: Gestiona mejor la memoria de GPU:
setprop debug.vulkan.extension_vk_ext_memory_budget true
# VK_KHR_shader_draw_parameters: Optimiza shaders en juegos complejos:
setprop debug.vulkan.extension_vk_khr_shader_draw_parameters true
# VK_EXT_vertex_attribute_divisor: Mejora el rendimiento de gráficos complejos:
setprop debug.vulkan.extension_vk_ext_vertex_attribute_divisor true
setprop debug.vulkan.render_priority high
# Optimizar la gestión de memoria dinámica:
setprop debug.vulkan.memory_optimization aggressive
# Habilitar reutilización agresiva de buffers:
setprop debug.vulkan.aggressive_buffer_reuse true
# Optimizar la compresión de texturas para GPUs modernas:
setprop debug.vulkan.texture_compression_mode fast
# Reducir el tiempo de carga de texturas dinámicas:
setprop debug.vulkan.texture_load_latency 0
# Acelerar la preparación de vistas
# Para mejorar la preparación y procesamiento de vistas (altos tiempos en "Prepare Process Execute"), puedes forzar el uso de cachés óptimos:
setprop debug.hwui.cache_flush true
setprop debug.hwui.text_cache_size 1024
# Forzar Compilación Anticipada de Shaders:
setprop debug.vulkan.precompile_shaders 1
setprop debug.vulkan.force_pipeline_cache 1
# Habilitar Multihilo Avanzado en Vulkan:
setprop debug.vulkan.threading_enable 1
setprop debug.vulkan.async_compute 1
# Reducir Latencia de Presentación:
setprop debug.vulkan.render_latency 1
setprop debug.vulkan.present_latency_reduction 1
# Forzar Uso de Extensiones Avanzadas:
setprop debug.vulkan.enable_advanced_extensions 1
setprop debug.vulkan.enable_raytracing 1
setprop debug.vulkan.use_vk12_extensions 1
# Habilitar Configuraciones Específicas de Hardware:
setprop debug.vulkan.adreno.performance_tuning 1
setprop debug.vulkan.mali.performance_tuning 1
# Overclocking de GPU (Si tu hardware lo permite):
setprop persist.sys.gpu_boost 1
setprop persist.sys.gpu.overclock 1
setprop debug.gpu.freq_boost 1
# Incrementar el Tamaño de Caché de GPU:
setprop debug.gpu.cache_boost 512
setprop debug.vulkan.cache_size 2048
# Habilitar Anticipación de Movimiento:
setprop debug.touch.motion_prediction 1
setprop debug.touch.latency_optimization 1
# Incrementar Tamaño de Búfer de Memoria Compartida:
setprop persist.sys.shared_memory_boost 1
setprop persist.sys.memory_cache_boost 2048
# Habilitar Administración Dinámica de Memoria para Vulkan:
setprop debug.vulkan.dynamic_memory 1
setprop debug.vulkan.memory_alloc_optimization 1


# últimos
# Priorizar el hilo de la UI
# El problema de latencia alta en el hilo principal ("High input latency") puede resolverse aumentando su prioridad:
setprop debug.hwui.render_thread_priority -10
# Limpiar cachés de GPU
# El uso actual de la GPU es 9.71 MB, de los cuales 7.66 MB son liberables. Limpia las cachés para optimizar el uso de memoria:
setprop debug.hwui.clear_cache 1
setprop debug.hwui.reset_gpu_context true
# Reducir carga de nodos de renderizado
# Si algunos nodos de renderizado son innecesarios, puedes reducir su capacidad:
setprop debug.hwui.render_nodes_capacity 100
# Incrementar los límites de memoria de GPU
# Algunos dispositivos establecen un límite bajo de memoria para la GPU. Puedes modificar este valor para permitir un mayor uso.
setprop debug.gpu.memory_limit 512
# Forzar la aceleración completa de Skia:
setprop debug.hwui.gpu_pixel_buffers true

# Obtener el FPS más bajo disponible
min_fps=$(dumpsys display | grep -o "refreshRate=[0-9.]*" | sed "s/refreshRate=//" | sort -n | head -n 1)
echo "FPS más bajo disponible: $min_fps"

# Obtener el FPS más alto disponible
highest_fps=$(dumpsys display | grep -o "refreshRate=[0-9.]*" | sed "s/refreshRate=//" | sort -nr | head -n 1)
echo "FPS más alto disponible: $highest_fps"

# JUEGOS (Funciona)
echo -e "\nConfiguración de FPS"
if [ "$(settings get global 0.0_fps_max)" != "$highest_fps" ]; then
    settings put global 0.0_fps_max $highest_fps
    echo "Set 0.0_fps_max to $highest_fps"
else
    echo "0.0_fps_max already set to $highest_fps"
fi

# 2. Propiedades persistentes relacionadas con NVidia
if [ "$(getprop persist.sys.NV_FPSLIMIT)" != "$highest_fps" ]; then
    setprop persist.sys.NV_FPSLIMIT $highest_fps
    echo "Set persist.sys.NV_FPSLIMIT to $highest_fps"
else
    echo "persist.sys.NV_FPSLIMIT already set to $highest_fps"
fi

if [ "$(getprop persist.sys.NV_POWERMODE)" != "1" ]; then
    setprop persist.sys.NV_POWERMODE 1
    echo "Set persist.sys.NV_POWERMODE to 1"
else
    echo "persist.sys.NV_POWERMODE already set to 1"
fi

if [ "$(getprop persist.sys.NV_PROFVER)" != "15" ]; then
    setprop persist.sys.NV_PROFVER 15
    echo "Set persist.sys.NV_PROFVER to 15"
else
    echo "persist.sys.NV_PROFVER already set to 15"
fi

if [ "$(getprop persist.sys.NV_STEREOCTRL)" != "0" ]; then
    setprop persist.sys.NV_STEREOCTRL 0
    echo "Set persist.sys.NV_STEREOCTRL to 0"
else
    echo "persist.sys.NV_STEREOCTRL already set to 0"
fi

if [ "$(getprop persist.sys.NV_STEREOSEPCHG)" != "0" ]; then
    setprop persist.sys.NV_STEREOSEPCHG 0
    echo "Set persist.sys.NV_STEREOSEP to 0"
else
    echo "persist.sys.NV_STEREOSEPCHG already set to 0"
fi

if [ "$(getprop persist.sys.NV_STEREOSEP)" != "20" ]; then
    setprop persist.sys.NV_STEREOSEP 20
    echo "Set persist.sys.NV_STEREOSEP to 20"
else
    echo "persist.sys.NV_STEREOSEP already set to 20"
fi

echo -e "\nHabilitar la Compilación JIT (Just-In-Time)"
# Esto puede mejorar el rendimiento en aplicaciones que requieren procesos dinámicos:
setprop dalvik.vm.usejit true

echo -e "\nActualizar el compilador JIT/AOT"
# Esto fuerza a Android a optimizar todas las apps instaladas, mejorando el rendimiento a costa de más tiempo.
cmd package bg-dexopt-job

# verificar si los fps se aplicaron
# dmesg | grep -i "fps"

# Hacer un reinicio suave para establecer vulkan
cmd sensorservice reset-uid-state system
# cmd sensorservice
