#!/bin/bash

# Ejecutar asi:
# su -c sh /sdcard/comandos_gpu_max

echo -e "\nForzar GPU para renderizado completo"
setprop debug.hwui.renderer skiavk

echo -e "Forzar el uso de Vulkan en lugar de OpenGL\n(si tu dispositivo lo soporta!!!):"
setprop debug.vulkan.enable 1
setprop debug.vulkan.sampler_optimize 1
setprop debug.vulkan.dyn_swapchain 1
setprop debug.vulkan.multiview 1
setprop debug.vulkan.dynamic_rendering 1
# En dispositivos de gama baja o en situaciones de alta carga gráfica (por ejemplo, juegos exigentes), esto podría generar latencia adicional o pérdida de rendimiento porque cada fotograma debe esperar a la sincronización (vsync).
# Sin embargo, en dispositivos potentes, esto puede ofrecer una experiencia visual más estable y agradable.
# Deshabilitar la sincronización vertical (si se busca un rendimiento más alto a costa de la suavidad visual):
setprop debug.sf.vsync_mode 0
# Mejora la suavidad en animaciones y movimientos al evitar el desgarro de pantalla (screen tearing).
setprop debug.sf.vsync 1
# **Activar GPU Rendering**: Esto puede ayudar con la velocidad de renderizado en ciertas aplicaciones:
setprop debug.hwui.use_gpu_for_composition true
# setprop enable_gpu_compositing 1
# Aumentar el límite de memoria de la GPU (si está permitido)
# setprop limit_gpu_memory 2048
# **Mejorar la eficiencia del uso de memoria de la GPU**:
setprop debug.vm.swaplog 1
setprop debug.hwui.target_gpu_time_percent 100
# Habilita el uso del motor de renderizado SKIA, que puede mejorar el rendimiento en algunas aplicaciones.
# setprop enable_skia_gpu_rendering 1
setprop debug.hwui.pipelinestats 1
setprop debug.sf.enabletraces false

echo -e "\nHabilitar Vulkan agresivo"
setprop debug.vulkan.swapchain 3
# Ajustes de renderizado para FPS estables
# Reducir la carga de trabajo del renderizado:
setprop debug.vulkan.gpu_profiling_enabled true
# Habilitar Shader Cache persistente
# Para Vulkan, el almacenamiento en caché de shaders reduce el tiempo de carga:
setprop debug.vulkan.persistent_cache true
# Ajustar el límite de cola de comandos de la GPU: usa 1 para mayor eficiencia, si tu gpu es potente usa 2, si notas que al escribir en el teclado hay una latencia (retraso), prueba a reducir el número. O no uses este comando.
setprop debug.vulkan.queue_limit 1
# Habilita la preempción del programador de GPU (GPU Scheduler Pre-emption). Esto permite a la GPU pausar y reanudar tareas menos prioritarias para dar prioridad a las más críticas, mejorando la respuesta en tiempo real.
# bajo prueba
setprop debug.gpu.scheduler_pre.emption 1
# Ajusta la prioridad de los procesos de la GPU a un nivel alto (7 es el valor máximo permitido).
# Esto fuerza al sistema a priorizar el trabajo de la GPU sobre otras tareas, como procesos de CPU o de I/O. Si hay demasiadas tareas compitiendo por recursos, podría causar problemas de estabilidad.
# setprop debug.gpuprio 7

# Comandos para maximizar la GPU
echo -e "\nHabilitar modo de alto rendimiento para gráficos"
setprop debug.performance.tuning 1
setprop debug.hwui.drop_shadow_cache_size 32
setprop debug.hwui.gradient_cache_size 4
setprop debug.hwui.layer_cache_size 512
setprop debug.hwui.r_buffer_cache_size 32
setprop debug.hwui.text_large_cache_height 2048
setprop debug.hwui.text_large_cache_width 2048
setprop debug.hwui.text_small_cache_height 2048
setprop debug.hwui.text_small_cache_width 2048

echo -e "\nOptimizar el consumo de memoria GPU"
setprop debug.hwui.memory_usage 768
setprop debug.hwui.layer_cache_size 128
setprop debug.hwui.texture_cache_size 512
setprop debug.sf.texture_cache_size 512
setprop debug.hwui.texture_filter_quality 4
setprop debug.hwui.fbo_cache_size 256

echo -e "\nReducir interrupciones de gráficos"
setprop debug.sf.triplebuffer 1
setprop debug.sf.trip_buffer 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.display_refresh_rate 1

# Comandos para una respuesta táctil extrema
echo -e "\nReducir latencia táctil"
setprop debug.touch.resampling 0
setprop debug.touch.prediction 1
setprop debug.touch.trace 1

echo -e "\nOptimizar el procesamiento táctil"
setprop debug.touch.average_filter 0
setprop debug.touch.fps_rate 240
setprop debug.touch.max_rate 1000

# Comandos para CPU y memoria (agresivo)
# echo -e "\nConfigurar CPU para alto rendimiento"

echo -e "\nComandos para juegos intensivos"
setprop debug.performance.mode 1
setprop debug.performance.game_mode 1
setprop debug.performance.gfx_quality 3
setprop debug.performance.render_distance 5

echo -e "\nAjustes gráficos dinámicos"
setprop debug.sf.dynamic_display_quality 1
setprop debug.hwui.texture_filter_anisotropic 16

# Optimizar el almacenamiento
# Optimizar el escalado de la CPU y GPU
# Activar el modo de alto rendimiento:
cmd power set-mode 2
pm trim-caches 1G
# Optimizar la memoria RAM: Reducir el número de procesos en caché
# Forzar que las aplicaciones en segundo plano se cierren más agresivamente:
settings put global activity_manager_constants max_cached_processes=8
# Optimizar el almacenamiento
# Priorizar procesos de GPU en el sistema
# Este comando prioriza los procesos relacionados con la GPU:
setprop debug.sf.limit_fps 0
setprop debug.vulkan.priority 1
# Activar angle (OpenGL sobre Vulkan)
# ANGLE (Almost Native Graphics Layer Engine) permite ejecutar OpenGL ES sobre Vulkan, lo que puede mejorar el rendimiento en dispositivos sin soporte directo de controladores de juegos:
settings put global angle_debug_package org.chromium.angle
setprop debug.angle.force_angle vulkan
setprop debug.angle.force_angle vulkan
setprop debug.angle.use_angle 1
# Activando angle driver
setprop debug.angle.enable true
setprop debug.angle.vulkan true

settings put global gfx_flush 1
setprop debug.sf.showfps 1

gpu_info=$(getprop ro.hardware.gpu)
gpu_vendor=$(getprop ro.hardware.egl)
if [ -n "$gpu_info" ]; then
    echo "[ GPU: \$(getprop ro.hardware.gpu) ]" >/dev/null
else
    gpu_info=$(dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}' | grep -owi mali)
    echo "[ GPU: $gpu_info ]" >/dev/null
fi

if [[ "$gpu_vendor" == *"adreno"* || "$gpu_info" == *"adreno"* || "$gpu_vendor" == *"Adreno"* || "$gpu_info" == *"Adreno"* ]]; then
    echo -e "\nConfiguraciones Específicas para Vulkan con GPU Adreno"
    # Si tu dispositivo tiene una GPU Adreno (Snapdragon), estas configuraciones son muy útiles:
    # 1. Habilitar optimizaciones específicas
    setprop debug.vulkan.adreno.dynamic.gfxboost 1
    setprop debug.vulkan.adreno.lowlatency 1
    # 2. Reducir el tiempo de compilación de shaders
    # Esto puede mejorar los tiempos de carga en juegos pesados:
    setprop debug.vulkan.adreno.shader_compilation 1
    # 3. Forzar GPU Boost para Vulkan
    # Maximiza el rendimiento de la GPU mientras usa Vulkan:
    setprop debug.vulkan.adreno.gpufreq_boost 1
    # Habilitar Configuraciones Específicas de Hardware:
    setprop debug.vulkan.adreno.performance_tuning 1
    # Habilitar optimizaciones avanzadas de Vulkan
    # Permite optimizaciones específicas del driver gráfico para Vulkan:
    setprop debug.vulkan.adreno.dynamic.gfxboost 1
    setprop debug.vulkan.adreno.lowlatency 1
elif [[ "$gpu_vendor" == *"mali"* || "$gpu_info" == *"mali"* || "$gpu_vendor" == *"Mali"* || "$gpu_info" == *"Mali"* ]]; then
    echo -e "\nConfiguraciones Específicas para GPU Mali"
    # Si usas una GPU Mali (Exynos, Kirin), estos ajustes son ideales:
    # 1. Optimizar consumo de energía
    setprop debug.vulkan.mali.performance_tuning 1
    setprop debug.vulkan.mali.power_optimize 1
    # 2. Ajustar el tamaño de cuadros de renderizado
    setprop debug.vulkan.mali.render_frame_size 128
    setprop debug.vulkan.mali.swap_interval 1
    setprop debug.vulkan.mali.dynamic_rendering 1
    setprop debug.vulkan.mali.shader_compilation 1
    # **Habilitar optimizaciones de GPU en aplicaciones**:
    setprop debug.egl.mali.allow_asynchronous 1
else
    echo -e "\nTipo de GPU no reconocido: $gpu_vendor"
fi


#----
# Ajustar el Pipeline de gráficos (Triple Buffering):
# Activa el Triple Buffering para reducir el "tearing" en gráficos. En dispositivos compatibles:
setprop debug.hwui.render_buffer 3   
setprop debug.hwui.vulkan true
setprop debug.vulkan.enable_low_latency true
# Aumentar el tamaño del búfer de la GPU
# Este ajuste permite manejar más cuadros simultáneamente para evitar cuellos de botella:
setprop debug.hwui.render_buffer_size 128
# Ajustar el tiempo de espera del renderizado
# Reduce el tiempo que la GPU espera antes de descartar un cuadro:
setprop debug.vulkan.timeout 150
# Optimizar el preprocesamiento de Vulkan
# Forzar a Vulkan a precompilar shaders, mejorando el rendimiento en la ejecución:
setprop debug.vulkan.shadercache.enable true
# Configurar la prioridad de los shaders
# Ajusta la prioridad para optimizar la carga de shaders en dispositivos con GPUs Adreno:
setprop debug.vulkan.adreno.shaders_priority 1
 # Activar Tiling en Vulkan
# Mejora el rendimiento en dispositivos que soporten GPU Tiling (especialmente Mali o Adreno):
setprop debug.vulkan.enable_tiling 1
# Reducir latencia de la GPU
# Minimiza el tiempo de espera de la GPU para renderizar cuadros:
setprop debug.gpu.reduce_latency 1
# Aumentar tamaño de buffer de gráficos
# Esto ayuda en juegos con texturas o gráficos intensivos:
setprop debug.gpu.graphics_buffer_size 256
# Habilitar optimización para juegos 3D
# Activa un modo especial para priorizar gráficos 3D:
setprop debug.gpu.game_3d_optimizations 1
# Habilitar Renderizado Multihilo
# Asegura que el renderizado de Vulkan aproveche múltiples hilos de la CPU:
setprop debug.vulkan.multithread_rendering 1
# Reducir la Latencia de la GPU
# Optimiza el tiempo entre el procesamiento del cuadro y su presentación:
setprop debug.vulkan.low_latency_mode 1
# Forzar la Prioridad Alta del Hilo de Renderizado
# Aumenta la prioridad del hilo principal de renderizado Vulkan:
setprop debug.hwui.render_thread_priority 1
# Activar Triple Buffering (Buffer Triple)
# Incrementa la fluidez al permitir que Vulkan maneje tres cuadros en paralelo:
# Habilitar buffer triple
# Incrementa la fluidez del renderizado en juegos y aplicaciones gráficamente intensivas:
setprop debug.hwui.triple_buffering 1
# Configurar Sincronización de Presentación
# Reduce la latencia al optimizar el manejo del V-Sync en Vulkan:
setprop debug.vulkan.presentation_mode fifo_relaxed
# Activar Soporte Extendido de Extensiones Vulkan
# Permite que Vulkan utilice extensiones avanzadas si el hardware las soporta:
setprop debug.vulkan.enable_extensions 1
# Configurar el Modo de Presentación
# Controla cómo se presentan los fotogramas al display para reducir latencia:
setprop debug.vulkan.present_mode mailbox
setprop debug.vulkan.present_mode immediate
# Habilitar optimizaciones de rendimiento en Vulkan:
# Activar la reducción de latencia en Vulkan:
setprop debug.vulkan.enable_latency_reduction true
# Ajuste del uso de CPU y GPU:
# Ajustar la prioridad de los hilos de Vulkan:
setprop debug.vulkan.thread_priority 2
# Optimizar el uso de la memoria de Vulkan:
# Ajustar la memoria de caché de Vulkan:
setprop debug.vulkan.memory_cache_size 2048
# Habilitar la extensión de Vulkan de uso avanzado:
# Habilitar la extensión VK_KHR_display:
setprop debug.vulkan.extension_vk_khr_display true
# Habilitar la extensión VK_KHR_swapchain:
setprop debug.vulkan.extension_vk_khr_swapchain true
# Ajustar la compilación de shaders de Vulkan:
setprop debug.vulkan.shader_optimizer true
# Ajustar el uso de shaders precompilados:
setprop debug.vulkan.precompiled_shaders true
# Ajustar el tamaño de los buffers de Vulkan:
setprop debug.vulkan.buffer_size 2048MB
# Habilitar validación de capas para Vulkan:
setprop debug.vulkan.enable_validation_layers true
# Habilitar optimización de texturas grandes:
setprop debug.vulkan.large_texture_optimization true
# Forzar el almacenamiento en caché de objetos Vulkan:
setprop debug.vulkan.force_cache_objects true
# Habilitar extensiones para renderizado avanzado:
# VK_EXT_memory_priority:
setprop debug.vulkan.extension_vk_ext_memory_priority true
setprop debug.vulkan.extension_vk_ext_pipeline_cache_control true
setprop debug.vulkan.extension_vk_ext_descriptor_indexing true
# Aumentar la cantidad máxima de frames en la cola:
setprop debug.vulkan.max_frames_in_flight 3
# Habilitar frame pacing para Vulkan:
# Esto asegura que los frames se presenten a intervalos constantes, mejorando la estabilidad de los FPS.
setprop debug.vulkan.frame_pacing true
# Forzar el modo de pantalla de alta frecuencia de actualización:
setprop debug.vulkan.force_high_refresh_rate true
setprop debug.vulkan.remove_memory_limits true
setprop debug.vulkan.multi_threaded_rendering true
# Aumentar la cantidad máxima de threads de renderizado:
setprop debug.vulkan.render_threads 6
# Cargar pipelines previamente para evitar retrasos en ejecución:
setprop debug.vulkan.preload_pipelines true
# Aumentar el tamaño de la caché de pipelines (tuberías de renderizado):
# Aumentar el número máximo de frames en la cola de procesamiento:
setprop debug.vulkan.max_frames_in_flight 5
# Habilitar presentación en un hilo dedicado (mejora fluidez):
setprop debug.vulkan.present_thread true
# VK_EXT_memory_budget: Gestiona mejor la memoria de GPU:
setprop debug.vulkan.extension_vk_ext_memory_budget true
# VK_KHR_shader_draw_parameters: Optimiza shaders en juegos complejos:
setprop debug.vulkan.extension_vk_khr_shader_draw_parameters true
# VK_EXT_vertex_attribute_divisor: Mejora el rendimiento de gráficos complejos:
setprop debug.vulkan.extension_vk_ext_vertex_attribute_divisor true
setprop debug.vulkan.render_priority high
# Optimizar la gestión de memoria dinámica:
setprop debug.vulkan.memory_optimization aggressive
# Habilitar reutilización agresiva de buffers:
setprop debug.vulkan.aggressive_buffer_reuse true
# Optimizar la compresión de texturas para GPUs modernas:
setprop debug.vulkan.texture_compression_mode fast
# Reducir el tiempo de carga de texturas dinámicas:
setprop debug.vulkan.texture_load_latency 0
# Acelerar la preparación de vistas
# Para mejorar la preparación y procesamiento de vistas (altos tiempos en "Prepare Process Execute"), puedes forzar el uso de cachés óptimos:
setprop debug.hwui.cache_flush true
setprop debug.hwui.text_cache_size 2048
# Forzar Compilación Anticipada de Shaders:
setprop debug.vulkan.precompile_shaders 1
setprop debug.vulkan.force_pipeline_cache 1
# Habilitar Multihilo Avanzado en Vulkan:
setprop debug.vulkan.threading_enable 1
setprop debug.vulkan.async_compute 1
# Reducir Latencia de Presentación:
setprop debug.vulkan.render_latency 1
setprop debug.vulkan.present_latency_reduction 1
# Forzar Uso de Extensiones Avanzadas:
setprop debug.vulkan.enable_advanced_extensions 1
setprop debug.vulkan.enable_raytracing 1
setprop debug.vulkan.use_vk12_extensions 1
setprop debug.gpu.freq_boost 1
# Incrementar el Tamaño de Caché de GPU:
setprop debug.gpu.cache_boost 1025
setprop debug.vulkan.cache_size 2048
# Habilitar Anticipación de Movimiento:
setprop debug.touch.motion_prediction 1
setprop debug.touch.latency_optimization 1
# Habilitar Administración Dinámica de Memoria para Vulkan:
setprop debug.vulkan.dynamic_memory 1
setprop debug.vulkan.memory_alloc_optimization 1

#---------------------------------------------------------------------------#
# últimos
# Priorizar el hilo de la UI
# El problema de latencia alta en el hilo principal ("High input latency") puede resolverse aumentando su prioridad:
setprop debug.hwui.render_thread_priority -10
# Limpiar cachés de GPU
# El uso actual de la GPU es 9.71 MB, de los cuales 7.66 MB son liberables. Limpia las cachés para optimizar el uso de memoria:
setprop debug.hwui.clear_cache 1
setprop debug.hwui.reset_gpu_context true
# Reducir carga de nodos de renderizado
# Si algunos nodos de renderizado son innecesarios, puedes reducir su capacidad:
setprop debug.hwui.render_nodes_capacity 100
# Incrementar los límites de memoria de GPU
# Algunos dispositivos establecen un límite bajo de memoria para la GPU. Puedes modificar este valor para permitir un mayor uso.
setprop debug.gpu.memory_limit 2048
# Forzar la aceleración completa de Skia:
setprop debug.hwui.gpu_pixel_buffers true
setprop debug.vulkan.jank_optimization 1
setprop debug.hwui.gpu_thread_priority 1
# Activar las optimizaciones asincrónicas de Vulkan
# Permite que Vulkan procese las tareas gráficas de forma más eficiente:
setprop debug.vulkan.asynchronous true
# Ajustar la prioridad del sistema para aplicaciones en primer plano:
setprop debug.performance.foreground_boost 1
# Optimización para Vulkan (adicional):
setprop debug.vulkan.async_compute true
setprop debug.vulkan.pipeline_cache_size 2048

: '
# últimos 2
setprop debug.composition.type gpu
# setprop debug_hw_overdraw 0
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late.sf.duration 27600000
setprop debug.sf.late.app.duration 20000000
setprop debug.sf.early.sf.duration 27600000
setprop debug.sf.early.app.duration 20000000
setprop debug.sf.earlyGl.sf.duration 27600000
setprop debug.sf.earlyGl.app.duration 20000000
setprop debug.composition.type gpu
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late.sf.duration 27600000
setprop debug.sf.late.app.duration 20000000
setprop debug.sf.early.sf.duration 27600000
setprop debug.sf.early.app.duration 20000000
setprop debug.sf.earlyGl.sf.duration 27600000
setprop debug.sf.earlyGl.app.duration 20000000
: '

: '
# Habilitar la asistencia de la CPU en ciertas tareas:
# Permite que la CPU complemente el trabajo gráfico de la GPU, como en cálculos adicionales o en tareas de baja latencia.
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.precision rs_fp_full
# Establece mayores prioridades para la CPU en ciertas operaciones.
setprop debug.cpuprio 7
setprop debug.gpuprio 5
setprop debug.ioprio 6
# Optimizar el manejo de texturas y gráficos:
# Asegúrate de que las texturas o gráficos complejos se manejen de manera eficiente entre CPU y GPU.
setprop debug.hwui.enable_partial_updates true
setprop debug.hwui.target_cpu_time_percent 20
setprop debug.hwui.target_gpu_time_percent 80
# CPU activa para cálculos adicionales (ideal para multitarea):
setprop debug.rs.default-CPU-driver 1
setprop debug.hwui.disable_vsync true
setprop debug.hwui.enable_partial_updates true
setprop debug.cpuprio 7
: '
# Mayor carga en GPU, asistencia mínima de CPU (recomendado para juegos):
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.disable_draw_defer false

: '
# optimizar los pipeline de vulkan 
setprop debug.vulkan.enable_pipeline_cache 1
setprop debug.vulkan.pipeline_cache_enable_all 1
setprop debug.vulkan.preload_shaders true
setprop debug.vulkan.vsync false
setprop debug.mali.multithreading true
setprop debug.vulkan.max_frame_latency 2
# Reducir la latencia de cuadros
# Esto configura Vulkan para que procese los cuadros con la menor latencia posible, crucial para juegos que necesitan respuestas rápidas:
setprop debug.vulkan.max_frame_latency 1
setprop debug.vulkan.swapchain_pre_rotate 1
setprop debug.vulkan.frame_present_mode immediate
# Esto incrementa la memoria asignada a Vulkan, mejorando el manejo de gráficos más complejos:
setprop debug.sys.vulkan.buffer_memory_multiplier 2
setprop debug.vulkan.large_heap_allocation 1
# Desactiva sincronizaciones que no sean críticas para mejorar la fluidez:
setprop debug.vulkan.sync_mode 0  # 0: Ninguna sincronización
setprop debug.vulkan.vsync false  # Deshabilitar VSync
setprop debug.vulkan.fast_present 1
# Para GPUs Mali (ARM)
# Configura características específicas para GPUs Mali:
setprop debug.mali.multithreading true
setprop debug.mali.turbo_mode 1
setprop debug.mali.vulkan.force_depth_clamp 1
setprop debug.mali.vulkan.optimize_descriptor_set 1
setprop debug.mali.disable_16bit_framebuffer 0
# Activa este modo para reducir el stuttering (tirones) en los juegos:
setprop debug.vulkan.async_shader_compilation 1
setprop debug.vulkan.async_pipeline_creation 1
# Reduce la carga gráfica para texturas grandes:
setprop debug.vulkan.texture_limit 8192  # En píxeles (8192x8192)
setprop debug.vulkan.mipmap_bias -2  # Usa mipmaps más pequeños
: '
#---------------------------------------------------------------------------#

# últimos 3
: '
setprop debug.renderengine.backend skiavk
setprop debug.hwui.renderer skiavk
setprop debug.sf.enable_hgl 1

setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 512
setprop debug.gpu.scheduler_pre.emption 1
setprop debug.hwui.target_gpu_time_percent 100

setprop debug.gpu.power_management_mode pref_max
setprop debug.gpurend.vsync true
setprop debug.hwui.disable_draw_defer false

setprop debug.sf.vsync_mode 0
setprop debug.sf.latch_unsignaled 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.early_phase_offset_ns 500000

setprop debug.gpuprio 7
setprop debug.cpuprio 6
: '

# Obtener el FPS más bajo disponible
min_fps=$(dumpsys display | grep -o "refreshRate=[0-9.]*" | sed "s/refreshRate=//" | sort -n | head -n 1)
echo -e "\nFPS más bajo disponible: $min_fps"

# Obtener el FPS más alto disponible
highest_fps=$(dumpsys display | grep -o "refreshRate=[0-9.]*" | sed "s/refreshRate=//" | sort -nr | head -n 1)
echo "FPS más alto disponible: $highest_fps"

# JUEGOS (Funciona)
echo -e "\nConfiguración de FPS"
if [ "$(settings get global 0.0_fps_max)" != "$highest_fps" ]; then
    settings put global 0.0_fps_max $highest_fps
    echo "Set 0.0_fps_max to $highest_fps"
else
    echo "0.0_fps_max already set to $highest_fps"
fi

settings put global enable_gpu_debug_layers 1
settings put global gpu_debug_app org.dolphinemu.mmjr3
settings put global gpu_debug_app org.ppsspp.ppssppgold
settings delete global gpu_debug_app >/dev/null 2>&1
settings put global gpu_debug_app org.citra.emu
settings put global gpu_debug_app xyz.aethersx2.android
settings put global gpu_debug_layers gfx:input:hwui
# Habilitar el modo de rendimiento para la GPU:
setprop debug.egl.hw 1
setprop debug.egl.driver 1
# adb shell setprop persist.sys.ui.hw 1


echo -e "\nActualizar el compilador JIT/AOT\nPor favor, no apague la pantalla del dispositivo. Espere..."
# Esto fuerza a Android a optimizar todas las apps instaladas, mejorando el rendimiento a costa de más tiempo.
cmd package bg-dexopt-job
echo -e "Completado!!!"

# verificar si los fps se aplicaron
# dmesg | grep -i "fps"

# Hacer un reinicio suave para establecer vulkan
cmd sensorservice reset-uid-state system
# cmd sensorservice

# Ajustes adicionales para prueba
: '
# Optimizar Vulkan y GPU
 # 1. Forzar Vulkan y Habilitar Pipeline de Alta Eficiencia:
setprop debug.hwui.renderer skiavk
setprop debug.hwui.use_vulkan true
setprop debug.vulkan.force_cpu_vsync 0
setprop debug.vulkan.force_pipeline_cache 1
setprop debug.vulkan.pipeline_cache_size 512
setprop debug.vulkan.async_compute 1

# Reducir Latencia en Renderización:
setprop debug.hwui.render_latency 1
setprop debug.hwui.overdraw false
setprop debug.vulkan.low_latency_mode true

# Ajustar el Tamaño de la Caché de GPU y Framebuffer:
setprop persist.sys.gpu_cache_size 2048
setprop persist.sys.framebuffer_boost 1
setprop debug.gpu.cache_boost 512

# Configurar la Sincronización Vertical y Limitar Janky Frames:
setprop debug.hwui.vsync_always true
setprop debug.hwui.skip_frames false
setprop debug.vulkan.jank_optimization 1

# Optimizar el Consumo de Memoria:
setprop debug.gpu.memory_optimization 1
setprop debug.hwui.texture_memory_threshold 512

# Optimizar el Consumo de Memoria:
setprop debug.gpu.memory_optimization 1
setprop debug.hwui.texture_memory_threshold 512

# Configurar Multihilo y Renderización Asíncrona:
# setprop debug.hwui.async_render 1
setprop debug.hwui.task_limit 4

# Optimización de Renderizado UI
# Priorizar los Hilos de Renderización:
setprop debug.hwui.render_thread_priority 1
setprop debug.hwui.gpu_thread_priority 1

# Reducir Carga en Dibujado de Vistas:
setprop debug.hwui.minimal_drawing 1 
setprop debug.hwui.texture_filtering 0
: '