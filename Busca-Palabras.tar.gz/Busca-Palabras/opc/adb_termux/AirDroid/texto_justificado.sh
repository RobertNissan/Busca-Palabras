# Definir códigos de color
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante
COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Función para manejar la señal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    exit 0
}
# Función para manejar la señal SIGINT (Ctrl+C)
handler_SIGINT() {
    exit 0
}
# Asignar las funciones del controlador a las señales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

# Obtener la ip wlan0 si está disponible...
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

#######FUNCIONES_DE_JUSTICACION_TEXTO#######
# Función para justificar texto
justify_text_space() {
    local width=$(tput cols) # Obtén el ancho de la terminal
    local text="$1"
    local justified=""
    # Divide el texto en palabras
    IFS=' ' read -ra words <<< "$text"
    local line=""
    for word in "${words[@]}"; do
        # Si la longitud de la línea actual más la palabra supera el ancho, justifícala
        if (( ${#line} + ${#word} + 1 > width )); then
            # Justifica la línea
            justified_line=$(justify_line "$line" "$width")
            justified+="$justified_line\n"
            line="$word"
        else
            # Agrega la palabra a la línea actual
            line="$line $word"
        fi
    done
    # Agrega la última línea
    justified+="$line"
    echo -e "$justified"
}
justify_text() {
    local width=$(tput cols) # Obtén el ancho de la terminal
    local text="$1"
    local justified=""
    IFS=' ' read -ra words <<< "$text"
    local line=""
    for word in "${words[@]}"; do
        if (( ${#line} + ${#word} + 1 > width )); then
            justified_line=$(justify_line "$line" "$width")
            justified+="${justified_line#"${justified_line%%[![:space:]]*}"}\n"
            line="$word"
        else
            line="$line $word"
        fi
    done
    justified+="${line#"${line%%[![:space:]]*}"}"
    printf "%s\n" "$justified"
}
# Función para justificar una línea
justify_line() {
    local line="$1"
    local width="$2"
    local spaces_needed=$((width - ${#line}))
    local words=($line)
    local space_count=$(( ${#words[@]} - 1 ))
    # Si solo hay una palabra, no se justifica
    if (( space_count == 0 )); then
        echo "$line"
        return
    fi
    # Distribuir espacios
    local extra_spaces=$(( spaces_needed / space_count ))
    local remainder_spaces=$(( spaces_needed % space_count ))
    local justified_line=""
    for i in "${!words[@]}"; do
        justified_line+="${words[i]}"
        if (( i < space_count )); then
            justified_line+="$(printf ' %.0s' $(seq 1 $((extra_spaces + (i < remainder_spaces ? 1 : 0)))))"
        fi
    done
    echo "$justified_line"
}
# Función para mostrar texto con colores
function print_color() {
    case $1 in
        red) echo -e "${RED}$2${NC}" ;;       # Rojo brillante
        green) echo -e "${GREEN}$2${NC}" ;;   # Verde brillante
        yellow) echo -e "${YELLOW}$2${NC}" ;; # Amarillo brillante
        blue) echo -e "${BLUE}$2${NC}" ;;     # Azul brillante
        cyan) echo -e "${CYAN}$2${NC}" ;;     # Cian brillante
        magenta) echo -e "${MAGENTA}$2${NC}" ;; # Magenta brillante
        white) echo -e "${WHITE}$2${NC}" ;;   # Blanco brillante
        *) echo "$2" ;;                       # Sin color
    esac
}
# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}
#######FIN_FUNCIONES_DE_JUSTICACION_TEXTO#######

print_text_complet() {
    # Título e instrucciones justificados
    print_color red "$(justify_text 'Servidor adb, no encendido!!!')"
    print_color green "$(justify_text 'Siga las instrucciones:')"
    # Instrucciones para habilitar depuración USB
    print_color cyan "$(justify_text 'Habilitar la depuración USB en Android, para hacer conexión adb:')"
    print_color yellow "$(justify_text '1. Abre la aplicación Configuración en tu dispositivo Android.')"
    print_color yellow "$(justify_text '2. Ve a Acerca del teléfono o Acerca de la tablet.')"
    print_color yellow "$(justify_text '3. Toca repetidamente Número de compilación hasta que se active el modo de desarrollador.')"
    print_color yellow "$(justify_text '4. Regresa al menú principal de Configuración y busca Opciones de desarrollador o Opciones del sistema.')"
    print_color yellow "$(justify_text '5. Habilita Depuración USB.')"
    # Instrucciones para depuración inalámbrica
    print_color cyan "$(justify_text 'Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra.')"
    print_color yellow "$(justify_text '6. Selecciona donde dice:')"
    echo -e " ${GREEN}Vincular dispositivo con código de sincronización${NC}"
    echo -e "  ${YELLOW}Selecciona ahora en:${NC}"
    echo -e "   ${GREEN}Vincular con dispositivo${NC}"
    echo -e "    ${BLUE}Código de vinculación de WI-FI${NC}: ${RED}123456${NC}"
    printf "    ${BLUE}Dirección IP y PUERTO${NC}: "
    printf "${GREEN}${ip}${NC}:${MAGENTA}12345${NC}\n"
    # Nota adicional
    print_color cyan "$(justify_text 'Para hacer la conexión correctamente:')"
    echo -e "${YELLOW}7${NC}. ${YELLOW}Habilita la pantalla dividida entre la ventana:\n${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC})."
    # Final
    print_color green "$(justify_text '¡Sigue estos pasos para activar el servidor adb correctamente!')"

    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    echo -en "\n${YELLOW}Ingrese el código de vinculación WI-FI${NC}: ${RED}"
    read code
}
print_text_complet #;exit


echo ""
simular_escritura() {
    # Función para simular el efecto de escritura (con delay muy bajo)
    type_text() {
        local text="$1"
        local delay="${2:-0.000001}" # Ajusta a un valor muy bajo
        for ((i = 0; i < ${#text}; i++)); do
            printf "%s" "${text:i:1}"
            # Puedes reducir el delay aún más o quitarlo
            sleep "$delay"
        done
        printf "\n" # Para finalizar la línea
    }
    
    # Título e instrucciones justificados
    type_text "$(print_color red "$(justify_text 'Servidor adb, no encendido!!!')")"
    type_text "$(print_color green "$(justify_text 'Siga las instrucciones:')")"
    # Instrucciones para habilitar depuración USB
    type_text "$(print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb:")")"
    type_text "$(print_color yellow "$(justify_text "1.$(generate_spaces 1)Abre la aplicación [Configuración] en tu dispositivo Android.")")"
    type_text "$(print_color yellow "$(justify_text "2. Ve a [Acerca del teléfono o de la tablet].")")"
    type_text "$(print_color yellow "$(justify_text "3. Toca repetidamente [Número de compilación] hasta que se active el modo de desarrollador.")")"
    type_text "$(print_color yellow "$(justify_text "4. Regresa al menú principal de [Configuración], busca y entra en: [Sistema].")")"
    type_text "$(print_color yellow "$(justify_text "5. Ahora da click en: [Opciones avanzadas] y entra en [Opciones para desarrolladores].")")"
    type_text "$(print_color yellow "$(justify_text "6. Habilita [Depuración por USB].")")"
    # Instrucciones para depuración inalámbrica
    type_text "$(print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra.")")"
    type_text "$(print_color yellow "$(justify_text "7. Selecciona donde dice:")")"
    type_text "$(print_color green "$(justify_text "$(generate_spaces 1)Vincular dispositivo con código de sincronización")")"
    type_text "$(print_color yellow "$(justify_text "$(generate_spaces 1)Selecciona ahora en:")")"
    type_text "$(echo -e "$(generate_spaces 2)${GREEN}Vincular con dispositivo${NC}")"
    type_text "$(echo -e "    ${BLUE}Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")"
    type_text "$(printf "    ${BLUE}Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345${NC}\n")"
    # Nota adicional
    type_text "$(print_color cyan "$(justify_text 'Para hacer la conexión correctamente:')")"
    type_text "$(print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: (Depuración inalámbrica) y la ventana de (Termux).")")"
    # Final
    type_text "$(print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")")"
        
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
        
    # Imprimir el mensaje justificado sin salto de línea al final
    printf "$(print_color yellow "$(justify_text "\nIngrese el código de vinculación de WI-FI${NC}: ")")"
    # Leer la entrada del usuario en la misma línea
    read seleccion
}
simular_escritura