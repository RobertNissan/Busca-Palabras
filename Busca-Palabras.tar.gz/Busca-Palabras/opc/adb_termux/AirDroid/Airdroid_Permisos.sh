# ver los permisos de ejecución de airdroid
u0_a255@localhost ~> adb shell appops get com.sand.airdroid
Uid mode: COARSE_LOCATION: ignore                          READ_CONTACTS: ignore
WRITE_CONTACTS: ignore                                     READ_CALL_LOG: ignore
CALL_PHONE: ignore                                         READ_SMS: ignore
RECEIVE_SMS: ignore                                        RECEIVE_MMS: ignore
RECEIVE_WAP_PUSH: ignore                                   SEND_SMS: ignore
CAMERA: ignore                                             RECORD_AUDIO: ignore
READ_PHONE_STATE: ignore                                   READ_EXTERNAL_STORAGE: ignore
WRITE_EXTERNAL_STORAGE: ignore                             GET_ACCOUNTS: ignore
ANSWER_PHONE_CALLS: ignore
LEGACY_STORAGE: ignore
MANAGE_EXTERNAL_STORAGE: allow
COARSE_LOCATION: allow; time=+2d15h55m8s944ms ago
FINE_LOCATION: allow; time=+5m37s135ms ago; rejectTime=+21d13h19m47s566ms ago
GPS: allow; time=+2d15h55m13s64ms ago; duration=+32s926ms
VIBRATE: allow; time=+25m11s936ms ago; duration=+88ms
WIFI_SCAN: allow; time=+5m37s134ms ago
SYSTEM_ALERT_WINDOW: allow; time=+10d14h27m33s590ms ago
CAMERA: allow; time=+2d15h55m32s405ms ago; duration=+8s916ms
READ_CLIPBOARD: allow; time=+25m10s972ms ago
WRITE_CLIPBOARD: allow; time=+25m10s973ms ago
TAKE_AUDIO_FOCUS: allow; time=+10d14h27m33s340ms ago
AUDIO_ALARM_VOLUME: allow; time=+12d15h25m30s259ms ago
WAKE_LOCK: allow; time=+3m47s324ms ago; duration=+8ms
MONITOR_LOCATION: allow; time=+2d15h55m13s84ms ago; duration=+32s908ms
MONITOR_HIGH_POWER_LOCATION: allow; time=+2d15h55m13s84ms ago; duration=+32s906ms
GET_USAGE_STATS: default; rejectTime=+2d18h31m33s988ms ago
TURN_ON_SCREEN: allow; time=+12d15h26m8s98ms ago
START_FOREGROUND: allow; time=+35s592ms ago (running)
WRITE_MEDIA_VIDEO: deny; rejectTime=+21d13h31m8s573ms ago
WRITE_MEDIA_IMAGES: deny; rejectTime=+21d13h31m8s575ms ago
MANAGE_EXTERNAL_STORAGE: default; time=+7m29s102ms ago; rejectTime=+21d13h31m9s193ms ago
NO_ISOLATED_STORAGE: deny; rejectTime=+27m42s426ms ago

# modificar 
# adb shell appops set com.sand.airdroid PERMISSION_NAME allow

#ejemplos claros
adb shell appops set com.sand.airdroid WRITE_MEDIA_VIDEO allow
adb shell appops set com.sand.airdroid WRITE_MEDIA_IMAGES allow
adb shell pm grant com.sand.airdroid android.permission.ACCESS_COARSE_LOCATION
adb shell pm grant com.sand.airdroid android.permission.ACCESS_FINE_LOCATION
adb shell pm grant com.sand.airdroid android.permission.CAMERA
adb shell pm grant com.sand.airdroid android.permission.RECORD_AUDIO
adb shell pm grant com.sand.airdroid android.permission.READ_EXTERNAL_STORAGE
adb shell pm grant com.sand.airdroid android.permission.WRITE_EXTERNAL_STORAGE
adb shell appops set com.sand.airdroid NO_ISOLATED_STORAGE allow
adb shell appops set com.sand.airdroid MANAGE_EXTERNAL_STORAGE allow

# Definir códigos de color ANSI
COLOR_NEGRO='\033[30m';COLOR_ROJO='\033[31m';COLOR_VERDE='\033[32m';COLOR_AMARILLO='\033[33m';COLOR_AZUL='\033[34m';COLOR_MAGENTA='\033[35m';COLOR_CIAN='\033[36m';COLOR_BLANCO='\033[37m';COLOR_RESET='\033[0m'
echo -e "\n${COLOR_AMARILLO}Cuando presiones en empezar, debés abrir la app que\nquieres saber su nombre antes de 5 segundos,\npuedes modificar el tiempo${COLOR_RESET}."
read -n 1 -p  "Presione cualquier tecla para empezar!!!..."
sleep 5;nombre_paquete=$(adb -s emulator-5554 shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}');echo -e "\n${COLOR_VERDE}El nombre de paquete de la app que abriste és${COLOR_RESET}:\n$nombre_paquete\n"
adb shell am force-stop "$nombre_paquete"
# abrir la aplicación de termux
adb -s emulator-5554 shell am start -n com.termux/.HomeActivity >/dev/null 2&>1

# Forzar cierre de la app AirDroid
adb shell am force-stop com.sand.airdroid
# Abrir la app de AirDroid
adb shell am start -n com.sand.airdroid/com.sand.airdroid.ui.main.Main2Activity_


# Ver las coordenadas de un click 
read -n 1 -p "Cuando abra la app espere 7 segundos y de click donde desees obtener las coordenadas!!!";sleep 5;adb shell am start -n com.sand.airdroid/com.sand.airdroid.ui.main.Main2Activity_;sleep 3;adb shell getevent -l

# Coordenadas de el boton Yo de Airdroid 
ABS_MT_POSITION_X    00000286
ABS_MT_POSITION_Y    0000059c

# Dar click en las coordenadas tomadas para dirigir sl correo.
adb shell am start -n com.sand.airdroid/com.sand.airdroid.ui.main.Main2Activity_;sleep 3;adb shell input tap 646 1436

# Coordenadas del ingreso al correo. usa el script para transf_coordenadas_click.py
# El script simplemente toma cada valor hexadecimal (00000216 y 000002eb), lo convierte a decimal usando la función int() con base 16 (int(hex_value, 16)) y luego imprime el resultado.
/dev/input/event6: EV_ABS       ABS_MT_POSITION_X    00000163
/dev/input/event6: EV_ABS       ABS_MT_POSITION_Y    000000a4