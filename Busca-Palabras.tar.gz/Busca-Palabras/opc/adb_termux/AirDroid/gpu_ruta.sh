# Detectar ruta de GPU
gpu_path=$(adb shell su -c "find /sys/class/devfreq -name '*gpu*'" | head -n 1)

if [ -z "$gpu_path" ]; then
    echo "No se encontró un archivo de configuración para la GPU."
    exit 1
fi
# echo $gpu_path

# Ver la frecuencia mínima y maxima que estan actualmente establecidas en mi CPU
gpu_min=$(adb shell "su -c cat $gpu_path/min_freq")
gpu_max=$(adb shell "su -c cat $gpu_path/max_freq")

# Aplicar configuraciones
adb shell "echo ${gpu_min} | su -c tee ${gpu_path}/min_freq" > /dev/null
adb shell "echo ${gpu_max} | su -c tee ${gpu_path}/max_freq" > /dev/null

echo "Frecuencia mínima de la gpu configurada en $gpu_min"
echo "Frecuencia máxima de la gpu configurada en $gpu_max"
    
