#!/bin/bash

# COLORES
COLOR_CIAN='\033[36m'
COLOR_RESET='\033[0m'
COLOR_AZUL='\033[34m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_NEGRO='\033[30m'
COLOR_BLANCO='\033[37m'
COLOR_AMARILLO='\033[33m'
COLOR_MAGENTA='\033[35m'

columns=$(tput cols)
col=$(($columns - 1))
mul=$(($columns*7/100))
mul2=$(($columns*78/100))
mul3=$(($columns*15/100))

# varibles para el encabezado
ID="[ID]"
CLI="CLIENTES"
DEU="VERSIÓN"

# array de usuarios
data=( '[01]' 'Alíce Wonder Dúck palo agúan' 'v10' 
             '[02]' 'Bob Dylan'          'V11' 
             '[03]' 'Ángel Guardían'          'Vá12' 
          )
     
 # Función para contar caracteres multibyte
count_multibyte_chars() {
    local text="$1"
    echo -n "$text" | awk '{ count = 0; for (i = 1; i <= length($0); i++) { char = substr($0, i, 1); if (char ~ /[^\x00-\x7F]/) count++ } print count }'
}

print() {
    #echo "$1"
    cantidad_multibyte="$1"
}

# Función para ajustar espacios dinámicamente
adjust_spaces() {
    local text="$1"
    local max_length="$2"
    local multibyte_count
    multibyte_count=$(count_multibyte_chars "$text")
    # Cada carácter multibyte se ajusta con un espacio adicional
    local adjusted_length=$((max_length + multibyte_count))
    printf "%-${adjusted_length}s" "$text"
    print "$multibyte_count"
    
}

# espacion4='\u00A0\u00A0\u00A0'
# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}

# Función para eliminar o reducir caracteres específicos (incluyendo multibyte)
remove_spaces() {
    local text="$1"
    # Reemplaza caracteres multibyte (\u00A0) o espacios comunes
    echo "$text" | sed -E 's/\u00A0+/ /g; s/[[:space:]]+/ /g; s/^[[:space:]]+|[[:space:]]+$//g'
}

ultimate=$(count_multibyte_chars "$CLI")
ultimate1=$(count_multibyte_chars "$DEU")
echo "ultimate: $ultimate"
echo "ultimate1: $ultimate1"

# Definimos el ancho inicial de cada columna
printf_string="█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n"
PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU")
# Contamos cuantos caracteres hay en la columna
char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
echo "Calculando caracteres (incluyendo espacios) en la fila: $char_count"

echo "Aplicando ajuste resposive"
# aquí va el ajuste resposive a encabezado
for i in {1..301}; do
    medida=$(($char_count + $i))
    if [[ "$medida" -eq "$columns" ]]; then
        echo "$char_count + $i = $columns"
        mul2=$(($mul2 + $i))
        break 
    fi

    medida=$(($char_count - $i))
    if [[ "$medida" -eq "$columns" ]]; then
        echo "$char_count - $i = $columns"
        mul2=$(($mul2 - $i))
        break
    fi
done 

: '
 Se alineó a la derecha la columna 3 de esta forma: 
| % ${mul3}s
'

printf "${COLOR_VERDE}┌%s┐\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
PRINTF_RESULT=$(printf "${COLOR_VERDE}█${COLOR_RESET} ${COLOR_BLANCO}%-${mul}s${COLOR_RESET} ${COLOR_VERDE}|${COLOR_RESET} ${COLOR_BLANCO}%-${mul2}s${COLOR_RESET} ${COLOR_VERDE}|${COLOR_RESET} ${COLOR_BLANCO}% ${mul3}s${COLOR_RESET} ${COLOR_VERDE}█${COLOR_RESET}\n" "$ID" "$CLI" "$DEU")
echo "$PRINTF_RESULT"

# bucle para recorrer el array por filas
for ((i=0;i<${#data[@]};i+=3)); do
    # imprimir línea de encabezado
    printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
    # contar caracteres
    # Ajustar espacios dinámicamente según los caracteres multibyte
    dato=$(adjust_spaces "${data[i]}")
    multibyte_text_count=$(count_multibyte_chars "${data[i]}")  # Conteo de multibyte en el texto
    
    dato1=$(adjust_spaces "${data[i+1]}")
    multibyte_text_count1=$(count_multibyte_chars "${data[i+1]}")  # Conteo de multibyte en el texto
    
    dato2=$(adjust_spaces "${data[i+2]}")
    multibyte_text_count2=$(count_multibyte_chars "${data[i+2]}")  # Conteo de multibyte en el texto
    
    #echo "spaces_text: $ultimate"
    #echo "multibyte_text_count: $multibyte_text_count" 
    
    suma_multibyte_dato=$((ultimate + multibyte_text_count))
    suma_multibyte_dato1=$((ultimate + multibyte_text_count1))
    suma_multibyte_dato2=$((ultimate1 + multibyte_text_count2))
    
    # Generar espacios para los caracteres multibyte en la opción
    spaces_text=$(generate_spaces "$suma_multibyte_dato")
    spaces_text1=$(generate_spaces "$suma_multibyte_dato1")
    spaces_text2=$(generate_spaces "$suma_multibyte_dato2")

    #echo "suma_multibyte_text: $suma_multibyte_text" 
    #echo "suma_multibyte_cate: $suma_multibyte_cate" 
    
    
    char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
    
    # ajustar resposive a cada columna
    for j in {1..301}; do
        medida=$((${#char_count} + $j))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $j))
            char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        fi

        medida=$((${#char_count} - $j))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $j))
            char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        fi   
    done
    
        
    char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
    final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s$spaces_text1${COLOR_RESET}${COLOR_VERDE}|${COLOR_RESET}${COLOR_BLANCO}% ${mul3}s$spaces_text2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
    
    
    printf "%s\n" "${final}"
done
printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 


size=$(tput cols)x$(tput lines)
printf "El tamaño de la terminal es:${size}\n"
# codigo para ajustar la pantalla 
# stty rows 30 columns 50

