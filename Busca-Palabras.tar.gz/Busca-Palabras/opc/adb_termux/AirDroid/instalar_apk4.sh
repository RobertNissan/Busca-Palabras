#!/bin/bash

# Colores
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

# Obtener la ip wlan0 si está disponible...
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

#######FUNCIONES_DE_JUSTICACION_TEXTO#######
# Función para eliminar secuencias ANSI (como colores)
strip_ansi() {
    echo -e "$1" | sed -r 's/\x1B(\[[0-9;]*[mK])?//g'
}
# Función para justificar texto respetando caracteres UTF-8 y espacios
justify_text() {
    local width=$(tput cols) # Ancho de la terminal
    local text="$1"
    local justified=""
    local line=""
    local leading_spaces=""
    local adjusted_width

    # Dividir el texto en líneas si contiene saltos
    while IFS= read -r line || [[ -n $line ]]; do
        # Extraer espacios iniciales de la línea
        leading_spaces=$(echo "$line" | sed -E 's/^([ ]*).*/\1/')

        # Ajustar el ancho restante después de los espacios iniciales
        adjusted_width=$((width - $(echo -n "$leading_spaces" | wc -c)))
        line=$(echo "$line" | sed -E 's/^[ ]*//') # Remover espacios iniciales temporales

        # Si la línea es más corta que el ancho ajustado, justificarla
        if [[ $(strip_ansi "$line" | wc -m) -le $adjusted_width ]]; then
            justified+="$leading_spaces$line\n"
        else
            # Dividir la línea en palabras y ajustar según el ancho
            local words=()
            local current_line=""
            IFS=' ' read -ra words <<< "$line"
            for word in "${words[@]}"; do
                if [[ $(strip_ansi "$current_line $word" | wc -m) -le $adjusted_width ]]; then
                    current_line+="$word "
                else
                    justified+="$leading_spaces$(justify_line "$current_line" "$adjusted_width")\n"
                    current_line="$word "
                fi
            done
            # Añadir la última línea justificada
            justified+="$leading_spaces$current_line\n"
        fi
    done <<< "$text"

    # Imprimir texto justificado
    printf "%b" "$justified"
}

# Función para justificar una línea
justify_line() {
    local line="$1"
    local width="$2"
    local spaces_needed=$((width - $(strip_ansi "$line" | wc -m)))
    local words=($line)
    local space_count=$(( ${#words[@]} - 1 ))

    # Si solo hay una palabra, no justificar
    if (( space_count == 0 )); then
        echo "$line"
        return
    fi

    # Calcular espacios por palabra y residuo
    local extra_spaces=$(( spaces_needed / space_count ))
    local remainder_spaces=$(( spaces_needed % space_count ))
    local justified_line=""

    for i in "${!words[@]}"; do
        justified_line+="${words[i]}"
        if (( i < space_count )); then
            justified_line+="$(printf ' %.0s' $(seq 1 $((extra_spaces + (i < remainder_spaces ? 1 : 0)))))"
        fi
    done

    echo "$justified_line"
}

# Función para imprimir texto con colores
print_color() {
    case $1 in
        red) echo -e "${RED}$2${NC}" ;;
        green) echo -e "${GREEN}$2${NC}" ;;
        yellow) echo -e "${YELLOW}$2${NC}" ;;
        blue) echo -e "${BLUE}$2${NC}" ;;
        cyan) echo -e "${CYAN}$2${NC}" ;;
        magenta) echo -e "${MAGENTA}$2${NC}" ;;
        white) echo -e "${WHITE}$2${NC}" ;;
        *) echo "$2" ;;
    esac
}
# espacion4='\u00A0\u00A0\u00A0'
# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}
#######FIN_FUNCIONES_DE_JUSTICACION_TEXTO#######






#######FUNCIONES_DE_CONEXION#######
disponible_adb='false'

mi_dispositivo() {
    echo ""
    echo "Brand ID: $(getprop ro.product.system.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Version de Android: $(getprop ro.build.version.release)"
    echo "Model ID: $(getprop ro.build.product)"
    echo "Kernel ID: $(uname -r)"
    echo "Chipset ID: $(getprop ro.product.board)"
    echo "Architecture: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        # seleccionar_dispositivo "$ip_objetivo"
        disponible_adb='true'
    fi
    
    conn=$(adb connect "$ip:5555")
    if [[ "$conn" == "failed"* ]]; then
        echo "ok" >/dev/null 2>&1
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    else
        echo "Conexion a Internet a traves del enrutador WiFi"
        conn=$(adb connect "${ip0}:5555")
        sleep 3
        return
        # seleccionar_dispositivo
    fi
    
    # Esto de aqui hasta el final de esta función no se esta usando
    # Mostrar la tabla de dispositivos adb conectados
    encabezado_tabla='false'
    mi_dispositivo
    my_device="$1"
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col*7/100))
    mul2=$(($col*47/100))
    mul3=$(($col*27/100))
    mul4=$(($col*9/100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 
    
    dispositivos=()
    # variable de conteo de cantidad de dispositivos a mostrar en la tabla
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    # offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}')
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}' | grep -v "$my_device")
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')
    
    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            if [ "$encabezado_tabla" == 'false' ]; then
                echo ""
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                encabezado_tabla='true'
            fi
            dispositivos+=("$device")
            # Formatear el id con 2 dígitos
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | v%-${mul4}s#\n" " $id_fortmat" "$device" "$model" "$version"
            printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
            id=$((id+1))
        done
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    : '
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo "Dispositivos OFFLINE:"
        echo "$offline_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo "Dispositivos NO AUTORIZADOS:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
    : '
}

# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    mostrar_dispositivos
    
    # arreglar el input read de bash cuando no ingresa nada y no borra...
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales.
    stty erase $(tput kbs)
    stty sane
    menu_principal
    : '
    echo -en "Ingrese el número del dispositivo o 'q+enter' para salir: "
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
    : '
}

# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    echo ""
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ]"
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell echo "[ DEVICE: \$(getprop ro.product.model) ]"
    adb -s "$dispositivo" shell echo "[ BRAND: \$(getprop ro.product.system.brand) ]"
    adb -s "$dispositivo" shell echo "[ MODEL: \$(getprop ro.build.product) ]"
    adb -s "$dispositivo" shell echo "[ KERNEL: \$(uname -r) ]"
    
    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell echo "[ GPU: \$(getprop ro.hardware.gpu) ]"
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell echo "[ GPU: $gpu_info ]"
    fi

    adb -s "$dispositivo" shell echo "[ CPU: \$(getprop ro.hardware) ]"
    adb -s "$dispositivo" shell echo "[ ANDROID VERSION: \$(getprop ro.build.version.release) ]"
    adb -s "$dispositivo" shell echo "[ Android ID: \$(getprop ro.serialno) ]"
    
}

function connect {
    code="$1"
    local capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        print_color green "$(justify_text "Conectando al puerto principal adb. ¡¡¡No cierres las ventanas!!!.\nPor favor, espere...")"
    fi
    
    # Obtener la ip wlan0 si está disponible...
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import concurrent.futures
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

ip_objetivo = "$ip_objetivo"
num_threads = 10 # Puedes ajustar este valor segun tus necesidades

# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

def scan_ports(start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    try:
        result = nm.scan(ip_objetivo, arguments=f'-p {port_range} -Pn -T4')
        if ip_objetivo in result['scan']:
            open_ports = []
            for protocol in result['scan'][ip_objetivo].all_protocols():
                ports = result['scan'][ip_objetivo][protocol].keys()
                open_ports.extend(ports)
            return open_ports
    except Exception:
        pass
    return []

# Dividir el rango de puertos
port_ranges = [(i, i + 65535 // num_threads) for i in range(10000, 65536, 65535 // num_threads)]

open_ports = []
with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
    futures = [executor.submit(scan_ports, start, end) for start, end in port_ranges]
    for future in concurrent.futures.as_completed(futures):
        open_ports.extend(future.result())

print(" ".join(map(str, sorted(open_ports))))
EOF
)
    # Capturar los puertos disponibles del script python.
    ports_output=$(python -c "$python_script")
    
    # Función para habilitar ADB permanente
    habilitar_adb_permanente() {
        DISPOSITIVO="$1"
        # Verificar si el dispositivo tiene root
        if su -c "id" > /dev/null 2>&1; then
            print_color green "$(justify_text "\n${NC}[${GREEN}Tienes acceso root${NC}].")"
            ROOT_PERMISSIONS="true"
        else
            echo "No tienes acceso root" >/dev/null 2>&1
            ROOT_PERMISSIONS="false"
        fi
        # dar dar a la tabla globa de setedit
        adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
        if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
            print_color yellow "$(justify_text 'Habilitando ADB permanente con root...')"
            # Estos 2 comandos son los que hacen persistente aún después de reiniciar en el puerto 5555.
            adb -s "$DISPOSITIVO" shell su -c "setprop persist.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "setprop service.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "resetprop ro.adb.secure 0"
            adb -s "$DISPOSITIVO" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado permanentemente incluso después del reinicio.')"
        else
            print_color yellow "$(justify_text 'Habilitando ADB temporal (sin root)...')"
            adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado hasta el próximo reinicio.')"
        fi
    }
    
    echo "code: $code"
    lista_port_adb=()
    # Si hay puertos disponibles, procesar los de 5 dígitos en una lista...
    if [[ -n "$ports_output" ]]; then
        echo -e "Puertos abiertos detectados:\n$ports_output"
        for port in $ports_output; do
            # Verificar si el puerto es un número de 5 dígitos
            if [[ $port =~ ^[0-9]{5}$ ]]; then
                lista_port_adb+=("$port")
            fi
        done
    fi
    
    # Mostrar todos los puertos almacenados
    # echo -e "\nLista_port_adb:\n${lista_port_adb[@]}"
    
    exito="false"
    # Iterar sobre los puertos en lista_port_adb
    for port in "${lista_port_adb[@]}"; do
        # echo "Procesando puerto: $port"
        # Intentar emparejar, y redireccionar los errore sl vacío.
        adb pair "${ip_objetivo}:${port}" "${code}" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Emparejamiento exitoso con${NC}: $ip_objetivo:$port"
            exito="true"
            port_pair="${port}"
            # Reconstruir la lista sin el puerto que se usó para emparejar...
            lista_port_adb=($(printf "%s\n" "${lista_port_adb[@]}" | grep -v "^$port_pair$"))
            break
        else
            echo -e "Falló el emparejamiento con $ip_objetivo:$port." > /dev/null
            continue
        fi
    done
    
    if [[ "$exito" == 'true' ]]; then
        echo -e "${YELLOW}Conectando adb con el puerto disponible...${NC}"
        for port_connect in "${lista_port_adb[@]}"; do
            # echo -e "${YELLOW}Intentando conectar adb con:\nadb connect ${ip_objetivo}:${port_connect}${NC}"
            verif_con=$(adb connect "${ip_objetivo}:${port_connect}" 2>/dev/null )
            # echo "verif_con: $verif_con"
            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}Conexión exitosa con${NC}: ${ip_objetivo}:${port_connect}"
                adb -s "${ip_objetivo}:${port_connect}" tcpip 5555 > /dev/null
                echo -e "${YELLOW}Reiniciando el modo TCP, al puerto${NC}: 5555"
                sleep 5
                adb connect "${ip_objetivo}:5555" > /dev/null
                echo -e "${GREEN}Conectado a${NC}: ${ip_objetivo}:5555"
                habilitar_adb_permanente "${ip_objetivo}:5555"
                adb disconnect "${ip_objetivo}:${port_connect}" > /dev/null
                seleccionar_dispositivo "${ip_objetivo}:5555"
                exit
            else
                echo -e "${RED}Conexión fallida con ${ip_objetivo}:${port_connect}.${NC}" > /dev/null
                adb disconnect "${ip_objetivo}:${port_connect}" >/dev/null 2>&1
            fi
        done
    else
        echo -e "${RED}Falló el emparejamiento${NC}..."
    fi
    local capp_adb='true'
    connect
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {
    # Obtener la IP de wlan0, si está disponible
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
    if [ -z "$ip" ]; then
        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    # Elegir entre el emulador o la ip si hay alguno.
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip})$")
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$ip_objetivo"
    fi
 
    # Título e instrucciones justificados
    print_color red "$(justify_text 'Servidor adb, no encendido!!!')"
    print_color green "$(justify_text 'Siga las instrucciones:')"
    # Instrucciones para habilitar depuración USB
    print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb${NC}:")"
    print_color yellow "$(justify_text "${GREEN}1${NC}.$(generate_spaces 0)${YELLOW}Abre la aplicación${NC} [${GREEN}Configuración${NC}] ${YELLOW}en tu dispositivo Android${NC}.")"
    print_color yellow "$(justify_text "${GREEN}2${NC}. ${YELLOW}Ve a${NC} [${GREEN}Acerca del teléfono${NC} o ${GREEN}de la tablet${NC}].")"
    print_color yellow "$(justify_text "${GREEN}3${NC}.  ${YELLOW}Toca repetidamente${NC} [${GREEN}Número de compilación${NC}] ${YELLOW}hasta que se active el modo de desarrollador${NC}.")"
    print_color yellow "$(justify_text "${GREEN}4${NC}. ${YELLOW}Regresa al menú principal de [${GREEN}Configuración${NC}], ${YELLOW}busca y entra en${NC}: [${GREEN}Sistema${NC}].")"
    print_color yellow "$(justify_text "${GREEN}5${NC}. ${YELLOW} Ahora da click en: [${GREEN}Opciones avanzadas${NC}] ${YELLOW}y entra en [${GREEN}Opciones para desarrolladores${NC}].")"
    print_color yellow "$(justify_text "${GREEN}6${NC}. ${YELLOW}Habilita ${NC}[${GREEN}Depuración por USB${NC}].")"
    # Instrucciones para depuración inalámbrica
    print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra${NC}.")"
    print_color yellow "$(justify_text "${GREEN}7${NC}. ${YELLOW}Selecciona donde dice${NC}:")"
    print_color green "$(justify_text " Vincular dispositivo con código de sincronización${NC}")"
    print_color yellow "$(justify_text "  Selecciona ahora en:${NC}")"
    print_color green "$(justify_text "   Vincular con dispositivo${NC}")"
    print_color blue "$(justify_text "    Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")"
    print_color blue "$(justify_text "    Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345")"
    # Nota adicional
    print_color cyan "$(justify_text "Para hacer la conexión correctamente:")"
    print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: ${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC}).")"
    # Final
    print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")"
    
    echo -en "${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
    read code
    echo -en "${NC}"
    while [[ ! "${code}" =~ ^[0-9]{6}$ ]]; do
        echo -e "\n${RED}Error${NC}: Debes ingresar un código válido de 6 dígitos."
        echo -en "${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
        read code
        echo -en "${NC}"
    done
    
    # Cambios Dom 19/Ene/2025
    # Ejecutar emparejamiento y conexión...
    connect "${code}"
}


wlan0() {
    : '
    # Si no puede obtener la IP usando ip addr, usa Termux-API
    if command -v termux-wifi-connectioninfo &>/dev/null; then
        ip0=$(termux-wifi-connectioninfo | grep "ip" | awk -F ':' '{print $2}' | tr -d ',')
        if [[ "$ip0" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            echo "IP obtenida a través de Termux-API: $ip0" >/dev/null 2>&1
            disponible_adb="true"
            return
        else
            echo "No se pudo obtener la IP a través de Termux-API." >/dev/null 2>&1
        fi
    else
        echo "No se pudo obtener la IP. Faltan permisos o comandos." >/dev/null 2>&1
    fi
    : '
    adb_conectado="$1"
    # echo "adb_conectado_wlan0: $adb_conectado"
    # Obtener la IP de wlan0, si está disponible
    ip0=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Si no se encuentra IP en wlan0, buscar una IP distinta que no sea 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi
    # Mostrar la IP de wlan0 si está disponible...
    if [ "$ip0" ]; then
        disponible_adb='true'
        adb_conectado='false'
        return
    fi
    # Mostrar otra IP si no se encontró en wlan0...
    if [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}):\n${YELLOW}ip: ${NC}$ip1" #  > /dev/null
        disponible_adb='false'
        adb_conectado='false'
        return
    fi
    # echo "disponible_adb: $disponible_adb"
}
verif_adb_conect() {
    # Obtener la IP local
    # str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
    # ip=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
    # ip=$(echo "${str%%/*}")
    
    # Capturar la ip del modem si acaso esta disponible...
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Obtener los dispositivos conectados por ADB.
    adb_output=$(adb devices -l)
    # echo $adb_output
    # connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    # connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip})$")
    connected_devices=$(echo "$adb_output" | awk -v ip="$ip" '$2 == "device" {print $1}')
    # echo -e "\nDispositivos conectados:\n$connected_devices"

    # echo $connected_devices
    if [[ -n "$ip" ]]; then
        # Mostrar la IP local
        echo -e "\nIP local: $ip" > /dev/null
    fi

    # Buscar si hay un dispositivo con la ip:5555 o el emulador-5554.
    ip_device=$(echo "$connected_devices" | grep -Ei "${ip}:5555|emulator-5554" | head -n 1)
    # echo "adb_conectado_ip_device: $ip_device"
    adb_conectado="${ip_device}"
    # Verificar, si se encontró algún dispositivo es porque $ip_device no esta vacia.
    if [[ -n "$ip_device" ]]; then
        # echo -e "${GREEN}Dispositivo conectado a adb 1${NC}: $ip_device"
        disponible_adb='false'
        adb_conectado="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        return 
    else
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0 "$adb_conectado"
    fi
}
#verif_adb_conect

verif_ip_externa() {
    proceso_ip_externa='false'
    TEMP_FILE=$(mktemp) # Archivo temporal para almacenar la salida de curl
    TIMEOUT=5 # Tiempo máximo en segundos para que curl termine

    # Ejecutar curl en segundo plano
    curl -s ipinfo.io/ip > "$TEMP_FILE" &
    CURL_PID=$! # Capturar el PID del proceso curl

    # Esperar a que curl termine con un tiempo límite
    SECONDS=0
    while kill -0 $CURL_PID 2>/dev/null; do
        if [[ $SECONDS -ge $TIMEOUT ]]; then
            echo -en "\nTimeout. ip externa curl 'PID: ($CURL_PID)'..."
            x=''
            kill -9 $CURL_PID 2>/dev/null
            rm -f "$TEMP_FILE"
            return 1
        fi
        sleep 0.5
    done

    # Verificar si curl se ejecutó correctamente
    wait $CURL_PID
    if [ $? -ne 0 ]; then
        echo "Error: curl no se ejecutó correctamente." >/dev/null
        rm -f "$TEMP_FILE"
        return 1
    fi

    proceso_ip_externa='true'
    echo "Curl se ejecutó correctamente." >/dev/null

    no_ip='<html><head><title>302 Found</title></head><body><h1>302 Found</h1><p>The document has moved <a href="https://mi.tigo.com.co/assets/captive.html?utm_source=captiveportal">here</a></p></body></html>'

    # Verificar si se captura la IP en 5 intentos
    for ((i=1; i<=1; i++)); do
        x=$(cat "$TEMP_FILE") # Leer la salida del archivo temporal

        if [[ -n "$x" && "$x" != "$no_ip" ]]; then
            echo "IP externa capturada: $x" >/dev/null
            rm -f "$TEMP_FILE" # Limpiar archivo temporal
            return 0
        else
            echo "Intento $i/5 fallido. Reintentando en 0.5 segundos..." >/dev/null
            sleep 0.5
        fi
    done

    # Si no se capturó una IP válida
    echo "No se pudo capturar una IP válida después de 5 intentos." >/dev/null
    rm -f "$TEMP_FILE" # Limpiar archivo temporal
    return 1
}
# Función para verificar el tipo tipo de conexión...
verif_tipo_con() {
        # variable que verifica adb
        disponible_adb="false"
        # variable que verifica internet 
        conect_internet="false"
        # variable que verifica modem
        disponible_modem="false"
        ##############INICIO INTERFAZ################
        # Función para obtener la IP de una interfaz
        obtener_ip() {
            local interfaz=$1
            busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
        }
        # Comprobamos primero si wlan0 está disponible.
        iplocal=$(obtener_ip "wlan0")
        # Si no hay IP en wlan0, buscar en otras interfaces activas.
        if [ -z "$iplocal" ]; then
            echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null
            # Iterar sobre las interfaces activas y capturar la primera IP disponible.
            for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                iplocal=$(obtener_ip "$interfaz")
                ip=$(obtener_ip "$interfaz")
                # Si no capturó una interfaz, el bucle for sigue iterando.
                if [ ! -z "$iplocal" ]; then
                    # Si capturó una interfaz, detiene el bucle for.
                    echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null
                    break
                fi
            done
        else
            # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular).
            echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null
        fi
        # Si después de todas las comprobaciones no hay IP disponible
        if [ -z "$iplocal" ]; then
            echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null
        else
            ip="$iplocal"
        fi
        ############## FIN INTERFAZ################
        
        # Verificar si hay conexión externa (Internet)
        # x=$(curl -s ifconfig.me)
        #x=$(curl -s ipinfo.io/ip)
        verif_ip_externa 2>/dev/null
        ipexterna=$(echo "${x//[<>]/}")
        ipexterna=$(echo "${x}")
        
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            ipexterna_full=$(echo -e "${CYAN}Dirección ip externa${NC}: $x")
        fi

        ###########Zona WiFi Comprobar#########
        iplocalc=".${iplocal}"
        iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
        
        # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            if [[ "$iplocal" == "127.0.0.1" ]]; then
                echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                    ip=$(obtener_ip "$interfaz")
                    if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                        echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null
                        break
                    fi
                done
            else
                echo "Conexión a Internet activa. IP local: $ip" > /dev/null
            fi
        else
            ip="$iplocal"
            echo "No hay conexión a Internet." > /dev/null
        fi

        ###########Zona WiFi Fin#########
        
              
        wlan0_verif='false'    
        # Verificar el estado de wlan0 usando ifconfig
        es_wlan0=$(busybox ifconfig wlan0 2>/dev/null)
        if echo "${es_wlan0}" | grep -q "RUNNING" && echo "${es_wlan0}" | grep -q "inet "; then
            # echo "wlan0_verif: true"
            wlan0_verif='true'
            echo "wlan0 conectada a modem" > /dev/null 2>&1
        elif echo "${es_wlan0}" | grep -q "RUNNING"; then
            #echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        else
            # echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        fi
        
        # echo "ip $ip"
        # echo "iplocal: $iplocal"
        # echo "iplocalc: $iplocal"
        # echo "ipexterna: $ipexterna"
        # Si no está conectado a una red externa.
        if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
            ipexterna="html"
            disponible_modem="true"
            conect_internet="false"
            disponible_adb='false'
            echo -e "\n${RED}No hay conexión wi-fi, datos ni ${NC}(${RED}zona wi-fi${NC})${nc}...\n" # > /dev/null 2>&1
            adb_conectado="$adb_conectado_ip_device"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi
  
        
        # Hay internet datos
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ ! "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Tienes internet para compartir datos por ${NC}(${GREEN}zona wi-fi${NC}).\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="true"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
                echo -e "$ipexterna_full"
                # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        # No hay internet pero está la zona wi-fi activa.
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Conexion por ${NC}(${GREEN}Zona WI-FI${NC}) ${GREEN}y no tienes internet,\npero puedes otorgar conexión${NC}.\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="false"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
        
        # Verificar si ipexterna contiene una dirección IP válida.
        # Tienes datos de internet y la zona wi-fi activa.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
            echo -e "\n${GREEN}Tienes datos de internet y la ${NC}(${GREEN}zona wi-fi${NC}) ${GREEN}activa${NC}.\n(${GREEN}Compartiendo datos${NC})\n"
            disponible_modem="true"
            disponible_adb="false"
            adb_conectado="$adb_conectado_ip_device"
            conect_internet="true"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
            echo -e "$ipexterna_full"
        fi
        
    if [[ "$disponible_modem" == "false" ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo -e "\n${GREEN}Tienes internet wi-fi del Módem${NC}.\n" # >/dev/null 2>&1
        conect_internet="true"
        disponible_adb="true"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        echo -e "$ipexterna_full"
    fi
    
    # No hay internet pero estás conectado a modem.
    if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
        echo -e "\n${GREEN}No hay internet pero estás conectado al Módem${NC}.\n" # >/dev/null 2>&1
        disponible_modem="true"
        disponible_adb='true'
        conect_internet="false"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
    # echo "disponible_adb: $disponible_adb"
    # echo "conect_internet: $conect_internet"
}
# verif_tipo_con
#######FUNCIONES_FIN_CONEXION#######


# Verifica permisos de almacenamiento
verificar_permisos() {
    adb_conectado="$1"
    echo -e "${YELLOW}Verificando permisos de almacenamiento...${NC}" > /dev/null
    if [ -d "/sdcard/" ]; then
        touch "/sdcard/.permiso_prueba" && rm "/sdcard/.permiso_prueba" > /dev/null
        echo -e "${GREEN}Permisos de almacenamiento ya concedidos.${NC}" > /dev/null
        if [[ -n "$adb_conectado" ]]; then
            # Concediendo permisos de almacenamiento con adb para reforzar...
            adb -s "$adb_conectado" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
            adb -s "$adb_conectado"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
        fi
    else
        echo -e "${YELLOW}Concediendo permisos...${NC}"
        termux-setup-storage
        sleep 5
        if [[ -n "$adb_conectado" ]]; then
            # Concediendo permisos de almacenamiento con adb para reforzar
            adb -s "$adb_conectado" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
            adb -s "$adb_conectado"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
        fi
    fi
}

# Verifica si un APK está instalado
verificar_app_instalada() {
    local package="$1"
    local adb_conectado="$2"
    if [[ -n "$adb_conectado" ]]; then
        adb -s "$adb_conectado" shell pm list packages | grep -q "^package:${package}$"
    fi
}

# Función para descargar y descomprimir archivos
descargar_archivo_mediafire() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    local conect_internet="$4"

    if [[ "$conect_internet" == 'true' ]]; then
        # Descargar el archivo
        echo -e "\n${YELLOW}Descargando${NC}: ${archivo_zip}"
        # Descargar simulando un navegador real
        wget --header="User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" \
             --header="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" \
             --header="Accept-Language: en-US,en;q=0.5" \
             --header="Connection: keep-alive" \
             --max-redirect=20 \
             -O file "$url"
        # curl -O $url
        link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
        rm -rf file
        cd "${destino}"  
        wget --no-check-certificate ${link}
        unzip "${archivo_zip}"
        # rm -rf "${archivo_zip}"
        echo -e "${YELLOW}Descarga y extracción completadas en:\n${GREEN}${destino}/${NC}"
        cd - > /dev/null
    else
        echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
        return
    fi
}

# Descarga archivo desde Google Drive
descargar_archivo_gdrive() {
    local file_id="$1"
    local destino="$2"
    local conect_internet"$3"
    local limpiar_residuos="$4"
    if [[ "$conect_internet" == 'true' ]]; then
        rm -rf "$limpiar_residuos"
        echo -e "${YELLOW}Descargando archivo desde Google Drive...${NC}"
        gdown -O "$destino" "https://drive.google.com/uc?id=${file_id}"
    else
        echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
        return
    fi
}

# Instala un APK en el dispositivo
instalar_apk() {
    local archivo_path="$1"
    local package_name="$2"
    local adb_conectado="$3"
    # echo $adb_conectado
    if [ ! -f "$archivo_path" ]; then
        echo -e "${RED}El archivo $archivo_path no existe en la ruta especificada.${NC}"
        return 1
    fi
    if [[ -n "$adb_conectado" ]]; then
        if verificar_app_instalada "$package_name" "$adb_conectado"; then
            echo -e "${GREEN}La aplicación ${package_name} ya está instalada.${NC}"
        else
            echo -e "${YELLOW}Instalando APK${NC}..."
            adb -s "$adb_conectado" install "$archivo_path" > /dev/null
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}Instalación completada${NC}.\n"
            else
                echo -e "${GREEN}La instalación no pudo ser completada.${NC}"
            fi
        fi
    else
        echo -e "${GREEN}La instalación no pudo ser completada.${NC}"
    fi
}

procesar_archivo() {
    local file_id="$1"
    local zip_file="$2"
    local archivo_path="$3"
    local destino_dir="$4"
    local adb_conectado="$5"
    local tamanio_esperado="$6"
    local pack_app="$7"
    local conect_internet="$8"
    
    # Obtener solo el nombre del archivo y luego la extensión
    # capturar solo el archivo sin su ruta
    nombre_archivo=$(basename "$archivo_path")
    # capturar solo la extensión del archivo
    extension="${nombre_archivo##*.}"
    # echo "nombre_archivo: $nombre_archivo"
    
    # Si existe el apk o rom, toma la extensión.
    if [ -f "${archivo_path}" ]; then
        # echo "Nombre de archivo_path: $archivo_path"
        # toma la extensión del archivo a analizar.
        nombre_archivo=$(basename "${archivo_path}")
        extension="${nombre_archivo##*.}"
        # echo "extension: $extension"
    fi
    
    case "$extension" in
        "apk")
            # Si existe el apk.
            if [[ -f "${archivo_path}" ]]; then
                # toma la extensión del archivo a analizar.
                nombre_archivo=$(basename "${nombre_archivo}")
                # echo -e "${YELLOW}nombre_archivo${NC}: $nombre_archivo"
                extension="${nombre_archivo##*.}"
                # echo -e "${YELLOW}extension${NC}: $extension"
                if [[ "$nombre_archivo" =~ [\(\)\[\]] ]]; then
                    nombre_archivo=""
                    for (( i=0; i<${#nombre_archivo}; i++ )); do
                        char="${nombre_archivo:i:1}"
                        case "$char" in
                            '(' | ')' | '[' | ']')
                                nombre_archivo+="\\$char" ;;
                        *)
                            nombre_archivo+="$char" ;;
                        esac
                    done
                fi
            fi
                
            echo -e "${YELLOW}nombre_archivo${NC}: $nombre_archivo"
            # echo -e "${YELLOW}adb_conectado${NC}: $adb_conectado"
            
            integridad_apk='mal'
            verif_integridad_apk() {
                if apksigner verify --verbose --print-certs "$archivo_path" 2>&1 | grep -qi "Exception\|Malformed"; then
                    # echo "Error: El archivo APK está corrupto o no es válido."
                    tamanio_archivo=$(stat --format="%s" "$archivo_path" 2>/dev/null)
                    tamanio_archivo="$tamanio_archivo"
                    # echo "tamanio_archivo: $tamanio_archivo"
                    # echo "tamanio_esperado $tamanio_esperado"
                    integridad_apk='mal'
                    # echo "integridad_apk: $integridad_apk"
                else
                    # echo "El archivo APK es válido."
                    tamanio_archivo=$(stat --format="%s" "$archivo_path" 2>/dev/null)
                    tamanio_archivo="$tamanio_archivo"
                    # echo "tamanio_archivo: $tamanio_archivo"
                    # echo "tamanio_esperado: $tamanio_esperado"
                    integridad_apk='bien'
                    # echo "integridad_apk: $integridad_apk"
                fi
            }
            verif_integridad_apk # > /dev/null
            
            # Si el zip y el apk no están presente o fueron eliminados sin saber si o si, o no está instalado. No adb conexión.
            if [[ -z "${adb_conectado}" && ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]]; then
                if [[ "$conect_internet" == ''true ]]; then
                    echo -e "${YELLOW}Descargando el archivo ZIP...${NC}"
                    descargar_archivo_gdrive "$file_id" "${destino_dir}/${zip_file}" "$conect_internet" "${destino_dir}/${zip_file}"*
                    echo -e "${YELLOW}Descomprimiendo archivo descargado...${NC}"
                    unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
                else
                    echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
                    return
                fi
            fi
            
            # Si el zip y el apk están presente y sin saber si, sí, o no está instalado. no adb conexión.
            if [[ -f "$archivo_path" ]] && [[ "$tamanio_archivo" -eq "$TAMANIO_ESPERADO" ]]; then
                if [[ -z "${adb_conectado}" ]]; then
                    echo -e "${GREEN}El archivo $archivo_path\nestá en exelente estado y listo para instalar desde tu\ngestor de archivo.${NC}"
                    return
                fi
            fi
            
            verif_integridad_apk # > /dev/null
            # Verifica si el APK está presente y si es válido (tamaño), si adb conexión, y si no está instalado procede a instalar.
            if [[ -f "$archivo_path" ]]; then
                if [[ "$tamanio_archivo" -eq "$TAMANIO_ESPERADO" ]]; then # && { echo "$result" | grep -qi "Exception" || echo "$result" | grep -qi "Malformed"; }; then
                    # echo "tamaño igual"
                    # echo -e "${YELLOW}adb_conectado${NC}: $adb_conectado"
                    if [[ -n "${adb_conectado}" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                        echo -e "${GREEN}El APK está en buen estado y listo para instalar${NC}."
                        instalar_apk "$archivo_path" "$pack_app" "$adb_conectado"
                        return
                    elif ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                        echo -e "${GREEN}El archivo $archivo_path\nestá en buen estado y listo para instalar desde tu\ngestor de archivo.${NC}"
                        return
                    fi
                else
                    echo -e "${RED}El APK está corrupto o incompleto. Procediendo a usar el ZIP...${NC}"
                    rm "$archivo_path"
                fi
            fi
        
            # Verifica si el ZIP está presente y en buen estado descomprimir y si no esta el apk y si no esta instalada el apk!!!.
            if [[ -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                echo -e "${YELLOW}Verificando el estado del archivo ZIP...${NC}"
                if unzip -t "${destino_dir}/${zip_file}" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP está en buen estado. Descomprimiendo${NC}..."
                    unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
                else
                    echo -e "${RED}El archivo ZIP está corrupto. Eliminando y descargando nuevamente...${NC}"
                    rm "${destino_dir}/${zip_file}"
                fi
            fi
            
            # redundancia
            # Verifica si el ZIP está presente y en buen estado
            if [[ -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                echo -e "${GREEN}El archivo $pack_app ya está instalado!!!.${NC}"
                return
            fi
            # Verifica si el ZIP está presente y en buen estado. hace la verificación de si esta instalada el apk, aunque falta verificar si hay o no adb conexión!!!.
            if [[ ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -E "^package:${pack_app}$"; then
                echo -e "${GREEN}El archivo $pack_app ya está instalado!!!.${NC}"
                return
            fi
            
            # Si el zip y el apk no están presente o fueron eliminados y si no está instalado, descargarlo. si adb conexión y si hay internet.
            if [[ -n "${adb_conectado}" && ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                if [[ "$conect_internet" == 'true' ]]; then
                    echo -e "${YELLOW}Descargando el archivo ZIP...${NC}"
                    descargar_archivo_gdrive "$file_id" "${destino_dir}/${zip_file}" "$conect_internet" "${destino_dir}/${zip_file}"*
                    echo -e "${YELLOW}Descomprimiendo archivo descargado...${NC}"
                    unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
                else
                    echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
                    return
                fi
            elif [[ ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                echo -e "${GREEN}El archivo $pack_app ya está instalado!!!.${NC}"
                return
            fi
            
            # Si el zip y el apk no están presente o fueron eliminados y si no está instalado, descargarlo. no adb conexión y si hay internet.
            if [[ -z "${adb_conectado}" && ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                if [[ "$conect_internet" == 'true' ]]; then
                    echo -e "${YELLOW}Descargando el archivo ZIP...${NC}"
                    descargar_archivo_gdrive "$file_id" "${destino_dir}/${zip_file}" "$conect_internet" "${destino_dir}/${zip_file}"*
                    echo -e "${YELLOW}Descomprimiendo archivo descargado...${NC}"
                    unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
                else
                    echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
                    return
                fi
            elif [[ ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                echo -e "${GREEN}El archivo $pack_app ya está instalado!!!.${NC}"
                return
            fi
        
            # Verifica nuevamente si el APK está disponible tras la descompresión. si adb conexión.
            if [[ -f "$archivo_path" ]]; then
                if [[ -n "${adb_conectado}" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                    echo -e "${GREEN}El APK está en buen estado y listo para instalar${NC}."
                    instalar_apk "$archivo_path" "$pack_app" "$adb_conectado"
                    return
                elif ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${pack_app}$"; then
                    echo -e "${GREEN}El archivo $archivo_path\nestá en exelente estado y listo para instalar desde tu\ngestor de archivo.${NC}"
                    return
                fi
                instalar_apk "$archivo_path" "$pack_app" "$adb_conectado"
            else
                echo -e "${RED}El archivo $archivo_path no se encontró después de todos los intentos.${NC}"
                exit 1
            fi
            # Verifica nuevamente si el APK está disponible tras la descompresión. no adb conexión.
            if [[ -f "$archivo_path" ]]; then
                if [[ -z "${adb_conectado}" ]]; then
                    echo -e "${GREEN}El archivo $archivo_path\nestá en exelente estado y listo para instalar desde tu\ngestor de archivo.${NC}"
                    return
                fi
            else
                echo -e "${RED}El archivo $archivo_path no se encontró después de todos los intentos.${NC}"
                exit 1
            fi
            ;;
        "iso")
            if [[ -f "${archivo_path}" ]]; then
                tamanio_archivo_actual=$(stat --format="%s" "${archivo_path}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo_actual}" -eq "${TAMANIO_ESPERADO}" ]]; then
                    echo -e "${GREEN}La iso ya esta descargada en:\n${YELLOW}$archivo_path${NC}"
                    return
                else
                    echo -e "${RED}La iso está corrupta${NC}"
                    # echo "tamaños no igual"
                    rm -f "$archivo_path"
                fi
            else
                echo -e "${RED}La iso no existe${NC}"
            fi
            echo -e "Verificando archivo zip principal"
            if [[ -f "${destino_dir}/${zip_file}" ]]; then
                if unzip -t "$zip_file" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$zip_file${NC}"
                    # Preguntar si desea descomprimir
                    read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                    if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                        echo "Descomprimiendo $ruta_archivo en $destino..."
                        unzip -o "$zip_file" -d "$destino_dir"
                        echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                    else
                        echo -e "${YELLOW}Descompresión cancelada.${NC}"
                    fi
                else
                    echo -e "${RED}El archivo ZIP $zip_file está corrupto o incompleto.${NC}"
                    # echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                    rm -f "$destino_dir/$zip_file"
                    descargar_archivo_mediafire "$file_id" "$zip_file" "$destino_dir" "$conect_internet"
                    return
                fi
            else
                echo -e "${RED}El archivo $zip_file no existe.${NC}"
                descargar_archivo_mediafire "$file_id" "$zip_file" "$destino_dir" "$conect_internet"
                return
            fi
             
            ;;
        *)
            echo -e "${YELLOW}Tipo de archivo no soportado para verificación: $ruta_archivo.${NC}"
            return
            ;;
    esac    
}




#### ajustando tabla inicial ####
# Definir el script Python en una variable
python_script_tabla=$(cat <<EOF
import re
import os
import sys
import signal
import subprocess

# Colores
verde='\\x1b[1;32m'
blanco='\\x1b[1;37m'
amarillo='\\x1b[1;33m'
reset='\\x1b[1;0m'
# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    print("\n¡Saliendo...!")
    option = "03"  # Opción predeterminada
    # Limpiar la salida y detener el progreso
    sys.exit(0)    
# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)
# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y salir del script
    print("\n¡Saliendo...!")
    option = "03"  # Opción predeterminada
    sys.exit(0)    
# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

# Verificar el valor desde las variables de entorno.
# obtener el último resultado de la variable disponible_adb y adb_conectado
disponible_adb = os.environ.get("disponible_adb", "$disponible_adb")
adb_conectado = os.environ.get("adb_conectado", "$adb_conectado")

def obtener_ip():
    # Intentar obtener la IP de wlan0
    try:
        output = subprocess.check_output("busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'", shell=True, stderr=subprocess.PIPE).decode().strip()
        # Buscar solo la IP después de 'addr:' o 'inet'
        match = re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)|addr:(\d+\.\d+\.\d+\.\d+)', output)
        if match:
            # Verifica que se capturó una IP
            return match.group(1) or match.group(2)
    except subprocess.CalledProcessError:
        pass
    # Si no se encuentra IP en wlan0, buscar otra IP que no sea 127.0.0.1
    try:
        output = subprocess.check_output("ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1", shell=True, stderr=subprocess.PIPE).decode().strip()
        return output if output else None
    except subprocess.CalledProcessError:
        return None
# Obtener la IP
ip = obtener_ip()
# print(f"IP obtenida: {ip}")

def tabla_proyect():
    # Datos simplificados (array de listas/tuplas)
    '''
    lista_app = [
        ["01", "Instalar termux-api - termux-boot"],
        ["02", "God Of War - Chains Of Olympus (Esp)"],
        ["03", "Volver al menú principal"],        
    ]
    '''
    # Datos simplificados (array de listas/tuplas)
    lista_app = []
    
    # print(f"Python disponible_adb: {disponible_adb}")
    # print(f"Python adb_conectado: {adb_conectado}")
    # print(f"Python adb_conectado_ip_device: {adb_conectado_ip_device}")

    # Verificar si disponible_adb es "true" y agregar opción
    if disponible_adb == "true" and adb_conectado == 'false':
        # disponible_adb = "true"
        # adb_conectado = ""
        # print(f"{amarillo}La dirección IP de wlan0 es{reset}: " + (ip.split()[1] if ip and 'inet' in ip else (ip if ip else '127.0.0.1')))
        print(f"{verde}Disponible para conectar adb{reset}. ({verde}Recomendado{reset})!!!")
        lista_app.append(["00", "Conectar adb"])
    elif (f"{ip}:5555" in adb_conectado or "emulator-5554" in adb_conectado):
        # print(f"{amarillo}La dirección IP de wlan0 es{reset}: " + (ip.split()[1] if ip and 'inet' in ip else (ip if ip else '127.0.0.1')))
        print(f"{verde}Dispositivo conectado a adb{reset}: {adb_conectado}")
    elif ("false" in disponible_adb or "true" in disponible_adb) and (f"{ip}:5555" in adb_conectado or "emulator-5554" in adb_conectado):
        # print(f"{amarillo}La dirección IP de wlan0 es{reset}: " + (ip.split()[1] if ip and 'inet' in ip else (ip if ip else '127.0.0.1')))
        print(f"{verde}Dispositivo conectado a adb{reset}: {adb_conectado}")
        
    # Agregar más opciones a la lista de la tabla
    lista_app.append(["01", "Instalar termux-api - termux-boot"])
    lista_app.append(["02", "God Of War - Chains Of Olympus (Esp)"])
    lista_app.append(["03", "Volver al menú principal"])        
    
    # limpiar las variables obtenidas 
    # Limpia las variables de entorno
    os.environ.pop("disponible_adb", None)  # Elimina 'disponible_adb' si existe
    os.environ.pop("adb_conectado", None)  # Elimina 'adb_conectado' si existe


    # Obtener el ancho máximo de la tabla a partir del ancho del terminal
    table_width = os.get_terminal_size().columns
    n1 = int(0.11 * table_width)
    n2 = int(1.14 * table_width)
    ID = '[ID]'
    NOMBRE = 'APP PREMIUM'
    row_str = f"█ {ID.center(n1)} █ {NOMBRE.ljust(n2)} █"
    long = len(row_str)
    for longitud in range(1, 399):
        medida = long - longitud
        if medida == table_width:
            n2 = n2 - longitud
            break
        else:
            medida = long + longitud
            if medida == table_width:
                n2 = n2 + longitud
                break
    texto = "----- TABLA DE APP -----"
    texto2 = "Instale termux-api para tener los permisos necesarios sobre otras aplicaciones"
    espacios = (table_width - len(texto)) // 2
    centrado = (" " * espacios) + texto + (" " * espacios)
    # print(centrado)
    espacios = (table_width - len(texto2)) // 2
    centrado2 = (" " * espacios) + texto2 + (" " * espacios)
    # print(centrado2)
    fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {blanco}{NOMBRE.ljust(n2)} {verde}█{reset}"
    linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
    print(linea_superior)
    print(fila_contenido)
    separador = f"{verde}█" + "═" * (table_width - 2) + "█" + f"{reset}"
    print(separador)
    total_filas = len(lista_app)
    contador = 0
    for fila in lista_app:
        id_ = f"[{fila[0]}]"
        name = fila[1]
        row_str = f"{verde}█ {blanco}{id_.center(n1)} {verde}┃ {blanco}{name.ljust(n2)} {verde}█{reset}{blanco}"
        print(row_str)
        contador += 1
        if contador < total_filas:
            print(separador)
    cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
    print(cierre)
    print(f"{verde}┃")
    option = input(f"{verde}└>>>{blanco} ")
    return option
if __name__ == "__main__":
    cap_input = os.environ.get("CAP_INPUT", "/tmp/.cap_input")
    user_input = tabla_proyect()
    with open(cap_input, "w") as f:
        f.write(user_input)
EOF
)
#### ajustando tabla inicial fin ####


# Menú principal
menu_principal() {
    while true; do
        
        verif_adb_conect # > /dev/null
        verif_tipo_con # > /dev/null
        
        if [ -n "$adb_conect" ]; then
            verificar_permisos "$adb_conectado"
        fi
        # Verificar si Python está instalado
        if [ -x ${PREFIX}/bin/python ]; then
            echo "Python ya está instalado." >/dev/null
        else 
            echo "Instalando python..."
            apt install python -y
            pkg install python-pip
            # dpkg --configure -a;apt list --upgradable;apt upgrade;apt-get check;apt clean
        fi
        
        # Función para instalar paquetes python si no están presentes.
        instalar_paquete_pip() {
            local comando=$1
            local instalacion=$2
            local mensaje_error=$3
            if ! command -v "$comando" &> /dev/null; then
                echo -e "${YELLOW}$comando no está instalado.\nInstalando $comando${NC}..."
                eval "$instalacion" >/dev/null 2>&1
                if [ $? -ne 0 ]; then
                    echo "$mensaje_error"
                    exit 1
                fi
            else
                echo "${GREEN}$comando ya está instalado${NC}." >/dev/null 2>&1
            fi
        }
        
        # Función para instalar paquetes si no están presentes en: $PREFIX/share/doc/
        instalar_paquete_share() {
            if [[ ! -x $PREFIX/share/doc/$1 ]]; then
                echo "${YELLOW}Instalando $2${NC}"
                pkg install -y $1 >/dev/null 2>&1
                echo -e "${GREEN}$1 instalado correctamente${NC}."
            else
                echo "${GREEN}$2 ya está instalado${NC}." >/dev/null
            fi
        }
        # Función para instalar paquetes si no están presentes en: $PREFIX/bin/
        instalar_paquete_bin() {
            if [[ ! -f $PREFIX/bin/$1 ]]; then
                echo "${YELLOW}Instalando $2${NC}"
                pkg install -y $1 >/dev/null 2>&1
                echo -e "${GREEN}$1 instalado correctamente${NC}."
            else
                echo "${GREEN}$2 ya está instalado${NC}." >/dev/null
            fi
        }
        
        # Instalar herramientas necesarias.
        instalar_paquete_bin "zip" "zip"
        instalar_paquete_bin "rarp" "rar"
        instalar_paquete_bin "adb" "adb"
        instalar_paquete_bin "unrar" "unrar"
        instalar_paquete_bin "nmap" "nmap"
        instalar_paquete_bin "apksigner" "apksigner"
        instalar_paquete_bin "mediainfo" "mediainfo"
        instalar_paquete_share "termux-api" "termux-api"
        instalar_paquete_pip "gdown" "pip install gdown" "Error al instalar gdown. Asegúrate de tener pip instalado."
    
        
        # Función para verificar si un paquete está instalado en el dispositivo de forma exacta.
        cap_nom_pack() {
            local package="$1"
            # Obtener solo el nombre del paquete exacto de la lista de paquetes instalados con esto: grep -E "^package:com.termux$" | awk -F ':' '{print $2}'
            nombre_pack=$(adb -s "${adb_conectado}" shell pm list packages | grep -E "^package:${package}$" | awk -F ':' '{print $2}') > /dev/null
            echo "$nombre_pack"
        }
        # cap_nom_pack "${pack_app}"
        
       # echo -e "\n${GREEN}disponible_adb${NC}: $disponible_adb"
       # echo -e "${GREEN}adb_conectado${NC}: $adb_conectado"
       
        # Pasar las variables de bash() {disponible_adb, adb_conectado, adb_conectado_ip_device} al script de Python
        export disponible_adb
        export adb_conectado
        export adb_conectado_ip_device
        # Ruta al archivo de salida
        cap_input="$(pwd)/.cap_input"
        export CAP_INPUT="$cap_input"
        # Eliminar archivo previo si existe
        [ -f "$cap_input" ] && rm -f "$cap_input"
        # Ejecutar el script Python
        python -c "$python_script_tabla"
        # Leer la opción seleccionada
        opt=$(cat "$cap_input" 2>/dev/null || echo "")
        # Eliminar archivo previo si existe
        [ -f "$cap_input" ] && rm -f "$cap_input"
        
        if [[ "$disponible_adb" == 'true' && "$adb_conectado" == 'false' ]]; then
            # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            # echo -e "\n${CYAN}Menú Principal${NC}" # > /dev/null
            adb_conectado=''
        elif [[ "$disponible_adb" == 'false' && "$adb_conectado" == 'false' ]]; then
            # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            # echo -e "\n${CYAN}Menú Principal${NC}" # > /dev/null
            adb_conectado=''
        fi
        # Limpiar la variable que contiene si acaso el un dispositivo adb conectado...
        adb_conectado_ip_device=""
        
        case $opt in
            0|00)
                if [ "$disponible_adb" == 'true' ]; then
                    solicitar_emparejamiento
                fi
                ;;
            1|01)
                # Variables globales
                PACK_APP='com.termux.api'
                TAMANIO_ESPERADO=2868448
                RUTA_DESTINO='/sdcard/Download'
                ARCHIVO_ZIP='Termux_API_0.50.1.zip'
                URL='1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY'
                ARCHIVO_PATH="${RUTA_DESTINO}/Termux_API_0.50.1.apk"
                CONECT_INTERNET="$conect_internet"
                ADB_CONECTADO="$adb_conectado"
                procesar_archivo "$URL" "$ARCHIVO_ZIP" "$ARCHIVO_PATH" "$RUTA_DESTINO" "$ADB_CONECTADO" "$TAMANIO_ESPERADO" "$PACK_APP" "$CONECT_INTERNET"
                
                ;;
            2|02)
                # Variables globales
                TAMANIO_ESPERADO=1651015680
                ADB_CONECTADO="$adb_conectado"
                CONECT_INTERNET="$conect_internet"
                ARCHIVO_ZIP='God_Of_War_Chains_Of_Olympus_Esp.zip'
                RUTA_DESTINO='/sdcard/Download/Games/PSE/PPSSPP'
                CARPETA_GAME="$RUTA_DESTINO/God_Of_War_Chains_Of_Olympus_Esp"
                ARCHIVO_PATH="$CARPETA_GAME/God Of War Chains Of Olympus (Esp).iso"
                URL='https://www.mediafire.com/file/23vdt913xtzedus/God_Of_War_Chains_Of_Olympus_Esp.zip/file'
                procesar_archivo "$URL" "$ARCHIVO_ZIP" "$ARCHIVO_PATH" "$RUTA_DESTINO" "$ADB_CONECTADO" "$TAMANIO_ESPERADO" "$CARPETA_GAME" "$CONECT_INTERNET"
                ;;
            3|03)
                echo "Saliendo..."
                # cd ~/Busca-Palabras
                # bash Menu-Busca-Palabras.sh
                exit 0
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo${NC}."
                ;;
        esac
    done
}

menu_principal # El script verifica automáticamente si hay un emulador adb conectado.
