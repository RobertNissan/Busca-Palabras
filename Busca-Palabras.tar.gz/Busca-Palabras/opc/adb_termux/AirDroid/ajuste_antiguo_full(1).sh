#!/bin/bash

# COLORES
COLOR_CIAN='\033[36m'
COLOR_RESET='\033[0m'
COLOR_AZUL='\033[34m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_NEGRO='\033[30m'
COLOR_BLANCO='\033[37m'
COLOR_AMARILLO='\033[33m'
COLOR_MAGENTA='\033[35m'

columns=$(tput cols)
col=$(($columns - 1))
mul=$(($columns*07/100))
mul2=$(($columns*78/100))
mul3=$(($columns*15/100))

# varibles para el encabezado
ID="[ID]"
CLI="CLIENTES"
DEU="VERSION"

# array de usuarios
data=( '[01]' 'Alíce Wonder Dúck - palo' 'v10' 
             '[02]' 'Bób Dylan'          'íVáú11' 
             '[03]' 'Ángel Guardían Bénditós'          'éVá12' 
          )
     
 # Función para contar caracteres multibyte
count_multibyte_chars() {
    local text="$1"
    echo -n "$text" | awk '{ count = 0; for (i = 1; i <= length($0); i++) { char = substr($0, i, 1); if (char ~ /[^\x00-\x7F]/) count++ } print count }'
}

print() {
    #echo "$1"
    cantidad_multibyte="$1"
}

# Función para ajustar espacios dinámicamente
adjust_spaces() {
    local text="$1"
    local max_length="$2"
    local multibyte_count
    multibyte_count=$(count_multibyte_chars "$text")
    # Cada carácter multibyte se ajusta con un espacio adicional
    local adjusted_length=$((max_length + multibyte_count))
    printf "%-${adjusted_length}s" "$text"
    print "$multibyte_count"
    
}

# espacion4='\u00A0\u00A0\u00A0'
# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}

# Función para eliminar o reducir caracteres específicos (incluyendo multibyte)
remove_spaces() {
    local text="$1"
    # Reemplaza caracteres multibyte (\u00A0) o espacios comunes
    echo "$text" | sed -E 's/\u00A0+/ /g; s/[[:space:]]+/ /g; s/^[[:space:]]+|[[:space:]]+$//g'
}

ultimate=$(count_multibyte_chars "$CLI")
ultimate1=$(count_multibyte_chars "$DEU")
echo "ultimate: $ultimate"
echo "ultimate1: $ultimate1"

# Definimos el ancho inicial de cada columna
printf_string="█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n"
PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU")
# Contamos cuantos caracteres hay en la columna
char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
echo "Calculando caracteres (incluyendo espacios) en la fila: $char_count"

echo "Aplicando ajuste resposive"
# aquí va el ajuste resposive a encabezado
for i in {1..301}; do
    medida=$(($char_count + $i))
    if [[ "$medida" -eq "$columns" ]]; then
        echo "$char_count + $i = $columns"
        mul2=$(($mul2 + $i))
        break 
    fi

    medida=$(($char_count - $i))
    if [[ "$medida" -eq "$columns" ]]; then
        echo "$char_count - $i = $columns"
        mul2=$(($mul2 - $i))
        break
    fi
done 

: '
 Se alineó a la derecha la columna 3 de esta forma: 
| % ${mul3}s
'

printf "${COLOR_VERDE}┌%s┐\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
PRINTF_RESULT=$(printf "${COLOR_VERDE}█${COLOR_RESET} ${COLOR_BLANCO}%-${mul}s${COLOR_RESET} ${COLOR_VERDE}|${COLOR_RESET} ${COLOR_BLANCO}%-${mul2}s${COLOR_RESET} ${COLOR_VERDE}|${COLOR_RESET} ${COLOR_BLANCO}% ${mul3}s${COLOR_RESET} ${COLOR_VERDE}█${COLOR_RESET}\n" "$ID" "$CLI" "$DEU")
echo "$PRINTF_RESULT"

# bucle para recorrer el array por filas
for ((i=0;i<${#data[@]};i+=3)); do
    # imprimir línea de encabezado
    printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 
    # contar caracteres
    # Ajustar espacios dinámicamente según los caracteres multibyte
    dato=$(adjust_spaces "${data[i]}")
    multibyte_text_count=$(count_multibyte_chars "${data[i]}")  # Conteo de multibyte en el texto
    
    dato1=$(adjust_spaces "${data[i+1]}")
    multibyte_text_count1=$(count_multibyte_chars "${data[i+1]}")  # Conteo de multibyte en el texto
    
    dato2=$(adjust_spaces "${data[i+2]}")
    multibyte_text_count2=$(count_multibyte_chars "${data[i+2]}")  # Conteo de multibyte en el texto
    
    #echo "spaces_text: $ultimate"
    # echo "multibyte_text_count1: $multibyte_text_count1" 
    
    ulimate_space=$(generate_spaces "$multibyte_text_count1")
    ulimate_space1=$(generate_spaces "$multibyte_text_count2")
    
    suma_multibyte_dato=$((ultimate + multibyte_text_count))
    suma_multibyte_dato1=$((ultimate + multibyte_text_count1))
    echo "suma_multibyte_dato1: $suma_multibyte_dato1" 
    suma_multibyte_dato2=$((ultimate1 + multibyte_text_count2))
    
    # Generar espacios para los caracteres multibyte en la opción
    spaces_text_p=$(generate_spaces "$multibyte_text_count")
    spaces_text1_p1=$(generate_spaces "$multibyte_text_count1")
    spaces_text1_p2=$(generate_spaces "$multibyte_text_count2")
    
    # Generar espacios para los caracteres multibyte en la opción
    spaces_text=$(generate_spaces "$suma_multibyte_dato")
    spaces_text1=$(generate_spaces "$suma_multibyte_dato1")
    spaces_text2=$(generate_spaces "$suma_multibyte_dato2")

    #echo "suma_multibyte_text: $suma_multibyte_text" 
    #echo "suma_multibyte_cate: $suma_multibyte_cate" 
    
    
    # char_count=$(printf "█ %-${mul}s | %-${mul2}s$ulimate_space | % ${mul3}s$ulimate_space1 █\n" "${dato}" "${dato1}" "${dato2}")
    
    
    
    ajuste_responsive() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$ulimate_space | % ${mul3}s$ulimate_space1 █\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive0() {
    # ajustar resposive a cada columna
    for j in {1..301}; do
        medida=$((${#char_count} + $j))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $j))
            char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        fi

        medida=$((${#char_count} - $j))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $j))
            char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        fi   
    done
    }
    ajuste_responsive1() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1| % ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1| % ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive2() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s█\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive3() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive3_1() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text$spaces_text2| % ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text$spaces_text2| % ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive4() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text2| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text2| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive5() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    ajuste_responsive6() {
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 + $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                mul2=$(($mul2 - $j))
                char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
            fi   
        done
    }
    #ajuste_responsive
        
    : '
    Otros operadores numéricos útiles:
    -eq: Igual a (==).
    -ne: No igual a (!=).
    -lt: Menor que (<).
    -le: Menor o igual (<=).
    -gt: Mayor que (>).
    : '
    # char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
    if [[ "$ultimate" -eq 0 && "$ultimate1" -ge 1 && "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui1.1"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive5
        char_count=$(printf "█ %-${mul}s | %-${mul2}s |% ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        #char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text_p1| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s${COLOR_RESET}${COLOR_VERDE}$spaces_text1_p2█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -ge 1 ]] && [[ "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui1.2"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive2
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE}| ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -ge 1 && "$multibyte_text_count1" -eq 0 && "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui3"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive3
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}% ${mul3}s${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -ge 1 ]]; then
        echo "aqui3.1"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive2
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1_p2 |% ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        #char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text_p1| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE} |${COLOR_RESET}${COLOR_BLANCO}%${mul3}s${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -eq 1 && "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui4"
        echo "$spaces_text2"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1| % ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive1
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE}$spaces_text1| ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s${COLOR_RESET}${COLOR_VERDE}$spaces_text2█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -eq 0 ]] && [[ "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui4.1"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive0
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -eq 0 ]] && [[ "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui4.2"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive0
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -ge 1 ]] && [[ "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui5"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive0
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s$spaces_text1_p2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE}| ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -ge 1 && "$multibyte_text_count2" -eq 0 ]]; then
        echo "aqui5.1"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive0
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE}$spaces_text1| ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
    
    elif [[ "$ultimate" -eq 0 && "$ultimate1" -eq 0 && "$multibyte_text_count1" -eq 0 && "$multibyte_text_count2" -eq 0 ]]; then
        echo "aqui6"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive0
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        #char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text_p1| % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s $spaces_text_p1${COLOR_RESET}${COLOR_VERDE}|${COLOR_RESET}${COLOR_BLANCO}%${mul3}s ${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}")
        printf "%s\n" "${final}"
        continue
        
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -eq 0 ]]; then
        echo "aqui2"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1 | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1 | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s$spaces_text1${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}% ${mul3}s${COLOR_RESET}${COLOR_VERDE} █${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}") 
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -ge 1 && "$multibyte_text_count1" -ge 1 && "$multibyte_text_count2" -ge 1 ]]; then
        echo "aqui1"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s$spaces_text1${COLOR_RESET}${COLOR_VERDE}|${COLOR_RESET}${COLOR_BLANCO}% ${mul3}s$spaces_text2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}") 
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -ge 1 && "$multibyte_text_count1" -ge 1 && "$multibyte_text_count2" -eq 0 ]]; then
        echo "aquiulti"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text1|% ${mul3}s$spaces_text2█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s$spaces_text1${COLOR_RESET}${COLOR_VERDE}|${COLOR_RESET}${COLOR_BLANCO}% ${mul3}s$spaces_text2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}") 
        printf "%s\n" "${final}"
        continue
    elif [[ "$ultimate" -ge 1 && "$ultimate1" -ge 1 && "$multibyte_text_count1" -eq 0 && "$multibyte_text_count2" -ge 1 ]]; then
        echo "aquiultimate"
        char_count=$(printf "█ %-${mul}s | %-${mul2}s$spaces_text$spaces_text2 | % ${mul3}s █\n" "${dato}" "${dato1}" "${dato2}")
        ajuste_responsive3_1
        char_count=$(printf "█ %-${mul}s | %-${mul2}s | % ${mul3}s█\n" "${dato}" "${dato1}" "${dato2}")
        final=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}${COLOR_BLANCO}%-${mul}s${COLOR_RESET}${COLOR_VERDE} | ${COLOR_RESET}${COLOR_BLANCO}%-${mul2}s${COLOR_RESET}${COLOR_VERDE}$spaces_text2| ${COLOR_RESET}${COLOR_BLANCO}%${mul3}s$spaces_text1_p2${COLOR_RESET}${COLOR_VERDE}█${COLOR_RESET}\n" "${dato}" "${dato1}" "${dato2}") 
        printf "%s\n" "${final}"
        continue
    
    fi
    
    
    #printf "%s\n" "${final}"
done
printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')" 


size=$(tput cols)x$(tput lines)
printf "El tamaño de la terminal es:${size}\n"
# codigo para ajustar la pantalla 
# stty rows 30 columns 50

