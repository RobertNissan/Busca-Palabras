# Función para manejar submenús
mostrar_submenu() {
    tipo_tabla=$1

    while true; do
        clear
        python3 - "$tipo_tabla" <<EOF
import os
import sys

if len(sys.argv) < 2:
    print("Error: No se recibió una opción válida.")
    sys.exit(1)

opcion = sys.argv[1]

# Colores
verde = '\\x1b[1;32m'
blanco = '\\x1b[1;37m'
reset = '\\x1b[1;0m'

def tabla_proyect(lista_app):
    table_width = os.get_terminal_size().columns
    n1 = int(0.1 * table_width)  # Ancho de ID
    n2 = int(0.75 * table_width)  # Ancho de NOMBRE
    n3 = int(0.17 * table_width)  # Ancho de STATUS

    ID = '[ID]'
    NOMBRE = 'OPCIÓN DISPONIBLE'
    STATUS = 'ESTADO'
    row_str = f"{verde}█{ID.center(n1)}┃{NOMBRE.ljust(n2)}┃{STATUS.ljust(n3)}█"

    long = len(row_str)
    for longitud in range(1, 399):
        medida = long - longitud
        if medida == table_width:
            n2 -= longitud
            break
        else:
            medida = long + longitud
            if medida == table_width:
                n2 += longitud
                break
    
    # Cabecera
    fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {blanco}{NOMBRE.ljust(n2)} {verde} ┃ {blanco}{STATUS.ljust(n3)}{verde} █{reset}"
    linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
    separador = f"{verde}█" + "═" * (table_width - 2) + "█" + f"{reset}"

    print(linea_superior)
    print(fila_contenido)
    print(separador)

    # Contenido de la tabla
    total_filas = len(lista_app)
    for i, fila in enumerate(lista_app):
        #id_ = f"[{fila[0]}]"
        id_ = f"[{fila[0]:02d}]" # Formatear el ID a dos dígitos
        name = fila[1]
        status = fila[2]

        row_str = f"{verde}█ {blanco}{id_.center(n1)} {verde}┃ {blanco}{name.ljust(n2)} {verde} ┃ {blanco}{status.ljust(n3)}{verde} █{reset}"
        print(row_str)

        if i < total_filas - 1:
            print(separador)

    # Cierre
    cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
    print(cierre)

# Ejemplo de datos: ID, NOMBRE, STATUS
datos = [
    (1, "Aplicación A", "Activo"),
    (2, "Aplicación B", "Inactivo"),
    (3, "Aplicación C", "En proceso")
]

tabla_proyect(datos)
EOF
        read -p "Presiona [Enter] para continuar..."
    done
}
mostrar_submenu
