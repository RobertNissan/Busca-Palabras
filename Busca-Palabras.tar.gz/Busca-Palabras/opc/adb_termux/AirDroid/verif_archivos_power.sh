#!/bin/bash

# Length: 1308417123 (1.2G) [application/zip]
# Saving to: ‘Modern_Combat_4_Zero_Hour.zip’

# Variable global para rastrear archivos en proceso
archivos_temporales=()
archivos_temporales1=()

# Función para eliminar archivos en el dispositivo si el proceso se interrumpe
limpiar_archivos() {
    if [[ -n "${archivos_temporales[@]}" ]]; then
        echo -e "\nLimpieza de archivos en proceso..."
        # Extraer el identificador del emulador (último elemento)
        dispositivo="${archivos_temporales[-1]}" 2>/dev/null
        # Eliminar archivos reales, no el emulador
        for archivo in "${archivos_temporales[@]}"; do
            if [[ "$archivo" != "$dispositivo" ]]; then
                echo "Eliminando $archivo en el dispositivo $dispositivo..."
                adb -s "$dispositivo" shell rm -f "$archivo"
            fi
        done    
        echo "Limpieza completada."
    else
        echo -e "\nLimpieza de archivos en proceso..."
        # Extraer el identificador del emulador (último elemento)
        # dispositivo="${archivos_temporales1[-1]}"
        # Eliminar archivos reales, no el emulador
        for archivo in "${archivos_temporales1[@]}"; do
            if [[ "$archivo" != "$dispositivo" ]]; then
                echo "Eliminando $archivo en el dispositivo $dispositivo..."
                rm -rf "$archivo"
            fi
        done    
        echo "Limpieza completada."
    fi
}

# Función para manejar señales de interrupción (Ctrl+C, Ctrl+Z, etc.)
trap_handler() {
    echo -e "\nProceso interrumpido por el usuario."
    limpiar_archivos
    archivos_temporales=()
    archivos_temporales1=()
    exit 1
}
# Asignar el manejador a las señales SIGINT (Ctrl+C) y SIGTSTP (Ctrl+Z)
trap 'trap_handler' SIGINT SIGTSTP


# Función para descargar y descomprimir archivos
descargar_archivo_mediafire() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    local conect_internet="$4"
    local ruta_destino_zip="$5"

    if [[ "$conect_internet" == 'true' ]]; then
        # Descargar el archivo
        echo -e "\n${YELLOW}Descargando${NC}: ${archivo_zip}"
        # Descargar simulando un navegador real
        wget --header="User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" \
             --header="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" \
             --header="Accept-Language: en-US,en;q=0.5" \
             --header="Connection: keep-alive" \
             --max-redirect=20 \
             -O file "$url" >/dev/null 2>&1
        # curl -O $url
        link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
        rm -rf file
        cd "${destino}"
        # wget --no-check-certificate ${link}
        # wget --spider --server-response "${link}" 2>&1 | awk '/Length:/ {print $0}'
        # Usa wget --spider para simular la descarga y obtener solo la cabecera sin descargar el archivo.
        # Extrae y muestra solo la línea que contiene el tamaño (Length:).
        wget --spider --server-response "${link}" 2>&1 | awk '/Length:/ {print $0}'
        # Descarga el archivo mostrando solo la barra de progreso sin mensajes extra.
        archivos_temporales1=("${archivo_zip}" "$adb_conectado")
        wget --no-check-certificate --quiet --show-progress -O "${archivo_zip}" "${link}"
        archivos_temporales1=()
        echo -e "${YELLOW}Descomprimiendo archivo descargado...${NC}"
        # unzip "${archivo_zip}"
        archivos_temporales1=("${ruta_destino_zip}" "$adb_conectado")
        7z x "${archivo_zip}"
        archivos_temporales1=()
        # rm -rf "${archivo_zip}"
        echo -e "${YELLOW}Descarga y extracción completadas en:\n${GREEN}${destino}/${NC}"
        cd - > /dev/null
        read -n 1 -p "Presione cualquier tecla para continuar!"
        return
    else
        echo -e "${RED}No hay conexión a internet para descargar el archivo${NC}!!!.\n"
        read -n 1 -p "Presione cualquier tecla para continuar!"
        return
    fi
}

# Verifica el estado del dispositivo conectado a ADB
verificar_estado_adb() {
    local ip="$1"
    local adb_output package="$2"
    local connected_devices estado_dispositivo

    adb_output=$(adb devices -l 2>/dev/null)
    connected_devices=$(echo "$adb_output" | awk '$2 == "device" {print $1}')

    if [[ -z "$connected_devices" ]]; then
        adb_conectado="$estado_dispositivo"  # Limpiar la variable global si no hay dispositivos
        return 1
    fi

    if [[ -n "$ip" ]]; then
        estado_dispositivo=$(echo "$connected_devices" | grep -Ei "${ip}:[0-9]+|emulator-5554" | head -n 1)
    fi

    if [[ -z "$estado_dispositivo" ]]; then
        estado_dispositivo=$(echo "$connected_devices" | grep -Ei "${ip}:[0-9]+|emulator-5554" | head -n 1)
        echo "$estado_dispositivo"
        return
    fi

    if [[ -n "$estado_dispositivo" && $(adb -s "$estado_dispositivo" shell echo "ping" > /dev/null 2>&1; echo $?) -eq 0 ]]; then
        adb_conectado="$estado_dispositivo"
        echo "$estado_dispositivo"
        return
    else
        echo ""
        return 1
    fi
}

verificar_archivos() {
    local archivo_zip="$1"
    local tamanio_zip_esperado="$2"
    if [[ -f "$archivo_zip" ]]; then
        local tamanio_archivo
        tamanio_archivo=$(stat --format=%s "$archivo_zip")
        if [[ "$tamanio_archivo" -eq "$tamanio_zip_esperado" ]]; then
            echo "true"
            return 0
        else
            echo "false"
            rm -rf "$archivo_zip" >/dev/null 2>&1
            return 1
        fi
    else
        echo "false"
        return 1
    fi
}

verificar_archivos_adb() {
    local archivo_zip="$1"
    local tamanio_zip_esperado="$2"
    # Ejecutar comandos en el dispositivo usando ADB
    local resultado
    resultado=$(adb -s "$adb_conectado" shell <<EOF
        if [[ -f "$archivo_zip" ]]; then
            tamanio_archivo=\$(stat -c %s "$archivo_zip" 2>/dev/null)
            if [[ "\$tamanio_archivo" -eq "$tamanio_zip_esperado" ]]; then
                echo "true"
                return 0
            else
                rm -rf "$archivo_zip"
                echo "false"
                return 0
            fi
        else
            echo "false"
            return 0
        fi
EOF
    )

    echo "$resultado"
    [[ "$resultado" == "true" ]]
}
verificar_varios_archivos() {
    declare -n archivos_ref="$1"  # Referencia a la variable asociativa
    for archivo in "${!archivos_ref[@]}"; do
        tamanio_esperado="${archivos_ref[$archivo]}"
        if [[ $(verificar_archivos "$archivo" "$tamanio_esperado") == "true" ]]; then
            echo "true"
        else
            echo "false"
            rm -rf "$archivo" >/dev/null 2>&1
            # echo "Error: Archivo $archivo es inválido o no existe."
            break
        fi
    done
}


verificar_app_instalada_adb() {
    local package="$1"
    local adb_conectado="$2"
    if adb -s "$adb_conectado" shell pm list packages | grep -q "^package:${package}$"; then
        echo 'true'
        # return 1  # La aplicación está instalada...
    else
        # echo -e "${YELLOW}La aplicación no está instalada.${NC}"
        echo 'false'
        # return 1
    fi
}

verificar_app_instalada_cmd() {
    local paquete="$1"
    local paquetes_instalados
    paquetes_instalados=$(cmd package list packages | cut -d: -f2)
    if echo "$paquetes_instalados" | grep -q "^$paquete$"; then
        echo "true"
    else
        echo "false"
    fi
}

verif_integridad_apk() {
    local archivo_path="$1"
    local tamanio_apk_esperado="$2"
    tamanio_archivo=$(stat --format="%s" "$archivo_path" 2>/dev/null)
    # Si la integridad no responde bien, entonces solo tomamos el tamaño.
    if [[ "$tamanio_archivo" -ne "$tamanio_apk_esperado" ]]; then
    # if apksigner verify --verbose --print-certs "$archivo_path" 2>&1 | grep -qi "Exception\|Malformed" && [[ "$tamanio_archivo" -ne "$tamanio_apk_esperado" ]]; then
        # echo "Error: El archivo APK está corrupto o no es válido."
        echo 'false' 
        rm -rf "$archivo_path" >/dev/null 2>&1
    elif [[ "$tamanio_archivo" -eq "$tamanio_apk_esperado" ]]; then
        # echo "El archivo APK es válido."
        echo 'true'
    fi
}

instalar_apk() {
    local apk_path="$1"
    local apk_instalado="$2"
    local integridad_apk="$3"
    local adb_conectado="$4"
    echo "Instalando APK desde $apk_path"
    if [[ -n "$adb_conectado" && -f "$apk_path" && "$apk_instalado" == 'false' && "$integridad_apk" == "true" ]]; then
        adb -s "${adb_conectado}" install "${apk_path}" > /dev/null
        if [[ $? -eq 0 ]]; then
            echo -e "${GREEN}Instalación completada${NC}.\n"
            apk_instalado='true'
            return 0
        else
            echo "Error: La instalación falló y la app no está instalada."
            apk_instalado='false'
            return 0
        fi
    fi
}
            
procesar_archivo_game_android() {
    local paquete_app="$1"
    local destino_dir="$2"
    declare -n zip_apk="$3"
    local ruta_destino_zip_apk="$4"
    declare -n archivo_path="$5"
    declare -n archivo_zip="$6"
    declare -n archivos_obb_ref="$7"
    local ruta_destino_obb="$8"
    declare -n archivo_zip_obb="$9"
    local adb_conectado="${10}"
    local conect_internet="${11}"
    local file_id1="${12}"
    local file_id2="${13}"
    
    RUTA_ARCHIVO="${!zip_apk[@]}"
    echo "Ruta del archivo zip apk: $RUTA_ARCHIVO"
    
    echo "destino_dir: ${destino_dir}"
    echo "ruta_destino_obb: ${ruta_destino_obb}"
    echo "ruta_destino_zip_apk: ${ruta_destino_zip_apk}"
    
    adb_conectado=$(verificar_estado_adb "$adb_conectado") 2>/dev/null
    echo "adb_conectado: $adb_conectado"
    
    verif_instal() {
        if [[ -n "$adb_conectado" ]]; then
           # echo "Verificar si está o no instalado usando adb si está conectado..."
            apk_instalado=$(verificar_app_instalada_adb "$paquete_app" "$adb_conectado") >/dev/null
        else
            # echo "Verificar si está o no instalado usando cmd..."
            apk_instalado=$(verificar_app_instalada_cmd "$paquete_app")
        fi
        echo "$apk_instalado"
    }
    verif_instal > /dev/null
    echo "apk_instalado: $apk_instalado"
    integridad_apk=$(verificar_varios_archivos archivo_path)
    echo "integridad_apk: $integridad_apk"
    integridad_zip_apk=$(verificar_varios_archivos zip_apk)
    echo "integridad_zip_apk: $integridad_zip_apk"
    integridad_zip_file=$(verificar_varios_archivos archivo_zip)
    echo "integridad_zip_file: $integridad_zip_file"
    integridad_archivo_zip_obb=$(verificar_varios_archivos archivo_zip_obb)
    echo "integridad_archivo_zip_obb: $integridad_archivo_zip_obb"
    
    if [[ -n "$adb_conectado" ]]; then
        local id_obb=1
        for archivo in "${!archivos_obb_ref[@]}"; do
            tamanio_obb_esperado="${archivos_obb_ref[$archivo]}"
            # echo "$id_obb"
            # echo "$archivo $tamanio_obb_esperado"
            # read
            # Comprobar si el archivo existe y tiene el tamaño correcto
            if [[ $(verificar_archivos_adb "$archivo" "$tamanio_obb_esperado") == "true" ]]; then
                # echo "Archivo $archivo es válido."
                integridad_archivo_obb='true'
                continue
            else
                # ruta_sin_archivo=$(dirname "$archivo")
                # adb -s "$adb_conectado" shell rm -rf "$ruta_sin_archivo"
                integridad_archivo_obb='false'
                # echo "Error: Archivo $archivo es inválido o no existe."
                break
            fi
            ((id_obb++))
        done
    fi
    echo "integridad_archivo_obb: $integridad_archivo_obb"
    
    # Obtener solo el nombre del archivo y luego la extensión
    # capturar solo el archivo sin su ruta
    nombre_archivo=$(basename "${!archivo_path[@]}")
    # capturar solo la extensión del archivo
    extension="${nombre_archivo##*.}"
    # echo "nombre_archivo: $nombre_archivo"
    
    # Si existe el apk o rom, toma la extensión.
    if [ -f "${!archivo_path[@]}" ]; then
        # echo "Nombre de archivo_path: $archivo_path"
        # toma la extensión del archivo a analizar.
        nombre_archivo=$(basename "${!archivo_path[@]}")
        extension="${nombre_archivo##*.}"
        # echo "extension: $extension"
    fi
    
    echo -e "\nEmpezamos"
    
    if [[ -z "$adb_conectado" && "$apk_instalado" == 'true' ]]; then
        echo -e "${GREEN}${nombre_archivo} ya está instalada.${NC}"
        if [[ -n "$adb_conectado" && "$integridad_archivo_zip_obb" == 'true' ]]; then
            echo "Datos obb: ${!archivo_zip_obb[@]}"
        fi
        read -n 1 -p "Presione cualquier tecla para continuar!"
    fi
    
    if [[ -n "$adb_conectado" && "$apk_instalado" == 'true' ]]; then
        echo -e "${GREEN}${nombre_archivo} ya está instalada.${NC}"
        # Si los OBB no están, pero el ZIP OBB sí está, descomprimirlo
        if [[ "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'true' ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
            archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}"
                archivos_temporales=()
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip_obb[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip_obb[@]}"
                archivos_temporales=()
            fi
        # Si los OBB no están y el ZIP OBB tampoco, pero el ZIP principal sí está → Descomprimir el ZIP principal
        elif [[ "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'false' && "$integridad_zip_file" == 'true' ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip[@]}...${NC}"
            archivos_temporales=("${!archivo_zip_obb[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip[@]}" -d "$destino_dir"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}"
                archivos_temporales=()
                # Ahora verificar si el ZIP OBB fue extraído correctamente
                if [[ -f "${!archivo_zip_obb[@]}" ]]; then
                    echo -e "${YELLOW}Ahora descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
                    archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
                    if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                        echo -e "${GREEN}Descompresión de OBB exitosa.${NC}"
                        archivos_temporales=()
                    else
                        echo -e "${RED}Error al descomprimir los OBB, eliminando ZIP OBB...${NC}"
                        rm -f "${!archivo_zip_obb[@]}"
                        archivos_temporales=()
                    fi
                else
                    echo -e "${RED}El ZIP OBB no se extrajo correctamente del ZIP principal.${NC}"
                    archivos_temporales=()
                fi
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip[@]}"
                archivos_temporales=()
            fi
        # Si nada está disponible, descargar el ZIP principal
        elif [[ "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'false' && "$integridad_zip_file" == 'false' ]]; then
            if [[ "$conect_internet" == "true" ]]; then 
                echo -e "${YELLOW}No se encontró ningún archivo necesario. Descargando ZIP principal...${NC}"
                descargar_archivo_mediafire "$file_id1" "${!archivo_zip[@]}" "$destino_dir" "$conect_internet" "$ruta_destino_zip_apk"
                echo -e "${GREEN}Descarga completa.${NC}"
            else
                echo -e "${RED}No hay conexión a internet y no se puede descargar el archivo.${NC}"
            fi
        fi
        read -n 1 -p "Presione cualquier tecla para continuar!"
    fi
    
    if [[ -n "$adb_conectado" && "$apk_instalado" == 'false' && "$integridad_apk" == 'false' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'true' && "$integridad_zip_apk" == 'true' ]]; then
        echo -e "\naqui2"
        echo -e "${YELLOW}Descomprimiendo ${!zip_apk[@]}...${NC}"
        7z x "${!zip_apk[@]}" -o"$ruta_destino_zip_apk"
        integridad_apk=$(verificar_varios_archivos archivo_path)
        instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
        if [[ -n "$adb_conectado" && $(verif_instal) == "true" ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
            archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}";archivos_temporales=()
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip_obb[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip_obb[@]}";archivos_temporales=()  # Eliminar archivo corrupto
            fi
        fi
        read -n 1 -p "Presione cualquier tecla para continuar!"
        
    elif [[ -n "$adb_conectado" && "$apk_instalado" == 'false' && "$integridad_apk" == 'false' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'true' && "$integridad_zip_apk" == 'false' ]]; then
        echo -e "\naqui3"
        # echo "Descargar el zip apk"
        descargar_archivo_mediafire "$file_id2" "${!zip_apk[@]}" "$ruta_destino_zip_apk" "$conect_internet"
        verif_instal
        integridad_apk=$(verificar_varios_archivos archivo_path)
        instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
        if [[ -n "$adb_conectado" && $(verif_instal) == "true" ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
            archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}";archivos_temporales=()
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip_obb[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip_obb[@]}";archivos_temporales=()  # Eliminar archivo corrupto
            fi
        fi
        read -n 1 -p "Presione cualquier tecla para continuar!"
        return
    fi
    
    if [[ -n "$adb_conectado" && "$apk_instalado" == 'false' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'false' && "$integridad_zip_file" == 'false' ]]; then
        echo "último 00"
        descargar_archivo_mediafire "$file_id1" "${!archivo_zip[@]}" "$destino_dir" "$conect_internet" "$ruta_destino_zip_apk"
        verif_instal
        integridad_apk=$(verificar_varios_archivos archivo_path)
        instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
        if [[ -n "$adb_conectado" && $(verif_instal) == "true" ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
            archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}";archivos_temporales=()
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip_obb[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip_obb[@]}";archivos_temporales=()  # Eliminar archivo corrupto
            fi
        fi
    fi
    
    if [[ -n "$adb_conectado" && "$apk_instalado" == 'false' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'false' && "$integridad_zip_file" == 'true' ]]; then
        echo "último 01"
        echo -e "${YELLOW}Descomprimiendo ${!archivo_zip[@]}...${NC}"
        archivos_temporales=("${!archivo_zip_obb[@]}" "$adb_conectado")
        if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip[@]}" -d "$destino_dir"; then
            echo -e "${GREEN}Descompresión exitosa.${NC}"
            archivos_temporales=()
            verif_instal >/dev/null
            integridad_apk=$(verificar_varios_archivos archivo_path)
            instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
            # Ahora verificar si el ZIP OBB fue extraído correctamente
            if [[ $(verif_instal) == "true" && -f "${!archivo_zip_obb[@]}" ]]; then
                echo -e "${YELLOW}Ahora descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
                archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
                if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                    echo -e "${GREEN}Descompresión de OBB exitosa.${NC}"
                    archivos_temporales=()
                else
                    echo -e "${RED}Error al descomprimir los OBB, eliminando ZIP OBB...${NC}"
                    rm -f "${!archivo_zip_obb[@]}"
                    archivos_temporales=()
                fi
            else
                # echo -e "${RED}El ZIP OBB no se extrajo correctamente del ZIP principal.${NC}"
                archivos_temporales=()
            fi
        else
            echo -e "${RED}Error al descomprimir ${!archivo_zip[@]}, eliminando archivo...${NC}"
            rm -f "${!archivo_zip[@]}"
            archivos_temporales=()
        fi
        return
    fi
    
    if [[ -n "$adb_conectado" && $(verif_instal) == 'false' && "$integridad_apk" == 'true' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'false' && "$integridad_zip_file" == 'true' ]]; then
        echo "último final"
        verif_instal
        integridad_apk=$(verificar_varios_archivos archivo_path)
        instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
        echo -e "${YELLOW}Descomprimiendo ${!archivo_zip[@]}...${NC}"
        archivos_temporales=("${!archivo_zip_obb[@]}" "$adb_conectado")
        if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip[@]}" -d "$destino_dir"; then
            echo -e "${GREEN}Descompresión exitosa.${NC}"
            archivos_temporales=()
            # Ahora verificar si el ZIP OBB fue extraído correctamente
            if [[ -f "${!archivo_zip_obb[@]}" ]]; then
                echo -e "${YELLOW}Ahora descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
                archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
                if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                    echo -e "${GREEN}Descompresión de OBB exitosa.${NC}"
                    archivos_temporales=()
                else
                    echo -e "${RED}Error al descomprimir los OBB, eliminando ZIP OBB...${NC}"
                    rm -f "${!archivo_zip_obb[@]}"
                    archivos_temporales=()
                fi
            else
                echo -e "${RED}El ZIP OBB no se extrajo correctamente del ZIP principal.${NC}"
                archivos_temporales=()
            fi
        else
            echo -e "${RED}Error al descomprimir ${!archivo_zip[@]}, eliminando archivo...${NC}"
            rm -f "${!archivo_zip[@]}"
            archivos_temporales=()
        fi
    fi
    
    if [[ -n "$adb_conectado" && "$apk_instalado" == 'false' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'true' ]]; then
        echo "último final obb"
        verif_instal
        integridad_apk=$(verificar_varios_archivos archivo_path)
        instalar_apk "${!archivo_path[@]}" "${apk_instalado}" "${integridad_apk}" "${adb_conectado}"
        # echo -e "${GREEN}${nombre_archivo} ya está instalada.${NC}"
        # Si los OBB no están, pero el ZIP OBB sí está, descomprimirlo
        if [[ $(verif_instal) == 'true' && "$integridad_archivo_obb" == 'false' && "$integridad_archivo_zip_obb" == 'true' ]]; then
            echo -e "${YELLOW}Descomprimiendo ${!archivo_zip_obb[@]}...${NC}"
            archivos_temporales=("${!archivos_obb_ref[@]}" "$adb_conectado")
            if adb -s "$adb_conectado" shell unzip -o "${!archivo_zip_obb[@]}" -d "$ruta_destino_obb"; then
                echo -e "${GREEN}Descompresión exitosa.${NC}"
                archivos_temporales=()
            else
                echo -e "${RED}Error al descomprimir ${!archivo_zip_obb[@]}, eliminando archivo...${NC}"
                rm -f "${!archivo_zip_obb[@]}"
                archivos_temporales=()
            fi
        fi
    fi
    # echo -e "pausa";read
}

# Variables globales
CONECT_INTERNET="true"
ADB_CONECTADO="192.168.20.89:5555"
PACK_APP='com.gameloft.android.ANMP.GloftM4HM'
RUTA_DESTINO='/sdcard/Download/Games/Modern_Combat'
RUTA_DESTINO_ZIP_APK='/sdcard/Download/Games/Modern_Combat/Modern_Combat_4_Zero_Hour'
declare -A ARCHIVO_ZIP=(["$RUTA_DESTINO/Modern_Combat_4_Zero_Hour.zip"]=1308417123)
declare -A ZIP_APK=(["$RUTA_DESTINO/Modern_Combat_4_Zero_Hour/mc4.zip"]=72251140)
declare -A ARCHIVO_PATH=(["$RUTA_DESTINO/Modern_Combat_4_Zero_Hour/Modern-Combat-4-Zero-Hour-v1-2-2e-Low.apk"]=36696935)
RUTA_DESTINO_OBB='/sdcard/Android/obb'
declare -A ARCHIVOS_OBB=(["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM4HM/main.1100.com.gameloft.android.ANMP.GloftM4HM.obb"]=2052015324 ["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM4HM/patch.12222.com.gameloft.android.ANMP.GloftM4HM.obb"]=15093838)
declare -A ARCHIVO_ZIP_OBB=(["$RUTA_DESTINO/Modern_Combat_4_Zero_Hour/Modern_Combat_4_obb.zip"]=1241337144)
URL1='https://www.mediafire.com/file/75vpclhv3m97xzk/Modern_Combat_4_Zero_Hour.zip/file'
URL2='https://www.mediafire.com/file/5gpfugpegtd8buc/mc4.zip/file'

procesar_archivo_game_android  "$PACK_APP" "$RUTA_DESTINO" ZIP_APK "$RUTA_DESTINO_ZIP_APK" ARCHIVO_PATH ARCHIVO_ZIP ARCHIVOS_OBB "$RUTA_DESTINO_OBB" ARCHIVO_ZIP_OBB "$ADB_CONECTADO" "$CONECT_INTERNET" "$URL1" "$URL2"
                                                                       #1                      #2                     #3                                #4                                  #5                       #6                        #7                                #8                                  #9                             #10                                  #11                     #12        #13









