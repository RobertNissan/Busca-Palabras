#!/bin/bash

# Colores
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

# Obtener la ip wlan0 si está disponible...
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

####### FUNCIONES DE JUSTIFICACION DE TEXTO #######
# Función para eliminar secuencias ANSI (como colores)
strip_ansi() {
    # Usar tr para eliminar caracteres ANSI, más rápido que sed
    echo -e "$1" | tr -d '\033' | sed 's/\[[0-9;]*m//g'
}

# Función para justificar texto respetando caracteres UTF-8 y espacios
justify_text() {
    local width=$(tput cols) # Ancho de la terminal
    local text="$1"
    local justified=""
    local line=""
    local leading_spaces=""
    local adjusted_width

    while IFS= read -r line || [[ -n $line ]]; do
        leading_spaces="${line%%[! ]*}" # Obtener los espacios iniciales
        adjusted_width=$((width - ${#leading_spaces}))
        line="${line#"${leading_spaces}"}" # Remover espacios iniciales

        if [[ $(strip_ansi "$line" | wc -m) -le $adjusted_width ]]; then
            justified+="$leading_spaces$line\n"
        else
            local words=($line)
            local current_line=""
            for word in "${words[@]}"; do
                # Solo calcular la longitud una vez por palabra
                if [[ $(strip_ansi "$current_line $word" | wc -m) -le $adjusted_width ]]; then
                    current_line+="$word "
                else
                    justified+="$leading_spaces$(justify_line "$current_line" "$adjusted_width")\n"
                    current_line="$word "
                fi
            done
            justified+="$leading_spaces$current_line\n"
        fi
    done <<< "$text"

    printf "%b" "$justified"
}

# Función para justificar una línea
justify_line() {
    local line="$1"
    local width="$2"
    local spaces_needed=$((width - $(strip_ansi "$line" | wc -m)))
    local words=($line)
    local space_count=$(( ${#words[@]} - 1 ))

    if (( space_count == 0 )); then
        echo "$line"
        return
    fi

    local extra_spaces=$(( spaces_needed / space_count ))
    local remainder_spaces=$(( spaces_needed % space_count ))
    local justified_line=""

    # Usar un bucle para construir la línea justificada
    for i in "${!words[@]}"; do
        justified_line+="${words[i]}"
        if (( i < space_count )); then
            justified_line+="$(printf ' %.0s' $(seq 1 $((extra_spaces + (i < remainder_spaces ? 1 : 0)))))"
        fi
    done

    echo "$justified_line"
}

# Función para imprimir texto con colores
print_color() {
    local color_code
    case $1 in
        red) color_code="${RED}" ;;
        green) color_code="${GREEN}" ;;
        yellow) color_code="${YELLOW}" ;;
        blue) color_code="${BLUE}" ;;
        cyan) color_code="${CYAN}" ;;
        magenta) color_code="${MAGENTA}" ;;
        white) color_code="${WHITE}" ;;
        *) color_code="" ;;
    esac
    # Imprimir el texto con el color
    echo -e "${color_code}$2${NC}"
}

# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}
####### FIN FUNCIONES DE JUSTIFICACION DE TEXTO #######


#######FUNCIONES_DE_CONEXION#######
disponible_adb='false'

# Función para restablecer adb y obtener el emulator-5554
seleccionar_dispositivo() {
    dispositivo_conectado="$1"
    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    
    for i in {1..10}; do
        if adb devices | grep -q "device$"; then
            break
        fi
        sleep 0.5
    done
    
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        disponible_adb='true'
    fi
    
    # Reconectar el dispositivo despues de haber establecido adb
    conn=$(adb connect "$dispositivo_conectado")
    # Rectificar la conexión. Si no está establecida, entonces volver a empareja, sino muestra el menú modificado...
    if [[ "$conn" == "failed"* ]]; then
        echo "ok" >/dev/null 2>&1
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados...
        exit 1
    else
        # Mostrar el menú inicial modificado...
        menu_principal 2>/dev/null || {
            # echo "La función no está definida aún. Recargando el script..."
            source "$0"
            menu_principal
        }

        return
    fi
}

function connect {
    code="$1"
    local capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        print_color green "$(justify_text "Conectando al puerto principal adb. ¡¡¡No cierres las ventanas!!!.\nPor favor, espere...")"
    fi
    
    # Obtener la ip wlan0 si está disponible...
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed  # Asegúrate de importar ambas clases

try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap

# Dirección IP objetivo
ip_objetivo = "$ip_objetivo"
num_threads = 10  # Número de hilos

# Manejo de señales (Ctrl+C y Ctrl+Z)
def signal_handler(signum, frame):
    print("\nEscaneo interrumpido.")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)  # Ctrl+C
signal.signal(signal.SIGTSTP, signal_handler)  # Ctrl+Z

# Función para escanear puertos
def scan_ports(start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    open_ports = []

    # Ajusta el comando con opciones adicionales
    arguments = f'-p {port_range} -Pn -T5 --max-retries 3 --max-rtt-timeout 100ms'

    try:
        # result = nm.scan(ip_objetivo, arguments=f'-p {port_range} -Pn -T4')
        result = nm.scan(ip_objetivo, arguments=arguments)
        if ip_objetivo in result['scan']:
            if 'tcp' in result['scan'][ip_objetivo]:
                for port, details in result['scan'][ip_objetivo]['tcp'].items():
                    if details['state'] == 'open':
                        open_ports.append(port)
    except Exception as e:
        print(f"Error escaneando puertos: {e}")

    return open_ports

# División del rango de puertos
step = (65535 - 10000 + 1) // num_threads
port_ranges = [(i, min(i + step - 1, 65535)) for i in range(10000, 65536, step)]

# Ejecución con hilos
open_ports = []
with ThreadPoolExecutor(max_workers=num_threads) as executor:
    futures = {executor.submit(scan_ports, start, end): (start, end) for start, end in port_ranges}
    for future in as_completed(futures):
        open_ports.extend(future.result())

# Mostrar puertos abiertos
print(" ".join(map(str, sorted(set(open_ports)))))
EOF
)
    # Capturar los puertos disponibles del script python.
    ports_output=$(python -c "$python_script")
    
    # Función para habilitar ADB permanente
    habilitar_adb_permanente() {
        DISPOSITIVO="$1"
        # Verificar si el dispositivo tiene root
        if su -c "id" > /dev/null 2>&1; then
            print_color green "$(justify_text "\n${NC}[${GREEN}Tienes acceso root${NC}].")"
            ROOT_PERMISSIONS="true"
        else
            echo "No tienes acceso root" >/dev/null 2>&1
            ROOT_PERMISSIONS="false"
        fi
        # dar dar a la tabla globa de setedit
        adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
        if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
            print_color yellow "$(justify_text 'Habilitando ADB permanente con root...')"
            # Estos 2 comandos son los que hacen persistente aún después de reiniciar en el puerto 5555.
            adb -s "$DISPOSITIVO" shell su -c "setprop persist.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "setprop service.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "resetprop ro.adb.secure 0"
            adb -s "$DISPOSITIVO" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado permanentemente incluso después del reinicio.')"
        else
            print_color yellow "$(justify_text '\nHabilitando ADB temporal (sin root)...')"
            adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado hasta el próximo reinicio.')"
        fi
    }
    
    # echo "code: $code"
    lista_port_adb=()
    # Si hay puertos disponibles, procesar los de 5 dígitos en una lista...
    if [[ -n "$ports_output" ]]; then
        echo -e "Puertos abiertos detectados:\n$ports_output"
        for port in $ports_output; do
            # Verificar si el puerto es un número de 5 dígitos
            if [[ $port =~ ^[0-9]{5}$ ]]; then
                lista_port_adb+=("$port")
            fi
        done
    fi
    
    : '
    # Prueba de mas puertos...
    # Mostrar todos los puertos detectados
    echo -e "\nPuertos detectados en lista_port_adb inicial:\n${lista_port_adb[@]}"
    # Guardar los puertos iniciales
    puertos_iniciales=("${lista_port_adb[@]}")
    # Lista ampliada de puertos para probar
    lista_port_adb+=(55555 50638 58039 56040 55041 56042 50443 50344 50345 53046 54047)
    # Eliminar puertos iniciales duplicados antes de moverlos al final
    for port in "${puertos_iniciales[@]}"; do
        lista_port_adb=($(printf "%s\n" "${lista_port_adb[@]}" | grep -v "^$port$"))
    done
    # Mover los puertos iniciales al final
    lista_port_adb+=("${puertos_iniciales[@]}")
    # Mostrar todos los puertos almacenados después de reorganizar
    echo -e "\nLista completa de puertos para probar:\n${lista_port_adb[@]}"
    : '
    
    # Mostrar todos los puertos almacenados
    # echo -e "\nLista_port_adb:\n${lista_port_adb[@]}"
    
    exito="false"
    # Iterar sobre los puertos en lista_port_adb
    for port in "${lista_port_adb[@]}"; do
        # echo "Procesando puerto: $port"
        # Intentar emparejar, y redireccionar los errore sl vacío.
        adb pair "${ip_objetivo}:${port}" "${code}" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Emparejamiento exitoso con${NC}: $ip_objetivo:$port"
            exito="true"
            port_pair="${port}"
            # Reconstruir la lista sin el puerto que se usó para emparejar...
            lista_port_adb=($(printf "%s\n" "${lista_port_adb[@]}" | grep -v "^$port_pair$"))
            break
        else
            echo -e "Falló el emparejamiento con $ip_objetivo:$port." > /dev/null
            continue
        fi
    done
    
    agilizar() {
    local dispositivo_5555="$1"
        for i in {1..10}; do
            connect=$(adb connect "${dispositivo_5555}")
            # Rectificar la conexión. Si no está establecida, entonces volver a empareja, sino muestra el menú modificado...
            if [[ "$connect" == *"connected"* ]]; then
                return
            else
                continue
            fi
            sleep 0.5
        done
        echo -e "${RED}No se pudo conectar a $1 después de 10 intentos.${NC}"
        return
    }

    if [[ "$exito" == 'true' ]]; then
        echo -e "${YELLOW}Conectando adb con el puerto disponible...${NC}"
        for port_connect in "${lista_port_adb[@]}"; do
            # Intentar conectar
            verif_con=$(adb connect "${ip_objetivo}:${port_connect}" 2>/dev/null)
            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}Conexión exitosa con${NC}: ${ip_objetivo}:${port_connect}"
            
                # Intentar reiniciar el modo TCP en el puerto 5555
                if adb -s "${ip_objetivo}:${port_connect}" tcpip 5555 >/dev/null 2>&1; then
                    echo -e "${YELLOW}Reiniciando el modo TCP al puerto 5555...${NC}"
                    # sleep 5  # Esperar para asegurarse de que el dispositivo esté listo.
                    # Intentar conectar al puerto 5555
                    if agilizar "${ip_objetivo}:5555"; then
                        echo -e "${GREEN}Conexión establecida en ${NC}${ip_objetivo}:5555"
                        habilitar_adb_permanente "${ip_objetivo}:5555"
                        adb disconnect "${ip_objetivo}:${port_connect}" >/dev/null 2>&1
                        seleccionar_dispositivo "${ip_objetivo}:5555"
                        exit 0
                    else
                        echo -e "${RED}Fallo al conectar a ${ip_objetivo}:5555.${NC}"
                    fi
                else
                    echo -e "${RED}Error al reiniciar el modo TCP en el puerto 5555.${NC}"
                fi
            else
                echo -e "${RED}Conexión fallida con ${ip_objetivo}:${port_connect}${NC}" > /dev/null
                continue
            fi
            adb disconnect "${ip_objetivo}:${port_connect}" >/dev/null 2>&1
        done
    else
        echo -e "${RED}Falló el emparejamiento.${NC}"
        # Una función que necesita ser llamada antes de su definición
        # echo "Intentando llamar a menu_principal..."
        menu_principal 2>/dev/null || {
            # echo "La función no está definida aún. Recargando el script..."
            source "$0"
            menu_principal
        }


    fi
    local capp_adb='true'
    connect
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {
    # Obtener la IP de wlan0, si está disponible
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
    if [ -z "$ip" ]; then
        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    for i in {1..10}; do
        if adb devices | grep -q "device$"; then
            break
        fi
        sleep 0.5
    done
    adb_output=$(adb devices -l)
    # Elegir entre el emulador o la ip si hay alguno.
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip})" | head -n 1)
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$connected_devices"
    fi
 
    # Título e instrucciones justificados
    print_color red "$(justify_text 'Servidor adb, no encendido!!!')"
    print_color green "$(justify_text 'Siga las instrucciones:')"
    # Instrucciones para habilitar depuración USB
    print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb${NC}:")"
    print_color yellow "$(justify_text "${GREEN}1${NC}.$(generate_spaces 0)${YELLOW}Abre la aplicación${NC} [${GREEN}Configuración${NC}] ${YELLOW}en tu dispositivo Android${NC}.")"
    print_color yellow "$(justify_text "${GREEN}2${NC}. ${YELLOW}Ve a${NC} [${GREEN}Acerca del teléfono${NC} o ${GREEN}de la tablet${NC}].")"
    print_color yellow "$(justify_text "${GREEN}3${NC}.  ${YELLOW}Toca repetidamente${NC} [${GREEN}Número de compilación${NC}] ${YELLOW}hasta que se active el modo de desarrollador${NC}.")"
    print_color yellow "$(justify_text "${GREEN}4${NC}. ${YELLOW}Regresa al menú principal de [${GREEN}Configuración${NC}], ${YELLOW}busca y entra en${NC}: [${GREEN}Sistema${NC}].")"
    print_color yellow "$(justify_text "${GREEN}5${NC}. ${YELLOW} Ahora da click en: [${GREEN}Opciones avanzadas${NC}] ${YELLOW}y entra en [${GREEN}Opciones para desarrolladores${NC}].")"
    print_color yellow "$(justify_text "${GREEN}6${NC}. ${YELLOW}Habilita ${NC}[${GREEN}Depuración por USB${NC}].")"
    # Instrucciones para depuración inalámbrica
    print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra${NC}.")"
    print_color yellow "$(justify_text "${GREEN}7${NC}. ${YELLOW}Selecciona donde dice${NC}:")"
    print_color green "$(justify_text " Vincular dispositivo con código de sincronización${NC}")"
    print_color yellow "$(justify_text "  Selecciona ahora en:${NC}")"
    print_color green "$(justify_text "   Vincular con dispositivo${NC}")"
    print_color blue "$(justify_text "    Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")"
    print_color blue "$(justify_text "    Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345")"
    # Nota adicional
    print_color cyan "$(justify_text "Para hacer la conexión correctamente:")"
    print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: ${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC}).")"
    # Final
    print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")"
    
    echo -en "\n${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
    read code
    echo -en "${NC}"
    while [[ ! "${code}" =~ ^[0-9]{6}$ ]]; do
        echo -e "\n${RED}Error${NC}: Debes ingresar un código válido de 6 dígitos."
        echo -en "${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
        read code
        echo -en "${NC}"
    done
    
    # Cambios Dom 19/Ene/2025
    # Ejecutar emparejamiento y conexión...
    connect "${code}"
}


wlan0() {
    adb_conectado="$1"
    # echo "adb_conectado_wlan0: $adb_conectado"
    # Obtener la IP de wlan0, si está disponible
    ip0=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Si no se encuentra IP en wlan0, buscar una IP distinta que no sea 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi
    
    # Mostrar la IP de wlan0 si está disponible...
    if [ "$ip0" ]; then
        disponible_adb='true'
        adb_conectado='false'
        return
    # Mostrar otra IP si no se encontró en wlan0...
    elif [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}):\n${YELLOW}ip: ${NC}$ip1" #  > /dev/null
        disponible_adb='false'
        adb_conectado='false'
        return
    fi
}
verif_adb_conect() {
    # Capturar la ip del modem si acaso esta disponible...
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Obtener los dispositivos conectados por ADB.
    adb_output=$(adb devices -l)
    # echo $adb_output
    connected_devices=$(echo "$adb_output" | awk -v ip="$ip" '$2 == "device" {print $1}')
    # echo -e "\nDispositivos conectados:\n$connected_devices"

    # echo $connected_devices
    if [[ -n "$ip" ]]; then
        # Mostrar la IP local
        echo -e "\nIP local: $ip" > /dev/null
    fi

    # Buscar si hay un dispositivo con la ip: o el emulador-5554.
    ip_device=$(echo "$connected_devices" | grep -Ei "${ip}:[0-9]+|emulator-5554" | head -n 1)

    # echo "adb_conectado_ip_device: $ip_device"
    adb_conectado="${ip_device}"
    # Verificar, si se encontró algún dispositivo es porque $ip_device no esta vacia.
    if [[ -n "$ip_device" ]]; then
        # echo -e "${GREEN}Dispositivo conectado a adb 1${NC}: $ip_device"
        disponible_adb='false'
        adb_conectado="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        return 
    else
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0 "$adb_conectado"
    fi
}

# Función para verificar el tipo tipo de conexión...
verif_tipo_con() {
        # variable que verifica adb
        disponible_adb="false"
        # variable que verifica internet 
        conect_internet="false"
        # variable que verifica modem
        disponible_modem="false"
        ##############INICIO INTERFAZ################
        # Función para obtener la IP de una interfaz
        obtener_ip() {
            local interfaz=$1
            busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
        }
        # Comprobamos primero si wlan0 está disponible.
        iplocal=$(obtener_ip "wlan0")
        # Si no hay IP en wlan0, buscar en otras interfaces activas.
        if [ -z "$iplocal" ]; then
            echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null
            # Iterar sobre las interfaces activas y capturar la primera IP disponible.
            for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                iplocal=$(obtener_ip "$interfaz")
                ip=$(obtener_ip "$interfaz")
                # Si no capturó una interfaz, el bucle for sigue iterando.
                if [ ! -z "$iplocal" ]; then
                    # Si capturó una interfaz, detiene el bucle for.
                    echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null
                    break
                fi
            done
        else
            # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular).
            echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null
        fi
        # Si después de todas las comprobaciones no hay IP disponible
        if [ -z "$iplocal" ]; then
            echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null
        else
            ip="$iplocal"
        fi
        ############## FIN INTERFAZ################
        
        # Verificar si hay conexión externa (Internet)
        # x=$(curl -s ifconfig.me)
        # Archivo temporal para almacenar la salida de curl
        TEMP_FILE=$(mktemp)
        # Ejecutar curl en segundo plano y redirigir la salida a un archivo temporal
        curl -s ipinfo.io/ip > "$TEMP_FILE" &
        CURL_PID=$! # Capturar el PID del proceso en segundo plano
        # Verificar si se captura la IP en 10 intentos
        for ((i=1; i<=20; i++)); do
            x=$(cat "$TEMP_FILE") # Leer la salida del archivo temporal
            if [[ -n "$x" ]]; then
                echo "IP externa capturada: $x"
                break
            fi
            echo "Intento $i/10 fallido. Reintentando en 0.5 segundos..." >/dev/null
            sleep 0.5
        done
        if [ "$TEMP_FILE" ]; then
            rm -f "$TEMP_FILE" # Eliminar el archivo temporal
        fi
        ipexterna=$(echo "${x//[<>]/}")
        ipexterna=$(echo "${x}")

        ###########Zona WiFi Comprobar#########
        iplocalc=".${iplocal}"
        iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
        
        # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            if [[ "$iplocal" == "127.0.0.1" ]]; then
                echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                    ip=$(obtener_ip "$interfaz")
                    if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                        echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null
                        break
                    fi
                done
            else
                echo "Conexión a Internet activa. IP local: $ip" > /dev/null
            fi
        else
            ip="$iplocal"
            echo "No hay conexión a Internet." > /dev/null
        fi

        ###########Zona WiFi Fin#########
        
              
        wlan0_verif='false'    
        # Verificar el estado de wlan0 usando ifconfig
        es_wlan0=$(busybox ifconfig wlan0 2>/dev/null)
        if echo "${es_wlan0}" | grep -q "RUNNING" && echo "${es_wlan0}" | grep -q "inet "; then
            # echo "wlan0_verif: true"
            wlan0_verif='true'
            echo "wlan0 conectada a modem" > /dev/null 2>&1
        elif echo "${es_wlan0}" | grep -q "RUNNING"; then
            #echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        else
            # echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        fi
        
        # echo "ip $ip"
        # echo "iplocal: $iplocal"
        # echo "iplocalc: $iplocal"
        # echo "ipexterna: $ipexterna"
        # Si no está conectado a una red externa.
        if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
            ipexterna="html"
            disponible_modem="true"
            conect_internet="false"
            echo -e "\n${RED}No hay conexión wi-fi, datos ni ${NC}(${RED}zona wi-fi${NC})${nc}...\n" # > /dev/null 2>&1
            adb_conectado="$adb_conectado_ip_device"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi
  
        
        # Hay internet datos
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ ! "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Tienes internet para compartir datos por ${NC}(${GREEN}zona wi-fi${NC}).\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="true"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
                # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        # No hay internet pero está la zona wi-fi activa.
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Conexion por ${NC}(${GREEN}Zona WI-FI${NC}) ${GREEN}y no tienes internet,\npero puedes otorgar conexión${NC}.\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="false"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
        
        # Verificar si ipexterna contiene una dirección IP válida.
        # Tienes datos de internet y la zona wi-fi activa.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
            echo -e "\n${GREEN}Tienes datos de internet y la ${NC}(${GREEN}zona wi-fi${NC}) ${GREEN}activa${NC}.\n(${GREEN}Compartiendo datos${NC})\n"
            disponible_modem="true"
            disponible_adb="false"
            adb_conectado="$adb_conectado_ip_device"
            conect_internet="true"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi
        
    if [[ "$disponible_modem" == "false" ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo -e "\n${GREEN}Tienes internet wi-fi del Módem${NC}.\n" # >/dev/null 2>&1
        conect_internet="true"
        disponible_adb="true"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
    fi
    
    # No hay internet pero estás conectado a modem.
    if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
        echo -e "\n${GREEN}No hay internet pero estás conectado al Módem${NC}.\n" # >/dev/null 2>&1
        disponible_modem="true"
        disponible_adb='true'
        conect_internet="false"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
    # echo "disponible_adb: $disponible_adb"
    # echo "conect_internet: $conect_internet"
}
# verif_tipo_con
#######FUNCIONES_FIN_CONEXION#######


menu_principal() {
    limpiar_variables() {
        # Limpiar las varibles
        if [[ "$disponible_adb" == 'true' && "$adb_conectado" == 'false' ]]; then
            adb_conectado=''
        elif [[ "$disponible_adb" == 'false' && "$adb_conectado" == 'false' ]]; then
            adb_conectado=''
        fi
        # Limpiar la variable que contiene si acaso un dispositivo adb conectado...
        adb_conectado_ip_device=""
    }
    while true; do
        verif_adb_conect # > /dev/null
        verif_tipo_con # > /dev/null
        # Verificar condiciones
        echo "adb_conectado_ip_device: $adb_conectado_ip_device"
        echo "disponible_adb: $disponible_adb"
        echo "adb_conectado: $adb_conectado"
        if [[ "$adb_conectado_ip_device" == "" ]]; then
            echo -e "${GREEN}Disponible para conectar adb${NC}. (${GREEN}Recomendado${NC})!!!"
            echo -e "${GREEN}00${NC}: Conectar adb"
        elif [[ "$adb_conectado_ip_device" =~ ^${ip}:[0-9]+$ || "$adb_conectado" == "emulator-5554" ]]; then
            echo -e "${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado"
        elif [[ ("$disponible_adb" == "true" || "$disponible_adb" == "false") && ("$adb_conectado_ip_device" =~ ^${ip}:[0-9]+$ || "$adb_conectado_ip_device" == "emulator-5554") ]]; then
            echo -e "${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado"
        else
            echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC})"
        fi
        
        # arreglar el input read de bash cuando no ingresa nada y no borra...
        # Configurar correctamente el terminal para manejar retroceso y teclas especiales.
        stty erase $(tput kbs)
        stty sane
        echo -e "${GREEN}01${NC}: Salir"
        read -p "Seleccione una opción: " opt
        case $opt in
            0|00)
                if [[ "$disponible_adb" == 'true' && "$adb_conectado" == 'false' ]]; then
                    solicitar_emparejamiento
                fi
                ;;
            1|01)
                echo "Saliendo..."
                exit 0
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo${NC}."
                ;;
        esac
        limpiar_variables
        # echo "adb_conectado: $adb_conectado" 
        # echo "disponible_adb: $disponible_adb"
    done
}
menu_principal