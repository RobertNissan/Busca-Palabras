import subprocess
import re
import os
import sys
from unidecode import unidecode

# Colores
negro = '\x1b[1;30m'      # Negro brillante
rojo = '\x1b[1;31m'       # Rojo brillante
verde = '\x1b[1;32m'      # Verde brillante
amarillo = '\x1b[1;33m'   # Amarillo brillante
azul = '\x1b[1;34m'       # Azul brillante
morado = '\x1b[1;35m'     # Morado brillante
cian = '\x1b[1;36m'       # Cian brillante
blanco = '\x1b[1;37m'     # Blanco brillante
reset = '\x1b[1;0m'       # Reset de color


def tabla_proyect(lista_app):
    table_width = os.get_terminal_size().columns
    n1 = int(0.1 * table_width)  # Ancho de ID
    n2 = int(0.78 * table_width)  # Ancho de NOMBRE
    n3 = int(0.12 * table_width)  # Ancho de STATUS

    print(f"tipo_tabla_python: $tipo_tabla")
    #input()
    ID = '[ID]'
    if f"$tipo_tabla" == "psp_ps":
        NOMBRE = 'PLAY STATION 2'
    else:
        NOMBRE = 'LISTA DE JUEGOS'
    STATUS = 'ESTADO'
    row_str = f"{verde}█{ID.center(n1)}┃{NOMBRE.ljust(n2)}┃{STATUS.ljust(n3)}█"

    long = len(row_str)
    for longitud in range(1, 399):
        medida = long - longitud
        if medida == table_width:
            n2 -= longitud
            break
        else:
            medida = long + longitud
            if medida == table_width:
                n2 += longitud
                break
    
    # Cabecera
    fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {cian}{NOMBRE.ljust(n2)} {verde} ┃ {blanco}{STATUS.center(n3)}{verde} █{reset}"
    linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
    separador = f"{verde}█" + "═" * (table_width - 2) + "█" + f"{reset}"

    print(linea_superior)
    print(fila_contenido)
    print(separador)

    # Contenido de la tabla
    total_filas = len(lista_app)
    for i, fila in enumerate(lista_app):
        id_ = f"[{fila[0]}]"
        name = fila[1]
        name = re.sub(r'\s+', ' ', name).strip()
        status = fila[2]
        
        # print(f"Verificando: {name}")
        
        if (name).lower() == ("PLAY STATION PORTÁTIL").lower():
            # print(f"Verificando: {name}")
            fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {cian}{name.ljust(n2)} {verde} ┃ {blanco}{STATUS.center(n3)}{verde} █{reset}"
            linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
            cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
            print(cierre)
            
            print(linea_superior)
            print(fila_contenido)
            print(separador)
            continue

        row_str = f"{verde}█ {blanco}{id_.center(n1)} {verde}┃ {blanco}{name.ljust(n2)} {verde} ┃ {blanco}{status.center(n3)}{verde} █{reset}"
        print(row_str)

        if i < total_filas - 1 and (name).lower() != ("Conflic Global Storm (Esp Lat)").lower():
            print(separador)

    # Cierre
    cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
    print(cierre)
    
def verificar_apps_instaladas(apps, dispositivo="emulator-5554"):
    try:
        # Ejecutar una sola vez adb para listar todas las apps instaladas
        resultado = subprocess.run(
            ["adb", "-s", dispositivo, "shell", "pm", "list", "packages"],
            capture_output=True, text=True, check=True
        )
        
        paquetes_instalados = set(line.strip().replace("package:", "") for line in resultado.stdout.splitlines())

        # Retornar un diccionario con el estado de cada app
        return {app: "✓" if app in paquetes_instalados else "x" for app in apps}

    except subprocess.CalledProcessError:
        print("Error ejecutando ADB. ¿Está el dispositivo conectado?")
        return {app: "?" for app in apps}  # '?' en caso de error

# Mapeo de nombres de apps con sus paquetes reales
mapa_apps = {
    "PSP Gold - Play Station": "org.ppsspp.ppssppgold",
    "Citra 3DS - Emulador y juegos": "org.citra.emu",
    "Más Emuladores y Juegos N64": "xyz.aethersx2.android",
    "Nintendo WII - Emulador y juegos": "org.dolphinemu.mmjr3"
}

# Obtener el estado de instalación
estados_apps = verificar_apps_instaladas(list(mapa_apps.values()))

# Construcción de la tabla con los estados correctos
lista_app_0 = [
    ["01", "Modern Combat 1 - Sand Storm", "[x]"],
    ["02", "Modern Combat 2 - Black Pegasus", "[x]"],
    ["03", "Modern Combat 3 - Fallen Nation", "[x]"],
    ["04", "Modern Combat 4 - Zero Hour", "[x]"],
    ["05", "Call Of Duty - Strike Team", "[x]"],
    ["06", "Shadow Gun - DeadZone", "[x]"],
    ["07", "PSP Gold - Play Station", f"[{estados_apps.get(mapa_apps['PSP Gold - Play Station'], '?')}]"],
    ["08", "Citra 3DS - Emulador y juegos", f"[{estados_apps.get(mapa_apps['Citra 3DS - Emulador y juegos'], '?')}]"],
    ["09", "Más Emuladores y Juegos N64", f"[{estados_apps.get(mapa_apps['Más Emuladores y Juegos N64'], '?')}]"],
    ["10", "Nintendo WII - Emulador y juegos", f"[{estados_apps.get(mapa_apps['Nintendo WII - Emulador y juegos'], '?')}]"],
    ["11", "Salir", "N/A"]
]

# Determinar qué tabla mostrar
opcion = "inicial"  # Definir esta variable según sea necesario

if opcion == "inicial":
    tabla_proyect(lista_app_0)
elif opcion == "psp_ps":
    tabla_proyect(lista_app_1)
elif opcion == "c3ds":
    tabla_proyect(lista_app_2)
else:
    print("Error: Opción desconocida.")
