# Formas de saber mi ip externa
pkg install dnsutils
dig +short myip.opendns.com @resolver1.opendns.com

# 3g sin datos aveces falla y tarda
curl -s ipinfo.io/ip
<html><head><title>302 Found</title></head><body><h1>302 Found</h1><p>The document has moved <a href="https://mi.tigo.com.co/assets/captive.html?utm_source=captiveportal&dest_url=http://ipinfo.io/ip&msisdn=573044027842">here</a></p></body></html>⏎


# muy lento sin datos 3g no funciona
curl -s https://api64.ipify.org



# muy lento sin datos 3g 
wget -qO- ifconfig.me
Prepended http:// to 'ifconfig.me'



# 3g sin datos
host myip.opendns.com resolver1.opendns.com
Using domain server:
Name: resolver1.opendns.com
Address: 208.67.222.222#53
Aliases:

myip.opendns.com has address 191.95.39.252
;; connection timed out; no servers could be reached




pkg install lynx -y
lynx -dump http://ifconfig.me/ip

# en modem routers wifi 
u0_a376@localhost ~/Busca-Palabras> lynx -dump http://ifconfig.me/ip
181.60.110.119

# en 4g con datos internet 
u0_a376@localhost ~/Busca-Palabras> lynx -dump http://ifconfig.me/ip
38.180.215.50

# en 3g con datos internet 
u0_a376@localhost ~/Busca-Palabras [1]> lynx -dump http://ifconfig.me/ip
38.180.215.50

# en 4g con datos sin internet 
u0_a376@localhost ~/Busca-Palabras> lynx -dump http://ifconfig.me/ip
   [spinner.gif]
   
# en 3g con datos sin internet 
u0_a376@localhost ~/Busca-Palabras> lynx -dump http://ifconfig.me/ip
Looking up ifconfig.me
Unable to locate remote host ifconfig.me.
Alert!: Unable to connect to remote host.

lynx: Can't access startfile http://ifconfig.me/ip'

# script con lynx
#!/bin/bash
# Instalar lynx si no está disponible
if ! command -v lynx &>/dev/null; then
    echo "Instalando lynx..."
    pkg install lynx -y || { echo "Error instalando lynx"; exit 1; }
fi
# Verificar la IP externa
echo "Verificando IP externa..."
RESULT=$(lynx -dump http://ifconfig.me/ip 2>&1)
# Analizar el resultado
if [[ -z "$RESULT" ]]; then
    echo "No se obtuvo respuesta. Podría no haber conexión a Internet."
elif [[ "$RESULT" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "Tu IP externa es: $RESULT"
elif echo "$RESULT" | grep -q "spinner.gif"; then
    echo "Conexión activa, pero no hay acceso a Internet (4G sin datos)."
elif echo "$RESULT" | grep -q "Unable to connect to remote host"; then
    echo "No se puede conectar al host remoto. Probablemente no hay acceso a Internet (3G sin datos)."
else
    echo "No se obtuvo una IP válida. Resultado recibido:"
    echo "$RESULT"
fi
