#!/bin/bash

# Colores
rojo='\033[0;31m'
verde='\033[0;32m'
amarillo='\033[1;33m'
cyan='\033[0;36m'
nc='\033[0m'

verif_tipo_con() {
        # Buscando la ip Android con wifi activado
        # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
        # iplocal=$(echo ${v%%/*})
        
        # variable que verifica adb
        disponible_adb="false"
        # variable que verifica internet 
        conect_internet="false"
        # variable que verifica modem
        disponible_modem="false"
        ##############INICIO INTERFAZ################
        # Función para obtener la IP de una interfaz
        obtener_ip() {
            local interfaz=$1
            busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
        }
        # Comprobamos primero si wlan0 está disponible.
        iplocal=$(obtener_ip "wlan0")
        # Si no hay IP en wlan0, buscar en otras interfaces activas.
        if [ -z "$iplocal" ]; then
            echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null 2>&1
            # Iterar sobre las interfaces activas y capturar la primera IP disponible.
            for interfaz in $(busybox ifconfig | grep '^[a-z]' | awk '{print $1}'); do
                iplocal=$(obtener_ip "$interfaz")
                ip=$(obtener_ip "$interfaz")
                # Si no capturó una interfaz, el bucle for sigue iterando.
                if [ ! -z "$iplocal" ]; then
                    # Si capturó una interfaz, detiene el bucle for.
                    echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null 2>&1
                    break
                fi
            done
        else
            # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular).
            echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null 2>&1
        fi
        # Si después de todas las comprobaciones no hay IP disponible
        if [ -z "$iplocal" ]; then
            echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null 2>&1
        else
            ip="$iplocal"
        fi
        ############## FIN INTERFAZ################
        
        # Verificar si hay conexión externa (Internet)
        # x=$(curl -s ifconfig.me)
        x=$(curl -s ipinfo.io/ip)
        ipexterna=$(echo "${x//[<>]/}")
        ipexterna=$(echo "${x}")

        ###########Zona WiFi Comprobar#########
        iplocalc=".${iplocal}"
        iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
        
        
        # Hay internet datos
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "127" ]]; then 
                echo -e "${GREEN}Tienes internet para compartir datos por ${NC}(${GREEN}zona wi-fi${NC}).\n" # >/dev/null 2>&1
                disponible_modem="true"
                conect_internet="true"
                # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            if [[ "$iplocal" == "127.0.0.1" ]]; then
                echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                for interfaz in $(busybox ifconfig | grep '^[a-z]' | awk '{print $1}'); do
                    ip=$(obtener_ip "$interfaz")
                    if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                        echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                        break
                    fi
                done
            else
                echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
            fi
        else
            ip="$iplocal"
            echo "No hay conexión a Internet." > /dev/null 2>&1
        fi

        ###########Zona WiFi Fin#########
        
        # Si no está conectado a una red externa.
        if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
            ipexterna="html"
            disponible_modem="true"
            conect_internet="false"
            echo -e "${RED}No hay conexión wi-fi, datos ni ${NC}(${RED}zona wi-fi${NC})${nc}...\n" # > /dev/null 2>&1
            adb_conectado="$adb_conectado_ip_device"
        fi
        
        wlan0_verif='false'
        # Verificar el estado de la wlan0
        es_wlan0=$(ip link show wlan0 2>/dev/null)
        # echo $es_wlan0
        if echo "${es_wlan0}" | grep -q "state DOWN"; then
            wlan0_verif='false'
            echo "wlan0 no conectada" > /dev/null 2>&1
        else
            wlan0_verif='true'
            echo "wlan0 conectada a modem" > /dev/null 2>&1
        fi
        
        # No hay internet pero está la zona wi-fi activa.
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "${GREEN}Conexion por ${NC}(${GREEN}Zona WI-FI${NC}) ${GREEN}y no tienes internet,\npero puedes otorgar conexión${NC}.\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="false"
        fi 
        
        # No hay internet pero estás conectado a modem.
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
                echo -e "${GREEN}No hay internet pero estás conectado al Módem${NC}.\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='true'
                conect_internet="false"
                
        fi 
        
        # Verificar si ipexterna contiene una dirección IP válida.
        # Tienes datos de internet y la zona wi-fi activa.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
            echo -e "${GREEN}Tienes datos de internet y la ${NC}(${GREEN}zona wi-fi${NC}) ${GREEN}activa${NC}.\n(${GREEN}Compartiendo datos${NC})\n"
            disponible_modem="true"
            disponible_adb="false"
            adb_conectado="$adb_conectado_ip_device"
            conect_internet="true"
            
        fi
        
    if [[ "$disponible_modem" == "false" ]]; then
        echo -e "${GREEN}Tienes internet wi-fi del Módem${NC}.\n" # >/dev/null 2>&1
        conect_internet="true"
        disponible_adb="true"
    fi
    # echo "disponible_adb: $disponible_adb"
    # echo "conect_internet: $conect_internet"
}
# verif_tipo_con

verif_tipo_con
export disponible_adb
# Lógica en Bash
if [ "${disponible_adb}" == "true" ]; then
    echo "ip: $ip"
    echo "disponible_adb: $disponible_adb"
    echo "conect_internet: $conect_internet"
else
    echo "ip: $ip"
    echo "disponible_adb: $disponible_adb"
    echo "conect_internet: $conect_internet"
fi

# Lógica en Python
python_script_get_var=$(cat <<EOF
import os

# Obtiene el valor de la variable de entorno
disponible_adb = os.environ.get("disponible_adb", "$disponible_adb")

# Imprime el valor desde Python
print(f"Valor de disponible_adb desde Python: {disponible_adb}")
EOF
)
python -c "$python_script_get_var"
