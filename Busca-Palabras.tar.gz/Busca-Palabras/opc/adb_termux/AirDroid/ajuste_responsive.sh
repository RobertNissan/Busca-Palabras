#!/bin/bash

# Ajuste resposive final

# COLORES
COLOR_CIAN='\033[36m'
COLOR_RESET='\033[0m'
COLOR_AZUL='\033[34m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_NEGRO='\033[30m'
COLOR_BLANCO='\033[37m'
COLOR_AMARILLO='\033[33m'
COLOR_MAGENTA='\033[35m'

columns=$(tput cols)
col=$((columns - 1))
col1=$((col * 7 / 100))
col2=$((col * 93 / 100))
    
# Crear un array con las opciones
opciones=(
    "Instalar Android control PC"
    "Instalar Speechkeys SmartVoice"
    "Instalar Galeria Mod v6.21.6"
    "Instalar VPN Unlimited"
    "Instalar ChatBot WhatsApp"
    "Limpiar las descargas"
    "Volver al menú principal"
)

# Función para calcular longitud visual del texto
longitud_visual() {
    echo -n "$1" | awk '{print length($0)}'
}

# varibles para el encabezado
ID=" [ID]"
APP="APP PREMIÚM"

# Definimos el ancho inicial de cada columna
printf_string="█ %-${col1}s | %-${col2}s █\n"
PRINTF_RESULT=$(printf "$printf_string" "$ID" "$APP")
# Contamos cuantos caracteres hay en la columna
char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
echo "Calculando caracteres (incluyendo espacios) en la fila: $char_count"

ajuste_responsive() {
    echo "Aplicando ajuste resposive"
    # aquí va el ajuste resposive a encabezado
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            echo "$char_count + $i = $columns"
            col2=$(($col2 + $i))
            break 
        fi

        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            echo "$char_count - $i = $columns"
            col2=$(($col2 - $i))
            break
        fi
    done 
}
ajuste_responsive

PRINTF_RESULT=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}%-${col1}s ${COLOR_VERDE}┃${COLOR_RESET} %-${col2}s${COLOR_VERDE} █${COLOR_RESET}\n" "$ID" "$APP")
printf "${COLOR_VERDE}┌%s┐${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
echo "$PRINTF_RESULT"
printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"

total_opciones=${#opciones[@]}  # Contar el número total de opciones

for i in "${!opciones[@]}"; do
    id=$(printf "%02d" $((i + 1)))  # Formatear el ID a dos dígitos
    texto="${opciones[$i]}"
    long_visual=$(longitud_visual "$texto")
    padding=$(($columns - long_visual - 12))  # Ajustar el relleno dinámicamente
    printf "${COLOR_VERDE}█${COLOR_RESET}  [%s] ${COLOR_VERDE}┃${COLOR_RESET} %s%${padding}s ${COLOR_VERDE}█${COLOR_RESET}\n" "$id" "$texto" ""

    # Imprimir el separador solo si no es la última opción
    if (( i < total_opciones - 1 )); then
        printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
    fi
done

printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
