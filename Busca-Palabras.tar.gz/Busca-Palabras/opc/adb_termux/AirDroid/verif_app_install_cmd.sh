#!/bin/bash

verificar_apps_instaladas() {
    local paquetes=("$@")  # Lista de paquetes pasados como argumento
    local paquetes_instalados
    paquetes_instalados=$(cmd package list packages | cut -d: -f2)  # Obtener lista de paquetes instalados

    for paquete in "${paquetes[@]}"; do
        if echo "$paquetes_instalados" | grep -q "^$paquete$"; then
            echo "$paquete: ✓"
        else
            echo "$paquete: x"
        fi
    done
}

# Ejemplo de uso
paquetes=("com.termux" "com.android.chrome" "com.ejemplo.noexistente")
verificar_apps_instaladas "${paquetes[@]}"
