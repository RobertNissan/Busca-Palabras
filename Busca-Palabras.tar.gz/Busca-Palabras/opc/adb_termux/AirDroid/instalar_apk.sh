#!/bin/bash

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

#######FUNCIONES_DE_CONEXION#######
disponible_adb='false'

mi_dispositivo() {
    echo ""
    echo "Brand ID: $(getprop ro.product.system.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Version de Android: $(getprop ro.build.version.release)"
    echo "Model ID: $(getprop ro.build.product)"
    echo "Kernel ID: $(uname -r)"
    echo "Chipset ID: $(getprop ro.product.board)"
    echo "Architecture: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        # seleccionar_dispositivo "$ip_objetivo"
        disponible_adb='true'
    fi
    
    conn=$(adb connect "$ip:5555")
    if [[ "$conn" == "failed"* ]]; then
        echo "ok" >/dev/null 2>&1
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    else
        echo "Conexion a Internet a traves del enrutador WiFi"
        conn=$(adb connect "${ip0}:5555")
        sleep 3
        return
        # seleccionar_dispositivo
    fi
    
    # Esto de aqui hasta el final de esta función no se esta usando
    # Mostrar la tabla de dispositivos adb conectados
    encabezado_tabla='false'
    mi_dispositivo
    my_device="$1"
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col*7/100))
    mul2=$(($col*47/100))
    mul3=$(($col*27/100))
    mul4=$(($col*9/100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 
    
    dispositivos=()
    # variable de conteo de cantidad de dispositivos a mostrar en la tabla
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    # offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}')
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}' | grep -v "$my_device")
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')
    
    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            if [ "$encabezado_tabla" == 'false' ]; then
                echo ""
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                encabezado_tabla='true'
            fi
            dispositivos+=("$device")
            # Formatear el id con 2 dígitos
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | v%-${mul4}s#\n" " $id_fortmat" "$device" "$model" "$version"
            printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
            id=$((id+1))
        done
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    : '
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo "Dispositivos OFFLINE:"
        echo "$offline_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo "Dispositivos NO AUTORIZADOS:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
    : '
}

# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    mostrar_dispositivos
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    menu_principal
    : '
    echo -en "Ingrese el número del dispositivo o 'q+enter' para salir: "
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
    : '
}

# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    echo ""
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ]"
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell echo "[ DEVICE: \$(getprop ro.product.model) ]"
    adb -s "$dispositivo" shell echo "[ BRAND: \$(getprop ro.product.system.brand) ]"
    adb -s "$dispositivo" shell echo "[ MODEL: \$(getprop ro.build.product) ]"
    adb -s "$dispositivo" shell echo "[ KERNEL: \$(uname -r) ]"
    
    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell echo "[ GPU: \$(getprop ro.hardware.gpu) ]"
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell echo "[ GPU: $gpu_info ]"
    fi

    adb -s "$dispositivo" shell echo "[ CPU: \$(getprop ro.hardware) ]"
    adb -s "$dispositivo" shell echo "[ ANDROID VERSION: \$(getprop ro.build.version.release) ]"
    adb -s "$dispositivo" shell echo "[ Android ID: \$(getprop ro.serialno) ]"
    
}

function connect {
    capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        echo -e "${GREEN}Conectando al puerto principal adb.\nPor favor, espere...${NC}"
    fi
    
    # ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    # ip_objetivo=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import multiprocessing
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

ip_objetivo = "$ip_objetivo"
num_processes = 10  # Puedes ajustar este valor segun tus necesidades

# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

def scan_ports(ip, start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    result = nm.scan(ip, arguments=f'-p {port_range} -Pn -T4')

    if 'scan' not in result or ip not in result['scan']:
        print(f"\nError al obtener los resultados del escaneo para la IP {ip} en el rango de puertos {port_range}")
        print("Asegúrate de que la IP sea válida y responda a los escaneos de puertos.")
    else:
        if nm[ip].all_protocols():
            for protocol in nm[ip].all_protocols():
                lport = sorted(nm[ip][protocol].keys())
                for port in lport:
                    print("Puerto", port, ":", nm[ip][protocol][port]['state'])
        else:
            print(f"\nNo se encontraron puertos abiertos para la IP {ip} en el rango de puertos {port_range}")

# Dividir el rango de puertos para escanear en varios subconjuntos
port_ranges = [(i, i + 65535//num_processes) for i in range(1, 65536, 65535//num_processes)]

# Crear procesos para escanear los puertos en paralelo
processes = []
for start, end in port_ranges:
    process = multiprocessing.Process(target=scan_ports, args=(ip_objetivo, start, end))
    processes.append(process)
    process.start()

# Esperar a que todos los procesos terminen
for process in processes:
    process.join()
EOF
)

    ports_output=$(python -c "$python_script")

    if echo "$ports_output" | grep -q "open"; then
        num_ports=$(echo "$ports_output" | grep "open" | awk '{print $2}')
        
        for port in $num_ports; do
            echo -e "${YELLOW}Probando puerto${NC}: $port"
            # adb start-server >/dev/null 2>&1
            verif_con=$(adb connect "${ip_objetivo}:${port}")

            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}La conexión fue exitosa.${NC}"
                adb -s "${ip_objetivo}:${port}" tcpip 5555
                sleep 5
                # Esperar hasta que el dispositivo esté listo en el puerto 5555
                while ! adb connect "${ip_objetivo}:5555" >/dev/null 2>&1; do
                    echo -e "${YELLOW}Esperando a que ADB esté listo en el puerto 5555...${NC}"
                    sleep 1  # Esperar un segundo antes de intentar de nuevo
                done
                
                puerto="5555"
                # Conección permanente
                adb -s "${ip_objetivo}:5555" tcpip "${puerto}"
                sleep 5
                ip=$(echo "${ip_objetivo}:5555" | cut -d: -f1)
                DISPOSITIVO="${ip_objetivo}:5555"
                # echo "${DISPOSITIVO}" 
                adb connect "${DISPOSITIVO}" 
                # adb devices
                adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
                
                seleccionar_dispositivo "$ip_objetivo"
                exit
            # Si los puertos fallan, prueba de inmediato con otro.
            elif [[ "$verif_con" == *"offline"* || "$verif_con" == *"not found"* || "$verif_con" == *"failed"* ]]; then
                continue  # No es necesario matar el servidor aquí
            else
                echo -e "${RED}La conexión falló. Mensaje: $verif_con${NC}"
            fi
        done
    fi
    connect
    capp_adb='true'
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$ip_objetivo"
    fi

    #sleep 3
    echo -e "\n${RED}Servidor adb, no encendido${NC}!!!"
    echo -e "${YELLOW}Siga las instrucciones${NC}:\n"
    echo "Habilitar la depuracion USB en Android, para hacer conexion adb:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB'."
    echo ""
    echo 'Si solo necesitas que se active en tu android, activa "Depuracion inalambirca"'
    echo '6. Selecciona donde dice: "Vincular dispositivo con codigo de sincronizacion"'
    echo -e  'En esa parte se mostrara una pequeña ventana que dice:'
    echo -e "Vincular con disposivo\n${YELLOW}Codigo de vinculacion de WI-FI\n${RED}123456\n${YELLOW}Direccion IP y PUERTO\n${YELLOW}${ip}${NC}:${BLUE}12345${NC}"
    echo '7. Habilitar la pantalla dividida entre "Vincular dispositivo con codigo de sincronizacion" y "Termux"' 

    echo -e "\nIngresa el puerto:"
    echo -en "$ip:"
    read puerto
    while [ -z "$puerto" ]; do
        # echo -en "${YELLOW}$ip:${BLUE}"
        read puerto
    done
    
    echo -en "Ingrese código de vinculación WI-FI: "
    read code
    while [ -z "${code}" ]; do
        echo -en "Ingrese código de vinculación WI-FI: "
        read code
    done
    
    echo -e "${YELLOW}Ejecutando: ${NC}adb pair ${YELLOW}${ip0}:${BLUE}${puerto} ${RED}${code}${NC}"
    adb pair ${ip0}:${puerto} ${code} 2>/dev/null
    # Si se conecta entonces: connect!!!
    # if [[ "${resultado}" == *"Failed"* || "${resultado}" == *"error"* ]]; then
    if [ $? -eq 0 ]; then
        echo -e "${YELLOW}Código correcto!!!.${NC}"
        connect
    else
        echo -e "${YELLOW}La conexion adb fallo. Mensaje:\n${RED}puerto o código erroneo...${NC}"
        return
    fi    
}


wlan0() {
    : '
    # Si no puede obtener la IP usando ip addr, usa Termux-API
    if command -v termux-wifi-connectioninfo &>/dev/null; then
        ip0=$(termux-wifi-connectioninfo | grep "ip" | awk -F ':' '{print $2}' | tr -d ',')
        if [[ "$ip0" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            echo "IP obtenida a través de Termux-API: $ip0" >/dev/null 2>&1
            disponible_adb="true"
            return
        else
            echo "No se pudo obtener la IP a través de Termux-API." >/dev/null 2>&1
        fi
    else
        echo "No se pudo obtener la IP. Faltan permisos o comandos." >/dev/null 2>&1
    fi
    : '
    # Obtener la IP de wlan0, si está disponible
    ip0=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Si no se encuentra IP en wlan0, buscar una IP distinta de 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(busybox ip addr | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi
    # Mostrar la IP de wlan0 si está disponible
    if [ "$ip0" ]; then
        disponible_adb='true'
        return
    fi
    # Mostrar otra IP si no se encontró en wlan0
    if [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1" #  > /dev/null
        disponible_adb='false'
        return
    fi
    # echo "$disponible_adb"
}
verif_adb_conect() {
    # Obtener la IP local
    # str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
    # ip=$(echo "${str%%/*}")
    
    # ip=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Obtener los dispositivos conectados por ADB
    adb_output=$(adb devices -l)
    # connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip})$")
    
    if [[ -n "$ip" ]]; then
        # Mostrar la IP local
        echo -e "\nIP local: $ip"
    fi

    # Buscar si hay un dispositivo con la IP o el emulador
    ip_device=$(echo "$connected_devices" | grep -Ei "$ip:5555|emulator-5554" | head -n 1)

    # Verificar si se encontró algún dispositivo
    if [[ -n "$ip_device" ]]; then
        echo -e "${GREEN}Dispositivo conectado a adb 1${NC}: $ip_device"
        disponible_adb='false'
        # adb_conectado='true'
        local adb_conectado="${ip_device}"
        echo "adb_conectado: $adb_conectado"
        return 
    else
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0
    fi
}
#######FUNCIONES_FIN_CONEXION#######


# Verifica permisos de almacenamiento
verificar_permisos() {
    adb_conectado="$1"
    echo -e "${YELLOW}Verificando permisos de almacenamiento...${NC}" > /dev/null
    if [ -d "/sdcard/" ]; then
        touch "/sdcard/.permiso_prueba" && rm "/sdcard/.permiso_prueba" > /dev/null
        echo -e "${GREEN}Permisos de almacenamiento ya concedidos.${NC}" > /dev/null
        if [[ -n "$adb_conectado" ]]; then
            # Concediendo permisos de almacenamiento con adb para reforzar
            adb -s "$adb_conectado" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
            adb -s "$adb_conectado"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
        fi
    else
        echo -e "${YELLOW}Concediendo permisos...${NC}"
        termux-setup-storage
        sleep 5
        if [[ -n "$adb_conectado" ]]; then
            # Concediendo permisos de almacenamiento con adb para reforzar
            adb -s "$adb_conectado" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
            adb -s "$adb_conectado"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
        fi
    fi
}

# Verifica si un APK está instalado
verificar_app_instalada() {
    local package="$1"
    local adb_conectado="$2"
    if [[ -n "$adb_conectado" ]]; then
        adb -s "$adb_conectado" shell pm list packages | grep -q "^package:${package}$"
    fi
}

# Descarga archivo desde Google Drive
descargar_archivo() {
    local file_id="$1"
    local destino="$2"
    echo -e "${YELLOW}Descargando archivo desde Google Drive...${NC}"
    gdown -O "$destino" "https://drive.google.com/uc?id=${file_id}"
}

# Instala un APK en el dispositivo
instalar_apk() {
    local archivo_path="$1"
    local package_name="$2"
    local adb_conectado="$3"
    # echo $adb_conectado

    if [ ! -f "$archivo_path" ]; then
        echo -e "${RED}El archivo $archivo_path no existe en la ruta especificada.${NC}"
        return 1
    fi

    if [[ -n "$adb_conectado" ]]; then
        if verificar_app_instalada "$package_name" "$adb_conectado"; then
            echo -e "${GREEN}La aplicación ${package_name} ya está instalada.${NC}"
        else
            echo -e "${YELLOW}Instalando APK...${NC}"
            adb -s "$adb_conectado" install "$archivo_path" > /dev/null
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}Instalación completada${NC}.\n"
            else
                echo -e "${GREEN}La instalación no pudo ser completada.${NC}"
            fi
        fi
    else
        echo -e "${GREEN}La instalación no pudo ser completada.${NC}"
    fi
}

procesar_archivo() {
    local file_id="$1"
    local zip_file="$2"
    local archivo_path="$3"
    local destino_dir="$4"
    local adb_conectado="$5"
    local TAMANIO_ESPERADO="$6"
    local PACK_APP="$7"
    
    # Obtener solo el nombre del archivo y luego la extensión
    # capturar solo el archivo sin su ruta
    nombre_archivo=$(basename "$archivo_path")
    # capturar solo la extensión del archivo
    extension="${nombre_archivo##*.}"
    # echo "nombre_archivo: $nombre_archivo"
    
    case "$extension" in
        "apk")
            # Si existe el apk o rom.
            if [[ -f "${archivo_path}" ]]; then
                # toma la extensión del archivo a analizar.
                nombre_archivo=$(basename "${nombre_archivo}")
                # echo -e "${YELLOW}nombre_archivo${NC}: $nombre_archivo"
                extension="${nombre_archivo##*.}"
                # echo -e "${YELLOW}extension${NC}: $extension"
                if [[ "$nombre_archivo" =~ [\(\)\[\]] ]]; then
                    nombre_archivo=""
                    for (( i=0; i<${#nombre_archivo}; i++ )); do
                        char="${nombre_archivo:i:1}"
                        case "$char" in
                            '(' | ')' | '[' | ']')
                                nombre_archivo+="\\$char" ;;
                        *)
                            nombre_archivo+="$char" ;;
                        esac
                    done
                fi
            fi
                
            echo -e "${YELLOW}nombre_archivo${NC}: $nombre_archivo"
            # echo -e "${YELLOW}adb_conectado${NC}: $adb_conectado"
        
            # Verifica si el APK está presente y es válido
            if [[ -f "$archivo_path" ]]; then
                echo -e "${YELLOW}Verificando el estado del APK...${NC}"
                local tamanio_archivo=$(stat --format="%s" "$archivo_path" 2>/dev/null)
                local result=$(apksigner verify --verbose --print-certs "$arc_rom_apk" 2>&1)
                if [[ "$tamanio_archivo" -eq "$TAMANIO_ESPERADO" ]] && { echo "$result" | grep -qi "Exception" || echo "$result" | grep -qi "Malformed"; }; then
                    # echo "tamaño igual"
                    # echo -e "${YELLOW}adb_conectado${NC}: $adb_conectado"
                    if [[ -n "${adb_conectado}" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                        echo -e "${GREEN}El APK está en buen estado y listo para instalar.${NC}"
                        instalar_apk "$archivo_path" "$PACK_APP" "$adb_conectado"
                        return
                    elif ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                        echo -e "${GREEN}El archivo $archivo_path\nestá en buen estado y listo para instalar desde tu gestor\nde archivo.${NC}"
                        return
                    fi
                else
                    echo -e "${RED}El APK está corrupto o incompleto. Procediendo a usar el ZIP...${NC}"
                    rm "$archivo_path"
                fi
            fi
        
            # Verifica si el ZIP está presente y en buen estado
            if [[ -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                echo -e "${YELLOW}Verificando el estado del archivo ZIP...${NC}"
                if unzip -t "${destino_dir}/${zip_file}" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP está en buen estado. Descomprimiendo...${NC}"
                    unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
                else
                    echo -e "${RED}El archivo ZIP está corrupto. Eliminando y descargando nuevamente...${NC}"
                    rm "${destino_dir}/${zip_file}"
                fi
            fi
        
            # Si el ZIP no está presente o fue eliminado, descargarlo
            if [[ ! -f "${destino_dir}/${zip_file}" && ! -f "$archivo_path" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                echo -e "${YELLOW}Descargando el archivo ZIP...${NC}"
                descargar_archivo "$file_id" "${destino_dir}/${zip_file}"
                echo -e "${YELLOW}Descomprimiendo archivo descargado...${NC}"
                unzip -o "${destino_dir}/${zip_file}" -d "$destino_dir"
            fi
        
            # Verifica nuevamente si el APK está disponible tras la descompresión
            if [[ -f "$archivo_path" ]]; then
                if [[ -n "${adb_conectado}" ]] && ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                    echo -e "${GREEN}El APK está en buen estado y listo para instalar.${NC}"
                    instalar_apk "$archivo_path" "$PACK_APP" "$adb_conectado"
                    return
                elif ! adb -s "${adb_conectado}" shell pm list packages 2>/dev/null | grep -q "^package:${PACK_APP}$"; then
                    echo -e "${GREEN}El archivo $archivo_path\nestá en exelente estado y listo para instalar desde tu gestor\nde archivo.${NC}"
                    return
                fi
                instalar_apk "$archivo_path" "$PACK_APP" "$adb_conectado"
            else
                echo -e "${RED}El archivo $archivo_path no se encontró después de todos los intentos.${NC}"
                exit 1
            fi
            ;;
        "3ds")
            # Verificacion if para comparar números use según su necesidad: 
            # (-eq: igual a), (-ne: no igual a), (-lt: menor que), (-le: menor o igual a), (-ge: mayor o igual a)
            # Capturar el tamaño de un archivo en bytes.
            tamanio_archivo=$(stat --format="%s" "${rom_apk}")
            # Comparar si son iguales en tamaño.
            if [ "${tamanio_archivo}" -eq 536870912 ]; then
                echo -e "${GREEN}La rom ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                return
            fi
            iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
            ;;
        "chd")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 6598202475 ]]; then
                    echo -e "${GREEN}La iso ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "iso")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 1355710464 || "${tamanio_archivo}" -eq 1651015680 || "${tamanio_archivo}" -eq 8383463424 || "${tamanio_archivo}" -eq 4866244608 || "${tamanio_archivo}" -eq 2468872192 || "${tamanio_archivo}" -eq 809631744 ]]; then
                    echo -e "${GREEN}La iso ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "wbfs")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 369098752 || "${tamanio_archivo}" -eq 1651015680 || "${tamanio_archivo}" -eq 8383463424 || "${tamanio_archivo}" -eq 4866244608 ]]; then
                    echo -e "${GREEN}La Rom ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "zip")
            if [ -d "$ruta_destino_apk" ]; then
                echo -e "${YELLOW}Verificando si existe el obb:\n${YELLOW}$ruta_obb${NC}"
                if [ -f "$ruta_obb" ]; then
                    echo -e "el archivo obb existe.\nVerificando archivo ZIP obb..."
                    if unzip -t "$ruta_obb" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP obb está en buen estado en:\n${YELLOW}$ruta_obb${NC}"
                        echo -e "\n${RED}Solo te falta el apk $rom_apk.${NC}"
                        # Verifica si existe el zip que contiene el apk
                        echo -e "${YELLOW}Verificar si existe el zip que contiene el apk${NC}"
                        if [[ -f "$ruta_destino_apk/$apk_zip" ]] && unzip -t "$ruta_destino_apk/$apk_zip" >/dev/null 2>&1; then
                            echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_destino_apk/$apk_zip${NC}"
                            echo "Descomprimiendo $ruta_destino_apk/$apk_zip..."
                            unzip -o "$ruta_destino_apk/$apk_zip" -d "$ruta_destino_apk"
                            echo -e "${GREEN}Descompresión completada.${NC}"
                            return
                        else
                            echo -e "${RED}El archivo ZIP $ruta_destino_apk/$apk_zip no existe o está incompleto.${NC}"
                            # echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}$ruta_destino_apk/$apk_zip${NC}"
                            rm -f "$ruta_destino_apk/$apk_zip"
                            iniciar_descarga_y_descomprimir "$apk_url" "$apk_zip" "$ruta_destino_apk"
                            return
                        fi
                    rm -rf ruta_destino_apk
                    fi
                fi
            fi                   
            ;;
        *)
            echo -e "${YELLOW}Tipo de archivo no soportado para verificación: $ruta_archivo.${NC}"
            return
            ;;
    esac    
}

verif_tipo_con() {
        # Buscando la ip Android con wifi activado
        # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
        # iplocal=$(echo ${v%%/*})
        
        conect_verificada="false"
        ##############INICIO INTERFAZ################
        # Función para obtener la IP de una interfaz
        obtener_ip() {
            local interfaz=$1
            busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
        }
        # Comprobamos primero si wlan0 está disponible
        iplocal=$(obtener_ip "wlan0")
        # Si no hay IP en wlan0, buscar en otras interfaces activas
        if [ -z "$iplocal" ]; then
            echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null 2>&1
            # Iterar sobre las interfaces activas y capturar la primera IP disponible
            for interfaz in $(busybox ifconfig | grep '^[a-z]' | awk '{print $1}'); do
                iplocal=$(obtener_ip "$interfaz")
                ip=$(obtener_ip "$interfaz")
                # Si no capturó una interfaz, el bucle for sigue iterando
                if [ ! -z "$iplocal" ]; then
                    # Si capturó una interfaz, detiene el bucle for
                    echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null 2>&1
                    break
                fi
            done
        else
            # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular)
            echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null 2>&1
        fi
        # Si después de todas las comprobaciones no hay IP disponible
        if [ -z "$iplocal" ]; then
            echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null 2>&1
        else
            ip="$iplocal"
        fi
        ############## FIN INTERFAZ################
        
        : '
        echo "ip: $ip"
        echo "iplocal: $iplocal"
        : '
        
        # Falta llevar una varible constante para cuando estoy conectado al modem con internet 
        # para eso debo hacer una sola variable que capture todas las verificación de conexión 
        # y si esta vacia entolves es la del modem, esa variable debe ser impresa al final vuamdo haya recolectado las verificiones de conexión
        
        # Verificar si hay conexión externa (Internet)
        # x=$(curl -s ifconfig.me)
        x=$(curl -s ipinfo.io/ip)
        ipexterna=$(echo "${x//[<>]/}")
        ipexterna=$(echo "${x}")
        # echo "ipexterna: $ipexterna"
        # read
        # echo -e ""
        
        ###########Zona WiFi Comprobar#########
        conexion_zonawifi='false'
        iplocalc=".${iplocal}"
        iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
        
        
        # Hay internet datos
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "127" ]]; then 
                echo -e "${verde}Tienes internet para compartir datos${blanco}.\n" # >/dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                conexion_zonawifi_si_internet='true'
                conect_verificada="true"
                echo -e "${verde}conexion_zonawifi_si_internet${blanco}: $conexion_zonawifi_si_internet\n" > /dev/null 2>&1
                read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        : '
        # Hay internet modem
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocal" =~ ^192+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$ip" =~ 192+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then 
                echo -e "${verde}Tienes internet wi-fi del modem${blanco}.\n" # >/dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                conexion_zonawifi_si_internet='true'
                echo -e "${verde}conexion_zonawifi_si_internet${blanco}: $conexion_zonawifi_si_internet\n" > /dev/null 2>&1
                read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        : '
        
        if [[ "$conexion_zonawifi_no_internet" == 'true' ]]; then
            # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo
            if [[ "$ipexterna" != "" ]]; then
                if [[ "$iplocal" == "127.0.0.1" ]]; then
                    echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                    for interfaz in $(busybox ifconfig | grep '^[a-z]' | awk '{print $1}'); do
                        ip=$(obtener_ip "$interfaz")
                        if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                            echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                            break
                        fi
                    done
                else
                    echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
                fi
            else
                ip="$iplocal"
                echo "No hay conexión a Internet." > /dev/null 2>&1
            fi
        fi
        ###########Zona WiFi Fin#########
        
        # clear
        # Si no está conectado a una red externa
        sin_internet='false'
        if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
            ipexterna="html"
            sin_conex='true'
            conect_verificada="true"
            echo -e "${rojo}No hay conexión${blanco}...\n" > /dev/null 2>&1
            # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        wlan0_verif='false'
        # Estado de la wlan0
        es_wlan0=$(ip link show wlan0 2>/dev/null)
        # echo $es_wlan0
        if echo "${es_wlan0}" | grep -q "state DOWN"; then
            wlan0_verif='false'
            echo "wlan0 no conectada" > /dev/null 2>&1
            # read
        else
            wlan0_verif='true'
            echo "wlan0 conectada a modem" > /dev/null 2>&1
            # read
        fi
        
        # No hay internet pero está la zona wi-fi activa
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "${verde}Conexion por Zona WI-FI y no tienes internet,\npero puedes otorgar conexión${blanco}.\n" # >/dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                conexion_zonawifi_no_internet='true'
                conect_verificada="true"
                disponible_adb='false'
                echo -e "conexion_zonawifi_no_internet: $conexion_zonawifi_no_internet" > /dev/null 2>&1
                # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi 
        
        # No hay internet pero estás conectado a modem
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
                echo -e "${verde}No hay internet pero estás conectado al modem${blanco}.\n" # >/dev/null 2>&1
                conect_verificada="true"
                #ngrok="Conexion externa deshabilitada"
                read -n 1 -p "Presione cualquier tecla para continuar!"
        fi 
        
        # Esto no esta en uso
        compartiendo_datos='false'
        # Hay conexión por zona wi-fi y externa
        if [[ "$conexion_zonawifi" == "true" ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            echo -e "${verde}Tienes internet y estás compartiendo datos${blanco}.\n"
            compartiendo_datos='true'
            conect_verificada="true"
            read
        fi
        
        modem_zona_wifi='false'
        # Verificar si ipexterna contiene una dirección IP válida
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
            echo -e "${verde}Tienes datos de internet y la zona wi-fi activa${blanco}.\n"
            modem_zona_wifi='true'
            conect_verificada="true"
            read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
    echo "disponible_adb: $disponible_adb"
}
#verif_tipo_con

# echo -e "\n${GREEN}disponible_adb${NC}: $disponible_adb"
#### ajustando tabla inicial ####
# Definir el script Python en una variable
python_script_tabla=$(cat <<EOF
import os
import sys
import signal
# Colores
verde = '\\x1b[1;32m'
blanco = '\\x1b[1;37m'
reset = '\\x1b[1;0m'
# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    print("\n¡Saliendo...!")
    # Limpiar la salida y detener el progreso
    sys.exit(0)    
# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)
# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y salir del script
    print("\n¡Saliendo...!")
    sys.exit(0)    
# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

# Verificar el valor de disponible_adb desde las variables de entorno
# disponible_adb = os.environ.get("disponible_adb", "true")
# obtener el último resultado de la variable disponible_adb
disponible_adb = os.environ.get("disponible_adb", "$disponible_adb")

def tabla_proyect():
    # Datos simplificados (array de listas/tuplas)
    '''
    lista_app = [
        ["01", "Instalar termux-api - termux-boot"],
        ["02", "Volver al menú principal"],        
    ]
    '''
    # Datos simplificados (array de listas/tuplas)
    lista_app = []

    # Verificar si disponible_adb es "true" y agregar opción
    if disponible_adb == "true":
        lista_app.append(["00", "Conectar adb"])
    
    # Agregar más opciones a la lista de la tabla
    lista_app.append(["01", "Instalar termux-api - termux-boot"])
    lista_app.append(["02", "Volver al menú principal"])        
    
    # Obtener el ancho máximo de la tabla a partir del ancho del terminal
    table_width = os.get_terminal_size().columns
    n1 = int(0.11 * table_width)
    n2 = int(1.14 * table_width)
    ID = '[ID]'
    NOMBRE = 'APP PREMIUM'
    row_str = f"█ {ID.center(n1)} █ {NOMBRE.ljust(n2)} █"
    long = len(row_str)
    for longitud in range(1, 399):
        medida = long - longitud
        if medida == table_width:
            n2 = n2 - longitud
            break
        else:
            medida = long + longitud
            if medida == table_width:
                n2 = n2 + longitud
                break
    texto = "----- TABLA DE APP -----"
    texto2 = "Instale termux-api para tener los permisos necesarios sobre otras aplicaciones"
    espacios = (table_width - len(texto)) // 2
    centrado = (" " * espacios) + texto + (" " * espacios)
    # print(centrado)
    espacios = (table_width - len(texto2)) // 2
    centrado2 = (" " * espacios) + texto2 + (" " * espacios)
    # print(centrado2)
    fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {blanco}{NOMBRE.ljust(n2)} {verde}█{reset}"
    linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
    print(linea_superior)
    print(fila_contenido)
    separador = f"{verde}█" + "═" * (table_width - 2) + "█" + f"{reset}"
    print(separador)
    total_filas = len(lista_app)
    contador = 0
    for fila in lista_app:
        id_ = f"[{fila[0]}]"
        name = fila[1]
        row_str = f"{verde}█ {blanco}{id_.center(n1)} {verde}┃ {blanco}{name.ljust(n2)} {verde}█{reset}{blanco}"
        print(row_str)
        contador += 1
        if contador < total_filas:
            print(separador)
    cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
    print(cierre)
    print(f"{verde}┃")
    option = input(f"{verde}└>>>{blanco} ")
    return option
if __name__ == "__main__":
    cap_input = os.environ.get("CAP_INPUT", "/tmp/.cap_input")
    user_input = tabla_proyect()
    with open(cap_input, "w") as f:
        f.write(user_input)
EOF
)
#### ajustando tabla inicial fin ####


# Menú principal
menu_principal() {
    while true; do
        
        verif_adb_conect > /dev/null
        cap_ac=$(verif_adb_conect)
        cap_tc=$(verif_tipo_con)
        adb_conectado=$(echo "$cap_ac" | grep -i "adb_conectado" | head -n 1 | awk -F ': ' '{print $2}')
        disponible_adb=$(echo "$cap_tc" | grep -i "disponible_adb" | head -n 1 | awk -F ': ' '{print $2}')
        # echo "$cap_ac" | grep -i "$disponible_adb" # | head -n 1 | awk -F ': ' '{print $2}'
        # echo "disponible_adb: $disponible_adb"
        # adb_conectado="$1"
        # if [ "$adb_conectado" == 'true' ]; then
        if [[ -n "$adb_conectado" ]]; then
            echo -e "\n${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado"
        fi
        if [[ -z "$adb_conectado" && "$disponible_adb" == 'true' ]]; then
            echo -e "${RED}\nNo se detectó un dispositivo adb conectado.${NC}" # > /dev/null
            # exit 1
        fi
        if [[ "$disponible_adb" == 'true' ]]; then
            echo -e "${YELLOW}La dirección IP de wlan0 es${NC}: $ip0"
            echo -e "${GREEN}Disponible para conectar adb${NC}. (${GREEN}Recomendado${NC})!!!."
            # echo -e "\n${CYAN}Menú Principal${NC}"
            # echo -e "00. ${GREEN}Conectar adb${NC}"
        fi
        if [ "$disponible_adb" == 'false' ]; then
            # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            echo -e "\n${CYAN}Menú Principal${NC}" > /dev/null
        fi
        
        verificar_permisos "$adb_conectado"
        # Verificar si Python está instalado
        if [ -x ${PREFIX}/bin/python ]; then
            echo "Python ya está instalado." >/dev/null
        else 
            echo "Instalando python..."
            apt install python -y
            pkg install python-pip
            # dpkg --configure -a
            # apt list --upgradable
            # apt upgrade
            # apt-get check
            # apt clean
        fi
        
        instalar_paquete_pip() {
            local comando=$1
            local instalacion=$2
            local mensaje_error=$3
    
            if ! command -v "$comando" &> /dev/null; then
                echo -e "${YELLOW}$comando no está instalado.\nInstalando $comando${NC}..."
                eval "$instalacion" >/dev/null 2>&1
                if [ $? -ne 0 ]; then
                    echo "$mensaje_error"
                    exit 1
                fi
            else
                echo "${GREEN}$comando ya está instalado${NC}." >/dev/null 2>&1
            fi
        }
    
        
        # Función para instalar paquetes si no están presentes
        instalar_paquete_share() {
            if [[ ! -x $PREFIX/share/doc/$1 ]]; then
                echo "${YELLOW}Instalando $2${NC}"
                pkg install -y $1 >/dev/null 2>&1
                echo -e "${GREEN}$1 instalado correctamente${NC}."
            else
                echo "${GREEN}$2 ya está instalado${NC}." >/dev/null
            fi
        }
        # Función para instalar paquetes si no están presentes
        instalar_paquete_bin() {
            if [[ ! -f $PREFIX/bin/$1 ]]; then
                echo "${YELLOW}Instalando $2${NC}"
                pkg install -y $1 >/dev/null 2>&1
                echo -e "${GREEN}$1 instalado correctamente${NC}."
            else
                echo "${GREEN}$2 ya está instalado${NC}." >/dev/null
            fi
        }
        
        # Instalar herramientas necesarias
        instalar_paquete_bin "zip" "zip"
        instalar_paquete_bin "rarp" "rar"
        instalar_paquete_bin "adb" "adb"
        instalar_paquete_bin "unrar" "unrar"
        instalar_paquete_bin "nmap" "nmap"
        instalar_paquete_bin "apksigner" "apksigner"
        instalar_paquete_bin "mediainfo" "mediainfo"
        instalar_paquete_share "termux-api" "termux-api"
        instalar_paquete_pip "gdown" "pip install gdown" "Error al instalar gdown. Asegúrate de tener pip instalado."
    
        
        # Función para verificar si un paquete está instalado en el dispositivo de forma exacta
        cap_nom_pack() {
            local package="$1"
            # Obtener solo el paquete exacto de la lista de paquetes instalados com esto: grep -E "^package:com.termux$" | awk -F ':' '{print $2}'
            nombre_pack=$(adb -s "${adb_conectado}" shell pm list packages | grep -E "^package:${package}$" | awk -F ':' '{print $2}') > /dev/null
            echo "$nombre_pack"
        }
        # cap_nom_pack "${pack_app}"
        
        
       #  echo -e "\n${GREEN}adb_conectado${NC}: $adb_conectado"
        # echo -e "\n${GREEN}disponible_adb${NC}: $disponible_adb"
        
        # Pasar la variable de bash wlan0() {disponible_adb} al script de Python
        export disponible_adb
        # Ruta al archivo de salida
        cap_input="$(pwd)/.cap_input"
        export CAP_INPUT="$cap_input"
        # Eliminar archivo previo si existe
        [ -f "$cap_input" ] && rm -f "$cap_input"
        # Ejecutar el script Python
        python -c "$python_script_tabla"
        # Leer la opción seleccionada
        opt=$(cat "$cap_input" 2>/dev/null || echo "")
        # Eliminar archivo previo si existe
        [ -f "$cap_input" ] && rm -f "$cap_input"

        case $opt in
            0|00)
                if [ "$disponible_adb" == 'true' ]; then
                    solicitar_emparejamiento
                fi
                ;;
            1|01)
                # Variables globales
                PACK_APP='com.termux.api'
                TAMANIO_ESPERADO=2868448
                RUTA_DESTINO='/sdcard/Download'
                ARCHIVO_ZIP='Termux_API_0.50.1.zip'
                URL='1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY'
                ARCHIVO_PATH="${RUTA_DESTINO}/Termux_API_0.50.1.apk"
                if [[ -n "$adb_conectado" ]] && ! adb -s "$adb_conectado" shell pm list package | grep -qE "^package:${PACK_APP}$" > /dev/null; then
                    # Procesar APK
                    procesar_archivo "$URL" "$ARCHIVO_ZIP" "$ARCHIVO_PATH" "$RUTA_DESTINO" "$adb_conectado" "$TAMANIO_ESPERADO" "$PACK_APP"
                elif [[ -n "$adb_conectado" ]]; then
                    # Procesar APK
                    procesar_archivo "$URL" "$ARCHIVO_ZIP" "$ARCHIVO_PATH" "$RUTA_DESTINO" "$adb_conectado" "$TAMANIO_ESPERADO" "$PACK_APP"
                else
                    # Procesar APK
                    procesar_archivo "$URL" "$ARCHIVO_ZIP" "$ARCHIVO_PATH" "$RUTA_DESTINO" "$adb_conectado" "$TAMANIO_ESPERADO" "$PACK_APP"
                    # echo -e "${GREEN}La aplicación ya está instalada en tu dispositivo!!!${NC}" # > /dev/null
                    echo ""
                fi
                ;;
            2|02)
                descargar_y_descomprimir "https://www.mediafire.com/file/23vdt913xtzedus/God_Of_War_Chains_Of_Olympus_Esp.zip/file" "God_Of_War_Chains_Of_Olympus_Esp.zip" "/sdcard/Download/Games/PSE/PPSSPP" "/sdcard/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp/God Of War Chains Of Olympus (Esp).iso"
                echo "Saliendo..."
                # cd ~/Busca-Palabras
                # bash Menu-Busca-Palabras.sh
                exit 0
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo${NC}.\n"
                ;;
        esac
    done
}

menu_principal # "emulator-5554"

# falta arreglar cuando no hay conexión de nada y dice que la app esta instalada 
