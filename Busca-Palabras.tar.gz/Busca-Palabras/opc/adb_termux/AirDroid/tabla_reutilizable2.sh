#!/bin/bash

# Función para mostrar el menú principal
mostrar_menu() {
    clear
    # Ajuste resposive final

    # COLORES
    COLOR_CIAN='\033[36m'
    COLOR_RESET='\033[0m'
    COLOR_AZUL='\033[34m'
    COLOR_ROJO='\033[31m'
    COLOR_VERDE='\033[32m'
    COLOR_NEGRO='\033[30m'
    COLOR_BLANCO='\033[37m'
    COLOR_AMARILLO='\033[33m'
    COLOR_MAGENTA='\033[35m'

    columns=$(tput cols)
    col=$((columns - 1))
    col1=$((col * 5 / 100))   # Ancho de la columna ID
    col2=$((col * 80 / 100))  # Ancho de la columna Nombre
    col3=$((col * 15 / 100))  # Ancho de la columna Status

    # Crear un array con las opciones y sus estados
    opciones=(
        "Modern Combat 1 - Sand Storm:Activo"
        "Modern Combat 2 - Black Pegasus:Activo"
        "Modern Combat 3 - Fallen Nation:null"
        "Modern Combat 4 - Zero Hour:Activo"
        "Call Of Duty - Strike Team:null"
        "PSP Gold - Play Station:Activo"
        "Citra 3DS - Emulador y juegos:Activo"
        "Más Emuladores y Juegos N64:null"
        "Nintendo WII - Emulador y juegos:Activo"
        "Salir:-"
    )

    # Función para calcular longitud visual del texto
    longitud_visual() {
        echo -n "$1" | awk '{print length($0)}'
    }

    # Variables para el encabezado
    ID="[ID]"
    APP="LISTA DE JUEGOS"
    STATUS="STATUS"

    # Definimos el ancho inicial de cada columna
    printf_string="█ %-${col1}s | %-${col2}s | %-${col3}s █\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$APP" "$STATUS")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    echo "Calculando caracteres (incluyendo espacios) en la fila: $char_count"

    # Ajuste responsivo
    ajuste_responsive() {
        echo "Aplicando ajuste resposive"
        for i in {1..301}; do
            medida=$(($char_count + $i))
            if [[ "$medida" -eq "$columns" ]]; then
                echo "$char_count + $i = $columns"
                col2=$(($col2 + $i))
                break
            fi

            medida=$(($char_count - $i))
            if [[ "$medida" -eq "$columns" ]]; then
                echo "$char_count - $i = $columns"
                col2=$(($col2 - $i))
                break
            fi
        done
    }
    ajuste_responsive

    # Encabezado de la tabla
    PRINTF_RESULT=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}%-${col1}s ${COLOR_VERDE}┃${COLOR_RESET} %-${col2}s ${COLOR_VERDE}┃${COLOR_RESET} %-${col3}s ${COLOR_VERDE}█${COLOR_RESET}\n" "$ID" "$APP" "$STATUS")
    printf "${COLOR_VERDE}┌%s┐${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
    echo "$PRINTF_RESULT"
    printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"

    total_opciones=${#opciones[@]}  # Contar el número total de opciones

    for i in "${!opciones[@]}"; do
        id=$(printf "%02d" $((i + 1)))  # Formatear el ID a dos dígitos
        texto=$(echo "${opciones[$i]}" | cut -d ":" -f1)  # Nombre del juego
        status=$(echo "${opciones[$i]}" | cut -d ":" -f2)  # Estado

        long_visual=$(longitud_visual "$texto")
        padding=$(($columns - long_visual - 24))  # Ajustar el relleno dinámicamente
        
        char_count=$(printf "█ %-${col1}s | %-${col2}s | % ${col3}s █\n" "[${id}]" "${texto}" "${status}")
    
        # ajustar resposive a cada columna
        for j in {1..301}; do
            medida=$((${#char_count} + $j))
            if [[ "$medida" -eq "$columns" ]]; then
                col2=$(($col2 + $j))
                char_count=$(printf "█ %-${col1}s | %-${col2}s | % ${col3}s █\n" "[${id}]" "${texto}" "${status}")
            fi

            medida=$((${#char_count} - $j))
            if [[ "$medida" -eq "$columns" ]]; then
                col2=$(($col2 - $j))
                char_count=$(printf "█ %-${col1}s | %-${col2}s | % ${col3}s █\n" "[${id}]" "${texto}" "${status}")
            fi   
        done
    
        
        char_count=$(printf "█ %-${col1}s | %-${col2}s | % ${col3}s █\n" "[${id}]" "${texto}" "${status}")

        #printf "${COLOR_VERDE}█${COLOR_RESET}  [%s] ${COLOR_VERDE}┃${COLOR_RESET} %s %${padding}s ${COLOR_VERDE}┃${COLOR_RESET} %s ${COLOR_VERDE}█${COLOR_RESET}\n" "$id" "$texto" "" "$status"
        printf "${COLOR_VERDE}█ ${COLOR_RESET}%-${col1}s${COLOR_VERDE} ┃ ${COLOR_RESET}%-${col2}s ${COLOR_VERDE}┃ ${COLOR_RESET}%-${col3}s${COLOR_VERDE} █${COLOR_RESET}\n" "[$id]" "$texto" "$status"
        

        # Imprimir el separador solo si no es la última opción
        if (( i < total_opciones - 1 )); then
            printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
        fi
    done

    printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"

    echo -n "Seleccione una opción: "
}

# Bucle principal del script
while true; do
    mostrar_menu
    read -r opcion

    case $opcion in
        10)
            echo "Saliendo..."
            exit 0
            ;;
        *)
            echo "Opción inválida, intente de nuevo."
            sleep 1
            ;;
    esac
done
