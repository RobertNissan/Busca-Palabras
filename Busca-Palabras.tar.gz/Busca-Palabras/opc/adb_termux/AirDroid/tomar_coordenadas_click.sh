#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color
COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}
# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT


# verifica que termux-api.apk esté instalado 
verifica_termux-api() {
    # pkg install apksigner
    
    EMULATOR_ID="$1"
    
    # Definir códigos de color
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    CYAN='\033[0;36m'
    NC='\033[0m' # Sin color
    
    # Verificar si los permisos de almacenamiento ya han sido concedidos
    # Ruta de prueba
    prueba_ruta="/sdcard/.prueba_permiso_termux.txt"
    # Verificar el estado del almacenamiento
    verificar_almacenamiento() {
        if [ -d "/sdcard/" ]; then
            # Intentar crear un archivo para verificar los permisos
            echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
            if [ -f "$prueba_ruta" ]; then
                echo -e "\n${GREEN}Los permisos de almacenamiento ya han sido concedidos.${NC}" >/dev/null 2>&1
                # Concediendo permisos de almacenamiento con adb para reforzar
                adb -s "$EMULATOR_ID" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
                adb -s "$EMULATOR_ID"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
                rm "$prueba_ruta"  # Eliminar el archivo de prueba
                return 0
            else
                echo -e "${RED}El directorio existe, pero los permisos de escritura no están disponibles.${NC}"
            fi
        fi
    
        # Si llegamos aquí, es porque no se tienen los permisos
        echo -e "${YELLOW}Concediendo permisos de almacenamiento...${NC}"
        termux-setup-storage
        sleep 5  # Esperar un momento para permitir que se concedan los permisos
    
        # Verificar de nuevo los permisos
        if [ -d "/sdcard/" ]; then
            echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
            if [ -f "$prueba_ruta" ]; then
                echo -e "${GREEN}Permisos de almacenamiento concedidos correctamente.${NC}"
                rm "$prueba_ruta"  # Eliminar el archivo de prueba
                return 0
            else
                echo -e "${RED}No se pudieron conceder los permisos de almacenamiento. Asegúrate de aceptar la solicitud de permisos.${NC}"
                return 1
            fi
        else
            echo -e "${RED}El directorio de almacenamiento no está disponible. Asegúrate de aceptar la solicitud de permisos.${NC}"
            return 1
        fi
    }
    # Ejecutar la función
    verificar_almacenamiento
    
    # Verificar si Python está instalado
    if [ -x ${PREFIX}/bin/python ]; then
        echo "Python ya está instalado." >/dev/null 2>&1
    else 
        echo "Instalando python..."
        apt install python -y
        pkg install python-pip
        # dpkg --configure -a
        # apt list --upgradable
        # apt upgrade
        # apt-get check
        # apt clean
    fi
    
    instalar_paquete_pip() {
        local comando=$1
        local instalacion=$2
        local mensaje_error=$3

        if ! command -v "$comando" &> /dev/null; then
            echo -e "$comando no está instalado.\nInstalando $comando..."
            eval "$instalacion" >/dev/null 2>&1
            if [ $? -ne 0 ]; then
                echo "$mensaje_error"
                exit 1
            fi
        else
            echo "$comando ya está instalado." >/dev/null 2>&1
        fi
    }

    
    # Función para instalar paquetes si no están presentes
    instalar_paquete_share() {
        if [[ ! -x $PREFIX/share/doc/$1 ]]; then
            echo "Instalando $2"
            pkg install -y $1 >/dev/null 2>&1
            echo -e "$1 instalado correctamente."
        else
            echo "$2 ya está instalado" >/dev/null 2>&1
        fi
    }
    # Función para instalar paquetes si no están presentes
    instalar_paquete_bin() {
        if [[ ! -f $PREFIX/bin/$1 ]]; then
            echo "Instalando $2"
            pkg install -y $1 >/dev/null 2>&1
            echo -e "$1 instalado correctamente."
        else
            echo "$2 ya está instalado" >/dev/null 2>&1
        fi
    }
    
    # Instalar herramientas necesarias
    instalar_paquete_bin "zip" "zip"
    instalar_paquete_bin "rarp" "rar"
    instalar_paquete_bin "adb" "adb"
    instalar_paquete_bin "unrar" "unrar"
    instalar_paquete_bin "nmap" "nmap"
    instalar_paquete_bin "apksigner" "apksigner"
    instalar_paquete_bin "mediainfo" "mediainfo"
    instalar_paquete_share "termux-api" "termux-api"
    instalar_paquete_pip "gdown" "pip install gdown" "Error al instalar gdown. Asegúrate de tener pip instalado."
    
    # Buscar rastro de pkg sucios:
    # find $PREFIX -name "*rarp*" # esta relacionado con net-tools 
    
    iniciar_descarga_google_drive() {
        # ID del archivo de Google Drive
        local FILE_ID="$1"
        local archivo_zip="$2"
        local destino="$3"
        local adb_conectado="$4"
        local arc_rom_apk="$5"
        local pack_app="$6"
        
        # Ruta y nombre del archivo donde deseas guardarlo
        RUTA_DESTINO="$destino/$archivo_zip"
        echo $RUTA_DESTINO
        
    
        # Verificar si el directorio de destino existe
        if [ ! -d "$destino" ]; then
            echo -e "${YELLOW}El directorio $destino no existe. Creándolo...${NC}"
            mkdir -p "$destino"
            
            # Verificar si se creó correctamente
            if [ $? -ne 0 ]; then
                echo -e "${RED}Error al crear el directorio $destino. Saliendo...${NC}"
                exit 1
            fi
            echo -e "${YELLOW}Directorio creado con éxito.${NC}"
        fi
    
        # Descargar el archivo utilizando gdown
        echo -e "\n${YELLOW}Descargando archivo desde Google Drive...${NC}"
        gdown -O "$RUTA_DESTINO" "https://drive.google.com/uc?id=$FILE_ID"
    
        # Comprobar si la descarga fue exitosa
        if [ $? -eq 0 ]; then
            echo -e "${YELLOW}Descargado con éxito en:\n${GREEN}${destino}/${archivo_zip}${NC}"
            cd "$destino"
            unzip "${archivo_zip}"
            echo -e "${YELLOW}Extracción completada en:\n${GREEN}${destino}/${NC}"
            
        # Obtener solo el nombre del archivo y luego la extensión
        # capturar solo el archivo sin su ruta
        nombre_archivo=$(basename "$arc_rom_apk")
        # capturar solo la extensión del archivo
        extension="${nombre_archivo##*.}"
    
        # Si existe el apk o rom.
        if [ -f "${arc_rom_apk}" ]; then
            # toma la extensión del archivo a analizar.
            nombre_archivo=$(basename "${arc_rom_apk}")
            # echo $nombre_archivo
            extension="${nombre_archivo##*.}"
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
        fi
        
        app_instalada='false'
        # echo "aqui"
        # echo ${adb_conectado}
        if adb -s "$dispositivo" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
            app_instalada='true'
        fi
        echo "app_instalada: $app_instalada"
    
        # adb -s "${adb_conectado}" shell pm list package | grep -E "^package:${pack_app}$" | awk -F ':' '{print $2}'
        echo -e "${YELLOW}Verificando archivo APK...${NC}"
        APK_PATH="$arc_rom_apk"
        echo "APK_PATH: $APK_PATH"
        
        apk='false'
        result='Exception'
        # verifica el archivo si existe
        if [[ -f "${arc_rom_apk}" ]]; then
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$arc_rom_apk" 2>&1)
            tamanio_archivo=$(stat --format="%s" "${arc_rom_apk}" 2>&1)
            apk='true'
            result='Exception'
        fi
        
        # Comparar si son iguales en tamaño.
        if [[ "${tamanio_archivo}" -eq 2868448 ]] && [[ -f "$arc_rom_apk" ]]; then
            echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}" # > /dev/null
            apk_malo='false'
            if [[ "${app_instalada}" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}"
                return
            elif [[ -n "${dispositivo}" ]] && [[ -f "$arc_rom_apk" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                return
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
        else
            # echo -e "${RED}El archivo APK no coincide en tamaño. Puede estar corrupto.${NC}"
            apk_malo='true'
        fi
        
            cd - > /dev/null
        else
            echo -e "${RED}Error al descargar el archivo. Verifica el enlace de Google Drive.${NC}"
            exit 1
        fi
    }
    # Función para descargar y descomprimir archivos
    descargar_apk_rom_y_descomprimir() {
        # "$1"   "$2"                  "$3"                    "$4"               "$5"        
        # "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$adb_conectado" 
        local url="$1"
        local archivo_zip="$2"
        local ruta_destino="$3"
        local arc_rom_apk="$4"
        local dispositivo="$5"
        local pack_app="$6"
        
        # Armar la ruta completa del archivo
        local ruta_archivo="${ruta_destino}/${archivo_zip}"
        # echo $ruta_archivo
        
        echo ""   
    
        # Obtener solo el nombre del archivo y luego la extensión
        # capturar solo el archivo sin su ruta
        nombre_archivo=$(basename "$ruta_archivo")
        # capturar solo la extensión del archivo
        extension="${nombre_archivo##*.}"
    
        # Si existe el apk o rom.
        if [ -f "${arc_rom_apk}" ]; then
            # toma la extensión del archivo a analizar.
            nombre_archivo=$(basename "${arc_rom_apk}")
            # echo $nombre_archivo
            extension="${nombre_archivo##*.}"
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
        fi
        
        app_instalada='false'
        # echo "aqui"
        # echo ${adb_conectado}
        if adb -s "$dispositivo" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
            app_instalada='true'
        fi
        # echo "app_instalada: $app_instalada"
    
        # adb -s "${adb_conectado}" shell pm list package | grep -E "^package:${pack_app}$" | awk -F ':' '{print $2}'
        echo -e "${YELLOW}Verificando archivo APK...${NC}"
        APK_PATH="$arc_rom_apk"
        # echo "APK_PATH: $APK_PATH"
        
        apk='false'
        result='Exception'
        # verifica el archivo si existe
        if [[ -f "${arc_rom_apk}" ]]; then
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$arc_rom_apk" 2>&1)
            tamanio_archivo=$(stat --format="%s" "${arc_rom_apk}" 2>&1)
            apk='true'
            result='Exception'
        fi
        
        # Comparar si son iguales en tamaño.
        if [[ "${tamanio_archivo}" -eq 2868448 ]] && [[ -f "$arc_rom_apk" ]]; then
            echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}" # > /dev/null
            apk_malo='false'
            if [[ "${app_instalada}" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}"
                return
            elif [[ -n "${dispositivo}" ]] && [[ -f "$arc_rom_apk" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$arc_rom_apk" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                return
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
        else
            # echo -e "${RED}El archivo APK no coincide en tamaño. Puede estar corrupto.${NC}"
            apk_malo='true'
        fi
        # Verificar otro archivo si contiene la palabra "Exception" o "Malformed"
        if [[ "$apk" == 'false' ]]; then
            echo -e "${RED}El archivo $arc_rom_apk\nno se encuentra en su dispositivo.${NC}"
        elif echo "$result" | grep -qi "Exception"; then
            echo -e "${RED}El archivo APK es inválido o está corrupto.${NC}"
            rm -rf "${APK_PATH}"
            apk_malo='true'
        elif echo "$result" | grep -qi "Malformed"; then
            echo -e "${RED}El archivo APK está mal formado.${NC}"
            rm -rf "${APK_PATH}"
            apk_malo='true'
        else
            echo -e "${GREEN}El archivo ya está descargado en1:\n${YELLOW}${APK_PATH}${NC}"
            apk_malo='false'
       
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                   ' ')
                       nombre_archivo_escapado=$(echo "${nombre_archivo}" | sed 's/ /\\ /g')
                       break
                       ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
            if [[ "$app_instalada" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}" # > /dev/null
                return
            elif [[ -n "$dispositivo" ]] && [[ "$app_instalada" == "false" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nen su dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
            return
        fi
        if [[ "$apk_malo" == 'true' ]] && [[ -f "$ruta_archivo" ]]; then
            echo "Verificando archivo ZIP apk..."
            if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                echo "Descomprimiendo $ruta_archivo..."
                unzip -o "$ruta_archivo" -d "$ruta_destino"
                echo -e "${GREEN}Descompresión completada.${NC}"
                echo -e "${YELLOW}Instalando $APK_PATH\nen su dispositivo!!!${NC}"
                nombre_archivo=$(basename "$APK_PATH")
                nombre_archivo_escapado=""
                for (( i=0; i<${#nombre_archivo}; i++ )); do
                    char="${nombre_archivo:i:1}"
                    case "$char" in
                        '(' | ')' | '[' | ']')
                            nombre_archivo_escapado+="\\$char"
                            ;;
                       ' ')
                           nombre_archivo_escapado=$(echo "${nombre_archivo}" | sed 's/ /\\ /g')
                           break
                           ;;
                        *)
                            nombre_archivo_escapado+="$char"
                            ;;
                    esac
                done
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
            else
                echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                rm -f "$ruta_archivo"
                iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$dispositivo" "$arc_rom_apk" "$pack_app"
                return
            fi
        else
            iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$dispositivo" "$arc_rom_apk" "$pack_app"
            return
        fi
    }
    
    pack_app='com.termux.api'
    # dispositivo='emulator-5554'
    ruta_destino='/sdcard/Download'
    archivo_zip='Termux_API_0.50.1.zip'
    url='1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY'
    ruta_rom_apk='/sdcard/Download/Termux_API_0.50.1.apk'
    # Verificar si hay un dispositivo conectado
    # dispositivo=$(adb devices | awk 'NR>1 && $2=="device" {print $1}')
    # dispositivo="emulator-5554"
    if [[ -z "$EMULATOR_ID" ]]; then
        echo "No hay dispositivos conectados."
        exit 1
    fi
    # Obtener el estado de la pantalla
    estado_pantalla=$(adb -s "$EMULATOR_ID" shell dumpsys power | grep -E "Display Power|mHoldingDisplay" | grep -oE "ON|OFF|true|false" | head -n 1)
    if [[ "$estado_pantalla" == "ON" || "$estado_pantalla" == "true" ]]; then
        echo "Mantenga la pantalla ENCENDIDA." # > /dev/null 2&>1
        pantalla_apagada='true'
    elif [[ "$estado_pantalla" == "OFF" || "$estado_pantalla" == "false" ]]; then
        echo "La pantalla está APAGADA."
        pantalla_apagada='false'
        return
    else
        echo "No se pudo determinar el estado de la pantalla." > /dev/null 2&>1
    fi
    
    # Función para verificar si un paquete está instalado en el dispositivo de forma exacta
    cap_nom_pack() {
        local package="$1"
        # Obtener solo el paquete exacto de la lista de paquetes instalados com esto: grep -E "^package:com.termux$" | awk -F ':' '{print $2}'
        nombre_pack=$(adb -s "${EMULATOR_ID}" shell pm list packages | grep -E "^package:${package}$" | awk -F ':' '{print $2}') > /dev/null
        echo "$nombre_pack"
    }
    # cap_nom_pack "${pack_app}"

    if ! adb -s "$EMULATOR_ID" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
        # https://drive.google.com/file/d/1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY/view?usp=drivesdk
        descargar_apk_rom_y_descomprimir "$url" "$archivo_zip" "$ruta_destino" "$ruta_rom_apk" "$EMULATOR_ID" "$pack_app"
    else
        echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}" > /dev/null
        echo ""
    fi
}
# Función para capturar el nombre del paquete de la app
ver_paquete_app() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    echo -e "\n${YELLOW}Cuando presiones empezar, abre la app que\nquieres saber su nombre antes de 5 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"
    
    # Mostrar la notificación del tiempo
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # sleep 5
    
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2&>1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
        echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null 2&>1
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    
    # Detener la aplicación detectada (si no es Termux)
    if [[ "$nombre_paquete" != "com.termux" ]]; then
        adb -s "$dispositivo" shell am force-stop "$nombre_paquete"
    fi
    # Abrir Termux
    adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
        
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    
    # Mensaje de finalización
    echo -e "${BLUE}Proceso completado.${NC}\n"
}
# Función para iniciar una aplicación por paquete
iniciar_aplicacion() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    echo -e "Escriba \"q\" para salir..."
    while true; do
        read -p "Introduce el nombre del paquete de la app (o escribe 'salir' para terminar): " package_name

        if [[ -z "$package_name" ]]; then
            echo "El nombre del paquete no puede estar vacío. Inténtalo de nuevo."
        elif [[ "$package_name" == "q" ]]; then
            echo "Saliendo..."
            menu_ver_paquete_app "$dispositivo"
            break
        else
            echo "Nombre del paquete introducido: $package_name"
            # Aquí puedes agregar lo que desees hacer con el paquete
            break
        fi
    done
    
    if ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${package_name}$" > /dev/null; then
        echo "Nombre del paquete no existe. Inténtalo de nuevo."
        return
    fi
    
    # Obtener la actividad principal
    ACTIVIDAD=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $package_name | tail -n 1")

    if [[ -z "$ACTIVIDAD" ]]; then
        echo -e "${RED}No se encontró la actividad principal para el paquete $package_name.${NC}"
        return
    fi

    echo -e "${GREEN}Iniciando la aplicación...${NC}"
    adb -s "$dispositivo" shell am start -n "$ACTIVIDAD" > /dev/null
    echo -e "${BLUE}Aplicación iniciada con éxito.${NC}\n"
}
capturar_swipe() {
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    echo -e "${YELLOW}Cuando abra la app, haga un gesto de swipe en cualquier dirección dentro de los próximos 3 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"

    # Capturar el nombre del paquete
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2&>1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
        echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    if [[ -z "$nombre_paquete" ]]; then
        echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}"
        return
    fi
    
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    

    adb -s "$dispositivo" shell getevent -l 2>/dev/null | while read -r line; do
        # Detectar inicio del toque
        if [[ "$line" =~ BTN_TOUCH.*DOWN ]]; then
            touch_active=true
        fi

        # Detectar posición inicial
        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex)) # Convertir de hexadecimal a decimal
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex)) # Convertir de hexadecimal a decimal
        fi

        if $touch_active && [[ -n "$x_coord" && -n "$y_coord" ]]; then
            if [[ -z "$x_start" && -z "$y_start" ]]; then
                x_start="$x_coord"
                y_start="$y_coord"
                echo -e "${CYAN}Punto inicial registrado:${NC} X=$x_start, Y=$y_start"
            fi
        fi

        # Detectar fin del toque
        if [[ "$line" =~ BTN_TOUCH.*UP ]]; then
            touch_active=false
            if [[ -n "$x_coord" && -n "$y_coord" ]]; then
                x_end="$x_coord"
                y_end="$y_coord"
                echo -e "${CYAN}Punto final registrado:${NC} X=$x_end, Y=$y_end"

                # Verificar si hubo desplazamiento
                if [[ "$x_start" -eq "$x_end" && "$y_start" -eq "$y_end" ]]; then
                    echo -e "${RED}No hubo movimiento detectado. Intenta de nuevo.${NC}"
                else
                    # Calcular diferencias
                    dx=$((x_end - x_start))
                    dy=$((y_end - y_start))

                    # Determinar dirección
                    if (( dx > 0 && dx >= dy )); then
                        echo -e "${GREEN}El gesto fue hacia la derecha.${NC}"
                    elif (( dx < 0 && -dx >= dy )); then
                        echo -e "${GREEN}El gesto fue hacia la izquierda.${NC}"
                    elif (( dy > 0 && dy > dx )); then
                        echo -e "${GREEN}El gesto fue hacia abajo.${NC}"
                    elif (( dy < 0 && -dy > dx )); then
                        echo -e "${GREEN}El gesto fue hacia arriba.${NC}"
                    else
                        echo -e "${RED}El gesto no fue claro. Intenta de nuevo.${NC}"
                    fi
                fi
                echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $dispositivo shell input swipe $x_start $y_start $x_end $y_end\n"
                # Abrir Termux
                adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
                # Detener la captura
                pkill -f getevent
                break
            fi
        fi
    done
}
# Función para tomar coordenadas de una app
tomar_coordenadas() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    # echo -e "\n${YELLOW}Cuando presiones empezar, abre la app que\nquieres capturar uns coordenada.${NC}"
    echo -e "${YELLOW}Cuando abra la app, espere 3 segundos y haga click\ndonde desee capturar las coordenadas...${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"
    
    
    # Mostrar la notificación del tiempo
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # sleep 5
    
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
            echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    
    # Captura los eventos de coordenadas X e Y
    adb -s "$dispositivo" shell getevent -l 2>/dev/null | while read -r line; do
        if [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex)) # Convertir de hexadecimal a decimal
        fi

        if [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex)) # Convertir de hexadecimal a decimal
        fi

        if [[ -n "$x_coord" && -n "$y_coord" ]]; then
            # echo -e "\n${GREEN}Coordenadas capturadas:${NC}"
            echo -e "\n${COLOR_VERDE}Coordenadas capturadas (Hexadecimal)${COLOR_RESET}:\n${COLOR_AMARILLO}ABS_MT_POSITION_X${COLOR_RESET}: $x_hex\n${COLOR_AMARILLO}ABS_MT_POSITION_Y${COLOR_RESET}: $y_hex"
            echo -e "\n${COLOR_VERDE}Coordenadas capturadas (Decimal)${COLOR_RESET}:\n${COLOR_AMARILLO}ABS_MT_POSITION_X${COLOR_RESET}: $x_coord\n${COLOR_AMARILLO}ABS_MT_POSITION_Y${COLOR_RESET}: $y_coord"
            echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $EMULATOR_ID shell input tap $x_coord $y_coord"
            # Abrir Termux
            adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
            pkill -f getevent
            echo ""
            break
        fi
    done
}
capturar_tap_prolongado() {
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    echo -e "${YELLOW}Cuando abra la app, mantenga presionado en cualquier posición durante al menos 1 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"

    # Capturar el nombre del paquete
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # Capturar el nombre del paquete de la aplicación actual
    while true; do
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2>&1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$"; then
            echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}Nombre del paquete detectado:${NC} $nombre_paquete"
            break
        fi

        sleep 0.5
    done

    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")

    if [[ -z "$nombre_paquete" ]]; then
        echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}"
        return
    fi

    echo -e "${GREEN}Para abrir la aplicación usando adb${NC}:\n$actividad_ini_app"

    # Captura eventos para detectar el tap prolongado
    adb -s "$dispositivo" shell getevent -lt 2>/dev/null | while read -r line; do
        if [[ "$line" =~ BTN_TOUCH.*DOWN ]]; then
            touch_active=true
            start_time=$(date +%s%7N) # Tiempo inicial en milisegundos
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex))
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex))
        fi

        if [[ "$line" =~ BTN_TOUCH.*UP ]]; then
            end_time=$(date +%s%7N) # Tiempo final en milisegundos
            touch_active=false

            duration=$((end_time - start_time))

            if [[ -n "$x_coord" && -n "$y_coord" ]]; then
                if ((duration >= 1000)); then
                    echo -e "${GREEN}Tap prolongado detectado en:${NC} X=$x_coord, Y=$y_coord (duración: $((duration / 1000)).$((duration % 1000))s)"
                    echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $EMULATOR_ID shell input swipe $x_coord $y_coord $x_coord $y_coord 2000\n"

                    # Detener la captura y salir
                    adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
                    pkill -f getevent
                    break
                else
                    echo -e "${RED}El toque fue demasiado corto (${duration}ms). Intenta de nuevo.${NC}" >/dev/null
                fi
            fi
        fi
    done
}
menu_ver_paquete_app() {
    # Menú principal
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    while true; do
        echo -e "${CYAN}MENÚ:${NC}"
        echo -e "${GREEN}01${NC} - Ver paquete de app"
        echo -e "${GREEN}02${NC} - Iniciar aplicación por paquete"
        echo -e "${GREEN}03${NC} - Capturar gesto de swipe de una app"
        echo -e "${GREEN}04${NC} - Tomar coordenadas de tap de una app"
        echo -e "${GREEN}05${NC} - Capturar coordenadas de tap prolongado"
        echo -e "${GREEN}06${NC} - Salir\n"
    
        read -p "Selecciona una opción: " opcion
    
        case $opcion in
            1|01) ver_paquete_app "$dispositivo" ;;
            2|02) iniciar_aplicacion "$dispositivo" ;;
            3|03) capturar_swipe "$dispositivo" ;;
            4|05) tomar_coordenadas "$dispositivo" ;;
            5|05) capturar_tap_prolongado "$dispositivo" ;;
            6|06) echo -e "${BLUE}Saliendo del script. Hasta luego.${NC}\n"; break ;;
            *) echo -e "${RED}Opción inválida. Intenta de nuevo.${NC}" ;;
        esac
    done
}


menu_ver_paquete_app "emulator-5554"