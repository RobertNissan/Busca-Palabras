#!/bin/bash

# Función para mostrar el menú principal
mostrar_menu() {
    clear
    # Ajuste resposive final

    # COLORES
    COLOR_CIAN='\033[36m'
    COLOR_RESET='\033[0m'
    COLOR_AZUL='\033[34m'
    COLOR_ROJO='\033[31m'
    COLOR_VERDE='\033[32m'
    COLOR_NEGRO='\033[30m'
    COLOR_BLANCO='\033[37m'
    COLOR_AMARILLO='\033[33m'
    COLOR_MAGENTA='\033[35m'
    
    columns=$(tput cols)
    col=$((columns - 1))
    col1=$((col * 7 / 100))
    col2=$((col * 93 / 100))
        
    # Crear un array con las opciones
    opciones=(
        "Modern Combat 1 - Sand Storm"
        "Modern Combat 2 - Black Pegasus"
        "Modern Combat 3 - Fallen Nation"
        "Modern Combat 4 - Zero Hour"
        "Call Of Duty - Strike Team"
        "PSP Gold - Play Station"
        "Citra 3DS - Emulador y juegos"
        "Más Emuladores y Juegos N64"
        "Nintendo WII - Emulador y juegos"
        "Salir"
    )
    
    # Función para calcular longitud visual del texto
    longitud_visual() {
        echo -n "$1" | awk '{print length($0)}'
    }
    
    # varibles para el encabezado
    ID=" [ID]"
    APP="LISTA DE JUEGOS"
    
    # Definimos el ancho inicial de cada columna
    printf_string="█ %-${col1}s | %-${col2}s █\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$APP")
    # Contamos cuantos caracteres hay en la columna
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    echo "Calculando caracteres (incluyendo espacios) en la fila: $char_count"
    
    ajuste_responsive() {
        echo "Aplicando ajuste resposive"
        # aquí va el ajuste resposive a encabezado
        for i in {1..301}; do
            medida=$(($char_count + $i))
            if [[ "$medida" -eq "$columns" ]]; then
                echo "$char_count + $i = $columns"
                col2=$(($col2 + $i))
                break 
            fi
    
            medida=$(($char_count - $i))
            if [[ "$medida" -eq "$columns" ]]; then
                echo "$char_count - $i = $columns"
                col2=$(($col2 - $i))
                break
            fi
        done 
    }
    ajuste_responsive
    
    PRINTF_RESULT=$(printf "${COLOR_VERDE}█ ${COLOR_RESET}%-${col1}s ${COLOR_VERDE}┃${COLOR_RESET} %-${col2}s${COLOR_VERDE} █${COLOR_RESET}\n" "$ID" "$APP")
    printf "${COLOR_VERDE}┌%s┐${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
    echo "$PRINTF_RESULT"
    printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
    
    total_opciones=${#opciones[@]}  # Contar el número total de opciones
    
    for i in "${!opciones[@]}"; do
        id=$(printf "%02d" $((i + 1)))  # Formatear el ID a dos dígitos
        texto="${opciones[$i]}"
        long_visual=$(longitud_visual "$texto")
        padding=$(($columns - long_visual - 12))  # Ajustar el relleno dinámicamente
        printf "${COLOR_VERDE}█${COLOR_RESET}  [%s] ${COLOR_VERDE}┃${COLOR_RESET} %s%${padding}s ${COLOR_VERDE}█${COLOR_RESET}\n" "$id" "$texto" ""
    
        # Imprimir el separador solo si no es la última opción
        if (( i < total_opciones - 1 )); then
            printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
        fi
    done
    
    printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"

    echo -n "Seleccione una opción: "
}

# Función para manejar submenús
mostrar_submenu() {
    tipo_tabla=$1

    while true; do
        clear
        python3 - "$tipo_tabla" <<EOF
import os
import sys

if len(sys.argv) < 2:
    print("Error: No se recibió una opción válida.")
    sys.exit(1)

opcion = sys.argv[1]

# Colores
verde = '\\x1b[1;32m'
blanco = '\\x1b[1;37m'
reset = '\\x1b[1;0m'

def tabla_proyect(lista_app):
    table_width = os.get_terminal_size().columns
    n1 = int(0.11 * table_width)
    n2 = int(1.14 * table_width)

    ID = '[ID]'
    NOMBRE = 'OPCIÓN DISPONIBLE'
    row_str = f"█ {ID.center(n1)} █ {NOMBRE.ljust(n2)} █"
    long = len(row_str)

    for longitud in range(1, 399):
        medida = long - longitud
        if medida == table_width:
            n2 -= longitud
            break
        else:
            medida = long + longitud
            if medida == table_width:
                n2 += longitud
                break

    fila_contenido = f"{verde}█ {blanco}{ID.center(n1)} {verde}┃ {blanco}{NOMBRE.ljust(n2)} {verde}█{reset}"
    linea_superior = f"{verde}┌" + "═" * (table_width - 2) + "┐" + f"{reset}"
    print(linea_superior)
    print(fila_contenido)
    separador = f"{verde}█" + "═" * (table_width - 2) + "█" + f"{reset}"
    print(separador)

    total_filas = len(lista_app)
    contador = 0
    for fila in lista_app:
        id_ = f"[{fila[0]}]"
        name = fila[1]
        row_str = f"{verde}█ {blanco}{id_.center(n1)} {verde}┃ {blanco}{name.ljust(n2)} {verde}█{reset}"
        print(row_str)
        contador += 1
        if contador < total_filas:
            print(separador)

    cierre = f"{verde}└" + "═" * (table_width - 2) + "┘" + f"{reset}"
    print(cierre)

# Listas de datos
lista_app_1 = [
    ["01", "Instalar termux - api - boot"],
    ["02", "Instalar Apex Launcher v4.9.20"],
    ["03", "Instalar Pixel Launcher vQ6"],
    ["04", "Instalar AirDroid v4.2.9.5"],
    ["05", "Instalar Team Viewer"],
    ["0", "Volver al menú principal"]
]

lista_app_2 = [
    ["01", "Configurar VPN"],
    ["02", "Actualizar Android"],
    ["03", "Limpiar caché del sistema"],
    ["04", "Activar permisos de root"],
    ["05", "Instalar custom ROM"],
    ["0", "Volver al menú principal"]
]

# Determinar qué tabla mostrar
if opcion == "apps":
    tabla_proyect(lista_app_1)
elif opcion == "config":
    tabla_proyect(lista_app_2)
else:
    print("Error: Opción desconocida.")
EOF

        # Leer la opción ingresada
        echo -n "Seleccione una opción o 0 para volver: "
        read -r subopcion

        if [ "$subopcion" == "0" ]; then
            break
        else
            echo "Opción seleccionada: $subopcion"
            echo "Ejecutando acción..."
            sleep 1
        fi
    done
}

# Bucle principal del script
while true; do
    mostrar_menu
    read -r opcion

    case $opcion in
        1)
            mostrar_submenu "apps"
            ;;
        2)
            mostrar_submenu "config"
            ;;
        10)
            echo "Saliendo..."
            exit 0
            ;;
        *)
            echo "Opción inválida, intente de nuevo."
            sleep 1
            ;;
    esac
done
