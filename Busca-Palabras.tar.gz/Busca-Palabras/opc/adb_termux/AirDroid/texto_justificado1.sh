#!/bin/bash


# Ajusta texto y justificalo en termux, e imprimir simulado de escritura

# Definir códigos de color
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante
COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Función para manejar la señal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    exit 0
}
# Función para manejar la señal SIGINT (Ctrl+C)
handler_SIGINT() {
    exit 0
}
# Asignar las funciones del controlador a las señales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

# Obtener la ip wlan0 si está disponible...
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

####### FUNCIONES DE JUSTIFICACION DE TEXTO #######
# Función para eliminar secuencias ANSI (como colores)
strip_ansi() {
    # Usar tr para eliminar caracteres ANSI, más rápido que sed
    echo -e "$1" | tr -d '\033' | sed 's/\[[0-9;]*m//g'
}

# Función para justificar texto respetando caracteres UTF-8 y espacios
justify_text() {
    local width=$(tput cols) # Ancho de la terminal
    local text="$1"
    local justified=""
    local line=""
    local leading_spaces=""
    local adjusted_width

    while IFS= read -r line || [[ -n $line ]]; do
        leading_spaces="${line%%[! ]*}" # Obtener los espacios iniciales
        adjusted_width=$((width - ${#leading_spaces}))
        line="${line#"${leading_spaces}"}" # Remover espacios iniciales

        if [[ $(strip_ansi "$line" | wc -m) -le $adjusted_width ]]; then
            justified+="$leading_spaces$line\n"
        else
            local words=($line)
            local current_line=""
            for word in "${words[@]}"; do
                # Solo calcular la longitud una vez por palabra
                if [[ $(strip_ansi "$current_line $word" | wc -m) -le $adjusted_width ]]; then
                    current_line+="$word "
                else
                    justified+="$leading_spaces$(justify_line "$current_line" "$adjusted_width")\n"
                    current_line="$word "
                fi
            done
            justified+="$leading_spaces$current_line\n"
        fi
    done <<< "$text"

    printf "%b" "$justified"
}

# Función para justificar una línea
justify_line() {
    local line="$1"
    local width="$2"
    local spaces_needed=$((width - $(strip_ansi "$line" | wc -m)))
    local words=($line)
    local space_count=$(( ${#words[@]} - 1 ))

    if (( space_count == 0 )); then
        echo "$line"
        return
    fi

    local extra_spaces=$(( spaces_needed / space_count ))
    local remainder_spaces=$(( spaces_needed % space_count ))
    local justified_line=""

    # Usar un bucle para construir la línea justificada
    for i in "${!words[@]}"; do
        justified_line+="${words[i]}"
        if (( i < space_count )); then
            justified_line+="$(printf ' %.0s' $(seq 1 $((extra_spaces + (i < remainder_spaces ? 1 : 0)))))"
        fi
    done

    echo "$justified_line"
}

# Función para imprimir texto con colores
print_color() {
    local color_code
    case $1 in
        red) color_code="${RED}" ;;
        green) color_code="${GREEN}" ;;
        yellow) color_code="${YELLOW}" ;;
        blue) color_code="${BLUE}" ;;
        cyan) color_code="${CYAN}" ;;
        magenta) color_code="${MAGENTA}" ;;
        white) color_code="${WHITE}" ;;
        *) color_code="" ;;
    esac
    # Imprimir el texto con el color
    echo -e "${color_code}$2${NC}"
}

# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}
####### FIN FUNCIONES DE JUSTIFICACION DE TEXTO #######


print_text_complet() {
    # Título e instrucciones justificados
    print_color red "$(justify_text 'Servidor adb, no encendido!!!')"
    print_color green "$(justify_text 'Siga las instrucciones:')"
    # Instrucciones para habilitar depuración USB
    print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb${NC}:")"
    print_color yellow "$(justify_text "${GREEN}1${NC}.$(generate_spaces 1)${YELLOW}Abre la aplicación ${NC}[${GREEN}Configuración${NC}] ${YELLOW}en tu dispositivo Android${NC}.")"
    print_color yellow "$(justify_text "${GREEN}2${NC}. ${YELLOW}Ve a${NC} [${GREEN}Acerca del teléfono${NC} o ${GREEN}de la tablet${NC}].")"
    print_color yellow "$(justify_text "${GREEN}3${NC}.  ${YELLOW}Toca repetidamente${NC} [${GREEN}Número de compilación${NC}] ${YELLOW}hasta que se active el modo de desarrollador${NC}.")"
    print_color yellow "$(justify_text "${GREEN}4${NC}. ${YELLOW}Regresa al menú principal de [${GREEN}Configuración${NC}], ${YELLOW}busca y entra en${NC}: [${GREEN}Sistema${NC}].")"
    print_color yellow "$(justify_text "${GREEN}5${NC}. ${YELLOW} Ahora da click en: ${NC}[${GREEN}Opciones avanzadas${NC}] ${YELLOW}y entra en [${GREEN}Opciones para desarrolladores${NC}].")"
    print_color yellow "$(justify_text "${GREEN}6${NC}. ${YELLOW}Habilita ${NC}[${GREEN}Depuración por USB${NC}].")"
    # Instrucciones para depuración inalámbrica
    print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra${NC}.")"
    print_color yellow "$(justify_text "${GREEN}7${NC}. ${YELLOW}Selecciona donde dice${NC}:")"
    print_color green "$(justify_text " Vincular dispositivo con código de sincronización${NC}")"
    print_color yellow "$(justify_text "  Selecciona ahora en:${NC}")"
    print_color green "$(justify_text "   Vincular con dispositivo${NC}")"
    print_color blue "$(justify_text "    Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")"
    print_color blue "$(justify_text "    Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345")"
    # Nota adicional
    print_color cyan "$(justify_text "Para hacer la conexión correctamente:")"
    print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: ${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC}).")"
    # Final
    print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")"
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    echo -en "\n${YELLOW}Ingrese el código de vinculación WI-FI${NC}: ${RED}"
    read code
}
print_text_complet

echo ""
simular_escritura() {
    # Función para simular el efecto de escritura (con delay muy bajo)
    type_text() {
        local text="$1"
        local delay="${2:-0.000001}" # Ajusta a un valor muy bajo
        for ((i = 0; i < ${#text}; i++)); do
            printf "%s" "${text:i:1}"
            # Puedes reducir el delay aún más o quitarlo
            sleep "$delay"
        done
        printf "\n" # Para finalizar la línea
    }

    # Título e instrucciones justificados
    type_text "$(print_color red "$(justify_text 'Servidor adb, no encendido!!!')")"
    type_text "$(print_color green "$(justify_text 'Siga las instrucciones:')")"
    # Instrucciones para habilitar depuración USB
    type_text "$(print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb${NC}:")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}1${NC}.$(generate_spaces 1)${YELLOW}Abre la aplicación ${NC}[${GREEN}Configuración${NC}] ${YELLOW}en tu dispositivo Android${NC}.")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}2${NC}. ${YELLOW}Ve a${NC} [${GREEN}Acerca del teléfono${NC} o ${GREEN}de la tablet${NC}].")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}3${NC}.  ${YELLOW}Toca repetidamente${NC} [${GREEN}Número de compilación${NC}] ${YELLOW}hasta que se active el modo de desarrollador${NC}.")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}4${NC}. ${YELLOW}Regresa al menú principal de [${GREEN}Configuración${NC}], ${YELLOW}busca y entra en${NC}: [${GREEN}Sistema${NC}].")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}5${NC}. ${YELLOW} Ahora da click en: ${NC}[${GREEN}Opciones avanzadas${NC}] ${YELLOW}y entra en [${GREEN}Opciones para desarrolladores${NC}].")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}6${NC}. ${YELLOW}Habilita ${NC}[${GREEN}Depuración por USB${NC}].")")"
    # Instrucciones para depuración inalámbrica
    type_text "$(print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra${NC}.")")"
    type_text "$(print_color yellow "$(justify_text "${GREEN}7${NC}. ${YELLOW}Selecciona donde dice${NC}:")")"
    type_text "$(print_color green "$(justify_text " Vincular dispositivo con código de sincronización${NC}")")"
    type_text "$(print_color yellow "$(justify_text "  Selecciona ahora en:${NC}")")"
    type_text "$(print_color green "$(justify_text "   Vincular con dispositivo${NC}")")"
    type_text "$(print_color blue "$(justify_text "    Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")")"
    type_text "$(print_color blue "$(justify_text "    Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345")")"
    # Nota adicional
    type_text "$(print_color cyan "$(justify_text "Para hacer la conexión correctamente:")")"
    type_text "$(print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: ${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC}).")")"
    # Final
    type_text "$(print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")")"
        
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
        
    # Imprimir el mensaje justificado sin salto de línea al final
    printf "$(print_color yellow "$(justify_text "\nIngrese el código de vinculación de WI-FI${NC}: ")")"
    # Leer la entrada del usuario en la misma línea
    read seleccion
}
simular_escritura