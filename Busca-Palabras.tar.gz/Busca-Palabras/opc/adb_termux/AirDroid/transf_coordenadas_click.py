def hex_to_decimal(hex_value, pos):
    # Convierte una cadena hexadecimal en su valor decimal
    return int(hex_value, 16)

def obtener_input(pos):
    # Solicitar al usuario el valor hexadecimal, asegurándose de que no esté vacío
    while True:
        hex_value = input(f"Ingrese un valor {pos}: ")
        if hex_value:  # Verifica si el campo no está vacío
            return hex_value
        else:
            print("El valor no puede estar vacío. Inténtalo de nuevo.")

# Solicitar los valores hexadecimales para las posiciones
hex_x = obtener_input("ABS_MT_POSITION_X")
hex_y = obtener_input("ABS_MT_POSITION_Y")

# Convierte los valores
decimal_x = hex_to_decimal(hex_x, "ABS_MT_POSITION_X")
decimal_y = hex_to_decimal(hex_y, "ABS_MT_POSITION_Y")

# Imprime los resultados
print(f"El valor hexadecimal {hex_x} en decimal es: {decimal_x}")
print(f"El valor hexadecimal {hex_y} en decimal es: {decimal_y}")