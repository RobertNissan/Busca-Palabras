# verificador ee uso de gpu o cpu por apps
adb shell dumpsys gpu | grep -A 8 "com.android.systemui"

# Desactivar Vsync:
adb shell setprop debug.hwui.disable_vsync true
# Forzar el dibujo:
adb shell setprop debug.hwui.force_draw true
# Activar superposición de hardware:
adb shell setprop debug.hwui.overdraw true
# Activar perfilado de GPU:
adb shell setprop debug.hwui.profile true
# Configurar la tasa de refresco:
adb shell setprop debug.hwui.refresh_rate 90.0
# Desactivar renderizado de regiones sucias:
adb shell setprop debug.hwui.render_dirty_regions false
# Configurar el renderizador a Skia con Vulkan:
adb shell setprop debug.hwui.renderer skiavk

# Estos comandos son utilizados para ajustar el comportamiento del subsistema gráfico en Android, específicamente el componente hwui (Hardware-Accelerated UI), que gestiona el renderizado de la interfaz de usuario utilizando la GPU.

# verificaciónes y muestras
adb shell getprop | grep debug.hwui
[debug.hwui.disable_vsync]: [true]
[debug.hwui.force_draw]: [true]
[debug.hwui.overdraw]: [true]
[debug.hwui.profile]: [true]
[debug.hwui.refresh_rate]: [90.0]
[debug.hwui.render_dirty_regions]: [false]
[debug.hwui.renderer]: [skiavk]

# Verificar si el renderizado forzado en GPU está activado
adb shell getprop debug.hwui.force_gpu_rendering
# Verificar la densidad de pantalla actual
adb shell wm density
# Verificar el intervalo de Vsync
adb shell service call SurfaceFlinger 1035
# Verificar si las superposiciones de hardware están activadas
adb shell getprop debug.hwui.overdraw
# Verificar el tamaño de caché grande de texto (altura)
adb shell getprop debug.hwui.text_large_cache_height
# Verificar el tamaño de caché grande de texto (ancho)
adb shell getprop debug.hwui.text_large_cache_width
# Verificar el tamaño del caché de buffer R
adb shell getprop debug.hwui.r_buffer_cache_size


adb shell setprop debug.hwui.force_gpu_rendering true
adb shell wm density 280 # Puedes probar con valores menores, como 240 o 200
adb shell service call SurfaceFlinger 1035 i32 1
adb shell setprop debug.hwui.overdraw false
adb shell setprop debug.hwui.text_large_cache_height 4096
adb shell setprop debug.hwui.text_large_cache_width 4096
adb shell setprop debug.hwui.r_buffer_cache_size 48

## en prueba máxima
# Activar el modo de juego en el dispositivo (si está disponible)
# Algunos dispositivos tienen un "modo gamer" o "modo de alto rendimiento" que puede activarse. Sin embargo, la disponibilidad de esta opción varía según la marca y el modelo, y no siempre es posible habilitarlo mediante comandos ADB. Aquí tienes algunos comandos generales para intentarlo:
adb shell settings put global settings_game_mode 1
adb shell settings put global settings_gamer_mode_on 1
# Modificar ajustes de settings para modos de rendimiento específicos
# lgunos dispositivos permiten ajustes en settings que pueden activar el "modo gamer" o el modo de alto rendimiento:
adb shell settings put global settings_gaming_mode 1
adb shell settings put global game_performance_boost 1
adb shell settings put global game_mode 1

# Optimizar un juego usando su nombre de paquete, en este caso citra y ppsspp
adb shell device_config put game_overlay org.citra.emu mode=2,downscaleFactor=0.4:mode=3,downscaleFactor=0.6
adb shell device_config put game_overlay org.ppsspp.ppssppgold mode=2,downscaleFactor=0.4:mode=3,downscaleFactor=0.6
# Modo de rendimiento fijo
adb shell cmd power set-fixed-performance-mode-enabled true

# adb shell getprop | grep vulkan  # Verificar compatibilidad de Vulkan
adb shell setprop debug.hwui.renderer skiavk  # Forzar el uso de Vulkan en el renderizador
adb shell su -c "setprop persist.graphics.vulkan 1" # Activar Vulkan en sistemas con soporte

# Asegurar que el Modo de Desempeño Esté Habilitado en Configuraciones Ocultas
# Algunos fabricantes tienen configuraciones de rendimiento ocultas que puedes intentar habilitar:
adb shell settings put global high_performance_mode 1
adb shell settings put global performance_profile 1

adb shell setprop debug.sf.hw 1
adb shell setprop debug.performance.tuning 1
adb shell su -c "setprop video.accelerate.hw 1"

# Forzar MSAA 4x (en opciones ee desarrolladores): Esto aumenta la calidad de los gráficos en algunos juegos.
adb shell settings put global enable_msaa_for_apps 1

adb shell setprop debug.performance.profile 1
# Comandos para actualizar el teléfono (estos ayudan a actualizar las aplicaciones del teléfono con un poco de potencia)
adb shell cmd package compile -m speed-profile -a
adb shell cmd package bg-dexopt-job
adb shell pm trim-caches 999999999999999999

# Aumentar el tamaño de la caché de gráficos (Gralloc Buffer)
# Este ajuste permite aumentar el tamaño del buffer de gráficos, útil para juegos pesados o aplicaciones gráficas intensas. Ten en cuenta que esto puede requerir acceso root.
adb shell setprop debug.gralloc.enable_fb_ubwc 1

# Forzar el renderizado de gráficos en modo de 64 bits
# Si tienes una GPU que admite operaciones de 64 bits, forzar a las aplicaciones a usar esta arquitectura puede mejorar el rendimiento en dispositivos modernos:
adb shell su -c setprop ro.product.cpu.abilist64 "arm64-v8a"

# Ajustar las particiones de texturas
# El ajuste de particiones de texturas ayuda a la GPU a manejar texturas de alta resolución de manera más eficiente:
adb shell setprop debug.sf.latch_unsignaled 1

adb shell setprop debug.vulkan.swapinterval 1

# Mejorar la velocidad de renderizado de la interfaz con una mayor frecuencia de cuadros (fps):
# Aunque no siempre es recomendable forzar un cambio aquí, este comando puede ser útil si deseas una mayor frecuencia de cuadros (fps) en la interfaz de usuario.
adb shell setprop debug.sf.framebuffer.format rgba8888 

# Aumentar el tamaño de la caché de GPU Render Thread
# Aumentar el tamaño de caché en el hilo de renderizado de la GPU puede ayudar en situaciones de gráficos intensivos:
adb shell setprop debug.hwui.raster_cache_size 24

# Aumentar la Velocidad de Renderizado en Hardware de UI
adb shell su -c setprop ro.hwui.fbo_cache_size 12
adb shell su -c setprop ro.hwui.vbo_cache_size 8
# Estos comandos aumentan el tamaño del caché de Frame Buffer Objects (FBO) y Vertex Buffer Objects (VBO), ayudando a mejorar el rendimiento en aplicaciones gráficas complejas.

## fin de prueba máxima

adb shell dumpsys gfxinfo org.citra.emu


# Tip for performance (ADB)
# If the game works horribly on low settings for you as it does for me, and if you don't mind downgraded and pixel-ish graphics, you can use this ADB command to downgrade the visuals and enhance performance.
# So as to use ADB, you need to enable USB Debugging on your developer settings, and install the Android SDK on your PC. Then, in your command line type:
adb shell cmd game downscale [0.3|0.4|0.5|0.6|0.7|0.8|0.9|disable] com.nianticlabs.monsterhunter
# Hope this works for you guys.

# Alternatively, if you find that when you restart the game it goes back to normal resolution, you can try typing:
adb shell device_config put game_overlay com.nianticlabs.monsterhunter mode=[2 | 3],downscaleFactor=[number from 0.3 - 0.9]
# Where mode=2 is "Performance" and mode=3 is "Battery Saver".
# Source is Game Mode Intervention in the official Android documentation.

# Este consejo sugiere cómo usar comandos adb para reducir la calidad gráfica y mejorar el rendimiento en juegos en dispositivos Android. Aquí tienes una explicación y cómo aplicarlo:
# Paso 1: Preparativos
# Paso 2: Comandos para Mejorar el Rendimiento
# Reducir la Escala de Gráficos Globalmente (Temporario): Puedes usar el siguiente comando adb para reducir la resolución del juego, lo que hace que los gráficos se vean menos detallados, pero aumenta el rendimiento.
adb shell cmd game downscale [0.3|0.4|0.5|0.6|0.7|0.8|0.9|disable] org.citra.emu
# Cambia [0.3|0.4|0.5|...] con el valor que prefieras. Por ejemplo, 0.5 reduce la calidad al 50%, mientras que 0.8 lo hace al 80%.
# disable revierte la configuración a la resolución normal.

# Establecer la Reducción de Escala Permanente: Si al reiniciar el juego la configuración se restaura a la resolución original, puedes establecer una configuración de escalado permanente.
adb shell device_config put game_overlay org.citra.emu mode=[2 | 3],downscaleFactor=[número entre 0.3 - 0.9]
# mode=2 es el modo "Rendimiento", donde se prioriza la velocidad.
# mode=3 es el modo "Ahorro de batería", que conserva la batería bajando la resolución aún más.
# Cambia [número entre 0.3 - 0.9] por el valor deseado. Un valor de 0.7 reduce la resolución al 70%, mientras que 0.9 apenas reduce la calidad visual.
# Ejemplo de Configuración Permanente

# Si quieres reducir la resolución al 80% en el modo de "Ahorro de batería", usa:
adb shell device_config put game_overlay org.citra.emu mode=3,downscaleFactor=0.8
# Esta configuración mantendrá la reducción de escala cada vez que abras el juego, mejorando el rendimiento al reducir el uso de recursos gráficos.



adb shell su -c setprop persist.sys.ui.hw true
adb shell su -c setprop ro.vendor.dfrc.use_triple_buffering 1
adb shell setprop debug.sf.disable_composition_sync true
adb shell setprop debug.hwui.render_offscreen false
adb shell setprop debug.hwui.compilation_mode performance
adb shell setprop debug.hwui.texture_compression etc2
adb shell setprop debug.hwui.low_overdraw true
adb shell setprop debug.hwui.on_demand_rendering true
# mantener una tasa de FPS más constante. Esto
adb shell setprop debug.sf.latch_unsignaled 1
# Configuración de la GPU para Prioridad de Alto Rendimiento
# Si tu dispositivo lo soporta, puedes intentar habilitar esta configuración para priorizar el rendimiento gráfico:
adb shell setprop debug.sf.high_fps_enabled 1
adb shell setprop debug.performance.tuning 1

# ultimas pruebas usadas
# Forzar el Compilador JIT (Just-In-Time)
# Este ajuste puede ayudar a mejorar el rendimiento general del sistema, incluyendo la estabilidad de FPS en juegos y aplicaciones exigentes.
adb shell su -c "setprop dalvik.vm.usejit true"
adb shell su -c "setprop persist.sys.ui.buffer.size 8"

adb shell settings put global cpu_boost 1
adb shell settings put global gpu_boost 1
adb shell settings put global system_ui_boost 1
adb shell settings put global game_boost 1
adb shell setprop debug.performance.tuning 1

# Activar Vulkan en modo de alto rendimiento (si el dispositivo lo permite):
adb shell setprop debug.vulkan.debug 1
adb shell setprop debug.vulkan.max_queues 8

# Habilitar un límite mayor en la memoria de la GPU:
adb shell setprop debug.vulkan.memory 1

# Habilitar el uso de Vulkan SKIA (Si está disponible en tu dispositivo):
adb shell setprop debug.skia.vulkan 1

# Activar perfiles de GPU de alto rendimiento:
adb shell setprop debug.gpu.profiler 1

# Optimización de la sincronización y la latencia
adb shell setprop debug.vulkan.synchronous 0

# **Limpiar cachés de gráficos**:
# A veces, limpiar cachés de gráficos puede tener un impacto positivo:
adb shell pm clear com.android.providers.media

# Forzar la GPU a funcionar a frecuencias más altas (aunque esto puede variar según el dispositivo):
adb shell su -c setprop persist.sys.gpu.boost 1
adb shell su -c setprop persist.sys.gpu.level 4
# Forzar el uso de Vulkan en aplicaciones específicas
adb shell su -c setprop persist.sys.opengles.vulkan.force 1
# **Configurar el modo de rendimiento de la CPU y la GPU**:
# Si tu dispositivo lo permite, cambia a un modo de rendimiento:
adb shell su -c setprop persist.sys.perf_mode high

# Para dispositivos con 3 GB o más RAM
adb shell su -c setprop dalvik.vm.heapstartsize 8m
adb shell su -c setprop dalvik.vm.heapgrowthlimit 256m
adb shell su -c setprop dalvik.vm.heapsize 512m
adb shell su -c setprop dalvik.vm.heaptargetutilization 0.75
adb shell su -c setprop dalvik.vm.heapminfree 512k
adb shell su -c setprop dalvik.vm.heapmaxfree 8m
# verificar las configuraciónes de dalvik.vm agregadas
adb shell getprop | grep dalvik.vm

# Optimización adicional (solo para Vulkan): Revisa configuraciones adicionales para Vulkan si estás utilizando apps o juegos que dependan de Vulkan:
adb shell settings put global enable_vulkan 1
adb shell settings put global vulkan_debug 0
# adb shell su -c setprop persist.sys.performance.fg_app <package_name>
adb shell su -c setprop persist.sys.performance.fg_app xyz.aethersx2.android

# Priorizar ciclos de CPU
# Esto asegura que la CPU priorice la aplicación activa:
adb shell su -c setprop persist.sys.use_first_cpu_cluster true
adb shell su -c setprop persist.sys.performance true
adb shell su -c setprop persist.vendor.sys.perf_hint true
 
 # Ajustar un perfil térmico existente
# Algunos dispositivos con procesadores Snapdragon (por ejemplo, Qualcomm) permiten seleccionar perfiles térmicos si tienen habilitados ciertos servicios. Si esto aplica a tu dispositivo, podrías usar un comando similar, pero con un perfil válido:
adb shell su -c "setprop persist.sys.performance gaming"
# Esto asume que el perfil gaming está definido en tu sistema.

 : '
 # Para dispositivos con 4 GB o más RAM
adb shell su -c setprop dalvik.vm.heapstartsize 16m
adb shell su -c setprop dalvik.vm.heapgrowthlimit 512m
adb shell su -c setprop dalvik.vm.heapsize 1024m
adb shell su -c setprop dalvik.vm.heaptargetutilization 0.75
adb shell su -c setprop dalvik.vm.heapminfree 2m
adb shell su -c setprop dalvik.vm.heapmaxfree 16m
: '

# En Android 10, de forma predeterminada, todas las aplicaciones están configuradas para usar el controlador de gráficos del sistema predeterminado. También se podía seleccionar el tipo de controlador (predeterminado, juego o sistema) desde un menú que usaría una aplicación al ejecutarse. En Android 11, esa opción no está disponible (a partir del 16 de junio de 2021).
# Sin embargo, en Android 11 puedes cambiar esto manualmente y habilitar el "controlador de desarrollador" para tus preferencias de gráficos para cualquier aplicación que use ADB.
# Código:
adb shell settings put global game_driver_opt_in_apps com.package.name
# Para agregar más de una aplicación al valor de configuración, probablemente tengas que separar los nombres de los paquetes con una coma o un punto y coma. Una vez que hayas terminado con ese paso, ejecuta el siguiente comando.
# Código:
adb shell settings put global game_driver_prerelease_opt_in_apps com.package.name
adb shell settings put global game_driver_prerelease_opt_in_apps org.ppsspp.ppssppgold,org.dolphinemu.mmjr,org.citra.emu,xyz.aethersx2.android
# A continuación, reinicia el dispositivo. Ingresa a configuración, sistema, avanzado, configuración de desarrollador y elige "Preferencias de controlador de gráficos". Asegúrate de que la aplicación que elegiste en el primer paso tenga seleccionado el "controlador de desarrollador". Ten en cuenta que la opción no estará presente en el menú desplegable al seleccionar la aplicación en las preferencias del controlador de gráficos. Todas las demás aplicaciones deberían decir "predeterminado".


# Usa la configuración de shell de adb para habilitar las capas:
adb shell settings put global enable_gpu_debug_layers 1

# Especifica la aplicación de destino para habilitar las capas:
adb shell settings put global gpu_debug_app xyz.aethersx2.android

adb shell settings put global gpu_debug_layers VK_LAYER_KHRONOS_validation

# Especifica uno o más paquetes para buscar capas dentro de lo siguiente:
adb shell settings put global gpu_debug_layer_app org.ppsspp.ppssppgold:org.dolphinemu.mmjr:org.citra.emu:xyz.aethersx2.android
  

