#!/bin/bash

echo "Dispositivos disponibles:"
dispositivos=$(adb devices)

if ! echo "$dispositivos" | grep -q "device"; then
    echo "No se ha detectado ningun dispositivo. Asegurate de que tu dispositivo este conectado y la depuracion USB este habilitada."
    echo "Para habilitar la depuracion USB en Android:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB y tambien la Depuracion inalambirca, y siga las instrucciones de conexion'."
    exit 1
fi

while true; do
    adb devices
    read -p "Ingrese el numero del dispositivo o 'q' para salir: " dispositivo

    if [ "$dispositivo" == "q" ]; then
        break
    fi

    # Verificar si el dispositivo esta en la lista de dispositivos
    if ! echo "$dispositivos" | grep -q "$dispositivo"; then
        echo "El dispositivo no se encuentra en la lista. Por favor, ingrese un dispositivo valido."
        continue
    fi

    while true; do
        echo "Ingrese el numero de la opcion deseada:"
        echo "1 - Deshabilitar aplicaciones"
        echo "2 - Habilitar aplicaciones"
        echo "3 - Volver a seleccionar dispositivo"
        echo "4 - Salir"

        read -p "Seleccione una opcion: " opcion

        case $opcion in
            1)
                read -p "Ingrese el nombre del paquete de la aplicacion que desea deshabilitar (deje en blanco para volver): " paquete
                if [ -z "$paquete" ]; then
                    break
                elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
                    adb -s "$dispositivo" shell pm disable-user --user 0 "$paquete"
                    echo "Aplicacion deshabilitada correctamente."
                else
                    echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
                fi
                ;;
            2)
                read -p "Ingrese el nombre del paquete de la aplicacion que desea habilitar (deje en blanco para volver): " paquete
                if [ -z "$paquete" ]; then
                    break
                elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
                    adb -s "$dispositivo" shell pm enable "$paquete"
                    echo "Aplicacion habilitada correctamente."
                else
                    echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
                fi
                ;;
            3)
                break
                ;;
            4)
                exit 0
                ;;
            *)
                echo "Opcion invalida. Por favor, seleccione 1, 2, 3 o 4."
                ;;
        esac
    done
done
