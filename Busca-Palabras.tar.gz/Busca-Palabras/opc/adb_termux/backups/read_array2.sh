#!/bin/bash

app=()  # Inicializa el array

echo "Ingrese los elementos, presione Ctrl+D cuando termine:"
while IFS= read -r linea; do
    app+=("$linea")
done

# Crea el array 'array_app'
array_app=("${app[@]}")

# Imprime el array 'array_app' usando un bucle for
echo "Elementos en 'array_app':"
for elemento in "${array_app[@]}"; do
    echo "$elemento"
done
