#!/bin/bash

# Verificar si la interfaz wlan0 esta conectada al router
if ip addr show wlan0 &> /dev/null && ip addr show wlan0 | grep -q "inet "; then
    ip0=$(ip addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)
else
    ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
fi

if [ "$ip0" ]; then
    echo "La direccion IP wlan0 es: $ip0"
else
    echo "La direccion IP datos es: $ip1"
fi
