#!/bin/bash

ingresos=()  # Inicializa el array

echo "Ingrese los ingresos, presione Ctrl+D cuando termine:"
while IFS= read -r linea; do
    ingresos+=("$linea")
done

# Imprime el array
echo "Ingresos:"
for elemento in "${ingresos[@]}"; do
    echo "$elemento"
done
