#!/bin/bash 
# Termux
# sudo adb -s 127.0.0.1 tcpip 5555
# sudo adb -s emulator-5554 tcpip 5555
# adb -s emulator-5554 tcpip 5555

if [ -x ${PREFIX}/bin/python ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python"
apt install python -y
fi

# killall adb
PWD=$(pwd)

if [ -x "$PREFIX/bin/adb" ]; then
     echo "adb instalado" >/dev/null 2>&1
 else
     echo "Instalando adb"
     pkg install android-tools -y >/dev/null 2>&1
     echo "adb instalado correctamente"
 fi
 if [ -x "$PREFIX/bin/nmap" ]; then
     echo "nmap instalado" >/dev/null 2>&1
 else
     echo "Instalando nmap"
     pkg install nmap -y >/dev/null 2>&1
     echo "nmap instalado correctamente"
 fi
 
echo ""
echo "Brand ID: $(getprop ro.product.system.brand)"
echo "Modelo: $(getprop ro.product.model)"
echo "Version de Android: $(getprop ro.build.version.release)"
echo "Model ID: $(getprop ro.build.product)"
echo "Kernel ID: $(uname -r)"
echo "Chipset ID: $(getprop ro.product.board)"
echo "Architecture: $(uname -m)"

str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
ip=$(echo "${str%%/*}")
 
# Ejecuta el siguiente comando para desbloquear los FPS a 120:
# adb -s emulator-5554 shell su -c settings put global 0.0_fps_max 120

function connect {
    echo "Conectando adb, por favor, espere..."

    ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    num_threads=5

    # Definir el script de Python con threading
python_script=$(cat <<EOF
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

ip_objetivo = "$ip_objetivo"
num_threads = 10  # Puedes ajustar este valor segun tus necesidades

def scan_ports(ip, port_range):
    nm = nmap.PortScanner()
    result = nm.scan(ip, arguments=f'-p {port_range} -Pn -T4')

    if 'scan' not in result or ip not in result['scan']:
        print("\nError al obtener los resultados del escaneo para la IP:", ip)
        print("Asegurate de que la IP sea valida y responda a los escaneos de puertos.")
    else:
        if nm[ip].all_protocols():
            for protocol in nm[ip].all_protocols():
                lport = sorted(nm[ip][protocol].keys())
                for port in lport:
                    print("Puerto", port, ":", nm[ip][protocol][port]['state'])
        else:
            print("\nNo se encontraron puertos abiertos para la IP:", ip)

# Dividir el rango de puertos para escanear en varias partes
port_ranges = [(i, i + 65535//num_threads) for i in range(1, 65536, 65535//num_threads)]

# Lista para almacenar los resultados de los hilos
results = []

# Realizar el escaneo de puertos en hilos separados
with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = [executor.submit(scan_ports, ip_objetivo, f'{start}-{end}') for (start, end) in port_ranges]

    # Obtener los resultados de los hilos
    for future in concurrent.futures.as_completed(futures):
        results.append(future.result())

# Imprimir los resultados
for result in results:
    if result is not None:
        print(result)
EOF
)

ports_output=$(python -c "$python_script")

# echo -e "Puertos preparados:\n$ports_output"
if echo "$ports_output" | grep -q "open"; then
    num_ports=$(echo "$ports_output" | grep "open" | awk '{print $2}')
#     
    for port in $num_ports; do
        echo "Probando puerto: $port"
        adb start-server >/dev/null 2>&1
        verif_con=$(adb connect "${ip_objetivo}:${port}")
        # echo "Probando conexion adb: $verif_con"

        if [[ "$verif_con" == *"connected"* ]]; then
            echo "La conexion fue exitosa."
            adb -s "${ip_objetivo}:${port}" tcpip 5555
            adb connect "${ip}:5555" >/dev/null 2>&1
            sleep 5
            seleccionar_dispositivo
            exit
        elif [[ "$verif_con" == *"offline"* && "$verif_con" == *"not found"* ]]; then
            adb kill-server >/dev/null 2>&1
            continue
        elif [[ "$verif_con" == *"failed"* ]]; then
            adb kill-server >/dev/null 2>&1
            continue
        else
            echo -e "La conexion fallo. Mensaje: $verif_con"
        fi
    done
fi

exit 2
}

 
function mostrar_instrucciones {
    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    #sleep 3
    echo "Habilitar la depuracion USB en Android, para hacer conexion adb:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB'."
    echo ""
    echo 'Si solo necesitas que se active en tu android, activa "Depuracion inalambirca"'
    echo '6. Selecciona donde dice: "Vincular dispositivo con codigo de sincronizacion"'
    echo -e  'En ta parte se mostrara una pequena ventana que dice:'
    echo -e "Vincular con disposivo\nCodigo de vinculacion de WI-FI\n123456\nDireccion IP y puerto\n${ip}:12345"
    echo '7. Habilitar la pantalla dividida entre "Vincular dispositivo con codigo de sincronizacion" y "Termux"' 
    
    
    ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    if ip addr show wlan0 &> /dev/null && ip addr show wlan0 | grep -q "inet "; then
        ip0=$(ip addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)
    else
        ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
    fi
    if [ "$ip0" ]; then
        echo "La direccion IP wlan0 es: $ip0" >/dev/null 2>&1
    else
        echo "La direccion IP datos es: $ip1" >/dev/null 2>&1
    fi
    
    
    if [[ "$ip0" ]]; then
        conn=$(adb connect "$ip:5555")
        #echo $conn
        #read
        if [[ "$conn" == "failed"* ]]; then
            echo "ok" >/dev/null 2>&1
        else
            echo "Conexion a Internet a traves del enrutador WiFi"
            conn=$(adb connect "${ip0}:5555")
            sleep 3
            seleccionar_dispositivo
        fi
        fi
        
        : '
        if [ "$ip1" == "$ip" ]; then
            echo "Conexion a Internet a traves del enrutador WiFi"
            conn=$(adb connect "127.0.0.1:5555")
            sleep 3
            seleccionar_dispositivo
        fi
        : '
         
    if [ "$ip0" == "$ip" ]; then
        echo "Conexion a Internet a traves del enrutador WiFi"
        
        #on/off Datos Mobiles
        # adb shell svc data disable
        # adb shell svc data enable
        if [ -x $PREFIX/share/doc/termux-api ]; then
            echo Existe >/dev/null 2>&1
        else 
            echo "Instalando termux-api"
            pkg install termux-api
        fi
        if [ -e ${HOME}/Termux_API_0.50.1.apk ]; then 
            echo "Ya esta descargado" >/dev/null 2>&1
            xdg-open ~/Termux_API_0.50.1.apk
        else
            echo -e ""
            echo "Descargando Termux_API_0.50.1"
            echo -e ""
            cd ${HOME};wget https://www.dropbox.com/s/ul0wj8yud8mq03f/Termux_API_0.50.1.apk
            mkdir -p /sdcard/Download
            cp -r ~/Termux_API_0.50.1.apk /sdcard/Download/ >/dev/null 2>&1
            xdg-open ~/Termux_API_0.50.1.apk
        fi
     
        # adb shell dumpsys wifi
        # adb -s emulator-5554 shell dumpsys netstats
        #WiFi on/off
        # termux-wifi-enable false
        # termux-wifi-enable true
        #sleep 3
        
        if [ "$ip1" == "$ip" ]; then
            echo "Conexion a Internet a traves del enrutador WiFi"
            conn=$(adb connect "${ip1}:5555")
            sleep 3
            seleccionar_dispositivo
        fi
    
        echo "Ingresa el puerto"
        #echo "aqui"
        read -p "$ip:" puerto
        while [ -z "$puerto" ]; do
            read -p "$ip:" puerto
        done
        
        dispositivos=$(adb devices)
        echo -e ""
        # Inicializar listas
        dispositivos_disponibles=()
        dispositivos_offline=()
        dispositivos_no_autorizados=()
         
        # Filtrar dispositivos autorizados (device)
d=$(echo "$dispositivos" | grep -E "device" | grep -v "List")
 
if [ -n "$d" ]; then
    echo "Dispositivos disponibles:"
    for linea in $d; do
        if [ "$linea" == "device" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
            # En Windows
            adb -s %linea% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
            # En Linux
            modelo=$(adb -s "$linea" shell 'echo -e "\033[34m$(getprop ro.product.model)\033[0m" | fmt -w 40')
        fi
        #echo "$linea device $modelo"
        # Agregar a la lista
        dispositivos_disponibles+=("$linea")
        echo -n "Ingrese codigo  de emparejamiento:"
        resultado=$(adb pair "${linea}:${puerto}" 2>&1)  # Capturar la salida del comando y el error

        if [[ "$resultado" == *"Failed"* ]]; then
            echo "La conexion fallo. Mensaje: $resultado"
            exit
        else
            echo "La conexion fue exitosa."
            connect
        fi    
        vacios=$(echo "No.")
    done
else
    vacios=$(echo "No hay dispositivos disponibles.")
    #return  # Utilizar return en lugar de break
fi
 
# Filtrar dispositivos offline
dispositivos_off=$(adb devices | grep -E 'offline' | grep -v "List" | cut -d ' ' -f1-)

if [ -n "$dispositivos_off" ]; then
    echo "Dispositivos offline:"
    for linea1 in $dispositivos_off; do
        if [ "$linea1" == "offline" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
            # En Windows
            adb -s %linea1% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
           # En Linux
           adb -s "$linea1" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40'
        fi
        echo "$linea1 offline"
        # Agregar a la lista
        dispositivos_offline+=("$linea1")
        vacios1=$(echo "No.")
    done
else
    vacios1=$(echo "No hay dispositivos offline.")
    #return  # Utilizar return en lugar de break
fi

# Filtrar dispositivos no autorizados (unauthorized)
dispositivos_unauthorize=$(adb devices | grep -E 'unauthorized' | grep -v "List" | cut -d ' ' -f1-)

if [ -n "$dispositivos_unauthorize" ]; then
    echo "Dispositivos no autorizados:"
    for linea2 in $dispositivos_unauthorize; do
        if [ "$linea2" == "unauthorized" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
            # En Windows
            adb -s %linea2% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
           # En Linux
           adb -s "$linea2" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40'
        fi
        echo "$linea2 unauthorized"
        # Agregar a la lista
        dispositivos_no_autorizados+=("$linea2")
        vacios2=$(echo "No.")
    done
else
    vacios2=$(echo "No hay dispositivos no autorizados.")
    #return  # Utilizar return en lugar de break
fi

        echo -n "Ingrese codigo  de emparejamiento:"
        resultado=$(adb pair "${ip}:${puerto}" 2>&1)  # Capturar la salida del comando y el error
               
        if [[ "$resultado" == *"Failed"* ]]; then
            echo "El codigo de emparejamiento: Fallo: no se puede iniciar el emparejamiento del cliente."
            echo 'Verifique que la "Depuracion inalambrica" este activada'
            exit
        else
            echo "La conexion de emparejamiento fue exitosa."
            connect
        fi
     
    else
        echo "No hay conexion a Internet a traves del enrutador WiFi"
        exit 1
    fi
        #exit 1 
     
    
}






function deshabilitar_aplicaciones {
    echo "Opcion seleccionada: Deshabilitar aplicaciones"
    # read -p "Ingrese el nombre del paquete de la aplicacion que desea deshabilitar (deje en blanco para volver): " paquete
    
    app=()  # Inicializa el array
    echo "Ingrese el paquete o los paquetes habilitar, presione Ctrl+D cuando termine:"
    while IFS= read -r linea; do
        app+=("$linea")
    done

    # Crea el array 'array_app'
    array_app=("${app[@]}")
    
    # Imprime el array 'array_app' usando un bucle for
    echo "Elementos en 'array_app':"
    for paquete in "${array_app[@]}"; do
        #echo "$paquete"
    
        if [ -z "$paquete" ]; then
            echo "Nombre del paquete vacio." 
            deshabilitar_aplicaciones
        elif [ ${#paquete} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
            deshabilitar_aplicaciones
        elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
            adb -s "$dispositivo" shell pm disable-user --user 0 "$paquete"
            echo "Aplicacion deshabilitada correctamente."
        else
            echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
            deshabilitar_aplicaciones
        fi
    done
    mostrar_menu "$dispositivo"
}

function habilitar_aplicaciones {
    echo "Opcion seleccionada: Habilitar aplicaciones"
    # read -p "Ingrese el nombre del paquete de la aplicacion que desea habilitar (deje en blanco para volver): " paquete
    
    app=()  # Inicializa el array
    echo "Ingrese el paquete o los paquetes habilitar, presione Ctrl+D cuando termine:"
    while IFS= read -r linea; do
        app+=("$linea")
    done

    # Crea el array 'array_app'
    array_app=("${app[@]}")
    
    # Imprime el array 'array_app' usando un bucle for
    echo "Elementos en 'array_app':"
    for paquete in "${array_app[@]}"; do
        #echo "$paquete"

        if [ -z "$paquete" ]; then
            echo "Nombre del paquete vacio." 
            habilitar_aplicaciones
        elif [ ${#paquete} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
            habilitar_aplicaciones
        elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
            adb -s "$dispositivo" shell pm enable "$paquete"
            echo "Aplicacion habilitada correctamente."
        else
            echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
            habilitar_aplicaciones
        fi
    done
    mostrar_menu "$dispositivo"
}

function multi_disable {
    archivo="packages.txt"
    #dispositivo="emulator-5554"
    # Obtener la lista de todos los paquetes de usuario 3
    packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

    # Aplicaciones que siempre deben estar en el archivo
    echo "com.facebook.katana" > packages.txt
    echo "com.google.android.videos" >> packages.txt
    echo "com.google.android.apps.photos" >> packages.txt
    echo "com.google.android.apps.docs" >> packages.txt

    excluidos=(
    "com.termux"
    "com.termux.api"
    "com.android.chrome"
    "com.rhmsoft.edit.pro"
    "ich.andre.partialscreen"
    "com.topjohnwu.magisk"
    "com.touchtype.swiftkey"
    "app.rvx.android.youtube"
    "com.estrongs.android.pop"
    "com.mgoogle.android.gms"
    "com.google.android.youtube"
    )

    # Bucle para cada una de las aplicaciones
    for package in $packages; do
        exclude=false
        for excluded_package in "${excluidos[@]}"; do
            if [[ "$package" == "$excluded_package" ]]; then
                exclude=true
                break
            fi
        done

        if [ "$exclude" == false ]; then
        echo "$package" >> packages.txt
        fi
    done

    contador=0 # Inicializa la variable contador a 0, que se usara para contar el numero de aplicaciones deshabilitadas.

    # Leer todas las lineas del archivo y almacenarlas en un array
    mapfile -t lineas < "$archivo"

    # Iterar sobre el array
    for linea in "${lineas[@]}"; do
        linea=$(echo "$linea" | tr -d '\r')  # Eliminar caracteres de retorno de carro
        #echo "Procesando paquete: $linea"
        if [ -z "$linea" ]; then
            echo "Nombre del paquete vacio."
        elif [ ${#linea} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        elif adb -s "$dispositivo" shell pm list packages | grep "$linea" >/dev/null 2>&1; then
            adb -s "$dispositivo" shell pm disable-user --user 0 "$linea" >/dev/null 2>&1
            echo -e "Aplicacion $linea deshabilitada correctamente.\n"
            ((contador++))
        else
            echo "Error al deshabilitar la aplicacion."
            continue
        fi
    done

    echo "Se deshabilitaron $contador aplicaciones."
    mostrar_menu "$dispositivo"
}

function multi_enable {
    archivo="packages.txt"
    # dispositivo="emulator-5554"
    # Obtener la lista de todos los paquetes de usuario 3
    packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

    # Aplicaciones que siempre deben estar en el archivo
    echo "com.facebook.katana" > packages.txt
    echo "com.google.android.videos" >> packages.txt
    echo "com.google.android.apps.photos" >> packages.txt
    echo "com.google.android.apps.docs" >> packages.txt

    excluidos=(
    "com.termux"
    "com.termux.api"
    "com.android.chrome"
    "com.rhmsoft.edit.pro"
    "ich.andre.partialscreen"
    "com.topjohnwu.magisk"
    "com.touchtype.swiftkey"
    "app.rvx.android.youtube"
    "com.estrongs.android.pop"
    "com.mgoogle.android.gms"
    "com.google.android.youtube"
    )

    # Bucle para cada una de las aplicaciones
    for package in $packages; do
        exclude=false
        for excluded_package in "${excluidos[@]}"; do
            if [[ "$package" == "$excluded_package" ]]; then
                exclude=true
                break
            fi
        done

        if [ "$exclude" == false ]; then
            echo "$package" >> packages.txt
        fi
    done

    contador=0 # Inicializa la variable contador a 0, que se usara para contar el numero de aplicaciones habilitadas.

    # Leer todas las lineas del archivo y almacenarlas en un array
    mapfile -t lineas < "$archivo"

    # Iterar sobre el array
    for linea in "${lineas[@]}"; do
        linea=$(echo "$linea" | tr -d '\r')  # Eliminar caracteres de retorno de carro
        #echo "Procesando paquete: $linea"
        if [ -z "$linea" ]; then
            echo "Nombre del paquete vacio."
        elif [ ${#linea} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        elif adb -s "$dispositivo" shell pm list packages | grep "$linea" >/dev/null 2>&1; then
            adb -s "$dispositivo" shell pm enable "$linea" >/dev/null 2>&1
            echo -e "Aplicacion $linea habilitada correctamente.\n"
            ((contador++))
        else
            echo "Error al habilitar la aplicacion."
            continue
        fi
    done
    echo "Se habilitaron $contador aplicaciones."
    mostrar_menu "$dispositivo"

}


function verif_conn_router {
    ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    if ip addr show wlan0 &> /dev/null && ip addr show wlan0 | grep -q "inet "; then
        ip0=$(ip addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)
    else
        ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
    fi
     if [ "$ip0" ]; then
        echo "La direccion IP wlan0 es: $ip0" >/dev/null 2>&1
    else
        echo "La direccion IP datos es: $ip1" >/dev/null 2>&1
     fi
}












function seleccionar_dispositivo {
    $1  # Aqui estamos llamando a la funcion  verif_conn_router que  pasamos como parametro
    
    str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
    ip=$(echo "${str%%/*}")
    
    mensaje_mostrado="false"
    conectado="false"
    conectado2="false"
    dispositivos=$(adb devices)
    echo -e ""
  
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($columns*7/100))
    mul2=$(($columns*47/100))
    mul3=$(($columns*27/100))
    mul4=$(($columns*9/100))

    ID="[ID]"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 

    # Inicializar listas
    dispositivos_disponibles=()
    dispositivos_offline=()
    dispositivos_no_autorizados=()
    modelo_d=()
    # Contador para el indice
    indice=1
    # Filtrar dispositivos autorizados (device)
    d=$(echo "$dispositivos" | grep -E "device" | grep -v "List") 
     

    if [ -n "$d" ]; then
        echo "Dispositivos disponibles:"
        printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
        PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')" 
        echo "$PRINTF_RESULT" 
        for linea in $d; do
           # echo $linea 
           # read
            if [ "$linea" == "device" ]; then
                 continue
            fi
            # Obtener el sistema operativo actual
            sistema_operativo=$(uname -s)
            if [[ "$sistema_operativo" == *"Windows"* ]]; then
                # En Windows
                adb -s %linea% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
            else
                # En Linux               
                in=$(adb connect "$linea")
                # in1=$(adb connect "$ip:5555")
                modelo_verif=$(adb -s "$linea" shell 'echo -e "$(getprop ro.product.model)"') 
                
                ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
                if ip addr show wlan0 &> /dev/null && ip addr show wlan0 | grep -q "inet "; then
                    ip0=$(ip addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)
                else
                    ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
                fi
                if [ "$ip0" ]; then
                    echo "La direccion IP wlan0 es: $ip0" >/dev/null 2>&1
                else
                    echo "La direccion IP datos es: $ip1" >/dev/null 2>&1
                 fi
    
                 # printf "$ip0\n"
                 # printf "$ip1\n"
                if [ "$ip0" == "$ip" ]; then
                    if [ "$conectado" == "false" ]; then
                        conn=$(adb connect "${ip0}:5555")
                        conectado="true"
                        #read
                        if [[ "$conn" == "failed"* ]]; then
                            echo "ok" >/dev/null 2>&1
                            conectado="true"
                        else
                            echo "Conexion a Internet a traves del enrutador WiFi" >/dev/null 2>&1 
                            conectado="true"
                            #seleccionar_dispositivo
                        fi
                    fi
                fi
                
                
                if [[ "$modelo_verif" == *"offline"* || "$in" == *"failed to connect to"* ]]; then
                    dispositivos_offline+=("$linea")
                    continue
                fi
                #if [ "$in" == *"failed to connect to"* ]; then
                    #dispositivos_offline+=("$linea")
                    #continue
                #fi
                install=("$linea")
               modelo=$(adb -s "$linea" shell 'echo -e "$(getprop ro.product.model)"' 2>&1) 
               version=$(adb -s "$linea" shell 'echo -e "$(getprop ro.build.version.release)"' 2>&1) 
            fi
            # Formatear el indice con un cero a la izquierda si es necesario
            indice_formateado=$(printf "%02d" "$indice")     
            # Construir el modelo con indice y agregar a la lista
            modelo=("[${indice_formateado}]" "$linea" "$modelo" "v$version")
            #echo "${modelo[@]}"
            # Agregar a la lista
            dispositivos_disponibles+=("$linea")
            # No hay dispositivos vacios
            vacios=$(echo "No.")           
            # Incrementar el indice
            ((indice++))
            # bucle para recorrer el array por filas
            for ((i=0;i<${#modelo[@]};i+=4)); do
               # imprimir linea de encabezado
               printf "#%s#\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  
              # contar caracteres
              char_count=$(printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" "${modelo[i]}" "${modelo[i+1]}" "${modelo[i+2]}" "${modelo[i+3]}")
 
                # ajustar ancho de la segunda columna
                for j in {1..301}; do
                    medida=$((${#char_count} + $j))
                    if [[ "$medida" -eq "$columns" ]]; then
                        mul2=$(($mul2 + $j))
                        char_count=$(printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" "${modelo[i]}" "${modelo[i+1]}" "${modelo[i+2]}" "${modelo[i+3]}")
                    fi
                    medida=$((${#char_count} - $j))
                    if [[ "$medida" -eq "$columns" ]]; then
                        mul2=$(($mul2 - $j))
                        char_count=$(printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" "${modelo[i]}" "${modelo[i+1]}" "${modelo[i+2]}" "${modelo[i+3]}")
                    fi   
                done

            char_count=$(printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" "${modelo[i]}" "${modelo[i+1]}" "${modelo[i+2]}" "${modelo[i+3]}")
            printf "%s\n" "$char_count"
            done
        done
       printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  
    else
    vacios=$(echo "No hay dispositivos disponibles.")
    #return  # Utilizar return en lugar de break
    fi


    # Filtrar dispositivos offline
    dispositivos_off=$(adb devices | grep -E 'offline' | grep -v "List" | cut -d ' ' -f1-)

    if [ -n "$dispositivos_off" ]; then
        # echo "Dispositivos offline:"
        for linea1 in $dispositivos_off; do
            #echo $linea1
            if [ "$linea1" == "offline" ]; then
                continue
            fi
            # Obtener el sistema operativo actual
            sistema_operativo=$(uname -s)
            if [[ "$sistema_operativo" == *"Windows"* ]]; then
                # En Windows
                adb -s %linea1% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
            else
               # En Linux
               adb -s "$linea1" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40' >/dev/null 2>&1
            fi
            # str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
            # ip=$(echo "${str%%/*}")
            dir_ip=$(echo $linea1 | cut -d ':' -f 1)
            doff=$(echo $linea1 | cut -d: -f1)
           #printf "$doff\n"
           #printf $dir_ip
            #printf "$ip"
            #read
            
            if [ "${ip0}" ]; then
                if [[ "$mensaje_mostrado" == "false" || ! " ${lin_imp[@]} " =~ " $linea " ]]; then
                    echo "Dispositivos offline:"
                    echo "Servidor local sin conexion"
                    echo 'Recomendado activar "Depuracion inalambrica"'     
                    mensaje_mostrado="true"
                    lin_imp+=($linea)  # Agregamos la linea a la lista de lineas previamente impresas 
                fi   
                #echo "$linea1 offline1"
            else
                #echo "$linea1 offline"
                echo "$linea1 offline2" >/dev/null 2>&1
            fi
            
            if [ "${ip}" != "${doff}" ]; then   
                if [[ "$mensaje_mostrado" == "false" || ! " ${lin_imp[@]} " =~ " $linea " ]]; then
                    echo "Dispositivos offline:"
                    echo "Servidor local sin conexion"
                    echo 'Recomendado activar "Depuracion inalambrica"'
                    mensaje_mostrado="true"
                    lin_imp+=($linea)  # Agregamos la linea a la lista de lineas previamente impresas  
                fi   
                echo "$linea1 offline3"
            else
                echo "$linea1 offline4"
                echo "$linea1 offline" >/dev/null 2>&1
            fi
            #fi
            # Agregar a la lista
            dispositivos_offline+=("$linea1")
            # No hay dispositivos vacios
            vacios1=$(echo "No.")
        done
    else
        vacios1=$(echo "No hay dispositivos offline.")
        #return  # Utilizar return en lugar de break
    fi

    # Filtrar dispositivos no autorizados (unauthorized)
    dispositivos_unauthorize=$(adb devices | grep -E 'unauthorized' | grep -v "List" | cut -d ' ' -f1-)

    if [ -n "$dispositivos_unauthorize" ]; then
        echo "Dispositivos no autorizados:"
        for linea2 in $dispositivos_unauthorize; do
            if [ "$linea2" == "unauthorized" ]; then
                continue
            fi
            # Obtener el sistema operativo actual
            sistema_operativo=$(uname -s)
            if [[ "$sistema_operativo" == *"Windows"* ]]; then
                # En Windows
                adb -s %linea2% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
             else
               # En Linux
               adb -s "$linea2" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40' >/dev/null 2>&1
            fi
            echo "$linea2 unauthorized"
            # Agregar a la lista
            dispositivos_no_autorizados+=("$linea2")
            # No hay dispositivos vacios
            vacios2=$(echo "No.")
        done
    else
        vacios2=$(echo "No hay dispositivos no autorizados.")
        #return  # Utilizar return en lugar de break
    fi


    if [[ "$vacios" == 'No hay dispositivos disponibles.' ]] && [[ "$vacios1" == 'No hay dispositivos offline.' ]] && [[ "$vacios2" == 'No hay dispositivos no autorizados.' ]]; then
        mostrar_instrucciones
    fi
    
    if [[ "$vacios" == 'No hay dispositivos disponibles.' ]] && [[ "$vacios1" == 'No.' ]] && [[ "$vacios2" == 'No hay dispositivos no autorizados.' ]]; then
        #adb kill-server >/dev/null 2>&1
        mostrar_instrucciones
    fi
    
#     : '
#     dis=$(printf "${dispositivos_disponibles[@]}" | cut -d ':' -f 1)
#     for dis_d in dis; do
#         if [ "$doff" == "$ip" ]; then
#             adb kill-server
#             echo
#         fi
#     done
#     read
#     : '
#     

    #echo $PWD
    x="$(echo $PWD)"
    #read
    if adb -s "$install" shell pm list packages | grep -q "com.termux.api"; then
        echo "Instalado Termux_API_0.50.1.apk" >/dev/null 2>&1
        line_number=$(grep -n 'xdg-open ~/Termux_API_0.50.1.apk' deshabiltar_habiltar_apps_adb_v3.sh | awk -F: '{print $1":"$3}' | head -n 1 | cut -d ':' -f1)
        
        # echo $line_number
        # read 
        
        # if: Inicia una estructura condicional.
        # !: Es el operador de negacion. En este contexto, significa "si no".
        # sed -n "${line_number}p" deshabiltar_habiltar_apps_adb_v3.sh: Utiliza el comando sed para imprimir la linea especifica indicada por ${line_number} del archivo deshabiltar_habiltar_apps_adb_v3.sh. El flag -n evita la impresion automatica de todas las lineas.
        # |: El operador de tuberia. Conecta la salida del comando sed con la entrada del siguiente comando.
        # grep -q "^# ": Utiliza grep para buscar lineas que comiencen con # en la salida del comando sed. El flag -q hace que grep opere en modo silencioso, es decir, no imprime nada, solo establece el codigo de salida.
        if ! sed -n "${line_number}p" deshabiltar_habiltar_apps_adb_v3.sh | grep -q "^# "; then
            sed -i "${line_number}s/^/# /" deshabiltar_habiltar_apps_adb_v3.sh
        fi
    else
        echo "Descargando Termux_API_0.50.1"
        cd ${HOME}
        wget https://www.dropbox.com/s/ul0wj8yud8mq03f/Termux_API_0.50.1.apk >/dev/null 2>&1
        mkdir -p /sdcard/Download
        cp -r ~/Termux_API_0.50.1.apk /sdcard/Download/ >/dev/null 2>&1
        echo "Instalando Termux_API_0.50.1"
        adb -s "$install" install /sdcard/Download/Termux_API_0.50.1.apk
        line_number=$(grep -n "xdg-open ~/Termux_API_0.50.1.apk" "${x}"/*.sh | awk -F: '{print $2":"$3}' | head -n 1 | cut -d ':' -f1)
        #echo $line_number
        #read 
        
        eval cd $x
        #pwd
        if ! sed -n "${line_number}p" "${x}"/deshabiltar_habiltar_apps_adb_v3.sh | grep -q "^# "; then
            
            sed -i "${line_number}s/^/#/" "${x}"/deshabiltar_habiltar_apps_adb_v3.sh
        fi
    fi

  
    # Ahora puedes verificar si un dispositivo esta en una lista
    read -p "Ingrese el servidor, o 'q+enter' para salir: " dispositivo

    if [ -z "$dispositivo" ]; then
        echo "Por favor, ingrese un numero de dispositivo valido de la lista."
        seleccionar_dispositivo
    elif [ "$dispositivo" == "q" ]; then
        exit 0
    elif [[ " ${dispositivos_disponibles[@]} " =~ " $dispositivo " ]]; then
        echo "$dispositivo esta en la lista de dispositivos disponibles."
        mostrar_menu "$dispositivo"
    elif [[ " ${dispositivos_offline[@]} " =~ " $dispositivo " ]]; then
        echo "$dispositivo esta en la lista de dispositivos offline."
        #echo "adb connect $dispositivo"
        #Tomar solo la ip de la variable $dispositivo
        direccion_ip=$(echo "$dispositivo" | cut -d ':' -f 1)
        echo "Conectando adb, por favor, espere..."
        # Verificar conexion a internet
        if ping -c 1 google.com >/dev/null 2>&1; then
            #adb kill-server
            #sleep 5
          
            ini=$(adb connect "$dispositivo")  # Capturar la salida del comando y el error
            #echo "Valor de ini: $ini"
            modelo_verif_off=$(adb -s "$dispositivo" shell 'echo -e "$(getprop ro.product.model)"' 2>&1)
            if [ "$modelo_verif_off" == *"offline"* ]; then
                sleep 1
                seleccionar_dispositivo
            fi
          
#             : '
#             if [[ "$ini" == *"connected to"* || "$ini" == *"already connected to"* ]]; then
#                 sleep 2
#                 seleccionar_dispositivo
#             fi
#             : '
            #echo aqui
            puertos=$(nmap -p 22-65535 -Pn "${direccion_ip}" | awk '/^ *[0-9]/ {print $1}')  # Obtener solo los numeros de puerto
            #adb kill-server
            for p in $puertos; do
                echo "Probando puerto $p"
                verif_con=$(adb connect "${direccion_ip}:${p}")
                if [[ "$verif_con" == *"failed"* || "$verif_con" == *"SO_ERROR"* ]]; then
                    echo -e "La conexion fallo. Mensaje: $verif_con"
               else
                    echo "La conexion fue exitosa."
                    adb connect "${direccion_ip}:${p}"
                    seleccionar_dispositivo
                fi
            done
            #exit
            mostrar_menu "$dispositivo"
        else
            echo "No hay conexion a Internet a traves del enrutador WiFi"
            exit 1
        fi
    elif [[ " ${dispositivos_no_autorizados[@]} " =~ " $dispositivo " ]]; then
        echo "$dispositivo esta en la lista de dispositivos no autorizados."
        echo "Por favor debe dar los permisos en el $dispositivo:"
        adb kill-server
        adb connect "$dispositivo"
        seleccionar_dispositivo
    else
        echo "$dispositivo no se encontro en ninguna lista."
        seleccionar_dispositivo
    fi
        echo ""
    
}

 
function mostrar_menu {
    echo ""
    echo "Ingrese el numero de la opcion deseada:"
    echo "1 - Deshabilitar aplicacion"
    echo "2 - Habilitar aplicacion"
    echo "3 - Multi Deshabilitar apps"
    echo "4 - Multi Habilitar apps"
    echo "5 - Volver a seleccionar dispositivo"
    echo "6 - Salir"
    
#function leer_opcion {
    #local dispositivo=$1
    read -p "Seleccione una opcion: " opcion
    
    case $opcion in
        1)
            deshabilitar_aplicaciones "$dispositivo"
            ;;
        2)
            habilitar_aplicaciones "$dispositivo"
            ;;
        3)
            multi_disable "$dispositivo"
            ;;
        4)
            multi_enable "$dispositivo"
            ;;
        5)
            seleccionar_dispositivo
            ;;
        6)
            exit 0
            ;;
        *)
            echo "Opcion invalida. Por favor, seleccione 1, 2, 3 o 4."
            mostrar_menu $dispositivo
            ;;
    esac
}


# # Nombre del paquete com.termux.api
# 
# # grep -ino "xdg-open ~/Termux_API_0.50.1.apk" "${PWD}"/*.sh | awk -F: '{print $2":"$3}' | head -n 1 | cut -d ':' -f1 # Captura solo la primera linea encontrada y muestra el numero de su ubicacion
# 
# 
# # Comentar una linea
# : '
# line_number=$(grep -ino "xdg-open ~/Termux_API_0.50.1.apk" "${PWD}"/*.sh | awk -F: '{print $2":"$3}' | head -n 1 | cut -d ':' -f1)
# sed -i "${line_number}s/^/# /" deshabiltar_habiltar_apps_adb_v3.sh
# : '
# 
# # Descomentar linea
# : '
# # line_number=$(grep -ino "xdg-open ~/Termux_API_0.50.1.apk" "${PWD}"/*.sh | awk -F: '{print $2":"$3}' | head -n 1 | cut -d ':' -f1)
# # sed -i "${line_number}s/^# //" deshabiltar_habiltar_apps_adb_v3.sh
# : '
# 
# #Verificar la existencia de un archivo
# : '
# adb -s ip:puerto shell ls /sdcard/Download/ | grep -i "Termux_API_0.50.1.apk"
# #Instalar apk
# adb -s emulator-5554 install /sdcard/Download/Termux_API_0.50.1.apk 
# : '

# Iniciar el script llamando a la funcion principal
# Llamada inicial
seleccionar_dispositivo verif_conn_router