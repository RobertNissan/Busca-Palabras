# Ram optima

adb -s emulator-5554 shell setprop debug.secure 0 # Desactiva características de seguridad adicionales.
adb -s emulator-5554 shell setprop debug.config.fha_enable true # Habilita FHA (Fast High Availability), que puede mejorar la disponibilidad y el rendimiento de las aplicaciones.
adb -s emulator-5554 shell setprop debug.sys.fw.bg_apps_limit 3 # Limita el número de aplicaciones en segundo plano.
adb -s emulator-5554 shell setprop debug.config.dha_cached_max 24 # Define el número máximo de aplicaciones en caché. baja a 16 si tienes poca ram 
adb -s emulator-5554 shell setprop debug.config.dha_lmk_scale 0.4 # Controla la escala del "Low Memory Killer". sube a 0.545 si tienes poca ram
adb -s emulator-5554 shell setprop debug.config.dha_th_rate 2.0 # Controla la tasa de activación del "Dynamic Handling Algorithm". 2.3 es un buen equilibrio, pero puede ajustarse dependiendo de la carga de trabajo del emulador.
adb -s emulator-5554 shell setprop debug.config.sdha_apps_bg_max 48 # Define el número máximo de aplicaciones en segundo plano bajo "Super Dynamic Handling Algorithm". Reducir a 48 para evitar saturar la memoria con demasiadas aplicaciones en segundo plano, permitiendo así un mejor rendimiento general.
adb -s emulator-5554 shell setprop debug.config.sdha_apps_bg_min 12 # Define el número mínimo de aplicaciones en segundo plano bajo "Super Dynamic Handling Algorithm".
adb -s emulator-5554 shell setprop debug.config.disable.hw_accel false # Desactiva la aceleración por hardware.
adb -s emulator-5554 shell setprop debug.hwui.render_dirty_regions false # Controla si las regiones "sucias" (modificadas) de la interfaz de usuario se vuelven a renderizar.
adb -s emulator-5554 shell setprop debug.hwui.disable_vsync true # Desactiva la sincronización vertical (vsync).
adb -s emulator-5554 shell setprop debug.persist.sampling_profiler 0 # Desactiva el profiler de muestreo persistente.
adb -s emulator-5554 shell setprop debug.persist.sys.use_8bpp_alpha 1 # Activa el uso de canal alfa de 8 bits. 1 para habilitar, útil para efectos de transparencia, manténlo así.

# Pruebas incrementales: Si encuentras que algunas aplicaciones aún se cierran inesperadamente o el sistema se ralentiza bajo carga, podrías experimentar ajustando:
# debug.config.dha_lmk_scale o debug.sys.fw.bg_apps_limit
