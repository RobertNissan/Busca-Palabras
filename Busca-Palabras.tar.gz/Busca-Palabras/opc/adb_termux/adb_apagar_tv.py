import os
import sys
import time

def cuenta_regresiva(tiempo):
    tiempo_segundos = int(tiempo) * 60
    for i in range(tiempo_segundos, -1, -1):
        minutos_restantes, segundos_restantes = divmod(i, 60)
        tiempo_restante = f"{minutos_restantes:02}:{segundos_restantes:02}"
        sys.stdout.write("\rEl dispositivo se apagara en: " + tiempo_restante)
        sys.stdout.flush()
        time.sleep(1)
    
def apagar_dispositivo(ip_port, tiempo):
    # Iniciar cuenta regresiva
    cuenta_regresiva(tiempo)

    print("")
    # Conectar al dispositivo mediante adb
    os.system(f"adb connect {ip_port} >/dev/null")
    # Apagar el dispositivo
    os.system(f"adb -s {ip_port} shell reboot -p >/dev/null 2>&1")
    print(f"Dispositivo {ip_port} apagado\n")

ip_port = input("Ingrese la IP:PUERTO del dispositivo: ")
tiempo = input("Ingrese el tiempo de apagado en minutos: ")

apagar_dispositivo(ip_port, tiempo)
