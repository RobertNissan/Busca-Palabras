#!/bin/bash

# Script para cerrar apps no-sistema periódicamente
# Uso:
#   bash cerrar_todas_app_timer.sh 2s | 5m | 1h
# Si no pasas argumento, te preguntará como antes.

# --- helpers de limpieza ---
cleanup_lines() {
  local n=$1
  # Borra desde la línea actual hacia arriba n líneas
  for ((i=0;i<n;i++)); do
    # Ir al inicio de línea y borrar
    tput cr 2>/dev/null || printf '\r'
    tput el 2>/dev/null || printf '\033[2K'
    # Subir una línea salvo en la última
    if (( i < n-1 )); then
      tput cuu1 2>/dev/null || printf '\033[1A'
    fi
  done
}

LAST_LINES=0
on_int() {
  # Limpia el bloque actual si está en pantalla
  if [ "$LAST_LINES" -gt 0 ]; then
    cleanup_lines "$LAST_LINES"
  fi
  printf "\nDetenido por usuario.\n"
  exit 0
}
trap on_int INT TERM

# --- cuenta regresiva (actualiza la MISMA línea) ---
countdown() {
  local secs=$1
  while [ $secs -gt 0 ]; do
    printf "\rPróxima comprobación en: %02d:%02d:%02d " $((secs/3600)) $(((secs%3600)/60)) $((secs%60))
    sleep 1
    : $((secs--))
  done
  # Mostrar 00:00:00 al final
  printf "\rPróxima comprobación en: 00:00:00 "
}

# --- parseo de argumento o modo interactivo ---
if [ -n "$1" ]; then
  interval_input="$1"
  if [[ "$interval_input" =~ ^([0-9]+)([sSmMhH])$ ]]; then
    num="${BASH_REMATCH[1]}"; unit="${BASH_REMATCH[2]}"
  elif [[ "$interval_input" =~ ^([0-9]+)$ ]]; then
    num="${BASH_REMATCH[1]}"; unit="s"
  else
    echo "Formato inválido. Usa 30s | 5m | 1h"; exit 1
  fi
else
  echo -n "Ingrese el intervalo (número): "; read num
  echo -n "Unidad (s=segundos, m=minutos, h=horas): "; read unit
  [[ "$num" =~ ^[0-9]+$ ]] || { echo "Número inválido."; exit 1; }
fi

case "${unit,,}" in
  s) interval=$num ;;
  m) interval=$((num*60)) ;;
  h) interval=$((num*3600)) ;;
  *) echo "Unidad inválida. Usa s, m o h."; exit 1 ;;
esac

# --- whitelist fija ---
WHITELIST=("com.termux" "com.whatsapp" "com.motorola.launcher3")

echo "Iniciando: cerrador periódico de apps (no-sistema)."
if [ -n "$interval_input" ]; then
  echo "Intervalo: $interval_input ($interval s)"
else
  echo "Intervalo: ${num}${unit} ($interval s)"
fi
echo "Whitelist: ${WHITELIST[*]}"
echo "Presiona Ctrl+C para detener."
echo

while true; do
  # Construir bloque de salida (sin countdown aún)
  lines=()
  lines+=("Comprobación: $(date)")

  running_apps=$(adb shell dumpsys activity activities 2>/dev/null \
                  | tr -d '\r' \
                  | grep "Hist" \
                  | grep -oP "u0\s+[\w\.]+(?=/)" \
                  | awk '{print $2}' \
                  | sort -u)

  for app in $running_apps; do
    # omitir sistema
    if [[ "$app" == com.android.* || "$app" == android.* ]]; then
      continue
    fi
    # omitir whitelist
    for w in "${WHITELIST[@]}"; do
      if [ "$app" = "$w" ]; then
        lines+=("⏩ Omitiendo (whitelist): $app")
        app=""
        break
      fi
    done
    [ -z "$app" ] && continue

    lines+=("🔴 Forzando cierre de: $app")
    adb shell am force-stop "$app" >/dev/null 2>&1
  done

  # Imprimir bloque (cada línea termina con \n)
  for l in "${lines[@]}"; do
    printf "%s\n" "$l"
  done

  # Imprimir la línea de countdown SIN salto de línea para actualizarla in-place
  printf "Próxima comprobación en: %02d:%02d:%02d " \
    $((interval/3600)) $(((interval%3600)/60)) $((interval%60))

  # Total de líneas a limpiar = líneas del bloque + 1 (countdown)
  LAST_LINES=$((${#lines[@]} + 1))

  # Ejecutar countdown (actualiza esa última línea)
  countdown "$interval"

  # Limpiar exactamente LAST_LINES líneas
  cleanup_lines "$LAST_LINES"

  # Evitar limpiar dos veces si se interrumpe aquí
  LAST_LINES=0
done
