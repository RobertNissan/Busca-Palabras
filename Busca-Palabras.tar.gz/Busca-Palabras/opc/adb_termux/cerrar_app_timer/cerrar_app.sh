#!/bin/bash
SERIAL="emulator-5554"      # deja "" para dispositivo por defecto
PKG="app.rvx.android.youtube"   # <-- asegúrate con "adb shell pm list packages"
INPUT_TIME="$1"

if [ -z "$INPUT_TIME" ]; then
  echo "Uso: $0 <tiempo> (ejemplos: 30s | 5m | 2h | 1h30m20s)"
  exit 1
fi

ADB="adb"
[ -n "$SERIAL" ] && ADB="adb -s $SERIAL"

trap 'printf "\nCancelado.\n"; exit 1' INT TERM

# convertir a segundos
to_seconds() {
  local t="$1"
  local total=0
  [[ $t =~ ([0-9]+)h ]] && total=$((total + ${BASH_REMATCH[1]} * 3600))
  [[ $t =~ ([0-9]+)m ]] && total=$((total + ${BASH_REMATCH[1]} * 60))
  [[ $t =~ ([0-9]+)s ]] && total=$((total + ${BASH_REMATCH[1]}))
  echo $total
}

DELAY=$(to_seconds "$INPUT_TIME")
[ "$DELAY" -le 0 ] && echo "Tiempo inválido: $INPUT_TIME" && exit 1

$ADB wait-for-device >/dev/null 2>&1

echo "Se forzará cierre de: $PKG"
echo "Cuenta regresiva ($INPUT_TIME):"

remaining=$DELAY
while [ $remaining -gt 0 ]; do
  hrs=$((remaining/3600))
  mins=$(( (remaining%3600)/60 ))
  secs=$((remaining%60))
  printf "\r  %02d:%02d:%02d " $hrs $mins $secs
  sleep 1
  remaining=$((remaining-1))
done
printf "\r  00:00:00 \n"

echo "Intentando forzar cierre de $PKG..."
MAX_INTENTOS=3
for i in $(seq 1 $MAX_INTENTOS); do
  $ADB shell am force-stop "$PKG" >/dev/null 2>&1
  sleep 1
  if ! $ADB shell ps -A | grep -q "$PKG"; then
    echo "App cerrada (intento $i)."
    exit 0
  else
    echo "Sigue en ejecución (intento $i). Reintentando..."
  fi
done

echo "No se logró cerrar completamente tras $MAX_INTENTOS intentos. Revisa manualmente."
exit 1
