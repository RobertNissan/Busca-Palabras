#!/bin/bash

archivo="packages.txt"
dispositivo="emulator-5554"
# Obtener la lista de todos los paquetes de usuario 3
packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

# Aplicaciones que siempre deben estar en el archivo
echo "com.facebook.katana" > packages.txt
echo "com.google.android.videos" >> packages.txt
echo "com.google.android.apps.photos" >> packages.txt
echo "com.google.android.apps.docs" >> packages.txt

excluidos=(
    "com.termux"
    "com.touchtype.swiftkey"
    "com.termux.api"
    "com.topjohnwu.magisk"
    "ich.andre.partialscreen"
    "app.rvx.android.youtube"
    "com.mgoogle.android.gms"
    "com.android.chrome"
    "com.google.android.youtube"
    "com.rhmsoft.edit.pro"
    "com.estrongs.android.pop"
    )

# Bucle para cada una de las aplicaciones
for package in $packages; do
    exclude=false
    for excluded_package in "${excluidos[@]}"; do
        if [[ "$package" == "$excluded_package" ]]; then
            exclude=true
            break
        fi
    done

    if [ "$exclude" == false ]; then
        echo "$package" >> packages.txt
    fi
done

contador=0 # Inicializa la variable contador a 0, que se usara para contar el numero de aplicaciones deshabilitadas.

# Leer todas las lineas del archivo y almacenarlas en un array
mapfile -t lineas < "$archivo"

# Iterar sobre el array
for linea in "${lineas[@]}"; do
    linea=$(echo "$linea" | tr -d '\r')  # Eliminar caracteres de retorno de carro
    #echo "Procesando paquete: $linea"
    if [ -z "$linea" ]; then
        echo "Nombre del paquete vacio."
    elif [ ${#linea} -lt 3 ]; then
        echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
    elif adb -s "$dispositivo" shell pm list packages | grep "$linea" >/dev/null 2>&1; then
        adb -s "$dispositivo" shell pm disable-user --user 0 "$linea" >/dev/null 2>&1
        echo -e "Aplicacion $linea deshabilitada correctamente.\n"
        ((contador++))
    else
        echo "Error al deshabilitar la aplicacion."
        continue
    fi
done

echo "Se deshabilitaron $contador aplicaciones."
