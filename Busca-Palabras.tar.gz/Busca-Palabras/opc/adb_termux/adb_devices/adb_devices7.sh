#!/bin/bash

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {
    echo ""
    echo "No se encontraron dispositivos conectados."
    echo "Por favor, ingrese los siguientes datos para emparejar el dispositivo."
    
    # Pedir la IP y el puerto
    read -p "Ingrese la IP del dispositivo: " ip
    read -p "Ingrese el puerto del dispositivo (normalmente 5555): " port
    read -p "Ingrese el código de vinculación por Wi-Fi: " code

    # Emparejar el dispositivo usando adb pair
    echo "Emparejando con adb pair..."
    adb pair "$ip:$port" "$code"

    # Buscar el puerto del dispositivo con nmap
    echo "Buscando puerto disponible con nmap..."
    port_found=$(nmap -p- --open -T4 "$ip" | grep -oP '\d+(?=/tcp)' | head -n 1)
    
    if [[ -n "$port_found" ]]; then
        echo "Puerto encontrado: $port_found"
        echo "Intentando conectar al dispositivo..."
        adb connect "$ip:$port_found"
    else
        echo "No se encontró ningún puerto abierto para conectar."
    fi
}

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si Python está instalado
if [ -x ${PREFIX}/bin/python ]; then
    echo "Python ya está instalado." >/dev/null 2>&1
else 
    echo "Instalando python..."
    apt install python -y
fi

# Verificar si adb está instalado
if [ -x "$PREFIX/bin/adb" ]; then
    echo "adb instalado." >/dev/null 2>&1
    adb start-server
else
    echo "Instalando adb..."
    pkg install android-tools -y >/dev/null 2>&1
    echo "adb instalado correctamente."
fi

# Verificar si nmap está instalado
if [ -x "$PREFIX/bin/nmap" ]; then
    echo "nmap instalado." >/dev/null 2>&1
else
    echo "Instalando nmap..."
    pkg install nmap -y >/dev/null 2>&1
    echo "nmap instalado correctamente."
fi
if [ -x $PREFIX/share/doc/termux-api ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando termux-api"
    pkg install termux-api
fi

mi_dispositivo() {
    echo ""
    echo "Brand ID: $(getprop ro.product.system.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Version de Android: $(getprop ro.build.version.release)"
    echo "Model ID: $(getprop ro.build.product)"
    echo "Kernel ID: $(uname -r)"
    echo "Chipset ID: $(getprop ro.product.board)"
    echo "Architecture: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {
    mi_dispositivo
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col*7/100))
    mul2=$(($col*47/100))
    mul3=$(($col*27/100))
    mul4=$(($col*9/100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 
    
    echo ""
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  

    dispositivos=()
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}')
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')
    
    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            dispositivos+=("$device")
            # Formatear el id con 2 dígitos
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | v%-${mul4}s#\n" " $id_fortmat" "$device" "$model" "$version"
            printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
            id=$((id+1))
        done
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo "Dispositivos OFFLINE:"
        echo "$offline_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo "Dispositivos NO AUTORIZADOS:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
}

# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    mostrar_dispositivos
    echo -n "Ingrese el número del dispositivo o 'q+enter' para salir: "
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
}

# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    echo ""
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ]"
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell echo "[ DEVICE: \$(getprop ro.product.model) ]"
    adb -s "$dispositivo" shell echo "[ BRAND: \$(getprop ro.product.system.brand) ]"
    adb -s "$dispositivo" shell echo "[ MODEL: \$(getprop ro.build.product) ]"
    adb -s "$dispositivo" shell echo "[ KERNEL: \$(uname -r) ]"
    
    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell echo "[ GPU: \$(getprop ro.hardware.gpu) ]"
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell echo "[ GPU: $gpu_info ]"
    fi

    adb -s "$dispositivo" shell echo "[ CPU: \$(getprop ro.hardware) ]"
    adb -s "$dispositivo" shell echo "[ ANDROID VERSION: \$(getprop ro.build.version.release) ]"
    adb -s "$dispositivo" shell echo "[ Android ID: \$(getprop ro.serialno) ]"
    
    echo ""
    echo "Opciones disponibles:"
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  
    echo "01 - Activar adb permanente"
    echo "02 - Deshabilitar aplicación"
    echo "03 - Habilitar aplicación"
    echo "04 - Multi Deshabilitar apps"
    echo "05 - Multi Habilitar apps"
    echo "06 - Optimizar (RAM)"
    echo "07 - Activar Gráficos Vulkan"
    echo "08 - Restablecer Gráficos a OpenGL"
    echo "09 - Configurar la conexión Wi-Fi"
    echo "10 - Restablecer configuración Wi-Fi"
    echo "11 - Apagar dispositivo"
    echo "12 - Detener aplicaciones"
    echo "13 - Volver a seleccionar dispositivo"
    echo "14 - Salir"
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  

    # Leer opción seleccionada
    read -p "Seleccione una opción: " opcion

    case $opcion in
        1|01)
            bash adb_termux/activar_adb_permanete/bash_activar_adb_root_noroot.sh "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        2|02)
            deshabilitar_aplicaciones "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        3|03)
            habilitar_aplicaciones "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        4|04)
            multi_disable "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        5|05)
            multi_enable "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        6|06)
            optimizar_ram "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        7|07)
            activar_vulkan "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        8|08)
            restablecer_opengl "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        9|09)
            configurar_max_wifi "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        10)
            restablecer_wifi_principal "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        11)
            apagar_dispositivo "$dispositivo"
            exit 0
            ;;
        12)
            force_stop_apps "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        13)
            seleccionar_dispositivo
            ;;
        14)
            echo "Saliendo..."
            exit 0
            ;;
        *)
            echo "Opción inválida. Intente de nuevo."
            mostrar_menu "$dispositivo"
            ;;
    esac
}

# Comienza la ejecución del script
seleccionar_dispositivo
