# Global Table
adb -s tu_ip:puerto_adb shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
adaptative_battery_management_enabled 1
adaptive_power_saving_setting 1
background_process_limit 4
cached_apps_freezer device_default
audio_hal_bt_enable_high_quality_mode 5
cpu_boost_enabled 1
low_power 0
hwui.disable_overlay 1
ring.delay 0
pm.sleep_mode 1
power_supply.wakeup enable
debug.enabletr true
debug.qctwa.preservebuf 1
debug.overlayui.enable 1
debug.egl.hw 1
debug.egl.profiler 1
debug.sf.hw 1
debug.composition.type c2d
debug.composition.type gpu
debug.performance.tuning 1
debug.composition.type vulkan
haptic_feedback_enabled 0
touch.presure.scale 0.5
refresh_rate_mode 2
min_refresh_rate 60
max_refresh_rate 90
persist.sys.NV_FPSLIMIT 120
0.0_fps_max 120
persist.sys.NV_POWERMODE 1
persist.sys.NV_PROFVER 15
persist.sys.NV_STEREOCTRL 0
persist.sys.NV_STEREOSEPCHG 0
persist.sys.NV_STEREOSEP 20
debug.gr.swapinterval 0
adb -s emulator-5554 shell su -c dmesg | grep -i "fps"

# System Table
touch_sensitivity 2
touchscreen_response_area 1
performance_mode 1
high_priority 1
screen_brightness 50
navigationbar_config 2
show_navigationbar 1
windowsmgr.max_events_per_sec 90
fod_animation_type 4
debug.config.disable.hw_accel false
debug.hwui.render_dirty_regions false
debug.hwui.disable_vsync true
debug.persist.sampling_profiler 0
debug.persist.sys.use_8bpp_alpha 1
dalvik.vm.checkjni false
dalvik.vm.dexopt-data-only 1
dalvik.vm.heapstartsize 5m
dalvik.vm.heapgrowthlimit 192m
dalvik.vm.heapsize 256m
dalvik.vm.verify-bytecode false
dalvik.vm.execution-mode int:jit
dalvik.vm.lockprof.threshold 250
dalvik.vm.dexopt-flags m=v,o=y
dalvik.vm.stack-trace-file /data/anr/traces.txt
dalvik.vm.jmiopts forcecopy
media.stagefright.enable-player true
media.stagefright.enable-meta true
media.stagefright.enable-scan true
media.stagefright.enable-http true
media.stagefright.enable-aac true
media.stagefright.enable-qcp true
media.stagefright.enable-record true
media_cache_size 52428800
windowsmgr.max_events_per_sec 90

# Secure Table
send_action_app_error 0
gpu_renderer_policy 1
tcp_default_init_rwnd 60
throttling_burst_timeout 2000
debug.secure 0
clock_seconds 1
double_tap_to_wake 0
hush_gesture_used 0
immersive_mode_confirmations 0
long_press_timeout 400
multi_press_timeout 400
ui_night_mode 1
af.resampler.quality 255
mpq.audio.decode true
debug.qc.hardware true
debug.qctwa.statusbar 1
debug.qctwa.preservebuf 1
net.ipv4.ip_no_pmtu_disc 0
net.ipv4.route.flush 1
net.ipv4.tcp_ecn 0
net.ipv4.tcp_fack 1
net.ipv4.tcp_moderate_rcvbuf 1
net.ipv4.tcp_no_metrics_save 1
net.ipv4.tcp_rfc1337 1
net.ipv4.tcp_sack 1
net.ipv4.tcp_timestamps 1
net.ipv4.tcp_window_scaling 1
net.ipv4.tcp_mem "187000 187000 187000"
net.ipv4.tcp_wmem "4096 39000 18700"
net.ipv4.tcp_rmem "4096 39000 187000"
