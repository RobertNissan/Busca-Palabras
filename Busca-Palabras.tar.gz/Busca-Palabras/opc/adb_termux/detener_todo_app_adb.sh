#!/bin/bash

force_stop_apps() {
    local dispositivo=$1

    # Obtener la lista de paquetes de usuario 2 (aplicaciones del sistema)
    local packages_user2=$(adb -s "$dispositivo" shell pm list packages | cut -d':' -f2)

    # Obtener la lista de paquetes de usuario 3 (aplicaciones instaladas por el usuario)
    local packages_user3=$(adb -s "$dispositivo" shell pm list packages -3 | cut -d':' -f2)

    # Combinar las listas de paquetes de usuario 2 y 3
    local packages=$(echo -e "$packages_user2\n$packages_user3" | sort | uniq)

    # Obtener la lista de paquetes deshabilitados
    local disabled_packages=$(adb -s "$dispositivo" shell pm list packages -d | cut -d':' -f2)

    # Bucle para detener cada una de las aplicaciones
    for package in $packages; do
        # Verificar si el paquete está deshabilitado
        if echo "$disabled_packages" | grep -q "^$package$"; then
            #echo "Skipping disabled package: $package"
            continue
        fi

        # Intentar detener las aplicaciones
        if [ "$package" != "com.termux" ]; then
            adb -s "$dispositivo" shell am force-stop "$package" 2>/dev/null
            if [ $? -eq 0 ]; then
                echo "Force-stopped $package"
            else
                echo "Failed to force-stop $package"
            fi
        fi
    done

    # Cerrar el paquete "com.termux" al final
    #adb -s "$dispositivo" shell am force-stop com.termux
    #echo "Force-stopped com.termux"
}

# Llamar a la función con el ID del dispositivo
force_stop_apps "emulator-5554"
