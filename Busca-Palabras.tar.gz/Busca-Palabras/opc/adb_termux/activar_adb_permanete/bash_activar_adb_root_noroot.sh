#!/bin/bash

echo "Para ejcutar bien pase el argumento:" >/dev/null 2>&1
echo "script.sh <ip:port>" >/dev/null 2>&1
# Verificar que se haya pasado el nombre del paquete como argumento
if [ -z "$1" ]; then
    echo "Uso: $0 <nombre_del_paquete>"
    exit 1
fi
DISPOSITIVO="$1"

: '
# Obtener la IP local
str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
IP=$(echo "${str%%/*}")

# Obtener los dispositivos conectados por ADB
adb_output=$(adb devices -l)
connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')

# Buscar si hay un dispositivo con la IP o el emulador
ip_device=$(echo "$connected_devices" | grep -Ei "$IP:5555|127.0.0.1:5555|emulator-5554" | head -n 1)

# Contar cuántos dispositivos están conectados
device_count=$(echo "$connected_devices" | wc -l)

if [[ $device_count -eq 1 && "$ip_device" == "emulator-5554" ]]; then
    echo "Conectado solo al emulador-5554. Intentando conectar a 127.0.0.1:5555..."
    DISPOSITIVO=$(adb connect 127.0.0.1:5555)
else
    DISPOSITIVO=$(echo "$connected_devices" | grep -Ei "$IP:5555|127.0.0.1:5555" | head -n 1)
    echo "Estado de conexión: $DISPOSITIVO"
fi
: '

# Verificar si el dispositivo tiene root
if su -c "id" > /dev/null 2>&1; then
    echo "Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    echo "No tienes acceso root" >/dev/null 2>&1
    ROOT_PERMISSIONS="false"
fi

# Función para habilitar ADB permanente
habilitar_adb_permanente() {
    DISPOSITIVO="$1"
    puerto="5555"
    # dar dar a la tabla globa de setedit
    # echo "DISPOSITIVO2: $DISPOSITIVO"
    adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
    if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
        echo "Habilitando ADB permanente con root..."
        # Esros 2 comandos son los que hace persistente aún después de reiniciar en el puerto 5555.
        adb -s "$DISPOSITIVO" shell su -c "setprop persist.adb.tcp.port 5555"
        adb -s "$DISPOSITIVO" shell su -c "setprop service.adb.tcp.port 5555"
        adb -s "$DISPOSITIVO" shell su -c "resetprop ro.adb.secure 0"
        adb -s "$DISPOSITIVO" tcpip "${puerto}"
        sleep 4
        ip=$(echo "$DISPOSITIVO" | cut -d: -f1)
        DISPOSITIVO="${ip}:${puerto}"
        adb connect "$DISPOSITIVO" 
        adb -s "$DISPOSITIVO" shell settings put global development_settings_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
        echo "ADB habilitado permanentemente incluso después del reinicio."
    else
        echo "Habilitando ADB temporal (sin root)..."
        adb -s "${DISPOSITIVO}" tcpip "${puerto}"
        sleep 4
        ip=$(echo "${DISPOSITIVO}" | cut -d: -f1)
        DISPOSITIVO="${ip}:${puerto}"
        # echo "${DISPOSITIVO}" 
        adb connect "${DISPOSITIVO}" 
        # adb devices
        adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
        adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
        echo "ADB habilitado hasta el próximo reinicio."
    fi
}

# Función para deshabilitar ADB permanente
deshabilitar_adb_permanente() {
    DISPOSITIVO="$1"
    puerto="5555"
    # dar dar a la tabla globa de setedit
    # echo "DISPOSITIVO2: $DISPOSITIVO"
    adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
    if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
        echo "Deshabilitando ADB permanente con root..."
        adb -s "$DISPOSITIVO" shell su -c "setprop persist.adb.tcp.port -1"
        adb -s "$DISPOSITIVO" usb
        echo "ADB deshabilitado permanentemente."
    else
        echo "Deshabilitando ADB temporal (sin root)..."
        adb -s "$DISPOSITIVO" usb
        echo "ADB deshabilitado (sin root)."
    fi
}

# Menú de opciones
echo "Selecciona una opción:"
echo "1) Habilitar ADB permanente"
echo "2) Deshabilitar ADB permanente"
read -p "Opción: " opcion

case $opcion in
    1)
        # echo "DISPOSITIVO1: $DISPOSITIVO"
        habilitar_adb_permanente "$DISPOSITIVO"
        ;;
    2)
        # echo "DISPOSITIVO1: $DISPOSITIVO"
        deshabilitar_adb_permanente "$DISPOSITIVO"
        ;;
    *)
        echo "Opción no válida."
        ;;
esac


# arreglar el script remoto
# dos2unix /sdcard/Documents/activar_adb_root_noroot.sh"
# nota no activar fish
# -s 192.168.20.89:5555 shell "sed -i 's/\r$//' /sdcard/Documents/activar_adb_root_noroot.sh"

