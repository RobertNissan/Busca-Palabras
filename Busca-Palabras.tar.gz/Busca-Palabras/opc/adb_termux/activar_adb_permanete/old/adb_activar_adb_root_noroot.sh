#!/bin/bash

# Verificar si el dispositivo tiene acceso root
if su -c "id" > /dev/null 2>&1; then
    echo "Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    echo "No tienes acceso root"
    ROOT_PERMISSIONS="false"
fi

# Función para habilitar de manera permanente
habilitar_adb_permanente() {
    if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
        echo "Habilitando adb permanente con root..."
        su -c "setprop persist.adb.tcp.port 5555"
        su -c "setprop ro.adb.secure 0"
        settings put global development_settings_enabled 1
        settings put global adb_enabled 1
        settings put global adb_wifi_enabled 1
        settings put global adb_port 5555
        echo "habilitado permanentemente incluso después del reinicio."
    else
        echo "Habilitando adb temporal (sin root)..."
        settings put global development_settings_enabled 1
        settings put global adb_enabled 1
        settings put global adb_wifi_enabled 1
        settings put global adb_port 5555
        echo "habilitado hasta el próximo reinicio."
    fi
}

# Función para deshabilitar de manera permanente
deshabilitar_adb_permanente() {
    if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
        echo "Deshabilitando adb permanente con root..."
        su -c "setprop persist.adb.tcp.port -1"
        su -c "setprop ro.adb.secure 1"
        settings put global adb_wifi_enabled 0
        settings delete global adb_port
        settings put global development_settings_enabled 1
        settings put global adb_enabled 1
        echo "deshabilitado permanentemente."
    else
        echo "Deshabilitando temporal (sin root)..."
        settings put global adb_wifi_enabled 0
        settings delete global adb_port
        echo "deshabilitado hasta el próximo reinicio."
    fi
}

# Menú de opciones
echo "Selecciona una opción:"
echo "1) Habilitar permanente"
echo "2) Deshabilitar permanente"
echo "Opción: " 
read opcion

case "$opcion" in
    1)
        habilitar_adb_permanente
        ;;
    2)
        deshabilitar_adb_permanente
        ;;
    *)
        echo "Opción no válida."
        ;;
esac


# arreglar el script remoto
# nota no activar fish
# -s 192.168.20.89:5555 shell "sed -i 's/\r$//' /sdcard/Documents/activar_adb_root_noroot.sh"