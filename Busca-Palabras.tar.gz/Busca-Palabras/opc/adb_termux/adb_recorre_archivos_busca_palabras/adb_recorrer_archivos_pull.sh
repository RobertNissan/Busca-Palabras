#!/bin/bash

# Definir colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se ha proporcionado el argumento <ip:port>
if [ $# -ne 1 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase el argumento:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}<ip:port>${NC}\n"
    exit 1
fi

DEVICE="$1"
echo "Dispositivo: $DEVICE"

# Definir extensiones de texto que queremos buscar
extensiones_de_texto=(
    '.txt' '.py' '.c' '.cpp' '.java' '.html' '.css' '.js' '.php'
    '.vb' '.rb' '.sh' '.pl' '.swift' '.kt' '.scala' '.ini' '.cfg'
    '.conf' '.properties' '.env' '.config' '.xml' '.json'
    '.yaml' '.yml' '.xsd' '.svg' '.markdown' '.rtf' '.doc' '.docx'
    '.odt' '.tex' '.pptx' '.odp' '.key' '.xls' '.xlsx' '.ods' '.csv'
)
# Construir la opción --include para grep
include_opts=""
for ext in "${extensiones_de_texto[@]}"; do
    include_opts+="--include=\"*${ext}\" "
done

# Función para crear una expresión regular basada en la palabra ingresada
crear_regex() {
    local palabra="$1"
    local regex_palabra=""
    
    declare -A mapeo=(
        ["a"]='[aåąæāªáàäâã]' ["e"]='[eēęėëéèê]' ["i"]='[iīîįìíï]' ["o"]='[oºōøœõôöóò]' ["u"]='[uūùúüû]' ["n"]='[nñń]'
        ["á"]='[aåąæāªáàäâã]' ["é"]='[eēęėëéèê]' ["í"]='[iīîįìíï]' ["ó"]='[oºōøœõôöóò]' ["ú"]='[uūùúüû]' ["ñ"]='[nñń]'
    )
    
    for ((i=0; i<${#palabra}; i++)); do
        letra="${palabra:i:1}"
        lower_letra=$(echo "$letra" | tr '[:upper:]' '[:lower:]')
        
        if [[ "${mapeo[$lower_letra]}" ]]; then
            regex_palabra+="${mapeo[$lower_letra]}"
        elif [[ "$lower_letra" == "?" ]]; then
            continue # Omitir el signo de interrogación
        elif [[ "$letra" == " " ]]; then
            regex_palabra+=" " # Agregar espacio literal
        else
            # Escapar caracteres especiales para grep/sed
            regex_palabra+="$(printf '%q' "$letra")"
        fi
    done
    
    echo "$regex_palabra"
}

# Función para mostrar instrucciones de uso
mostrar_instrucciones() {
    echo -e "\n${YELLOW}Instrucciones de uso:${NC}"
    echo -e "Debe ingresar las frases de búsqueda separadas por el carácter | (barra vertical)."
    echo -e "Ejemplo: ${CYAN}adb|kill-server${NC} o ${CYAN}speed metal${NC}"
    echo -e "${YELLOW}Nota:${NC} Si no se ingresa nada, se volverá a solicitar la entrada.\n"
}

# Iniciar un bucle para solicitar las frases de búsqueda hasta que se ingresen
while :; do
    read -p "Ingrese las frases de búsqueda (separadas por '|'): " frases
    # Si el usuario no ingresa nada, mostrar instrucciones
    if [ -z "$frases" ]; then
        mostrar_instrucciones
    else
        break
    fi
done

IFS='|' read -ra frases_array <<< "$frases"
regex_final=""
for frase in "${frases_array[@]}"; do
    regex=$(crear_regex "$frase")
    regex_final+="$regex|"
done
# Quitar el último pipe
regex_separador1=${regex_final%|}
echo "$regex_separador1"

final_brand=""
final_serial=""
path=""
descargar_plus1() {
    archivo="$1"
    # Obtener propiedades del dispositivo
        brand=$(adb -s $DEVICE shell "getprop ro.product.brand")
        system_brand=$(adb -s $DEVICE shell "getprop ro.product.system.brand")
        manufacturer=$(adb -s $DEVICE shell "getprop ro.product.manufacturer")
        serial=$(adb -s $DEVICE shell "getprop ro.serialno")
        # Selecciona la primera marca válida
        if [ -n "$system_brand" ] && [ "$system_brand" != "unknown" ]; then
            final_brand=$system_brand
        elif [ -n "$brand" ] && [ "$brand" != "unknown" ]; then
            local final_brand=$brand
        else
            local final_brand=$manufacturer
        fi
        # Verifica si el serial está disponible y no es "unknown"
        if [ -z "$serial" ] || [ "$serial" == "unknown" ]; then
            final_serial="Serial no disponible"
        else
            local final_serial=$serial
        fi

        # Mostrar resultados
        # echo "Brand: $final_brand"
        # echo "Serial: $final_serial"
        
    # Asegúrate de que las variables no contienen códigos de color
    # archivo=$(echo "$archivo" | sed 's/\x1b\[[0-9;]*m//g')
    # echo "Dispositivo: $DEVICE"
    mkdir -p "/sdcard/adb_dispositivos/${final_brand}_${final_serial}/"
    path="/sdcard/adb_dispositivos/${final_brand}_${final_serial}/"
}
descargar_plus1

# Ejecuta el código Python
python_script=$(cat <<EOF
import os
# Ruta del directorio
directorio = '$path'
# Verifica si la ruta es un directorio
if os.path.isdir(directorio):
    # Recorre todos los archivos en el directorio
    for archivo in os.listdir(directorio):
        ruta_archivo = os.path.join(directorio, archivo)
        # Verifica si es un archivo
        if os.path.isfile(ruta_archivo):
            print(f'Archivo remoto:\n{archivo}\n')
            # Elimina el archivo después de mostrar su nombre
            os.remove(ruta_archivo)
else:
    print(f'La ruta {directorio} no es un directorio válido.')
EOF
)

descargar() {
    archivo="$1"    
    # Asegúrate de que las variables no contienen códigos de color
    # archivo=$(echo "$archivo" | sed 's/\x1b\[[0-9;]*m//g')
    if [ ! -d "$path" ]; then
        mkdir -p "$path"
    fi
    # Descargar el archivo desde Android a la máquina local
    adb -s "${DEVICE}" pull "${archivo}" "${path}$(basename $archivo)" 2>/dev/null
    # Verificar si la descarga fue exitosa
    if [ $? -eq 0 ]; then
        echo -e "${CYAN}Archivo descargado a local para procesar en:\n${NC}${path}$(basename "$archivo"${NC})"
        # Ejecuta el script Python
        python -c "$python_script"
    else
        echo -e "Error al descargar el archivo ${archivo}"
    fi
}

# Ejecuta el código Python
python_script=$(cat <<EOF
import re
import os
import mmap
import subprocess

# Ruta del directorio
directorio = '$path'
regex_separador1 = '$regex_separador1'

def main():
    if os.path.isdir(directorio):
        # Recorre todos los archivos en el directorio
        for archivo in os.listdir(directorio):
            ruta_archivo = os.path.join(directorio, archivo)
            # Verifica si es un archivo
            if os.path.isfile(ruta_archivo):
                try:
                    if os.path.getsize(ruta_archivo) > 0:
                        # print(f'Archivo: {archivo}\\n')
                        with open(ruta_archivo, 'r', encoding='utf-8') as file:
                            with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
                                # Convertir el contenido del mapeo en una cadena de bytes y luego decodificarla a una cadena de texto
                                texto = mm[:].decode('utf-8')
                                # Buscar si en el archivo se encuentra alguna de las palabras
                                if re.search(regex_separador1, texto, re.IGNORECASE):
                                    print(f'Resultados encontrados:')
                                    resultado_busqueda = subprocess.run(
                                        ['grep', '--color=always', '-n', '-E', f"{regex_separador1}", ruta_archivo],
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE
                                    )
                                    print(resultado_busqueda.stdout.decode('utf-8'))
                                    # Elimina el archivo después de mostrar su nombre
                                    os.remove(ruta_archivo)
                                else:
                                    # Elimina el archivo después de mostrar su nombre
                                    os.remove(ruta_archivo)
                                    print('No se encontraron resultados.\n')
                except Exception as e:
                    print(f"Error al leer el archivo {archivo}: {e}")
                    # Elimina el archivo después de mostrar su nombre
                    os.remove(ruta_archivo)

if __name__ == "__main__":
    main()
EOF
)

# Comando ADB para encontrar y listar todos los archivos dentro de /sdcard/
# adb -s $DEVICE shell "find /sdcard/ -type f" | while read -r FILE; do
adb -s "${DEVICE}" shell "find /sdcard/ -path /sdcard/Android -prune -o -type f -print" | while read -r FILE; do
    # Extrae la extensión del archivo
    archivo_ext="${FILE##*.}"
    # Comprueba si la extensión está en la lista de extensiones permitidas
    if [[ " ${extensiones_de_texto[@]} " =~ " .${archivo_ext} " ]]; then
        echo -e "${BLUE}Archivo remoto:\n${NC}${FILE}"   
        descargar "${FILE}"
    fi
   
done

