#!/bin/bash

# Definir colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se ha proporcionado el argumento <ip:port>
if [ $# -ne 1 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase el argumento:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}<ip:port>${NC}\n"
    exit 1
fi

DEVICE="$1"

# Definir extensiones de texto que queremos buscar
extensiones_de_texto=(
    '.txt' '.py' '.c' '.cpp' '.java' '.html' '.css' '.js' '.php'
    '.vb' '.rb' '.sh' '.pl' '.swift' '.kt' '.scala' '.ini' '.cfg'
    '.conf' '.properties' '.env' '.config' '.xml' '.json'
    '.yaml' '.yml' '.xsd' '.svg' '.markdown' '.rtf' '.doc' '.docx'
    '.odt' '.tex' '.pptx' '.odp' '.key' '.xls' '.xlsx' '.ods' '.csv'
)

# Construir la opción --include para grep
include_opts=""
for ext in "${extensiones_de_texto[@]}"; do
    include_opts+="--include=\"*${ext}\" "
done

# Función para simplificar la creación de regex
crear_regex() {
    local palabra="$1"
    local regex_palabra=""
    
    # Variantes más comunes de letras acentuadas y equivalentes
    declare -A mapeo=(
        ["a"]='[aáàäâã]' ["e"]='[eéèêë]' ["i"]='[iíìîï]' ["o"]='[oóòôöõ]' ["u"]='[uúùûü]' ["n"]='[nñ]'
        ["á"]='[aáàäâã]' ["é"]='[eéèêë]' ["í"]='[iíìîï]' ["ó"]='[oóòôöõ]' ["ú"]='[uúùûü]' ["ñ"]='[nñ]'
    )
    
    # Construcción de la expresión regular
    for ((i=0; i<${#palabra}; i++)); do
        letra="${palabra:i:1}"
        lower_letra=$(echo "$letra" | tr '[:upper:]' '[:lower:]')
        
        if [[ "${mapeo[$lower_letra]}" ]]; then
            regex_palabra+="${mapeo[$lower_letra]}"
        else
            # Escapar caracteres especiales
            regex_palabra+="$(echo "$letra" | sed -e 's/[.*+?^${}()|[\]\/\\]/\\&/g')"
        fi
    done
    
    echo "$regex_palabra"
}

# Ejemplo de uso de la creación de regex
palabra="detener adb aplicacion dispositivo plus"
echo -e "Frase a transformar:\n$palabra"
regex=$(crear_regex "$palabra")
echo -e "Expresión regular generada:\n$regex"
regex_separador=$(echo "$regex" | tr ' ' '|')

# Realizar la búsqueda
echo -e "\nRealizando búsqueda en los archivos...\n"

# Utilizar grep para búsqueda en tiempo real
adb -s "$DEVICE" shell "grep --color=always -irn -E --line-buffered $include_opts '$regex_separador' '/sdcard/'" 2>/dev/null |
    # Eliminar bytes nulos
    tr -d '\000' |
    # Procesar cada línea
    while IFS= read -r linea; do
        # Extraer el archivo, la línea y el contenido
        archivo=$(echo "$linea" | awk -F: '{print $1}')
        numero_linea=$(echo "$linea" | awk -F: '{print $2}')
        contenido=$(echo "$linea" | cut -d: -f3-)

        # Verificar si el archivo ha cambiado
        if [ "$archivo" != "$archivo_actual" ]; then
            # Imprimir el archivo solo si ha cambiado
            if [ -n "$archivo_actual" ]; then
                echo ""
            fi
            echo -e "${BLUE}Archivo:${NC} $archivo"
            archivo_actual="$archivo"
        fi

        # Imprimir la línea encontrada
        echo -e "${CYAN}Línea $numero_linea:${NC} $contenido"
    done

# Salida
echo -e "\nBúsqueda completada."
