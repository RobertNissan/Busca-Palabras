#!/bin/bash

# Define el dispositivo
# DEVICE="emulator-5554"
# DEVICE="192.168.20.44:5555"

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color
COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Verificar si se ha proporcionado el argumento <ip:port>
if [ $# -ne 1 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase el argumento:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${COLOR_AMARILLO}bash ${COLOR_AZUL}${script_name} ${COLOR_ROJO}<ip:port>${NC}\n"
    exit 1
fi

DEVICE="$1"

# Define las extensiones de texto que queremos buscar
extensiones_de_texto=(
    '.txt' '.py' '.c' '.cpp' '.java' '.html' '.css' '.js' '.php'
    '.vb' '.rb' '.sh' '.pl' '.swift' '.kt' '.scala' '.ini' '.cfg'
    '.conf' '.properties' '.env' '.config' '.xml' '.json'
    '.yaml' '.yml' '.xsd' '.svg' '.plist' '.markdown' '.rtf'
    '.doc' '.docx' '.odt' '.tex' '.pptx' '.odp' '.key'
    '.xls' '.xlsx' '.ods' '.csv' '.tsv' '.log' '.dat' '.po'
    '.pot' '.mo' '.lst' '.out' '.err' '.rpt' '.man' '.help'
    '.eml' '.msg' '.chat' '.db' '.srt' '.pub' '.dy' ''
)

# Función para crear una expresión regular basada en la palabra ingresada
crear_regex() {
    local palabra="$1"
    local regex_palabra=""
    
    declare -A mapeo=(
        ["a"]='[aåąæāªáàäâã]' ["e"]='[eēęėëéèê]' ["i"]='[iīîįìíï]' ["o"]='[oºōøœõôöóò]' ["u"]='[uūùúüû]' ["n"]='[nñń]'
        ["á"]='[aåąæāªáàäâã]' ["é"]='[eēęėëéèê]' ["í"]='[iīîįìíï]' ["ó"]='[oºōøœõôöóò]' ["ú"]='[uūùúüû]' ["ñ"]='[nñń]'
    )
    
    for ((i=0; i<${#palabra}; i++)); do
        letra="${palabra:i:1}"
        lower_letra=$(echo "$letra" | tr '[:upper:]' '[:lower:]')
        
        if [[ "${mapeo[$lower_letra]}" ]]; then
            regex_palabra+="${mapeo[$lower_letra]}"
        elif [[ "$lower_letra" == "?" ]]; then
            continue # Omitir el signo de interrogación
        elif [[ "$letra" == " " ]]; then
            regex_palabra+=" " # Agregar espacio literal
        else
            # Escapar caracteres especiales para grep/sed
            regex_palabra+="$(printf '%q' "$letra" | sed 's/\./\\./g')"
        fi
    done
    
    echo "$regex_palabra"
}

limpiar() {
    FILE="${FILE#"${FILE%%[![:space:]]*}"}"
    echo "$FILE"
}

# Ejemplo de uso
palabra="detener adb aplicacion dispositivo plus?"
echo -e "frase a transformar:\n$palabra"
regex=$(crear_regex "$palabra")
echo -e "Expresión regular generada:\n$regex"
regex_separador=$(echo "$regex" | tr ' ' '|')
# regex_separador=$(echo "$regex" | sed 's/ \(.*\)/|\1/')
echo "$regex_separador"

# Realizar la búsqueda con grep
echo -e "\nRealizando búsqueda en los archivos...\n"

# adb -s "$DEVICE" shell grep --color=always -rn -E "'$regex_separador' '/sdcard/'"
# Recorrer solo las extensiones.txt y .sh ambas sirven puede elegir 1
adb -s "$DEVICE" shell find /sdcard/ \( -name "*.txt" -o -name "*.sh" \) -exec grep --color=always -rn -E "'$regex_separador'" {} +
adb -s "$DEVICE" shell grep --color=always -rn -E --include="*.txt" --include="*.sh" "'$regex_separador'" '/sdcard/'


# Comando ADB para encontrar y listar todos los archivos dentro de /sdcard/
adb -s $DEVICE shell "find /sdcard/ -path '/sdcard/Android' -prune -o -type f -print" | while read -r FILE; do
    # Escapar caracteres especiales en la ruta del archivo para adb shell
    ruta_mod=$(echo "$FILE" | sed 's/ /\\ /g; s/(/\\(/g; s/)/\\)/g; s/\[/\\[/g; s/\]/\\]/g; s/!/\\!/g; s/\$/\\$/g; s/\*/\\*/g; s/?/\\?/g')
    
    # Extrae la extensión del archivo
    archivo_ext="${FILE##*.}"

    # limpiando el espacio inicial de la cadena
    FILE=$(limpiar "$FILE")
    
    # Comprueba si la extensión está en la lista de extensiones permitidas
    if [[ " ${extensiones_de_texto[@]} " =~ " .$archivo_ext " ]]; then
        # Realizar la búsqueda con grep dentro del adb shell
        if grep --color=always -n -E "$regex_separador" "$FILE" 2>/dev/null; then
            echo -e "${COLOR_VERDE}$FILE${COLOR_RESET}\n"
            continue
        elif [ $? -eq 1 ]; then
            echo "No se encontraron coincidencias en el archivo: $FILE" >/dev/null
            continue
        elif [ $? -eq 2 ]; then
            echo "${COLOR_ROJO}Error: El archivo '$FILE' no se encuentra o no es accesible.${COLOR_RESET}" >/dev/null
            continue
        else
            echo "Ocurrió un error desconocido con grep1."
            echo "$FILE"
            continue
        fi
    fi
done
