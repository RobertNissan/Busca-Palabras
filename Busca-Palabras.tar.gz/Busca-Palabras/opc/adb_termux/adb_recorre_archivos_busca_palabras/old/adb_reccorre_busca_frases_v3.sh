#!/bin/bash

# Definir colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se ha proporcionado el argumento <ip:port>
if [ $# -ne 1 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase el argumento:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}<ip:port>${NC}\n"
    exit 1
fi

DEVICE="$1"

# Definir extensiones de texto que queremos buscar
extensiones_de_texto=(
    '.txt' '.py' '.c' '.cpp' '.java' '.html' '.css' '.js' '.php'
    '.vb' '.rb' '.sh' '.pl' '.swift' '.kt' '.scala' '.ini' '.cfg'
    '.conf' '.properties' '.env' '.config' '.xml' '.json'
    '.yaml' '.yml' '.xsd' '.svg' '.markdown' '.rtf' '.doc' '.docx'
    '.odt' '.tex' '.pptx' '.odp' '.key' '.xls' '.xlsx' '.ods' '.csv'
)

# Construir la opción --include para grep
include_opts=""
for ext in "${extensiones_de_texto[@]}"; do
    include_opts+="--include=\"*${ext}\" "
done

# Función para crear una expresión regular basada en la palabra ingresada
crear_regex() {
    local palabra="$1"
    local regex_palabra=""
    
    declare -A mapeo=(
        ["a"]='[aåąæāªáàäâã]' ["e"]='[eēęėëéèê]' ["i"]='[iīîįìíï]' ["o"]='[oºōøœõôöóò]' ["u"]='[uūùúüû]' ["n"]='[nñń]'
        ["á"]='[aåąæāªáàäâã]' ["é"]='[eēęėëéèê]' ["í"]='[iīîįìíï]' ["ó"]='[oºōøœõôöóò]' ["ú"]='[uūùúüû]' ["ñ"]='[nñń]'
    )
    
    for ((i=0; i<${#palabra}; i++)); do
        letra="${palabra:i:1}"
        lower_letra=$(echo "$letra" | tr '[:upper:]' '[:lower:]')
        
        if [[ "${mapeo[$lower_letra]}" ]]; then
            regex_palabra+="${mapeo[$lower_letra]}"
        elif [[ "$lower_letra" == "?" ]]; then
            continue # Omitir el signo de interrogación
        elif [[ "$letra" == " " ]]; then
            regex_palabra+=" " # Agregar espacio literal
        else
            # Escapar caracteres especiales para grep/sed
            regex_palabra+="$(printf '%q' "$letra" | sed 's/\./\\./g')"
        fi
    done
    
    echo "$regex_palabra"
}


# Función para mostrar instrucciones de uso
mostrar_instrucciones() {
    echo -e "\n${YELLOW}Instrucciones de uso:${NC}"
    echo -e "Debe ingresar las frases de búsqueda separadas por el carácter | (barra vertical)."
    echo -e "Ejemplo: ${CYAN}adb|kill-server${NC} o ${CYAN}speed metal${NC}"
    echo -e "${YELLOW}Nota:${NC} Si no se ingresa nada, se volverá a solicitar la entrada.\n"
}
# Ejemplo de uso de la creación de regex
# Iniciar un bucle para solicitar las frases de búsqueda hasta que se ingresen
while :; do
    read -p "Ingrese las frases de búsqueda (separadas por '|'): " frases
    # Si el usuario no ingresa nada, mostrar instrucciones
    if [ -z "$frases" ]; then
        mostrar_instrucciones
    else
        break
    fi
done
# frases="speed metal"
# frases="adb|speed metal"
IFS='|' read -ra frases_array <<< "$frases"
regex_final=""
for frase in "${frases_array[@]}"; do
    regex=$(crear_regex "$frase")
    regex_final+="$regex|"
done

# Quitar el último pipe
regex_final=${regex_final%|}

echo -e "Frases a transformar:\n$frases"
echo -e "Expresión regular generada:\n$regex_final"

# Realizar la búsqueda
echo -e "\nRealizando búsqueda en los archivos...\n"

# Recorrer solo las extensiones.txt y .sh ambas sirven puede elegir 1
# adb -s "$DEVICE" shell find /sdcard/ \( -name "*.txt" -o -name "*.sh" \) -exec grep --color=always -rn -E "'$regex_separador'" {} +
# adb -s "$DEVICE" shell grep --color=always -rn -E --include="*.txt" --include="*.sh" "'$regex_separador'" '/sdcard/'

# Capturar la hora de inicio
inicio=$(date +%s)
hora_inicio=$(date +"%T")

echo -e "${GREEN}Hora de inicio:${NC} $hora_inicio"

# ver codificación de un archivo 
# pkg install file
# file -i adb_buscador3.sh # Motrar la codificación

if [ -e $PREFIX/bin/iconv ]; then
    echo ""
else
    pkg install iconv
fi
convert_utf8() {
   # por si un paquete esta en conflicto con la instalación de iconv, en mi caso fue cloudflared 
   # E: The package cloudflared:arm64 needs to be reinstalled, but I can't find an archive for it.
   # solución
    # dpkg --remove --force-remove-reinstreq cloudflared
    # Reparar la base de datos dedpkg
    # Una vez eliminado, puedes intentar reparar cualquier problema residual con dpkg:
    # dpkg --configure -a
    if [ -e $PREFIX/bin/iconv ]; then
        echo ""
    else
        pkg install iconv
    fi
    local linea="${1}"
    local linea_utf8
    # Intentar convertir la línea a UTF-8 desde ISO-8859-1
    linea_utf8=$(echo "${linea}" | iconv -f ISO-8859-1 -t UTF-8 2>/dev/null || \
    echo "${linea}" | iconv -f WINDOWS-1252 -t UTF-8 2>/dev/null || \
    echo "${linea}" | iconv -f UTF-16 -t UTF-8 2>/dev/null)
    if [ $? -ne 0 ]; then
        # Si aún falla, devolver la línea original
        linea_utf8="${linea}"
    fi
    echo "${linea_utf8}"
}     

descargar() {
    DEVICE="$1"
    archivo="$2"   
    # Asegúrate de que las variables no contienen códigos de color
    DEVICE=$(echo "$DEVICE" | sed 's/\x1b\[[0-9;]*m//g')
    archivo=$(echo "$archivo" | sed 's/\x1b\[[0-9;]*m//g')
    # Descargar el archivo desde Android a la máquina local
    adb -s "$DEVICE" pull "$archivo" /sdcard/txt/$(basename "$archivo") 2>/dev/null
    # Verificar si la descarga fue exitosa
    if [ $? -eq 0 ]; then
        echo -e "${CYAN}Archivo descargado a /sdcard/txt/$(basename "$archivo"${NC})"
        archivo_actual="$archivo"
    else
        echo -e "Error al descargar el archivo ${archivo}"
    fi
}

# Utilizar grep para búsqueda en tiempo real
# Nota: tuve que tener en cuenta encerrar la variable de la frase entre corchetes '{}' para que lograra hacer múltiples búsquedas, de lo contrario solo buscará una frase!!!
adb -s "$DEVICE" shell grep -irn -E --line-buffered "${include_opts} '${regex_final}' '/sdcard/'" 2>/dev/null | iconv -f UTF-8 -t UTF-8//IGNORE |
    # Eliminar bytes nulos
    tr -d '\000' |
    # Procesar cada línea
    while IFS= read -r linea; do
        # Extraer el archivo, la línea y el contenido
        archivo=$(echo "${linea}" | awk -F: '{print $1}')
        numero_linea=$(echo "${linea}" | awk -F: '{print $2}')
        contenido=$(echo "${linea}" | cut -d: -f3-)

        # Verificar si el archivo ha cambiado
        if [ "${archivo}" != "${archivo_actual}" ]; then
            # Si el archivo ha cambiado, descargar el nuevo archivo a la máquina local
            if [ -n "${archivo_actual}" ]; then
                echo ""
            fi
            echo -e "${BLUE}Archivo:${NC} ${archivo}"
             descargar "${DEVICE}" "${archivo}"    
        fi

        # Imprimir la línea encontrada desde el archivo descargado
        # Procesar el contenido del archivo localmente si es necesario
        # Resaltar las coincidencias en la variable usando awk
        echo -e "$contenido" | awk -v rojo="$RED" -v reset="$NC" -v regex="$regex" '
        {
            # En cada línea, resaltar todas las coincidencias
            while (match($0, regex)) {
                # Imprimir el texto antes de la coincidencia
                printf "%s", substr($0, 1, RSTART-1)
                # Imprimir la coincidencia resaltada
                printf "%s%s%s", rojo, substr($0, RSTART, RLENGTH), reset
                # Eliminar el texto procesado
                $0 = substr($0, RSTART + RLENGTH)
            }
            # Imprimir el resto de la línea que no fue procesado
            print $0
        }'
        # echo -e "Línea ${numero_linea}: ${contenido}"
    done

# Capturar la hora de finalización
fin=$(date +%s)
hora_fin=$(date +"%T")

# Calcular la duración
duracion=$((fin - inicio))

# Mostrar la hora de finalización y el tiempo de duración
echo -e "${GREEN}Hora de finalización:${NC} $hora_fin"
echo -e "${YELLOW}Tiempo de duración:${NC} ${duracion} segundos"

echo -e "Búsqueda completada.\n"

