#!/bin/bash

# adb recorrer archivo en directorio y subdirectorios
# Define el dispositivo
DEVICE="emulator-5554"

# Define las extensiones de texto que queremos buscar
extensiones_de_texto=(
    '.txt' '.py' '.c' '.cpp' '.java' '.html' '.css' '.js' '.php'
    '.vb' '.rb' '.sh' '.pl' '.swift' '.kt' '.scala' '.ini' '.cfg'
    '.conf' '.properties' '.env' '.config' '.xml' '.json'
    '.yaml' '.yml' '.xsd' '.svg' '.plist' '.markdown' '.rtf'
    '.doc' '.docx' '.odt' '.pdf' '.tex' '.pptx' '.odp' '.key'
    '.xls' '.xlsx' '.ods' '.csv' '.tsv' '.log' '.dat' '.po'
    '.pot' '.mo' '.lst' '.out' '.err' '.rpt' '.man' '.help'
    '.eml' '.msg' '.chat' '.db' '.srt' '.pub' '.dy' ''
)
#extensiones_de_texto=('.dy')
# Comando ADB para encontrar y listar todos los archivos dentro de /sdcard/
adb -s $DEVICE shell "find /sdcard/ -type f" | while read -r FILE; do
    # Extrae la extensión del archivo
    archivo_ext="${FILE##*.}"
    
    # Comprueba si la extensión está en la lista de extensiones permitidas
    if [[ " ${extensiones_de_texto[@]} " =~ " .$archivo_ext " ]]; then
        echo "Archivo encontrado: $FILE"
    fi
done
