#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # Sin color

# Función para verificar si la app se actualizó hoy
app_actualizada_hoy() {
    local dispositivo="$1"
    local paquete="$2"
    
    # Obtener la fecha de la última actualización directamente en formato YYYY-MM-DD
    lastUpdate=$(adb -s "$dispositivo" shell dumpsys package "$paquete" | grep -E "lastUpdateTime" | sed 's/lastUpdateTime=\([0-9\-]*\).*/\1/' | head -n 1 | xargs)

    # Verificar si se obtuvo la fecha correctamente
    if [ -z "$lastUpdate" ]; then
        echo -e "${RED}[X] No se pudo obtener la fecha de última actualización para $paquete.${NC}"
        return 1
    fi

    # Convertir el timestamp de milisegundos a formato YYYY-MM-DD
    # lastUpdateFormatted=$(date -d @"$((lastUpdate / 1000))" +%Y-%m-%d 2>/dev/null)

    # Obtener la fecha actual en formato YYYY-MM-DD
    currentDate=$(date +%Y-%m-%d)

    # Mostrar las fechas para depuración
    #echo -e "${YELLOW}Verificando aplicación: $paquete${NC}"
    #echo -e "Fecha última actualización: ${lastUpdateFormatted}"
    #echo -e "Fecha actual: ${currentDate}"

    # Comparar las fechas
    if [ "$lastUpdate" = "$currentDate" ]; then
        return  # Actualizada hoy
    else
        return  # No actualizada hoy
    fi
}

# Función para listar aplicaciones actualizadas hoy
listar_apps_actualizadas_hoy_otimizar() {
    local dispositivo="$1"

    echo -e "${YELLOW}Obteniendo lista de todas las aplicaciones para el dispositivo:${NC} $dispositivo"

    # Obtener todas las aplicaciones instaladas (sistema y usuario)
    apps=$(adb -s "$dispositivo" shell pm list packages)

    aplicaciones_actualizadas=0

    # Verificar cada aplicación para ver si fue actualizada hoy
    for app in $apps; do
        if app_actualizada_hoy "$dispositivo" "${app#*:}"; then
            echo -en "${GREEN}[OPTIMIZANDO]${NC} - ${CYAN}Mejorando el inicio de ${app#*:} (Actualizada hoy):${NC} "
            adb -s "$dispositivo" shell cmd package compile -m speed-profile "${app#*:}"
            echo -e "${GREEN}[✓]${NC} - Optimización de $paquete completada."
            aplicaciones_actualizadas=1
        fi
    done

    # Mensaje si no hay aplicaciones actualizadas hoy
    if [ $aplicaciones_actualizadas -eq 0 ]; then
        echo -e "${RED}No se encontraron aplicaciones actualizadas hoy.${NC}"
    fi
}

# Llamar a la función para listar las apps actualizadas hoy
listar_apps_actualizadas_hoy_otimizar "emulator-5554"
