#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Función para listar las aplicaciones de usuario y mostrar las del sistema incluidas
listar_apps_usuario_y_sistema() {
    incluidas_app=("com.facebook.katana" "com.android.chrome" "com.google.android.gm" "com.netflix.ninja" "com.google.android.apps.maps" "com.google.android.gm")
    
    local dispositivo="$1"
    echo -e "${YELLOW}Obteniendo lista de todas las aplicaciones de usuario para el dispositivo${NC}: $dispositivo"
    
    # Obtener paquetes de usuario (third-party apps)
    packages_usuario=$(adb -s "$dispositivo" shell pm list packages -3 | cut -d':' -f2)
    
    # Verificar si hay paquetes de usuario y mostrarlos
    if [[ -n "${packages_usuario}" ]]; then
        echo -e "${GREEN}Aplicaciones de usuario instaladas${NC}:"
        echo "$packages_usuario" | while IFS= read -r app; do
            echo "$app" # Mostrar cada aplicación en una nueva línea
        done
    else
        echo -e "${RED}No se encontraron aplicaciones de usuario en este dispositivo${NC}."
    fi

    # Luego, verificar las aplicaciones del sistema incluidas
    echo -e "${YELLOW}Verificando las aplicaciones del sistema incluidas en la lista${NC}..."
    packages_sistema=$(adb -s "$dispositivo" shell pm list packages -s | cut -d':' -f2)
    
    # Mostrar solo las aplicaciones incluidas que estén instaladas en el sistema
    encontrado=0
    for incluida in "${incluidas_app[@]}"; do
        if echo "$packages_sistema" | grep -q "$incluida"; then
            if [[ $encontrado -eq 0 ]]; then
                echo -e "${GREEN}Aplicaciones del sistema incluidas encontradas${NC}:"
            fi
            echo "$incluida" # Mostrar cada aplicación en una nueva línea
            encontrado=1
        fi
    done

    # Si no se encontró ninguna aplicación incluida en las del sistema
    if [[ $encontrado -eq 0 ]]; then
        echo "Ninguna de las aplicaciones incluidas está instalada en el sistema."
    fi
}

# Llamar a la función para listar las aplicaciones
listar_apps_usuario_y_sistema "emulator-5554"
