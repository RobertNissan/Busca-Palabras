# RSYNC Y SSH: Este método usa ssh y rsync, sirve para reanudar el envío de archivos. y si ya está completo no hace nada para no sobreescribir 

rsync -avP -e "ssh -p 8022" "tasker y autoresponder dicen nombre del remitente WhatsApp.mp4" u0_a275@192.168.20.34:/sdcard/Movies/