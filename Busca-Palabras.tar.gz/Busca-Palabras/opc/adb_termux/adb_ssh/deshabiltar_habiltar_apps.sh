#!/bin/bash

while true; do
    echo "Dispositivos disponibles:"
    dispositivos=$(adb devices)

    if ! echo "$dispositivos" | grep -q "device"; then
        echo "No se ha detectado ningun dispositivo. Asegurate de que tu dispositivo este conectado y la depuracion USB este habilitada."
        echo "Para habilitar la depuracion USB en Android:"
        echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
        echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
        echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
        echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
        echo "5. Habilita 'Depuracion USB'."
        exit 1
    fi

    while true; do
        adb devices
        read -p "Ingrese el numero del dispositivo o 'q' para salir: " dispositivo

        if [ -z "$dispositivo" ]; then
            echo "Por favor, ingrese un numero de dispositivo valido de la lista."
            continue
        elif [ "$dispositivo" == "q" ]; then
            break 2  # Salir de ambos bucles
        elif ! echo "$dispositivos" | grep -q "$dispositivo"; then
            echo "El dispositivo no se encuentra en la lista. Por favor, ingrese un dispositivo valido."
            continue
        fi

        while true; do
            echo "Ingrese el numero de la opcion deseada:"
            echo "1 - Deshabilitar aplicaciones"
            echo "2 - Habilitar aplicaciones"
            echo "3 - Volver a seleccionar dispositivo"
            echo "4 - Salir"

            read -p "Seleccione una opcion: " opcion

            case $opcion in
                1)
                    # Resto del codigo para deshabilitar aplicaciones
                    ;;
                2)
                    # Resto del codigo para habilitar aplicaciones
                    ;;
                3)
                    break  # Volver a seleccionar dispositivo
                    ;;
                4)
                    exit 0  # Salir del script
                    ;;
                *)
                    echo "Opcion invalida. Por favor, seleccione 1, 2, 3 o 4."
                    ;;
            esac
        done
    done
done
