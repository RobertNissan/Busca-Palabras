#!/bin/bash
echo ""
echo "Brand ID: $(getprop ro.product.system.brand)"
echo "Modelo: $(getprop ro.product.model)"
echo "Version de Android: $(getprop ro.build.version.release)"
echo "Model ID: $(getprop ro.build.product)"
echo "Kernel ID: $(uname -r)"
echo "Chipset ID: $(getprop ro.product.board)"
echo "Architecture: $(uname -m)"

str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
ip=$(echo "${str%%/*}")
echo -e ""

# Ejecuta el siguiente comando para desbloquear los FPS a 120:
# adb shell settings put global 0.0_fps_max 120

function connect {
echo "Conectando, por favor, espere..."
    puertos=$(nmap -p 22-65535 -Pn "${ip}" | awk '/^ *[0-9]/ {print $1}')  # Obtener solo los numeros de puerto
    for p in $puertos; do
        verif_con=$(adb connect "${ip}:${p}")
        if [[ "$resultado" == *"failed"* ]]; then
            echo -e "La conexion fallo. Mensaje: $verif_con"
        else
            echo "La conexion fue exitosa."
            adb connect "${ip}:${p}"
            seleccionar_dispositivo
        fi
    done
exit 2
}

function mostrar_instrucciones {
    echo "Para habilitar la depuracion USB en Android, para hacer conexion adb:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB'."
    echo ""
    echo 'Si solo necesitas que se active en tu android, activa "Depuracion inalambirca"'
    echo '6. Selecciona donde dice: "Vincular dispositivo con codigo de sincronizacion"'
    echo -e  'En ta parte se mostrara una pequena ventana que dice:'
    echo -e "Vincular con disposivo\nCodigo de vinculacion de WI-FI\n123456\nDireccion IP y puerto\n${ip}:12345"
    echo '7. Habilitar la pantalla dividida entre "Vincular dispositivo con codigo de sincronizacion" y "Termux"' 
    
    
    : '
    #on/off Datos Mobiles
    #adb shell svc data disable
    # adb shell svc data enable
    if [ -x $PREFIX/share/doc/termux-api ]; then
        echo Existe >/dev/null 2>&1
    else 
        echo "Instalando termux-api"
        pkg install termux-api
    fi
    if [ -e ${HOME}/Termux_API_0.50.1.apk ]; then 
        echo "Ya esta descargado"
        sleep 2
        xdg-open Termux_API_0.50.1.apk
        #clear
    else
        echo -e ""
        echo "Descargando Termux_API_0.50.1"
        echo -e ""
        cd ${HOME};wget https://www.dropbox.com/s/ul0wj8yud8mq03f/Termux_API_0.50.1.apk
        xdg-open Termux_API_0.50.1.apk
    fi
    : '
    
    #adb shell dumpsys wifi
    #adb -s emulator-5554 shell dumpsys netstats
    #WiFi on/off
    #termux-wifi-enable false
    termux-wifi-enable true
    
    if adb shell ping -c 1 google.com > /dev/null; then
    echo "Conexion a Internet a traves del enrutador WiFi"
    
    echo "Ingresa el puerto"
    read -p "$ip:" puerto
    echo -n "Ingrese codigo  de emparejamiento:"
    resultado=$(adb pair "${ip}:${puerto}" 2>&1)  # Capturar la salida del comando y el error
    
    if [[ "$resultado" == *"Failed"* ]]; then
        echo "La conexion fallo. Mensaje: $resultado"
    else
        echo "La conexion fue exitosa."
        connect
    fi
    
else
    echo "No hay conexion a Internet a traves del enrutador WiFi"
    exit 1
fi
    exit 1 
    
}

function deshabilitar_aplicaciones {
    echo "Opcion seleccionada: Deshabilitar aplicaciones"
    read -p "Ingrese el nombre del paquete de la aplicacion que desea deshabilitar (deje en blanco para volver): " paquete
    
    if [ -z "$paquete" ]; then
        echo "Nombre del paquete vacio." 
        deshabilitar_aplicaciones
        #return
        #break
    elif [ ${#paquete} -lt 3 ]; then
        echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        deshabilitar_aplicaciones
    elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
        adb -s "$dispositivo" shell pm disable-user --user 0 "$paquete"
        echo "Aplicacion deshabilitada correctamente."
    else
        echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
        deshabilitar_aplicaciones
    fi
}

function habilitar_aplicaciones {
    echo "Opcion seleccionada: Habilitar aplicaciones"
    read -p "Ingrese el nombre del paquete de la aplicacion que desea habilitar (deje en blanco para volver): " paquete
    
    if [ -z "$paquete" ]; then
        echo "Nombre del paquete vacio." 
        habilitar_aplicaciones
        #return
        #break
    elif [ ${#paquete} -lt 3 ]; then
        echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        habilitar_aplicaciones
    elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
        adb -s "$dispositivo" shell pm enable "$paquete"
        echo "Aplicacion habilitada correctamente."
    else
        echo "Nombre del paquete no valido. Por favor, ingrese un nombre de paquete valido."
        habilitar_aplicaciones
    fi
}

function seleccionar_dispositivo {
    dispositivos=$(adb devices)
echo -e ""

# Inicializar listas
dispositivos_disponibles=()
dispositivos_offline=()
dispositivos_no_autorizados=()

# Filtrar dispositivos autorizados (device)
d=$(echo "$dispositivos" | grep -E "device" | grep -v "List")

if [ -n "$d" ]; then
    echo "Dispositivos disponibles:"
    for linea in $d; do
        if [ "$linea" == "device" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
        # En Windows
            adb -s %linea% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
           # En Linux
           modelo=$(adb -s "$linea" shell 'echo -e "\033[34m$(getprop ro.product.model)\033[0m" | fmt -w 40')
        fi
        echo "$linea device $modelo"
        # Agregar a la lista
        dispositivos_disponibles+=("$linea")
        vacios=$(echo "No.")
    done
else
    vacios=$(echo "No hay dispositivos disponibles.")
    #return  # Utilizar return en lugar de break
fi

# Filtrar dispositivos offline
dispositivos_off=$(adb devices | grep -E 'offline' | grep -v "List" | cut -d ' ' -f1-)

if [ -n "$dispositivos_off" ]; then
    echo "Dispositivos offline:"
    for linea1 in $dispositivos_off; do
        if [ "$linea1" == "offline" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
        # En Windows
            adb -s %linea1% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
           # En Linux
           adb -s "$linea1" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40'
        fi
        echo "$linea1 offline"
        # Agregar a la lista
        dispositivos_offline+=("$linea1")
        vacios1=$(echo "No.")
    done
else
    vacios1=$(echo "No hay dispositivos offline.")
    #return  # Utilizar return en lugar de break
fi

# Filtrar dispositivos no autorizados (unauthorized)
dispositivos_unauthorize=$(adb devices | grep -E 'unauthorized' | grep -v "List" | cut -d ' ' -f1-)

if [ -n "$dispositivos_unauthorize" ]; then
    echo "Dispositivos no autorizados:"
    for linea2 in $dispositivos_unauthorize; do
        if [ "$linea2" == "unauthorized" ]; then
            continue
        fi
        # Obtener el sistema operativo actual
        sistema_operativo=$(uname -s)
        if [[ "$sistema_operativo" == *"Windows"* ]]; then
        # En Windows
            adb -s %linea2% shell 'echo Modelo: $(getprop ro.product.model)' | fmt -w 40 | color 1F
        else
           # En Linux
           adb -s "$linea2" shell 'echo -e "\033[34mModelo: $(getprop ro.product.model)\033[0m" | fmt -w 40'
        fi
        echo "$linea2 unauthorized"
        # Agregar a la lista
        dispositivos_no_autorizados+=("$linea2")
        vacios2=$(echo "No.")
    done
else
    vacios2=$(echo "No hay dispositivos no autorizados.")
    #return  # Utilizar return en lugar de break
fi


if [[ "$vacios" == 'No hay dispositivos disponibles.' ]] && [[ "$vacios1" == 'No hay dispositivos offline.' ]] && [[ "$vacios2" == 'No hay dispositivos no autorizados.' ]]; then
    mostrar_instrucciones
fi

# Ahora puedes verificar si un dispositivo esta en una lista
read -p "Ingrese el numero del dispositivo o 'q' para salir: " dispositivo

if [ -z "$dispositivo" ]; then
    echo "Por favor, ingrese un numero de dispositivo valido de la lista."
    seleccionar_dispositivo
elif [ "$dispositivo" == "q" ]; then
    exit 0
elif [[ " ${dispositivos_disponibles[@]} " =~ " $dispositivo " ]]; then
    echo "$dispositivo esta en la lista de dispositivos disponibles."
    mostrar_menu
elif [[ " ${dispositivos_offline[@]} " =~ " $dispositivo " ]]; then
    echo "$dispositivo esta en la lista de dispositivos offline."
    mostrar_menu
elif [[ " ${dispositivos_no_autorizados[@]} " =~ " $dispositivo " ]]; then
    echo "$dispositivo esta en la lista de dispositivos no autorizados."
    mostrar_menu
else
    echo "$dispositivo no se encontro en ninguna lista."
    seleccionar_dispositivo
fi
    echo ""
    
}

function mostrar_menu {
    echo ""
    echo "Ingrese el numero de la opcion deseada:"
    echo "1 - Deshabilitar aplicaciones"
    echo "2 - Habilitar aplicaciones"
    echo "3 - Volver a seleccionar dispositivo"
    echo "4 - Salir"
    

#function leer_opcion {
    #local dispositivo=$1

    read -p "Seleccione una opcion: " opcion

    case $opcion in
        1)
            deshabilitar_aplicaciones
            ;;
        2)
            habilitar_aplicaciones
            ;;
        3)
            seleccionar_dispositivo
            ;;
        4)
            exit 0
            ;;
        *)
            echo "Opcion invalida. Por favor, seleccione 1, 2, 3 o 4."
            mostrar_menu $dispositivo
            ;;
    esac
}

# Iniciar el script llamando a la funcion principal
seleccionar_dispositivo
