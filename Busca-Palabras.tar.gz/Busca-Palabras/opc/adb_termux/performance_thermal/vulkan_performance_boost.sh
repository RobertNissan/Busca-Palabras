#!/system/bin/sh
# vulkan_performance_boost.sh - Optimizaciones Vulkan avanzadas para Moto G20

ACTION="$1"
BACKUP_DIR="/data/local/tmp/vulkan_backup"

log() {
    echo "[VULKAN] $1"
}

backup_prop() {
    PROP="$1"
    VAL=$(getprop "$PROP" 2>/dev/null)
    if [ -n "$VAL" ]; then
        mkdir -p "$BACKUP_DIR" 2>/dev/null
        echo "$PROP=$VAL" >> "$BACKUP_DIR/props.bak"
    fi
}

setprop() {
    PROP="$1"
    VAL="$2"
    backup_prop "$PROP"
    setprop "$PROP" "$VAL" 2>/dev/null
}

vulkan_boost() {
    log "Aplicando optimizaciones Vulkan avanzadas..."
    
    mkdir -p "$BACKUP_DIR" 2>/dev/null
    
    # Vulkan core optimizations
    setprop "debug.hwui.renderer" "skiavk"
    setprop "debug.vulkan.layers" ""
    setprop "debug.vulkan.enable_callback" "false"
    setprop "debug.vulkan.disable_validation" "true"
    setprop "ro.hwui.use_vulkan" "true"
    
    # GPU memory optimizations
    setprop "debug.hwui.gpu_memory" "2048"
    setprop "debug.vulkan.memory" "2048"
    setprop "debug.hwui.raster_cache_size" "32"
    
    # Rendering optimizations
    setprop "debug.egl.hw" "1"
    setprop "debug.sf.hw" "1"
    setprop "debug.composition.type" "gpu"
    setprop "debug.sf.latch_unsignaled" "1"
    setprop "debug.sf.disable_backpressure" "1"
    
    # Performance tweaks
    setprop "debug.hwui.force_draw" "true"
    setprop "debug.hwui.use_gpu" "true"
    setprop "debug.performance.tuning" "1"
    
    # Gaming specific
    setprop "debug.vulkan.swap_chain.image_count" "3"
    setprop "debug.vulkan.swapinterval" "1"
    
    log "✔ Vulkan optimizations applied"
}

emulator_boost() {
    log "Aplicando optimizaciones para emuladores..."
    
    # Dolphin/PPSSPP specific
    setprop "debug.gralloc.enable_fb_ubwc" "1"
    setprop "debug.sf.enable_hwc_vds" "1"
    
    # Audio latency for emulation
    setprop "audio.deep_buffer.media" "false"
    setprop "audio.offload.disable" "true"
    
    # Memory management
    setprop "ro.config.fha_enable" "true"
    setprop "ro.sys.fw.bg_apps_limit" "6"
    
    log "✔ Emulator optimizations applied"
}

gpu_boost() {
    log "Optimizando GPU para Vulkan..."
    
    # GPU frequency (if accessible)
    GPU_DIR="/sys/class/devfreq/60000000.gpu"
    if [ -w "$GPU_DIR/governor" ]; then
        echo "performance" > "$GPU_DIR/governor" 2>/dev/null
        log "GPU governor set to performance"
    fi
    
    # GPU rendering
    setprop "debug.hwui.force_gpu_rendering" "1"
    setprop "debug.hwui.use_cpu" "false"
    setprop "debug.egl.force_msaa" "true"
    
    log "✔ GPU optimizations applied"
}

restore_vulkan() {
    log "Restaurando configuración anterior..."
    
    if [ -f "$BACKUP_DIR/props.bak" ]; then
        while IFS='=' read -r prop val; do
            setprop "$prop" "$val" 2>/dev/null
        done < "$BACKUP_DIR/props.bak"
        log "✔ Properties restored"
    fi
    
    # Reset to OpenGL
    setprop "debug.hwui.renderer" "opengl" 2>/dev/null
    setprop "ro.hwui.use_vulkan" "false" 2>/dev/null
    
    log "✔ Vulkan disabled, OpenGL restored"
}

status_vulkan() {
    echo "=== VULKAN STATUS ==="
    echo ""
    echo "Renderer: $(getprop debug.hwui.renderer)"
    echo "Vulkan enabled: $(getprop ro.hwui.use_vulkan)"
    echo "GPU memory: $(getprop debug.hwui.gpu_memory)"
    echo "Composition: $(getprop debug.composition.type)"
    echo ""
    echo "GPU Governor: $(cat /sys/class/devfreq/60000000.gpu/governor 2>/dev/null || echo 'N/A')"
    echo "GPU Freq: $(cat /sys/class/devfreq/60000000.gpu/cur_freq 2>/dev/null || echo 'N/A')"
    echo "=== END STATUS ==="
}

case "$ACTION" in
    enable)
        vulkan_boost
        emulator_boost
        gpu_boost
        ;;
    gaming)
        vulkan_boost
        emulator_boost
        gpu_boost
        log "Gaming mode activated with Vulkan"
        ;;
    restore)
        restore_vulkan
        ;;
    status)
        status_vulkan
        ;;
    *)
        echo "Uso: sh /sdcard/vulkan_performance_boost.sh [enable|gaming|restore|status]"
        echo ""
        echo "enable  - Activa optimizaciones Vulkan"
        echo "gaming  - Modo gaming completo"
        echo "restore - Restaura OpenGL"
        echo "status  - Muestra estado actual"
        ;;
esac
