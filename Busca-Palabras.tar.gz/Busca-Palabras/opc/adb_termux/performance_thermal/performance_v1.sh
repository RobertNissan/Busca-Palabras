#!/system/bin/sh
# performance_intermedio.sh - Moto G20 (seguro y rápido)

ACTION="$1"
BACKUP_DIR="/data/local/tmp/perf_g20_safe"

log() {
    echo "[*] $1"
}

backup_file() {
    SRC="$1"
    DST="$BACKUP_DIR/$(basename $SRC).bak"
    if [ -e "$SRC" ]; then
        mkdir -p "$BACKUP_DIR" 2>/dev/null
        cp "$SRC" "$DST" 2>/dev/null
    fi
}

write_val() {
    FILE="$1"
    VAL="$2"
    if [ -w "$FILE" ]; then
        echo "$VAL" > "$FILE" 2>/dev/null
    fi
}

# =====================================================
#      ENABLE – RÁPIDO, SEGURO, SIN CALENTÓN
# =====================================================

enable_perf() {
    log "Aplicando modo intermedio seguro..."

    mkdir -p "$BACKUP_DIR" 2>/dev/null

    # ---------------------------------------------------
    # THERMAL (CPU sigue protegido, GPU suavizado)
    # ---------------------------------------------------
    for T in /sys/devices/virtual/thermal/thermal_zone*/mode; do
        backup_file "$T"

        zone=$(basename "$(dirname "$T")")

        case "$zone" in
            thermal_zone0|thermal_zone1|thermal_zone2)
                # CPU / battery → mantener ON
                write_val "$T" "enabled"
                ;;
            *)
                # GPU / PMIC → suavizar
                write_val "$T" "disabled"
                ;;
        esac
    done

    # ---------------------------------------------------
    # CPU (igual que tu script, ultra rápido pero seguro)
    # ---------------------------------------------------

    CPU0_GOV="/sys/devices/system/cpu/cpufreq/policy0/scaling_governor"
    CPU0_MIN="/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq"
    CPU0_MAX="/sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq"

    backup_file "$CPU0_GOV"
    backup_file "$CPU0_MIN"
    backup_file "$CPU0_MAX"

    write_val "$CPU0_GOV" "performance"
    write_val "$CPU0_MIN" "614400"
    write_val "$CPU0_MAX" "1820000"

    CPU6_GOV="/sys/devices/system/cpu/cpufreq/policy6/scaling_governor"
    CPU6_MIN="/sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq"
    CPU6_MAX="/sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq"

    backup_file "$CPU6_GOV"
    backup_file "$CPU6_MIN"
    backup_file "$CPU6_MAX"

    write_val "$CPU6_GOV" "performance"
    write_val "$CPU6_MIN" "1228800"
    write_val "$CPU6_MAX" "1820000"

    # ---------------------------------------------------
    # GPU igual a tu script (potente y sin riesgo)
    # ---------------------------------------------------

    GPU_DIR="/sys/class/devfreq/60000000.gpu"
    GPU_GOV="$GPU_DIR/governor"
    GPU_MIN="$GPU_DIR/min_freq"
    GPU_MAX="$GPU_DIR/max_freq"

    backup_file "$GPU_GOV"
    backup_file "$GPU_MIN"
    backup_file "$GPU_MAX"

    write_val "$GPU_GOV" "performance"
    write_val "$GPU_MIN" "200000000"
    write_val "$GPU_MAX" "850000000"

    log "✔ Modo intermedio seguro activado."
}

# =====================================================
# RESTORE
# =====================================================

restore_perf() {
    log "Restaurando valores originales..."

    if [ ! -d "$BACKUP_DIR" ]; then
        log "No hay backups."
        exit 1
    fi

    for B in $BACKUP_DIR/*.bak; do
        base=$(basename $B | sed 's/.bak$//')
        find /sys -type f -name "$base" -exec cp "$B" {} \; 2>/dev/null
    done

    log "✔ Restaurado."
}

# =====================================================
# STATUS
# =====================================================

status_perf() {
    echo "=== STATUS PERF G20 (INTERMEDIO) ==="

    echo "-- Thermal Zones --"
    for T in /sys/devices/virtual/thermal/thermal_zone*/mode; do
        echo "$T: $(cat $T)"
    done

    GPU_DIR="/sys/class/devfreq/60000000.gpu"
    echo ""
    echo "-- GPU --"
    echo "Governor: $(cat $GPU_DIR/governor)"
    echo "Min freq: $(cat $GPU_DIR/min_freq)"
    echo "Max freq: $(cat $GPU_DIR/max_freq)"

    echo ""
    echo "-- CPU policy 0 --"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq)"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq)"

    echo ""
    echo "-- CPU policy 6 --"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_governor)"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq)"
    echo "$(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq)"

    echo "==============================="
}

case "$ACTION" in
    enable) enable_perf ;;
    restore) restore_perf ;;
    status) status_perf ;;
    *)
        echo "Uso: sh perf_intermedio.sh [enable|restore|status]"
        ;;
esac
