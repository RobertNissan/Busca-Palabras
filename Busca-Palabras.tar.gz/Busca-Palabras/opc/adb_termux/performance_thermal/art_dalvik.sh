#!/usr/bin/env bash
# optimizar_art_agresivo.sh
# Uso: bash optimizar_art_agresivo.sh [device_serial]
# Más agresivo que el script anterior; chequea memoria antes de aplicar.

dispositivo="$1"
if [ -z "$dispositivo" ]; then
  ADB="adb"
else
  ADB="adb -s $dispositivo"
fi

# Backup como antes (si no existe ya uno reciente)
BACKUP_DIR="./art_props_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
PROPS_LIST=(
  "dalvik.vm.jit"
  "dalvik.vm.jit.threshold"
  "dalvik.vm.jit.initial.threshold"
  "dalvik.vm.jit.count"
  "dalvik.vm.usejitprofiles"
  "dalvik.vm.dex2oat-threads"
  "dalvik.vm.dexopt-flags"
  "dalvik.vm.gc.type"
)
echo "[*] Guardando propiedades actuales..."
for p in "${PROPS_LIST[@]}"; do
  val=$($ADB shell getprop "$p" 2>/dev/null | tr -d '\r')
  echo "$p=$val" >> "$BACKUP_DIR/props_backup.txt"
done
echo "[*] Backup: $BACKUP_DIR/props_backup.txt"

# Comprobar memoria libre (MemAvailable si está disponible)
mem_kb=$($ADB shell "cat /proc/meminfo | grep -i '^MemAvailable:' || cat /proc/meminfo | grep -i '^MemFree:'" 2>/dev/null | awk '{print $2}' | tr -d '\r')
if [ -z "$mem_kb" ]; then
  echo "[!] No pude leer memoria disponible en el dispositivo. Procediendo con precaución."
  mem_kb=0
fi
mem_mb=$((mem_kb/1024))
echo "[*] Memoria disponible aproximada: ${mem_mb} MB"

# Umbral mínimo para aplicar ajustes agresivos
MIN_MB=400
if [ "$mem_mb" -lt "$MIN_MB" ]; then
  echo "[!] Memoria < ${MIN_MB}MB. No aplicar ajustes agresivos. Usa el script conservador."
  exit 1
fi

echo "[*] Aplicando ajustes agresivos (pero con chequeo de memoria)..."
$ADB shell su -c "setprop dalvik.vm.jit true"
$ADB shell su -c "setprop dalvik.vm.jit.threshold 800"          # mucho más bajo = JIT más temprano
$ADB shell su -c "setprop dalvik.vm.jit.initial.threshold 200"  # JIT inicial aún más agresivo
$ADB shell su -c "setprop dalvik.vm.jit.count 8"               # más compilaciones concurrentes
$ADB shell su -c "setprop dalvik.vm.usejitprofiles 1"
$ADB shell su -c "setprop dalvik.vm.dex2oat-threads 4"         # si el sistema invoca dex2oat podrá usar 4 hilos
$ADB shell su -c "setprop dalvik.vm.dexopt-flags speed"        # preferir velocidad en optimizaciones
$ADB shell su -c "setprop dalvik.vm.gc.type sticky"

echo
echo "[*] Ajustes aplicados. Reinicia runtime: adb shell stop && adb shell start  (o reboot)."
echo "[*] Si quieres revertir:"
echo "    while read line; do p=\${line%%=*}; v=\${line#*=}; $ADB shell su -c \"setprop \$p \$v\"; done < $BACKUP_DIR/props_backup.txt"
echo "FIN."
