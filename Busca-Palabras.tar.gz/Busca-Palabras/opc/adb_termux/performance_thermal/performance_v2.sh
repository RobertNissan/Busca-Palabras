#!/system/bin/sh
# performance.sh - Moto G20

ACTION="$1"
BACKUP_DIR="/data/local/tmp/perf_g20_backup"

log() {
    echo "[*] $1"
}

backup_file() {
    SRC="$1"
    DST="$BACKUP_DIR/$(basename $SRC).bak"
    if [ -e "$SRC" ]; then
        mkdir -p "$BACKUP_DIR" 2>/dev/null
        cp "$SRC" "$DST" 2>/dev/null
    fi
}

write_val() {
    FILE="$1"
    VAL="$2"
    if [ -w "$FILE" ]; then
        echo "$VAL" > "$FILE" 2>/dev/null
    fi
}

# =====================================================
# ENABLE — TUS VALORES EXACTOS / NO SE CAMBIA NADA
# =====================================================

enable_perf() {
    log "Aplicando SAFE performance para Moto G20..."

    mkdir -p "$BACKUP_DIR" 2>/dev/null
    chmod 777 "$BACKUP_DIR" 2>/dev/null

    # Thermal
    for T in /sys/devices/virtual/thermal/thermal_zone*/mode; do
        backup_file "$T"
        write_val "$T" "disabled"
    done

    # CPU policy 0
    CPU0_GOV="/sys/devices/system/cpu/cpufreq/policy0/scaling_governor"
    CPU0_MIN="/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq"
    CPU0_MAX="/sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq"

    backup_file "$CPU0_GOV"
    backup_file "$CPU0_MIN"
    backup_file "$CPU0_MAX"

    write_val "$CPU0_GOV" "performance"
    write_val "$CPU0_MIN" "614400"
    write_val "$CPU0_MAX" "1820000"

    # CPU policy 6
    CPU6_GOV="/sys/devices/system/cpu/cpufreq/policy6/scaling_governor"
    CPU6_MIN="/sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq"
    CPU6_MAX="/sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq"

    backup_file "$CPU6_GOV"
    backup_file "$CPU6_MIN"
    backup_file "$CPU6_MAX"

    write_val "$CPU6_GOV" "performance"
    write_val "$CPU6_MIN" "1228800"
    write_val "$CPU6_MAX" "1820000"

    # GPU
    GPU_DIR="/sys/class/devfreq/60000000.gpu"
    GPU_GOV="$GPU_DIR/governor"
    GPU_MIN="$GPU_DIR/min_freq"
    GPU_MAX="$GPU_DIR/max_freq"

    backup_file "$GPU_GOV"
    backup_file "$GPU_MIN"
    backup_file "$GPU_MAX"

    write_val "$GPU_GOV" "performance"
    write_val "$GPU_MIN" "200000000"
    write_val "$GPU_MAX" "850000000"

    # Animaciones
    settings put global window_animation_scale 0.5
    settings put global transition_animation_scale 0.5
    settings put global animator_duration_scale 0.5

    log "✔ Tweaks aplicados."
}

# =====================================================
# RESTORE
# =====================================================

restore_perf() {
    log "Restaurando valores..."

    if [ ! -d "$BACKUP_DIR" ]; then
        log "No hay backups previos."
        exit 1
    fi

    for B in $BACKUP_DIR/*.bak; do
        base=$(basename $B | sed 's/.bak$//')
        # Buscar archivo original en sys
        find /sys -type f -name "$base" -exec cp "$B" {} \; 2>/dev/null
    done

    log "✔ Restaurado."
}

# =====================================================
# STATUS — FUNCIONANDO AHORA
# =====================================================

status_perf() {
    echo "=== PERF G20 STATUS ==="

    echo ""
    echo "-- Thermal Zones --"
    for T in /sys/devices/virtual/thermal/thermal_zone*/mode; do
        echo "$T: $(cat $T)"
    done

    echo ""
    echo "-- CPU policy0 --"
    echo "Governor: $(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor)"
    echo "Min freq: $(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq)"
    echo "Max freq: $(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq)"

    echo ""
    echo "-- CPU policy6 --"
    echo "Governor: $(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_governor)"
    echo "Min freq: $(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq)"
    echo "Max freq: $(cat /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq)"

    echo ""
    echo "-- GPU --"
    GPU_DIR="/sys/class/devfreq/60000000.gpu"
    echo "Governor: $(cat $GPU_DIR/governor)"
    echo "Min freq: $(cat $GPU_DIR/min_freq)"
    echo "Max freq: $(cat $GPU_DIR/max_freq)"

    echo ""
    echo "-- Animaciones --"
    settings get global window_animation_scale
    settings get global transition_animation_scale
    settings get global animator_duration_scale

    echo "=== FIN STATUS ==="
}

# =====================================================
# MENÚ
# =====================================================

case "$ACTION" in
    enable) enable_perf ;;
    restore) restore_perf ;;
    status) status_perf ;;
    *)
        echo "Uso: sh /sdcard/performance.sh [enable|restore|status]"
        ;;
esac

# uso
# adb shell su -c "chmod 755 /sdcard/performance.sh"
# adb shell su -c "sh /sdcard/performance.sh status"
# adb shell su -c "sh /sdcard/performance.sh enable"
# adb shell su -c "sh /sdcard/performance.sh restore"
