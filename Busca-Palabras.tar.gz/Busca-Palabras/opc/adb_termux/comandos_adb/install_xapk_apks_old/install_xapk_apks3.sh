#!/bin/bash
#────────────────────────────────────────────#
#   INSTALADOR UNIVERSAL ADB (.apk/.apks/.xapk)
#────────────────────────────────────────────#

set -e

# Colores
GREEN='\033[1;32m'
RED='\033[1;31m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
NC='\033[0m'

#───────────────────────────────#
#   FUNCIONES
#───────────────────────────────#
uso() {
    echo -e "${YELLOW}Uso:${NC} $0 <archivo.apk|archivo.apks|archivo.xapk>"
    exit 1
}

verif_adb() {
    if ! command -v adb >/dev/null 2>&1; then
        echo -e "${RED}Error:${NC} adb no está instalado o no está en PATH."
        echo -e "${YELLOW}Instálalo con:${NC} pkg install android-tools${NC}"
        exit 1
    fi
}

verif_dispositivo() {
    local devices
    devices=$(adb devices | grep -w "device" | wc -l)
    if [[ "$devices" -eq 0 ]]; then
        echo -e "${RED}No hay dispositivos ADB conectados.${NC}"
        echo -e "${YELLOW}Conecta un dispositivo y habilita la depuración USB.${NC}"
        exit 1
    fi
}

firmar_apk() {
    local apk_in="$1"
    local apk_out="$2"

    if ! command -v apksigner >/dev/null 2>&1; then
        echo -e "${RED}Error:${NC} apksigner no está instalado."
        echo -e "${YELLOW}Instálalo con:${NC} pkg install apksigner"
        exit 1
    fi

    echo -e "${CYAN}🔏 Firmando APK...${NC}"

    if [ ! -f ~/.android/debug.keystore ]; then
        echo -e "${YELLOW}Creando debug.keystore...${NC}"
        mkdir -p ~/.android
        keytool -genkeypair -v \
            -keystore ~/.android/debug.keystore \
            -keyalg RSA -keysize 2048 -validity 10000 \
            -alias androiddebugkey \
            -storepass android -keypass android \
            -dname "CN=Android Debug,O=Android,C=US" >/dev/null
    fi

    apksigner sign \
        --ks ~/.android/debug.keystore \
        --ks-pass pass:android \
        --key-pass pass:android \
        --out "$apk_out" \
        "$apk_in"
}

desactivar_verificador() {
    echo -e "${YELLOW}⚙️ Desactivando verificador ADB...${NC}"
    adb shell settings put global verifier_verify_adb_installs 0 >/dev/null 2>&1 || true
    adb shell settings put global package_verifier_enable 0 >/dev/null 2>&1 || true
}

#───────────────────────────────#
#   NUEVA FUNCIÓN: detectar arquitectura
#───────────────────────────────#
detectar_arquitectura() {
    local arch
    arch=$(adb shell getprop ro.product.cpu.abi | tr -d '\r')

    case "$arch" in
        *arm64*) echo "arm64_v8a" ;;
        *armeabi-v7a*) echo "armeabi_v7a" ;;
        *x86_64*) echo "x86_64" ;;
        *x86*) echo "x86" ;;
        *) echo "arm64_v8a" ;; # valor por defecto
    esac
}

#───────────────────────────────#
#   LÓGICA PRINCIPAL
#───────────────────────────────#
archivo="$1"
[[ -z "$archivo" ]] && uso

verif_adb
verif_dispositivo
desactivar_verificador

ext="${archivo##*.}"
tmpdir=""

# Limpieza automática
trap 'if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then echo -e "\n🧹 ${YELLOW}Limpiando temporales...${NC}"; rm -rf "$tmpdir"; fi' EXIT INT TERM

case "$ext" in
    apk)
        echo -e "${CYAN}📦 Instalando APK:${NC} $archivo"
        adb install -r "$archivo"
        echo -e "${GREEN}✔ APK instalado correctamente${NC}"
        ;;

    apks)
        echo -e "${CYAN}📦 Instalando APKS (bundle):${NC} $archivo"
        tmpdir=$(mktemp -d)
        unzip -q "$archivo" -d "$tmpdir"

        arch=$(detectar_arquitectura)
        echo -e "${YELLOW}🧠 Arquitectura detectada:${NC} ${arch}"

        base_apk=$(find "$tmpdir" -name "base.apk")
        split_arch=$(find "$tmpdir" -name "split_config.${arch}.apk" | head -n 1)

        if [[ -f "$base_apk" && -f "$split_arch" ]]; then
            echo -e "${CYAN}🧩 Instalando base + arquitectura (${arch})...${NC}"
            adb install-multiple -r "$base_apk" "$split_arch"
        else
            echo -e "${YELLOW}⚠️ No se encontró split específico para ${arch}, instalando todo.${NC}"
            adb install-multiple -r "$tmpdir"/*.apk
        fi

        echo -e "${GREEN}✔ APKS instalado correctamente${NC}"
        ;;

    xapk)
        echo -e "${CYAN}📦 Instalando XAPK:${NC} $archivo"
        tmpdir=$(mktemp -d)
        unzip -q "$archivo" -d "$tmpdir"

        arch=$(detectar_arquitectura)
        echo -e "${YELLOW}🧠 Arquitectura detectada:${NC} ${arch}"

        apkfiles=($(find "$tmpdir" -name "*.apk"))
        if [ ${#apkfiles[@]} -eq 0 ]; then
            echo -e "${RED}❌ No se encontró ningún APK dentro del XAPK.${NC}"
            exit 1
        fi

        base_apk=$(find "$tmpdir" -name "base.apk" | head -n 1)
        split_arch=$(find "$tmpdir" -name "split_config.${arch}.apk" | head -n 1)

        if [[ -f "$base_apk" && -f "$split_arch" ]]; then
            echo -e "${CYAN}🧩 Instalando base + arquitectura (${arch})...${NC}"
            adb install-multiple -r "$base_apk" "$split_arch"
        else
            echo -e "${YELLOW}⚠️ No se encontró split específico para ${arch}, instalando todo.${NC}"
            adb install-multiple -r "${apkfiles[@]}"
        fi

        # Copiar OBB si existe
        if [[ -d "$tmpdir/Android/obb" ]]; then
            echo -e "${YELLOW}📂 Copiando archivos OBB...${NC}"
            adb push "$tmpdir/Android/obb" /sdcard/Android/ >/dev/null
        fi

        echo -e "${GREEN}✔ XAPK instalado correctamente${NC}"
        ;;

    *)
        echo -e "${RED}Error:${NC} formato desconocido '$ext'."
        echo "Solo se aceptan: .apk, .apks, .xapk"
        exit 1
        ;;
esac

# Confirmación
echo -e "${GREEN}Ruta de instalación:${NC}"
adb shell pm path com.appveyor.flet
