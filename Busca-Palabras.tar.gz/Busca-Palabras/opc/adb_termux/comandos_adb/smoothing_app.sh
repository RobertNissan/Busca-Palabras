#!/bin/bash

APP="com.estrongs.android.pop"
ACT="com.estrongs.android.pop/.view.FileExplorerActivity"

echo "=============================================="
echo "        BOOST APP (Normal / Fuerte / Extremo)"
echo "=============================================="
echo ""
echo "1 - Normal Boost"
echo "2 - Fuerte"
echo "3 - Extremo"
echo ""
read -p "Seleccione modo: " MODE


# -----------------------------------------------
#  SAFE BOOST FUNCTIONS
# -----------------------------------------------

normal_boost() {
    echo "🚀 NORMAL BOOST"

    # Optimización ART suave
    adb shell cmd package compile -m speed $APP

    # Limpieza ligera de procesos en segundo plano
    adb shell am kill-all

    # Lanzar app limpia
    adb shell am start -n $ACT
}

fuerte_boost() {
    echo "🔥 BOOST FUERTE"

    # Optimización ART completa
    adb shell cmd package compile -m speed $APP

    # Limpieza de memoria de la propia app (si está abierta)
    adb shell "pid=\$(pidof $APP); if [ -n \"\$pid\" ]; then kill -9 \$pid; fi"

    # Limpieza general de RAM (segura)
    adb shell am kill-all

    # Precalentamiento real -> restart package
    adb shell cmd package restart $APP >/dev/null 2>&1

    # Lanzar la app
    adb shell am start -n $ACT
}

extremo_boost() {
    echo "⚡ BOOST EXTREMO (SEGURO)"

    # Compilar ART al máximo (dos modos compatibles)
    adb shell cmd package compile -m speed $APP
    adb shell cmd package compile -m speed-profile $APP

    # Cerrar cualquier proceso de la app
    adb shell "pid=\$(pidof $APP); if [ -n \"\$pid\" ]; then kill -9 \$pid; fi"

    # Limpiar todo proceso viejo
    adb shell am kill-all

    # Eliminar cachés ART antiguas para regenerar optimizadas
    adb shell cmd package compile -m everything $APP

    # Pre-JIT (solo si aplica al SO)
    adb shell cmd package compile -r $APP >/dev/null 2>&1

    # Lanzarla totalmente limpia y compilada
    adb shell am start -n $ACT
}

# -----------------------------------------------
# RUN MODE
# -----------------------------------------------

case $MODE in
    1)
        normal_boost
        ;;
    2)
        fuerte_boost
        ;;
    3)
        extremo_boost
        ;;
    *)
        echo "Opción inválida"
        exit 1
        ;;
esac
