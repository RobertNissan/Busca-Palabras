Saltar al contenido
Menú de navegación
Iniciar sesión
Inalámbrico
/
melodía_android
Público
Script de melodía para Android.

 69 estrellas 6 tenedores   Sucursales  Etiquetas  Actividad
Código
Asuntos
Solicitudes de extracción
ionuttbara/melody_android
Carpetas y archivos
Nombre	
Último commit
autor
Ionut Bara
Hace 2 meses
Historia
Léame.md
Hace 2 meses
Navegación por los archivos del repositorio
README
Melody Script para Android optimiza el teléfono Android.


# Logotipo de melodía
# Requisitos
# Teléfono Android con sistema operativo versión 7.1.1 o posterior. Para teléfonos Samsung con sistema operativo versión 9 o posterior (solo OneUI). ADB instalado con controladores (el instalador de ADB se incluirá en la administración de versiones y código fuente).

# Comandos
PUEDES CREAR UN ARCHIVO BAT A PARTIR DE ESTOS COMANDOS. La lista de comandos para

# MEJORA DEL RENDIMIENTO DEL SISTEMA
# Desactiva los efectos de desenfoque de ventana y las animaciones
adb shell settings put global accessibility_reduce_transparency 1
adb shell settings put global disable_window_blurs 1
adb shell settings put global window_animation_scale 0.0
adb shell settings put global transition_animation_scale 0.0
adb shell settings put global animator_duration_scale 0.0
adb shell settings put system screen_auto_brightness_adj 1.0

# ( ESTO CONFIGURA LA PANTALLA A UNA frecuencia de actualización de 48 Hz; si no lo desea, no lo ponga en la lista de murciélagos ) .
adb shell settings put system peak_refresh_rate 48.0
adb shell settings put system min_refresh_rate 1.0

# MEJORA DEL RENDIMIENTO DE LAS REDES MÓVILES
# Transferencia de datos de red mejorada (3G/4G/5G). También bloqueará el 90-95 % de anuncios y sitios web pornográficos sin root. Deshabilitará algunas limitaciones, habilitará los datos móviles de manera predeterminada al iniciar y habilitará el GPS asistido.
adb shell settings put global network_recommendations_enabled 0
adb shell settings put global network_scoring_ui_enabled 0
adb shell settings put global tether_offload_disabled 0
adb shell settings put global wifi_power_save 0
adb shell settings put global enable_cellular_on_boot 1
adb shell settings put global mobile_data_always_on 0
adb shell settings put global ble_scan_always_enabled 0
adb shell settings put global private_dns_specifier family.adguard-dns.com

# Mejore la velocidad de la red reparando la calidad de la señal (no para todos los dispositivos)
adb shell settings put global preferred_network_mode 9,9

# MEJORANDO LA GESTIÓN DE ENERGÍA EN LOS TELÉFONOS
# Mejorar la forma en que el teléfono duerme desactivando los algoritmos de sueño adaptativo. Si recibe notificaciones retrasadas de las aplicaciones de mensajería, vaya a Configuración, Aplicación, vaya a la aplicación de mensajería, batería y configure Sin restricciones . No use aplicaciones de terceros u OEM para hacer eso. No recomiendo hacerlo con ellos porque el efecto no será el deseado como se ve. Recomendación: elimine todas las aplicaciones de limpieza o cuidado del dispositivo de terceros para que el algoritmo funcione correctamente.
adb shell settings put global sem_enhanced_cpu_responsiveness 0
adb shell settings put global enhanced_processing 0
adb shell settings put global app_standby_enabled 0
adb shell settings put global adaptive_battery_management_enabled 0
adb shell settings put global app_restriction_enabled true
adb shell settings put system intelligent_sleep_mode 0
adb shell settings put secure adaptive_sleep 0
adb shell settings put global automatic_power_save_mode 0

# Deshabilite el modo de ahorro de energía de Android, si desea volver a habilitarlo, vaya a Configuración o configure low_power en 1 en el comando.
adb shell settings put global low_power 0
adb shell settings put global dynamic_power_savings_enabled 0
adb shell settings put global dynamic_power_savings_disable_threshold 20

# DESACTIVAR EL PROTECTOR DE PANTALLA DE ANDROID PARA OBTENER UNA MAYOR DURACIÓN DE LA BATERÍA
adb shell settings put secure screensaver_enabled 0
adb shell settings put secure screensaver_activate_on_sleep 0
adb shell settings put secure screensaver_activate_on_dock 0

# Acelerar el retardo de pulsación larga
adb shell settings put secure long_press_timeout 250
adb shell settings put secure multi_press_timeout 250

# Funciones de llamadas. Habilitación de volumen adicional durante las llamadas y reducción de ruido
# Añadir volumen en la llamada
adb shell settings put system call_extra_volume 1

# Añadir reducción de ruido en las llamadas
adb shell settings put system call_noise_reduction 1

# Desactivación de la vibración al responder una llamada
adb shell settings put system call_answer_vib 0

# Desactivación de la vibración al finalizar la llamada
adb shell settings put system call_end_vib 0

# Desactivación de la función Deslizar para llamar o enviar mensajes desde la aplicación Contactos de Samsung
adb shell settings put global swipe_to_call_message 0

# Cambiar el nombre del teléfono
adb shell settings put secure bluetooth_name "device name"
adb shell settings put global device_name "device name"
adb shell settings put global synced_account_name "device name"

# Sonidos y vibraciones del sistema
# Desactiva algunos sonidos y vibraciones de control del sistema como: Navegación
adb shell settings put system navigation_gestures_vibrate 0

# Pantalla de bloqueo
adb shell settings put system lockscreen_sounds_enabled 0

# Cámara
adb shell settings put system camera_feedback_vibrate 0
adb shell settings put system sound_effects_enabled 0

# Habilitar la sincronización de vibración con el tono de llamada
adb shell settings put system sync_vibration_with_ringtone 1
adb shell setting put system sync_vibration_with_ringtone_2 1

# Habilitar la sincronización de vibración con las notificaciones
adb shell settings put system sync_vibration_with_notification 1

# Vibración en general
adb shell settings put system haptic_feedback_enabled 0
adb shell settings put system SEM_VIBRATION_FORCE_TOUCH_INTENSITY 0
adb shell settings put system SEM_VIBRATION_NOTIFICATION_INTENSITY 0
adb shell settings put system SEM_VIBRATION_RING_INTENSITY 5
adb shell settings put system vibrate_when_ringing 0
adb shell settings put system vibration_sound_enabled 0
adb shell settings put system VIB_FEEDBACK_MAGNITUDE 0
adb shell settings put system VIB_RECVCALL_MAGNITUDE 0

# Sonidos de poder
adb shell settings put global power_sounds_enabled 0

# Cargando
adb shell settings put secure charging_vibration_enabled 0
adb shell settings put secure charging_sounds_enabled 0
adb shell settings put secure adaptive_charging_enabled 0

# Códecs de audio Bluetooth
adb shell settings put secure bluetooth_a2dp_bt_uhq_state 1
adb shell settings put secure bluetooh_a2dp_uhqa_support 1

# Google
# Deshabilitar las funciones de Google, si desea habilitarlas, cambie de 0 a 1
Android Auto
adb shell settings put system gearhead:driving_mode_settings_enabled 0

# Ajuste GSM
adb shell settings put secure assistant 0
adb shell settings put secure smartspace 0
adb shell settings put global google_core_control 0
adb shell settings put secure adaptive_connectivity_enabled 0
adb shell settings put secure systemui.google.opa_enabled 0

# Desactivar el sensor de motor de movimiento de Android (puede ahorrar algo de batería) también desactiva algunas funciones malas del sueño adaptativo
adb shell settings put system master_motion 0
adb shell settings put system motion_engine 0
adb shell settings put system air_motion_engine 0
adb shell settings put system air_motion_wake_up 0
adb shell settings put system intelligent_sleep_mode 0
adb shell settings put secure adaptive_sleep 0

# Deshabilitar la URL del manual en línea y el soporte remoto (Samsung ONE UI, todas las versiones con o sin consejos instalados)
adb shell settings put global online_manual_url 0
adb shell settings put system remote_control 0

# Mejorar los tiempos de inicio de aplicaciones para teléfonos Samsung (y la telemetría en Android Vanilla)
adb shell settings put global activity_starts_logging_enabled 0
adb shell settings put secure send_action_app_error 0
adb shell settings put global bixby_pregranted_permissions 0
adb shell settings put system send_security_reports 0
adb shell settings put system rakuten_denwa 0

# La calidad del audio mejora en los teléfonos
adb shell settings put system tube_amp_effect 1
adb shell settings put system k2hd_effect 1

# Habilitar el Programador de Paquetes Multimedia (también puede hacerlo yendo a Opciones de Desarrollador desde Configuración)
adb shell settings put system multicore_packet_scheduler 1

# Eliminando el servicio de optimización de juegos (GOS en Samsung) 👆GOS
adb shell settings put secure game_auto_temperature_control 0
adb shell pm clear --user 0 com.samsung.android.game.gos
adb shell settings put secure gamesdk_version 0
adb shell settings put secure game_home_enable 0
adb shell settings put secure game_bixby_block 1

# Bloquear actualizaciones del sistema Galaxy (actualización de políticas y/o del dispositivo) (no interfiere con la actualización de Galaxy Store ni con las actualizaciones F/OTA)
adb shell settings put global galaxy_system_update_block 1

# Ajuste de pantalla OLED
adb shell settings put global burn_in_protection 1

# Mejore la capacidad de respuesta y la latencia de la pantalla táctil en los teléfonos Android
adb shell settings put secure tap_duration_threshold 0.0
adb shell settings put secure touch_blocking_period 0.0

# Deshabilitar el escaneo en segundo plano para dispositivos (Bluetooth, dispositivos cercanos)
adb shell settings put system nearby_scanning_permission_allowed 0
adb shell settings put system nearby_scanning_enabled 0
adb shell settings put global ble_scan_always_enabled 0

# Desactivar la detección de palabras clave (OK Google o Hey Google) en segundo plano (mejora la batería)
adb shell settings put global hotword_detection_enabled 0

# Otra configuración del teléfono Samsung
# Sincronización entre dispositivos de Samsung
adb shell settings put system mcf_continuity 0
adb shell settings put system mcf_continuity_permission_denied 1
adb shell settings put system mcf_permission_denied 1

# Desactivar RAM Plus
adb shell settings put global ram_expand_size_list 0
adb shell settings put global zram_enabled 0

# Comandos para actualizar el teléfono (estos ayudan a actualizar las aplicaciones del teléfono con un poco de potencia)
adb shell cmd package compile -m speed-profile -a
adb shell cmd package bg-dexopt-job
adb shell pm trim-caches 999999999999999999


# Otros comando estos si los uso para optimizar el sistema usando adb
adb shell settings put system rakuten_denwa 0
adb shell settings put system send_security_reports 0
adb shell settings put secure send_action_app_error 0
adb shell settings put global activity_starts_logging_enabled 0
adb shell cmd power set-fixed-performance-mode-enabled true
adb shell settings put global sem_enhanced_cpu_responsiveness 1
adb shell pm trim-caches 128G
adb shell cmd appops set com.microsoft.office.word RUN_IN_BACKGROUND ignore
adb shell cmd appops set com.google.android.apps.docs.editors.docs RUN_IN_BACKGROUND ignore
# La app de Google es pesada en segundo plano, este comando adb ayuda que Google no consuma ram
adb shell cmd appops set com.google.android.googlequicksearchbox RUN_IN_BACKGROUND ignore
adb shell pm clear --cache-only com.google.android.googlequicksearchbox

# Mantener Voces de vocalizer siempre activa en servicios de ejecución
# voces de vocalizer siempre activa en servicios en ejecución 

# Funciona! El servicio se mantiene activo después de 10
# segundos. La configuración que funciona es:
adb shell dumpsys deviceidle whitelist +es.codefactory.vocalizertts
adb shell cmd appops set es.codefactory.vocalizertts RUN_IN_BACKGROUND allow
adb shell cmd appops set es.codefactory.vocalizertts RUN_ANY_IN_BACKGROUND allow
adb shell cmd appops set es.codefactory.vocalizertts WAKE_LOCK allow
adb shell cmd appops set es.codefactory.vocalizertts START_FOREGROUND allow
adb shell am set-inactive es.codefactory.vocalizertts false
adb shell am startservice -n es.codefactory.vocalizertts/.services.VocalizerTTSService --es sticky true
adb shell am start-foreground-service -n es.codefactory.vocalizertts/.services.VocalizerTTSService --ei priority 10000

# Modificar el OOM usando adb
# Reducir procesos en cache
adb shell settings put global activity_manager_constants max_cached_processes=8,max_empty_processes=4                 
# Optimizar gestión de memoria
adb shell settings put global sys_free_storage_log_interval 60000
adb shell settings put global sys_storage_threshold_percentage 5
adb shell settings put global background_settle_time 60000
# Limpiar memoria regularmente
adb shell am broadcast -a android.intent.action.TRIM_MEMORY --ei level 80


# Los smartphones modernos ofrecen una excelente calidad de audio, que puede mejorarse aún más con aplicaciones de ecualizador. Sin embargo, también puedes disfrutar de una mejor experiencia de audio en teléfonos Android activando los efectos K2HD y Tube Amp mediante ADB.
adb shell settings put system k2hd_effect 1
adb shell settings put system tube_amp_effect 1

# El siguiente comando congelará una aplicación que se esté ejecutando en segundo plano.
adb shell cmd appops set <nombre-del-paquete> RUN_IN_BACKGROUND ignore

# Si quieres borrar la caché y los datos de todas las aplicaciones instaladas en tu  teléfono , debes usar el siguiente comando.
adb shell cmd package list packages|cut -d -f2|while read package ;do pm clear $package;done

Lanzamientos
No hay comunicados publicados
Pie de página
© 2024 GitHub, Inc.
Navegación de pie de página
Términos
Privacidad
Seguridad
Estado
Documentos
Contacto
Administrar cookies
No compartas mi información personal
Copied!