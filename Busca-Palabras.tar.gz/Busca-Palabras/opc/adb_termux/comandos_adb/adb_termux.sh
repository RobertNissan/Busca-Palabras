# Ver la versión de termux instalada.
termux-info | grep -E "TERMUX_VERSION"
# Salida ejemplo:
TERMUX_VERSION=0.118.0

#ip y ports tomados de la imagen:
#ip_port_20230104-165615.png

# Cerrar los servidores adb
adb kill-server
# Encender los servidores
adb start-server
# Instalar el repositorio adb en termux
pkg install android-tools -y

# ver si una app esta instalda sin usar adb ni root
cmd package list packages | grep "com.termux"
package:com.termux.api
package:com.termux
# ver si una app específica esta instalda sin usar adb ni root
cmd package list packages | cut -d: -f2 | grep "^com.termux\$"
com.termux


# Capturar el código de verificación WiFi usando tesseract y captura de pantalla con volumen abajo y encendido
pkg update -y
pkg install image-magick tesseract -y   # tesseract para OCR; imagemagick para posibles preprocesos
# opcional (si usas Termux:API):
pkg install termux-api
pkg update -y
pkg install termux-api imagemagick tesseract -y
# opción recomendable hasta ahora
# ve a la depuración inalambrica y abre dónde dice vincular dispositivo con código de sincronización
# cuando muestra los 6 dígitos de código de verificación WiFi 
# crea una captura con VOL- y Botón encender 
# y en termux pega esto:
latest=$(ls -t /sdcard/Pictures/Screenshots/* /sdcard/DCIM/Screenshots/* /sdcard/Download/* 2>/dev/null | head -n1) && [ -f "$latest" ] && tesseract "$latest" stdout 2>/dev/null | grep -oE '[0-9]{6}' | head -n1 || echo "NO_PIN"
# O
latest=$(ls -t /sdcard/Pictures/Screenshots/* /sdcard/DCIM/Screenshots/* /sdcard/Download/* 2>/dev/null | head -n1) && pin=$( [ -f "$latest" ] && tesseract "$latest" stdout 2>/dev/null | grep -oE '[0-9]{6}' | head -n1 ) && [ -n "$pin" ] || pin="NO_PIN"
echo "$pin"

#-----------------------------------------------------------------------------------#
para que se pueda hacer sin salir, solo debes habilitar la pantalla dividida entre los:
"ajustes de desarrollador/Depuracion inalambirca" y termux 
# activa la Depuracion inalambirca y luego ingresa:
presiona en "Vincular dispositivo con codigo de sincronizacion"

ahora si puedes agregar los codigos en termux.
adb pair 192.168.20.45:36161
#codigo 559121

nmap -p 22-65535 192.168.20.45
Starting Nmap 7.93 ( https://nmap.org ) at 2023-01-05 10:50 -05
Nmap scan report for 192.168.20.45
Host is up (0.0030s latency).
Not shown: 65513 closed tcp ports (conn-refused)
PORT      STATE SERVICE
32909/tcp open  unknown

# Ahora despues de emparejar, en la parte donde dice: "Direccion IP y puerto" te mostrara algo asi:
# Tambien escribe esto en termux.
adb connect 192.168.20.45:32909

# saber que app esta abierta actualmente en el dispositivo Android usando adb
adb -s emulator-5554 shell dumpsys window | grep -E 'mCurrentFocus'
# Captura el nombre del paquete
nombre_paquete=$(adb -s emulator-5554 shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
# Imprime el nombre del paquete (opcional)
echo "$nombre_paquete"
# o
adb -s emulator-5554 shell dumpsys activity activities | grep mResumedActivity
# Captura el nombre del paquete
nombre_paquete=$(adb -s emulator-5554 shell dumpsys activity activities | grep 'mResumedActivity' | sed -E 's/.*ActivityRecord\{[^ ]+ u0 ([^/]+)\/.*/\1/')
# Imprime el nombre del paquete (opcional)
echo "$nombre_paquete"


# reconfigurar el puerto adb a 5555
adb -s ip_objetivo:port tcpip 5555
# Ejemplo: adb -s 192.168.20.114:42197 tcpip 5555
# Ahora nos conectamos
adb connect ip_objetivo:5555
adb connect 192.168.20.114:5555

# hacer permanente adb sin wifi hasta que se reinicie el celular
adb tcpip 5555
adb shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
# Configura ADB para usar Wi-Fi permanentemente: Si estás utilizando ADB por Wi-Fi y quieres que la configuración sea más permanente, asegúrate de que no se esté intentando cambiar la conexión de vuelta a USB. Puedes intentar deshabilitar el modo USB por completo si es posible:
adb shell settings put global development_settings_enabled 1
adb shell settings put global adb_enabled 1
# Revisa el modo de depuración USB: Si no necesitas depuración USB, podrías deshabilitarla para evitar que ADB intente usar el puerto USB y mantenga la conexión Wi-Fi:
adb shell settings put global adb_wifi_enabled 1
adb shell settings put global adb_port 5555
######opcional########
# agregar a setedit, a global table. Nota: debes tener setedit instalado y activar la global table
adb shell settings put global development_settings_enabled 1
adb shell settings put global adb_enabled 1
adb shell settings put global adb_wifi_enabled 1
adb shell settings put global adb_port 5555


# hacer permanente total adb, para que funcione luego sin wifi, requiere root
adb shell getprop | grep adb
# adb logcat | grep 'adbd'
# Para que los cambios sean realmente permanentes (sobrevivan al reinicio), es necesario tener acceso root y modificar propiedades persistentes del sistema con comandos como:
adb shell su -c "setprop persist.adb.tcp.port 5555"
adb tcpip 5555
adb shell su -c "setprop ro.adb.secure 0"
# Configura ADB para usar Wi-Fi permanentemente: Si estás utilizando ADB por Wi-Fi y quieres que la configuración sea más permanente, asegúrate de que no se esté intentando cambiar la conexión de vuelta a USB. Puedes intentar deshabilitar el modo USB por completo si es posible:
adb shell settings put global development_settings_enabled 1
adb shell settings put global adb_enabled 1
# Revisa el modo de depuración USB: Si no necesitas depuración USB, podrías deshabilitarla para evitar que ADB intente usar el puerto USB y mantenga la conexión Wi-Fi:
adb shell settings put global adb_wifi_enabled 1
adb shell settings put global adb_port 5555

# revertir los cambios para que no sean permanentes
# Restaurar el puerto predeterminado de ADB (USB)
adb shell su -c "setprop persist.adb.tcp.port -1"
adb usb
# Rehabilitar la seguridad de ADB
adb shell su -c "setprop ro.adb.secure 1"
# Deshabilitar ADB por Wi-Fi
adb shell settings put global adb_wifi_enabled 0
adb shell settings delete global adb_port
# Restaurar la depuración USB si se había deshabilitado
adb shell settings put global development_settings_enabled 1
adb shell settings put global adb_enabled 1
# Reiniciar el servidor ADB para aplicar los cambios
adb kill-server
adb start-server
# Verificar que ADB esté usando USB y no Wi-Fi
adb devices


# activar la posición GPS usando Termux 
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_FINE_LOCATION
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_COARSE_LOCATION
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_BACKGROUND_LOCATION
# conceder los permisos GPS de termux:api 
adb shell pm grant com.termux.api android.permission.ACCESS_FINE_LOCATION
adb shell pm grant com.termux.api android.permission.ACCESS_COARSE_LOCATION
# Ver la coordenadas de posición gps
termux-location -p network | jq -r '"Lat,Lon: \(.latitude),\(.longitude) | Alt: \(.altitude)m | Precisión: ±\(.accuracy)m"'
# O mejor 
curl -s http://ip-api.com/json | jq '{lat: .lat, lon: .lon, ciudad: .city}'
termux-location -p gps -r once
# O mejor
adb shell dumpsys location | grep 'last location=Location\[gps' | sed -E 's/.*Location\[gps ([^ ]+),([^ ]+) hAcc=([^ ]+).*alt=([^ ]+).*/Lat,Lon: \1,\2 | Alt: \4m | Precisión: ±\3m/'




# ver número telefónico usando adb
adb -s emulator-5554 shell service call iphonesubinfo 15 2>/dev/null | awk 'function hx(v){return strtonum("0x"v)} {while(match($0,/[0-9A-Fa-f]{8}/)){w=substr($0,RSTART,8);printf "%c%c",hx(substr(w,5,4)),hx(substr(w,1,4));$0=substr($0,RSTART+8)}} END{print ""}'
3044027842

# Y para los cuatro métodos, también en una sola línea:
for i in 15 16 19 20; do printf "Método $i: "; adb -s emulator-5554 shell service call iphonesubinfo $i 2>/dev/null | awk 'function hx(v){return strtonum("0x"v)} {while(match($0,/[0-9A-Fa-f]{8}/)){w=substr($0,RSTART,8);printf "%c%c",hx(substr(w,5,4)),hx(substr(w,1,4));$0=substr($0,RSTART+8)}} END{print ""}'; done
Método 15:
3044027842
Método 16:
3044027842
Método 19:
3044027842
Método 20:
3044027842





# ssvaber mi ubicación usando adb
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_FINE_LOCATION
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_COARSE_LOCATION
adb shell pm grant com.google.android.apps.maps android.permission.ACCESS_BACKGROUND_LOCATION
adb shell pm grant com.google.android.apps.maps android.permission.CAMERA
adb shell pm grant com.google.android.apps.maps android.permission.RECORD_AUDIO
adb shell pm grant com.google.android.apps.maps android.permission.READ_CONTACTS
adb shell pm grant com.google.android.apps.maps android.permission.POST_NOTIFICATIONS
adb shell pm grant com.google.android.apps.maps android.permission.ACTIVITY_RECOGNITION
adb shell appops set com.google.android.apps.maps PICTURE_IN_PICTURE allow
adb shell appops set com.google.android.apps.maps SYSTEM_ALERT_WINDOW allow
adb shell dumpsys deviceidle whitelist +com.google.android.apps.maps
# Added: com.google.android.apps.maps
u0_a292@localhost ~> termux-location -p passive -r last
^C⏎                                                   
u0_a292@localhost ~ [SIGINT]> pkg install termux-api  No mirror or mirror group selected. You might want to select one by running 'termux-change-repo'
Checking availability of current mirror:              [*] https://mirror.rinarin.dev/termux/termux-main: ok Hit:1 https://packages-cf.termux.dev/apt/termux-root root InRelease                                         Hit:2 https://mirror.rinarin.dev/termux/termux-main stable InRelease                                        Get:3 https://packages-cf.termux.dev/apt/termux-x11 x11 InRelease [14.0 kB]                                 Get:4 https://packages-cf.termux.dev/apt/termux-x11 x11/main aarch64 Packages [229 kB]                      Fetched 243 kB in 8s (30.3 kB/s)
Reading package lists... Done                         Building dependency tree... Done
Reading state information... Done
4 packages can be upgraded. Run 'apt list --upgradable' to see them.
Reading package lists... Done                         Building dependency tree... Done
Reading state information... Done                     termux-api is already the newest version (0.59.1-1).
0 upgraded, 0 newly installed, 0 to remove and 4 not upgraded.
u0_a292@localhost ~> adb shell pm grant com.termux android.permission.ACCESS_FINE_LOCATION
                     adb shell pm grant com.termux.api android.permission.ACCESS_FINE_LOCATION
                     adb shell pm grant com.termux.api android.permission.ACCESS_COARSE_LOCATION

u0_a292@localhost ~> termux-location -p passive -r last
u0_a292@localhost ~ [SIGINT]> termux-location -p gps -r once
u0_a292@localhost ~ [SIGINT]> adb shell cmd location set-location-enabled true
u0_a292@localhost ~> termux-location -p gps -r once   adb shell cmd location set-location-enabled true
u0_a292@localhost ~ [SIGINT]> adb shell cmd location set-location-enabled true
u0_a292@localhost ~> termux-location -p gps -r once   ^C⏎                                                   u0_a292@localhost ~ [SIGINT]> adb shell settings put secure location_mode 3

u0_a292@localhost ~> termux-location -p network -r conceder
u0_a292@localhost ~ [0|1]> adb shell dumpsys location | grep -oE "Location\[[a-zA-Z]+ [0-9.-]+,[0-9.-]+" | head -n 1

Location[fused 5.536183,-73.371202






# El comando universal para abrir esa URL en el navegador predeterminado de tu Smart TV (Android TV / Google TV / Fire TV) usando ADB es:
adb shell am start -a android.intent.action.VIEW -d "https://linktr.ee/MagisReddit"


# notificaciones con adb, puede enviar a otro servidor adb o en tu mismo celular.
adb -s emulator-5554 shell cmd notification post -S bigtext -t '𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜𝗢𝗡 [3.0]' \'Tag: FPS Booster and Stabilizer Telah berhasil di 𝗜𝗡𝗦𝗧𝗔𝗟𝗟, 𝗛𝗮𝗿𝗮𝗽 𝗝𝗮𝗻𝗴𝗮𝗻 𝗗𝗶 𝗥𝗲𝗯𝗼𝗼𝘁. jika mau Uninstall module, jalankan file Uninstall, lalu Reboot \(mulai ulang hp\)\' > /dev/null 2>&1

# Para estas notificaciones toast se necesita tener instalado la apk de termux-api
# Mostrar la notificación del tiempo
for i in {3..1}; do
    termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
    sleep 1.7
done
termux-toast "¡Tiempo terminado!" > /dev/null



# Descomprimir un tar.gz
tar -xvzf Busca-Palabras.tar.gz
# Si quieres descomprimirlo en una carpeta diferente:
tar -xvzf Busca-Palabras.tar.gz -C /ruta/destino

# dar permiso a un script usando adb
adb -s emulator-5554 shell chmod 755 /sdcard/archivo.sh

# dar permiso a un script root inicial solo para sentenforce
# Desactiva temporalmente SELinux: Ejecuta el siguiente comando para poner SELinux en modo Permissive:
adb -s emulator-5554 shell su -c setenforce 0
#Cambia los permisos de la carpeta /data/local/tmp
adb -s emulator-5554 shell chmod 777 /data/local/tmp
# Verifica los permisos: Confirma que los permisos se aplicaron correctamente:
adb -s emulator-5554 shell ls -ld /data/local/tmp
# Deberías ver:
drwxrwxrwx 2 shell shell 3488 <fecha> /data/local/tmp
u0_a255@localhost ~> adb shell su -c setenforce 1
u0_a255@localhost ~> adb shell ls /data/local/tmp
ls: /data/local/tmp: Permission denied
u0_a255@localhost ~ [1]> adb shell su -c chcon u:object_r:shell_data_file:s0 /data/local/tmp

#--------------cpu-thermald------------------#
# Verificar si el servicio thermald está detenido o no: usando adb
# Para verificar si el servicio se ha detenido correctamente, puedes intentar lo siguiente:
adb shell ps | grep thermald
# Detener el servicio thermald:
# El servicio thermald se encarga del control térmico en muchos dispositivos Android. Para detenerlo, puedes usar el siguiente comando:
adb shell su -c stop vendor.thermald
# Reiniciar el servicio:
# Si deseas reiniciar el servicio de control térmico, puedes usar el siguiente comando:
adb shell su -c start vendor.thermald

# elevar la carga de los núcleos del cpu (mejor método)
proot-distro login ubuntu
apt update
apt install stress-ng
stress-ng --cpu 8 --cpu-load 1 --cpu-method ackermann
# o para juegos
stress-ng --cpu 8 --cpu-load 1 --cpu-method fft
# o
stress-ng --cpu 8 --cpu-load 1 # o 5 o 10
# ------
# script uso por segundos (no probado):
#!/bin/bash
# Script para alternar estrés del CPU con descansos
while true; do
    echo "Iniciando estrés en el CPU por 60 segundos..."
    stress-ng --cpu 8 --cpu-load 1 --timeout 60s
    echo "Descansando por 30 segundos..."
    sleep 30
done

#Esto ejercitará las escrituras de memoria a 2000 MB/s y las lecturas a 1000 MB/s. Ajuste la configuración para que se ajuste a sus necesidades. Esto está disponible en versiones más nuevas de stress-ng, por lo que es posible que deba compilar stress-ng desde la fuente.
stress-ng --memrate 1 --memrate-wr 2000 --memrate-rd 1000 --memrate-flush -v

# elevar la carga de los núcleos del cpu (método viejo)
Ejemplo para Cargar Todos los Núcleos
Para utilizar más núcleos de tu CPU, puedes ejecutar varias instancias del comando yes. Por ejemplo:

adb shell
yes > /dev/null &
yes > /dev/null &
yes > /dev/null &
yes > /dev/null &

Cómo Detener el Proceso
Para detener los procesos en ejecución, puedes usar el siguiente comando para matar todas las instancias del comando yes:
Listar los procesos en ejecución:
adb shell ps | grep yes
Esto mostrará los IDs de los procesos (PID) del comando yes.

Matar los procesos:
adb shell kill <PID>
Sustituye <PID> por el número del proceso que quieres detener.

Si quieres matar todos los procesos de una vez:
adb shell pkill yes
#--------------cpu-thermald-fin------------------#

# ajustar nucleos a una app desde termux
# Verifica el pid de uja app
adb shell ps | grep org.citra.emu
# salida:
u0_a351       28674    524 14275072 138996 0                  0 S org.citra.emu
# ajustar los nucleos
adb shell su -c "taskset -p 8 28674"
# Salida:
pid 28674's current affinity mask: f
pid 28674's new affinity mask: 8

# desactivar actualizaciones automáticas del sistema Android usando adb
adb -s emulator-5554 shell settings put global auto_update_system 0

# ver la capacidad de almacenamiento del dispositivo
adb -s emulator-5554 shell df -h /data

# Ver la ram
adb -s emulator-5554 shell cat /proc/meminfo

# Ver la zram
adb -s emulator-5554 shell cat /sys/block/zram0/size

# Transferir un archivo de mi celular a otro por adb 
# adb -s emulator-5554 pull /sdcard/Download/archivo.apk ./archivo.apk
adb -s 192.168.20.94:5555 push /sdcard/Download/archivo.apk /sdcard/archivo.apk
# o envíalo al directorio donde se puede instalar luego 
adb -s 192.168.20.94:5555 push /sdcard/Download/archivo.apk /data/local/tmp/archivo.apk

# Para traer el archivo `archivo.apk` desde el otro dispositivo a tu celular, el comando completo sería:
adb -s 192.168.20.94:5555 pull /sdcard/Download/archivo.apk /sdcard/archivo.apk
#----------------------------------------------------------------------------#

# 1. Identificar el proceso causante de elevar la CPU:
# Usa top o ps para buscar procesos que siguen usando CPU:
ps aux --sort=-%cpu | head
adb shell ps --sort=-%cpu | head
# Esto muestra los procesos más intensivos en uso de CPU.
# 2. Terminar procesos residuales:
# Identifica y termina procesos innecesarios:
kill -9 <PID>

# Crear un backup de una o varias app usando adb
adb backup -f backup.ab -apk -obb -shared com.openai.chatgpt
# para restaurar el backup
adb restore backup.ab

# instalar APK en adb remoto
# primero transfiere el APK a la ruta /data/local/tmp/
# Este ejemplo es la IP del servidor alm cuál enviaremos al apk.
# luego apunta la ruta dónde está tu APK, y luego apunta la ruta destino del servidor adb (destino 192.168.20.94:5555)
adb -s 192.168.20.94:5555 push /sdcard/ruta de mi app/archivo.apk /data/local/tmp/
# ahora sí instala
adb -s 192.168.20.94:5555 shell pm install /data/local/tmp/by4a.setedit22_2018.10.31_apkgk.com.apk

#Verificar la existencia de un archivo
adb -s ip:puerto shell ls /sdcard/ | grep -i "archivo.txt"

# Listar los comandos de setedit
adb -s emulator-5554 shell settings list system
adb -s emulator-5554 shell settings list secure
adb -s emulator-5554 shell settings list global

# Para habilitar la Global Tablet, debes hacerlo desde adb:
# Cuando hayas emparejado solo escribe esto en termux o breven:
adb -s tu_ip:puerto_adb shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
# Listo


#Instalar apk usando adb, debes estar en esta ruta: /data/local/tmp/archivo.apk 
# si tienes el archivo.apk en /sdcard/archivo.apk debes moverlo a /data/local/tmp/archivo.apk 
adb -s emulator-5554 pull /sdcard/archivo.apk /data/local/tmp/archivo.apk 
adb -s emulator-5554 shell pm install /data/local/tmp/archivo.apk 
# Buscar haber si existe el paquete
adb -s emulator-5554 shell pm list packages | grep --color=always 'youtube' | sed 's/package://'
#desinstalar apk 
adb -s emulator-5554 shell pm uninstall -k --user 0 com.google.android.youtube
nota: para saber el nombre del packete de una app usa "Lucky Patcher.apk"

# Para deshabilitar o congelar una app (Sin root) usando adb
adb -s emulator-5554 shell pm disable-user --user 0 "$paquete"
# Para habilitar o descongelar una app (Sin root) usando adb
adb -s emulator-5554 shell pm enable "$paquete"

# Para deshabilitar o congelar una app (Necesita root)
adb shell su -c pm disable com.free.unblock.melon.vpn
# Para habilitar o descongelar una app
adb shell su -c pm enable com.free.unblock.melon.vpn

# Compartir un archivo de Android a Android con adb:
1. Desde tu dispositivo con terminal, ejecuta el siguiente comando para conectarte al dispositivo que tiene el archivo (192.168.20.44:5555):
```bash
adb connect 192.168.20.44:5555
```
2. A continuacion, ejecuta el siguiente comando para acceder al dispositivo remoto:
```bash
adb -s 192.168.20.44:5555 shell
cd /sdcard/
```
3. Una vez en la sesion de shell del dispositivo remoto, ejecuta el siguiente comando para crear el archivo `model.sh` a una ubicacion accesible:
```bash
pwd
/sdcard/
touch model.sh
```

# ingresar a la shell 
adb shell
# O si tienes varios dispositivos, de esta forma, puedes seleccionar al cual quieres conectarte.
adb -s host:port shell


# abrir el asistente de Google o Gemini usando adb
sleep 3;adb shell input keyevent 231
# O
sleep 3;adb shell input keyevent 219

# limpiar Bluetooth 
adb shell su -c 'pm clear com.android.bluetooth'
# o (sin su, si eres root en adb):
adb shell pm clear com.android.bluetooth


# Otorgar los permisos de almacenamiento de una app (Ejemplo usando la app termux)
adb -s emulator-5554 shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
adb -s emulator-5554  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE


# tener esto para adb comandos sobre todo el de los permisos 
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid 3 v8.01_arm64 (Premium).apk"
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid Permissions Plugin v2.32 sign.apk"
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid repository plugin v4.00 sign.apk"
pkg="ru.iiec.pydroid3"
# Permiso especial: Permitir administrar todo los archivos
# adb -s "${dispositivo}" shell am start -a android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION -d package:ru.iiec.pydroid3
uid=$(adb shell dumpsys package "$pkg" | grep -m1 "userId=" | sed 's/.*userId=//')
adb shell cmd appops set --uid "$uid" MANAGE_EXTERNAL_STORAGE allow
# PERMISOS PARA PYDROID3 (ru.iiec.pydroid3)
adb -s "${dispositivo}" shell pm grant ru.iiec.pydroid3 android.permission.READ_EXTERNAL_STORAGE


# Otorgar permisos en tasker para reforzar, usando adb
# PERMISOS PARA TASKER  
adb shell pm grant net.dinglisch.android.taskerm android.permission.READ_LOGS
adb shell appops set net.dinglisch.android.taskerm PROJECT_MEDIA allow
adb shell pm grant net.dinglisch.android.taskerm android.permission.DUMP
adb shell pm grant net.dinglisch.android.taskerm android.permission.WRITE_SECURE_SETTINGS # Permisos de Tasker para permanecer siempre corriendo servicio de accesibilidad.
# permisos especiales para copia de portapapeles 
adb shell pm grant net.dinglisch.android.taskerm android.permission.READ_LOGS
# Otorgar permisos de Archivos y contenido multimedia
adb shell appops set --uid net.dinglisch.android.taskerm MANAGE_EXTERNAL_STORAGE allow
# Permitir acceso al micrófono 
adb shell pm grant net.dinglisch.android.taskerm android.permission.RECORD_AUDIO
# Permiso adicional: Permite que la aplicación solicite a Tasker que ejecute tareas definidas por el usuario y sus propias tareas 
adb shell pm grant net.dinglisch.android.taskerm net.dinglisch.android.zoom.permission.MAKE_CHANGES
# Permisos adicionales para correr comandos de termux.
adb shell pm grant net.dinglisch.android.taskerm com.termux.permission.RUN_COMMAND # para ver si se aplicó: adb shell pm list permissions -g -d | grep termux
# Permisos especiales para tasker
# Otorgar permisos para: Acceso a uso de datos.
# am start -a android.settings.USAGE_ACCESS_SETTINGS
adb shell appops set net.dinglisch.android.taskerm GET_USAGE_STATS allow
# Otorgar permisos para: Modificar las configuraciones del sistema.
adb shell appops set net.dinglisch.android.taskerm WRITE_SETTINGS allow
# Otorgar permisos para: Permitir mostrar sobre otras aplicaciones.
adb shell appops set net.dinglisch.android.taskerm SYSTEM_ALERT_WINDOW allow
# PERMISOS PARA AUTONOTIFICATION
# adb shell dumpsys package com.joaomgcd.autonotification | grep permission 
adb shell pm grant com.joaomgcd.autonotification android.permission.READ_EXTERNAL_STORAGE
# Permiso para enviar comandos a Tasker
adb shell pm grant com.joaomgcd.autonotification net.dinglisch.android.tasker.PERMISSION_SEND_COMMAND
# Permiso adicional: Permite que la aplicación active el evento "Comando" en Tasker con cualquier comando que elija.
adb shell pm grant com.joaomgcd.autonotification net.dinglisch.android.tasker.PERMISSION_SEND_COMMAND
# Otorgar permisos para: Permitir mostrar sobre otras aplicaciones.
adb shell appops set com.joaomgcd.autonotification SYSTEM_ALERT_WINDOW allow
# PERMISOS PARA AUTOINPUT
adb shell pm grant com.joaomgcd.autoinput android.permission.READ_EXTERNAL_STORAGE
# Otorgar permisos para: Acceso a uso de datos.
adb shell appops set com.joaomgcd.autoinput WRITE_SETTINGS allow
# Otorgar permisos para: Permitir mostrar sobre otras aplicaciones.
adb shell appops set com.joaomgcd.autoinput SYSTEM_ALERT_WINDOW allow
# ----------
# ver los permisos otorgados de una app en este caso: Tasker 
adb shell dumpsys package net.dinglisch.android.taskerm | grep permission # Para ver permisos adicionales
adb shell pm dump net.dinglisch.android.taskerm | grep "granted" # Para ver todos los permisos que e otorgado
adb shell appops get net.dinglisch.android.taskerm # para ver algo general de los que se han otorgado y los que no
adb shell appops get net.dinglisch.android.taskerm | grep allow # Para ver permisos normales
# ----------
# agregar a la lista blanca para doze no las cierre. (Agotando un poco más de batería pero las app serán más estable)
adb shell dumpsys deviceidle whitelist +com.joaomgcd.autonotification
adb shell dumpsys deviceidle whitelist +net.dinglisch.android.taskerm
# If you're on a mac write
./adb shell pm grant net.dinglisch.android.taskerm android.permission.DUMP
# verificar 
adb shell dumpsys package net.dinglisch.android.taskerm | grep READ_LOGS
adb shell dumpsys deviceidle whitelist
# PERMISOS PARA ACTIVAR LA APP DE ADMINISTRACIÓN
# Para ver los permisos y recibir de las app 
# Comando versión (Receiver)
adb shell dumpsys package net.dinglisch.android.taskerm | grep -i receiver -A 3
# Para otorgar permisos tasker: Aplicación de administración del dispositivo 
adb shell dpm set-active-admin --user current net.dinglisch.android.taskerm/.MyDeviceAdminReceiver
# Para desactivar:
adb shell dpm remove-active-admin net.dinglisch.android.taskerm/.MyDeviceAdminReceiver
# Para otorgar permisos SecureSettings: Aplicación de administración del dispositivo 
adb shell dpm set-active-admin --user current com.intangibleobject.securesettings.plugin/.Receivers.AdminReceiver
# Para desactivar 
adb shell dpm remove-active-admin --user current com.intangibleobject.securesettings.plugin/.Receivers.AdminReceiver
# Abrir la ventana Aplicación de administración del dispositivo 
adb shell am start -a android.settings.SECURITY_SETTINGS
# VER LOS PAQUETES QUE ESTÁN ACTIVADOS EN ACCESIBILIDAD 
adb shell settings get secure enabled_accessibility_services
# ACTIVAR VARIOS PAQUETES  (APPS) EN ACCESIBILIDAD 
adb shell settings put secure enabled_accessibility_services "com.sand.remotesupportaddon/com.sand.remotesupportaddon.SmartService:com.quickcursor/com.quickcursor.android.services.CursorAccessibilityService:net.dinglisch.android.taskerm/net.dinglisch.android.taskerm.MyAccessibilityService:com.joaomgcd.autoinput/com.joaomgcd.autoinput.service.ServiceAccessibilityV2:com.termux.x11/com.termux.x11.utils.KeyInterceptor"
adb shell settings put secure accessibility_enabled 1
# ACTIVAR PAQUETES INDIVIDUALES
# activar termux:x11 en accesibilidad
adb shell settings put secure enabled_accessibility_services "com.termux.x11/com.termux.x11.utils.KeyInterceptor"
# activar ADB Mouse en accesibilidad
adb shell settings put secure enabled_accessibility_services "com.quickcursor/com.quickcursor.android.services.CursorAccessibilityService"
# activar Airdroid en accesibilidad
adb shell settings put secure enabled_accessibility_services "com.sand.remotesupportaddon/com.sand.remotesupportaddon.SmartService"
# activar Tasker en accesibilidad
adb shell settings put secure enabled_accessibility_services "net.dinglisch.android.taskerm/net.dinglisch.android.taskerm.MyAccessibilityService"
# activar AutoInput en accesibilidad
adb shell settings put secure enabled_accessibility_services "com.joaomgcd.autoinput/com.joaomgcd.autoinput.service.ServiceAccessibilityV2"
# activar AutoNotification en accesibilidad
adb shell settings put secure enabled_accessibility_services "com.joaomgcd.autonotification/com.joaomgcd.autonotification.service.ServiceToastIntercept"
# #####
# Para usar termux:tasker
primero instale la apk, luego abra, 
# y en tasker vaya a configurar y otorgue permiso: Permisos adicionales o ejecute el comando adb
luego en termux terminal ejecute este script:
# Inicio del script
#!/bin/bash
# Ruta del archivo de configuración de Termux
FILE="$HOME/.termux/termux.properties"
LINE="allow-external-apps = true"
# Si el archivo no existe, créalo
if [ ! -f "$FILE" ]; then
    echo "# Archivo creado automáticamente" > "$FILE"
fi
# Verificar si la línea ya existe (ignorando espacios)
if grep -q "^[[:space:]]*allow-external-apps[[:space:]]*=[[:space:]]*true" "$FILE"; then
    echo "✅ La regla ya existe en $FILE"
else
    echo "$LINE" >> "$FILE"
    echo "🆕 Línea agregada al final de $FILE"
fi
# Fin del script
# ahora abra tasker y cree una tarea y seleccionar plugin:
# termux:tasker y entra al lápiz, y en la primera línea coloca la ruta de tu script:
# en mi caso:
# La dos primeras líneas dicen:
 * Executable (file in ~/.termux/tasker or absolute path to executable)
 * ~/miscript.sh # Está es la ruta de mi script de ejemplo...
# #####
# OTROS PERMISOS ADB
# Permisos relacionados con las funciones integradas de Tasker
# Verificar servicios en ejecución (Contexto - Aplicación)
adb shell pm grant net.dinglisch.android.taskerm android.permission.DUMP
# Manejo de pulsaciones de teclas multimedia (Contexto - Estado - Botón multimedia)
adb shell pm grant net.dinglisch.android.taskerm android.permission.SET_MEDIA_KEY_LISTENER
# Leer registros del sistema (Contexto - Evento - Entrada LogCat)
adb shell pm grant net.dinglisch.android.taskerm android.permission.READ_LOGS
adb shell am force-stop net.dinglisch.android.taskerm
# Manejo de pulsación larga de teclas de volumen (Contexto - Evento - Hardware - Pulsación larga de volumen)
adb shell pm grant net.dinglisch.android.taskerm android.permission.SET_VOLUME_KEY_LONG_PRESS_LISTENER
# Escribir configuraciones seguras (Acción - Configuraciones - Configuración personalizada)
adb shell pm grant net.dinglisch.android.taskerm android.permission.WRITE_SECURE_SETTINGS
# Permisos relacionados con AutoApps
# LogCat para AutoTools
adb shell pm grant com.joaomgcd.autotools android.permission.READ_LOGS
# Configuraciones seguras para AutoTools
adb shell pm grant com.joaomgcd.autotools android.permission.WRITE_SECURE_SETTINGS
# Eliminar advertencia de grabación de pantalla de AutoInput
adb shell appops set com.joaomgcd.autoinput PROJECT_MEDIA allow
# Configuraciones seguras para AutoInput (no estoy seguro exactamente qué acción de AI necesita configuraciones seguras)
adb shell pm grant com.joaomgcd.autoinput android.permission.WRITE_SECURE_SETTINGS
# Configuraciones seguras para AutoWear
adb shell pm grant com.joaomgcd.autowear android.permission.WRITE_SECURE_SETTINGS
# Permisos de unión
# Permisos de lectura del portapapeles
adb -d shell appops set com.joaomgcd.join SYSTEM_ALERT_WINDOW allow
adb shell pm grant com.joaomgcd.join android.permission.WRITE_SECURE_SETTINGS
adb shell pm grant com.joaomgcd.join android.permission.READ_LOGS
adb shell am force-stop com.joaomgcd.join
# Otros permisos (Cortesía de u/DutchOfBurdock)
# Cambiar configuración regional del sistema
adb shell pm grant net.dinglisch.android.taskerm android.permission.CHANGE_CONFIGURATION
# Dibujar sobre otras aplicaciones para pantallas web
adb shell pm grant net.dinglisch.android.taskerm android.permission.SYSTEM_ALERT_WINDOW
# Para bloquear la pantalla + otras acciones administrativas
adb shell pm grant net.dinglisch.android.taskerm android.permission.BIND_DEVICE_ADMIN
# Para reaccionar a las notificaciones recibidas, borradas y pulsadas de otras aplicaciones
adb shell pm grant net.dinglisch.android.taskerm android.permission.BIND_NOTIFICATION_LISTENER_SERVICE
# Para reaccionar a los cambios de aplicación, obtener información de la aplicación, tiempos de ejecución y más!
adb shell pm grant net.dinglisch.android.taskerm android.permission.PACKAGE_USAGE_STATS
# Usar el servicio de accesibilidad para detectar el inicio de aplicaciones y otra información
adb shell pm grant net.dinglisch.android.taskerm android.permission.BIND_ACCESSIBILITY_SERVICE
# Llamadas telefónicas
adb shell pm grant net.dinglisch.android.taskerm android.permission.ANSWER_PHONE_CALLS 
adb shell pm grant net.dinglisch.android.taskerm android.permission.CALL_PHONE
# #####

Para ver los puertos abiertos en un dispositivo Android utilizando ADB, puedes utilizar el shell de ADB para ejecutar comandos del sistema. Aunque Android no tiene un comando nativo como `netstat` para visualizar los puertos abiertos, puedes usar `iptables` o `ss` si están disponibles en tu versión de Android.
### Opción 1: Usar `netstat`
Si el comando `netstat` está disponible en tu dispositivo (no siempre lo está, especialmente en versiones modernas de Android), puedes intentar lo siguiente:

1. Conéctate a tu dispositivo usando ADB:
    ```bash
    adb -s emulator-5554 shell
    ```

2. Luego, ejecuta el comando:
    ```bash
    netstat -tuln
    ```
Esto mostrará los puertos TCP y UDP abiertos.

### Opción 2: Usar `ss`
Algunos dispositivos Android tienen el comando `ss`, que también puede mostrar información de conexión:

1. Conéctate a tu dispositivo:
    ```bash
    adb -s emulator-5554 shell
    ```

2. Ejecuta el comando:
    ```bash
    ss -tuln
    ```

### Opción 3: Usar `iptables`
También puedes usar `iptables` para ver algunos detalles relacionados con las conexiones de red:

1. Conéctate a tu dispositivo:
    ```bash
    adb -s emulator-5554 shell
    ```

2. Ejecuta el comando:
    ```bash
    iptables -L -n -v
    ```
Esto mostrará las reglas de las tablas de `iptables`, aunque no te dará directamente todos los puertos abiertos.

### Notas
- Asegúrate de que tienes los permisos necesarios para ejecutar estos comandos en el dispositivo.
- Algunos de estos comandos pueden no estar disponibles en dispositivos no rooteados o en versiones más recientes de Android por motivos de seguridad.


# Ver mi cersion de Opengl
adb shell dumpsys SurfaceFlinger | grep -i "gles"

adb -s emulator-5554 shell dumpsys gfxinfo | grep -i pipeline
bien, ahora quiero una funtion {
que si es compatible con vulkan lo active con los comandos del terminal por adb si no diga que no es compatible 
# mod a vulkan, comando ya no funhiona bien, no usar
(setprop debug.hwui.renderer skiavk;for a in $(pm list packages|grep -v ia.mo cut -f2 -d:); do am force-stop "$a"&done)>/dev/null 2>&1&
# Desde el terminal puede hacer así
adb -s emulator-5554 shell "setprop debug.hwui.renderer skiavk; for a in \$(pm list packages | grep -v ia.mo | cut -f2 -d:); do am force-stop \"\$a\" & done" >/dev/null 2>&1 &
# restablecer 
(setprop debug.hwui.renderer opengl;for a in $(pm list packages|grep -v ia.mo|cut -f2 -d:);do am force-stop "$a"&done)>/dev/null 2>&1&
# desde el terminal puedes hacer así:
adb -s emulator-5554 shell "setprop debug.hwui.renderer opengl; for a in \$(pm list packages | grep -v ia.mo | cut -f2 -d:); do am force-stop \"\$a\" & done" >/dev/null 2>&1 &

# verificar si una app está usando vulkan, abre la app específica, ejemplo (org.citra.emu) y luego en termux escribe lo siguiente:
adb -s emulator-5554 shell dumpsys gfxinfo org.citra.emu
adb -s emulator-5554 shell dumpsys gfxinfo org.citra.emu | grep -E 'Vulkan|OpenGL'


# Crear archivo
touch archivo.txt
# Escribir en el archivo usando adb
echo -e "#!/bin/sh" > model.sh
echo -e "" >> model.sh
echo -e "# Definir los códigos de colores" >> model.sh
echo -e "RED='\\033[0;31m'" >> model.sh
echo -e "GREEN='\\033[0;32m'" >> model.sh
echo -e "YELLOW='\\033[0;33m'" >> model.sh
echo -e "BLUE='\\033[0;34m'" >> model.sh
echo -e "NC='\\033[0m'" >> model.sh
echo -e "" >> model.sh
echo -e "echo -e \"\${GREEN}Brand ID: \${NC}\$(getprop ro.product.system.brand)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Modelo: \${NC}\$(getprop ro.product.model)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Version de Android: \${NC}\$(getprop ro.build.version.release)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Model ID: \${NC}\$(getprop ro.build.product)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Kernel ID: \${NC}\$(uname -r)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Chipset ID: \${NC}\$(getprop ro.product.board)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Architecture: \${NC}\$(uname -m)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Android ID: \${NC}\$(getprop ro.serialno)\"" >> model.sh
echo -e "echo -e \"\${GREEN}Unique Android ID: \${NC}\$(settings get secure android_id)\"" >> model.sh

# opción de pantalla de bloqueo, 

# despertar la pantalla al llegar notificaciones usando adb
    adb -s emulator-5554 shell settings put secure lock_screen_show_notifications 1
# no despertar la pantalla al llegar notificaciones usando adb
    adb -s emulator-5554 shell settings put secure lock_screen_show_notifications 0

# Para cambiar la configuración de clock_seconds en un dispositivo Android usando adb, puedes intentar lo siguiente:
# Verifica si el comando está disponible en las configuraciones actuales:
adb shell settings list secure | grep "clock_seconds"
adb -s emulator-5554 shell settings put secure clock_seconds 1

# Deshabilitar la vibración de los botones de navegación "Nabvar" y teclado: usando adb
adb -s emulator-5554 shell settings put system haptic_feedback_enabled 0

# Habilita la vibración de los botones de navegación "Nabvar" y teclado: usando adb
adb -s emulator-5554 shell settings put system haptic_feedback_enabled 0

# agregar nuevo boton al navigationbar "Nabvar" usando adb
adb -s emulator-5554 shell settings put system navigationbar_config 2

# Desactivar actualizaciones del sistema Android usando adb
adb -s emulator-5554 shell settings put global auto_update_system 0

# Entrar o abrir la linea de volumens usando adb
adb -s emulator-5554 shell am start -a android.settings.SOUND_SETTINGS

# Entrar a opciones de desarrollador usando adb
adb -s emulator-5554 shell am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS

# Activar ver toques "0 desactivar" usando adb
adb -s 192.168.20.83:5555 shell settings put system show_touches 1

# saber las tasas de fps disponibles en mi dispositivo 
adb -s emulator-5554 shell dumpsys display | grep -i "refreshRate=" | awk -F 'refreshRate=' '{print $2}' | awk '{print $1}' | sort -u

# ver apps en segundo plano sin restricción de batería usando adb
adb -s emulator-5554 shell ps | grep u0_a
# o
adb -s emulator-5554 shell dumpsys deviceidle
# detener una app
adb -s emulator-5554 shell am force-stop com.whatsapp
# detener las que están sin la optimización de batería wue estam drenando 
adb -s emulator-5554 shell dumpsys deviceidle whitelist -com.whatsapp

# desactivar la optimización por batería para una aplicación específica, y se mantenga siempre en segundo plano sin cerrarce nunca: usando adb
adb -s emulator-5554 shell dumpsys deviceidle whitelist +com.termux.boot
# revertir optimizar app por batería (se cerrará cuando sea necesario) usando adb
adb -s emulator-5554 shell dumpsys deviceidle whitelist -com.termux.boot
# abrir la ventana de configuración de la app usando adb
adb -s emulator-5554 shell am start -a android.settings.APPLICATION_DETAILS_SETTINGS -d package:com.termux.boot
# ver las app que estan siendo optimizadas por la batería usando adb
adb -s emulator-5554 shell dumpsys deviceidle


# configuración de escala de animación Android usando adb
# 1. Configurar la escala de animación de ventanas
# (Valores comunes: 0.5, 1.0, 1.5, 2.0, etc. 0.5 es más rápido, 2.0 es más lento)
adb -s emulator-5554 shell settings put global window_animation_scale 0.5
# 2. Configurar la escala de animación de transición
adb -s emulator-5554 shell settings put global transition_animation_scale 0.5
# 3. Configurar la escala de duración de animación
adb -s emulator-5554 shell settings put global animator_duration_scale 0.5

# optimizar una app usando adb
adb -s emulator-5554 shell cmd package compile -m speed-profile com.android.chrome
# verificar si la app se optimizo. 
# si funciona, solo que para verificar se necesita root, pero la optimización si se aplica sin root
adb -s emulator-5554 shell su -c ls /data/misc/profiles/cur/0/com.android.chrome
#Salida:
auxiliary_search.split.prof
cablev2_authenticator.split.prof
chrome.split.prof
dev_ui.split.prof
feedv2.split.prof
primary.prof
read_aloud_playback.split.prof
stack_unwinder.split.prof
survey.split.prof
test_dummy.split.prof
# Parece que la optimización se ha aplicado correctamente, ya que los archivos de perfil (*.prof) que mencionas en el directorio /data/misc/profiles/cur/0/com.android.chrome confirman que la compilación de perfiles se ha generado para com.android.chrome.
# En particular, el archivo primary.prof es el perfil principal que Android utiliza para optimizar la aplicación basada en su uso, mientras que los archivos con el sufijo split.prof corresponden a otros componentes o funciones de la aplicación.
# Conclusión:
Los archivos de perfil (*.prof) indican que la optimización de la aplicación ha sido aplicada con éxito.
# primary.prof es el archivo clave para la optimización del perfil principal.
# No es necesario que el comando dumpsys muestre siempre resultados específicos en cuanto a Dexopt state, ya que la presencia de estos archivos es una confirmación clara de que la compilación de perfiles está funcionando.
# Puedes estar seguro de que la optimización de com.android.chrome se ha aplicado correctamente.

# borrar la cache de todas las app de Android, probe con mas 9 usando adb
adb -s emulator-5554 shell pm trim-caches 99999999999
# Limpiar solo la cache de una app, parece que borra los datos
adb -s emulator-5554 shell pm clear com.facebook.lite --cache-only
# Limpiar datos de una app usando adb
adb -s emulator-5554 shell pm clear com.facebook.lite


# hacer forwarding usando adb
2. Verificar la Configuración del Reenvío de Puertos
En el Dispositivo Remoto:
Verifica que el puerto 5554 esté correctamente configurado para el emulador. Si puedes acceder a una shell ADB en el dispositivo remoto, puedes intentar:
adb -s emulator-5554 shell forward tcp:5554 tcp:5554
En tu Máquina Local:
Asegúrate de que el reenvío de puertos esté configurado para el dispositivo remoto:
adb -s 192.168.20.94:5555 forward tcp:5554 tcp:5555
3. Verificar Conexión a Emulador
En tu Máquina Local:
Asegúrate de que el emulador remoto está correctamente redirigido a tu máquina local. Conéctate al emulador remoto con el puerto redirigido:
adb connect localhost:5554
Luego, intenta acceder al shell del emulador:
adb -s localhost:5554 shell

# fix, arreglar, corregir, resolver error de runit
cómo resolver este error cada vez que abro una nueva sesión de termux me pide runit
Welcome to Termux!
Docs:       https://termux.dev/docs
Donate:     https://termux.dev/donate
Community:  https://termux.dev/community
Working with packages:
Search:  pkg search <query>
Install: pkg install <package>
Upgrade: pkg upgrade
Subscribing to additional repositories:
Root:    pkg install root-repo
X11:     pkg install x11-repo
For fixing any repository issues,
try 'termux-change-repo' command.
Report issues at https://termux.dev/issues
fail: started: unable to change to service directory: file does not exist





Report issues at https://termux.dev/issues
Report issues at https://termux.dev/issues
The program sv is not installed. Install it by executing:
pkg install runit
fail: started: unable to change to service directory: file does not exist
~ $ $PREFIX/var/service
bash: /data/data/com.termux/files/usr/var/service: Is a directory
# Aquí la solución...
cp ~/.profile ~/.profile.bak.$(date +%s) && echo "Backup creado: ~/.profile.bak.*"
sed -i '/sv up sshd/d' ~/.profile
sed -n '1,200p' ~/.profile
grep -nH "sv up\|started" ~/.profile || echo "No quedan coincidencias en ~/.profile"

pkg install -y termux-services runit
# Reinicia la shell de Termux o arranca el demonio:
adb -s emulator-5554 shell 'service-daemon start'
# Habilita/arranca sshd (si ya tienes el servicio creado):
adb -s emulator-5554 shell 'sv up sshd'
# ejecutar comandos de termux usando adb
adb -s emulator-5554 shell 'echo "sv up sshd && echo '\''sshd started'\''" >> /data/local/tmp/.profile'
adb -s emulator-5554 shell 'echo "sv up sshd && echo '\''sshd started'\''" >> /data/data/com.termux/files/home/.profile'
# abrir la aplicación de termux
adb -s emulator-5554 shell am start -n com.termux/.HomeActivity
# forzar cierre de AirDroid
adb shell am force-stop com.sand.airdroid
# Ver las actividades para ejecutar
adb shell dumpsys package com.sand.airdroid | grep Activity
# Abrir la app de AirDroid
adb shell am start -n com.sand.airdroid/com.sand.airdroid.ui.main.Main2Activity_
# Al ejecutar el siguiente código en termux, debés abrir la app que quieres saber su nombre de paquete antes de 5 segundos, puede modificar el tiempo 
sleep 5;nombre_paquete=$(adb -s emulator-5554 shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}');echo $nombre_paquete
# tranferir el comando
adb -s emulator-5554 shell input text 'your%scommand%shere'
adb -s emulator-5554 shell input text 'pkg%sinstall%sphp'
# ejecutar enter
adb -s emulator-5554 shell input keyevent ENTER

# Ver la fecha de instalación de una app y su última actualización, ejemplo usando facebook lite usando adb
adb -s emulator-5554 shell dumpsys package com.facebook.lite | grep -E "firstInstallTime|lastUpdateTime"

# Obtener la lista de todos los paquetes de usuario 3 usando adb
packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

# Controlar el uso de la app (limitar background processes) usando adb
# Puedes reducir la cantidad de procesos en segundo plano para que el dispositivo use menos recursos y las apps principales se carguen más rápido:
adb shell settings put global limit_background_processes 2

# Desactivar la actividad en segundo plano para una app específica usando adb
# Este comando evita que una aplicación se ejecute en segundo plano, lo que puede mejorar el rendimiento general del sistema: usando adb
adb shell am set-inactive <nombre_del_paquete> true

#Puedes usar el siguiente comando para verificar si está la pantalla apagada o encendida en un dispositivo Android conectado usando adb:
adb shell dumpsys power | grep "Display Power"

# Habilitar o deshabilitar Doze y App Standby
# Doze y App Standby pueden reducir la actividad de las aplicaciones en segundo plano, lo que mejora la duración de la batería y el rendimiento general:
# Para activar Doze inmediatamente (mientras la pantalla está apagada): usando adb
adb shell dumpsys deviceidle force-idle

# Para permitir que una app evite ser afectada por Doze: usando adb
adb shell dumpsys deviceidle whitelist +<nombre_del_paquete>

# Desactivar la recolección de datos innecesaria por apps en segundo plano usando adb
# Esto puede evitar que las apps ejecuten tareas innecesarias mientras están en segundo plano, lo que podría mejorar el rendimiento del sistema:
adb shell settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"

# Reducir los servicios en segundo plano de apps específicas
# Esto limita los servicios que una aplicación puede ejecutar en segundo plano:
adb shell cmd appops set <nombre_del_paquete> RUN_IN_BACKGROUND ignore

# Forzar a usar el modo Doze inmediatamente: usando adb
# Este comando pone al dispositivo en modo Doze de inmediato. No modifica la lista blanca de Doze; simplemente activa el modo Doze aplicando las restricciones a todas las aplicaciones excepto a aquellas que están en la lista blanca.
adb shell dumpsys deviceidle force-idle
# revertir 
adb shell dumpsys deviceidle unforce
adb shell dumpsys deviceidle disable
adb shell dumpsys deviceidle unforce
adb shell settings delete global device_idle_constants
adb shell settings delete global device_idle_constants_original

# Aumentar swap, solo funciona con root
# Crea un nuevo archivo de Swap de 512 MB
adb shell su -c "dd if=/dev/zero of=/data/swapfile_extra bs=1M count=512"
# Prepara el archivo Swap con el comando mkswap:
adb shell su -c "mkswap /data/swapfile_extra"
# Activa el archivo Swap adicional:
adb shell su -c "swapon /data/swapfile_extra"

# verificar cuanto consumen las app la swap
adb shell su -c "cat /proc/sys/vm/swappiness"
# Ajusta el swappiness a un valor más alto, por ejemplo 80:
adb shell          
java:/ $ su                                           
java:/ # echo 150 | tee /proc/sys/vm/swappiness
# Para hacerlo persistente entre reinicios, agrega la configuración al archivo sysctl.conf. En muchos sistemas Android, esto puede requerir modificaciones en archivos del sistema o el uso de scripts de inicio.
adb shell su -c "echo 'vm.swappiness=150' >> /etc/sysctl.conf"

# Ver la frecuencia máxima  de cpu usando adb
ls /sys/devices/system/cpu/cpu0/cpufreq/
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
# Ver las frecuencias que maneja mi CPU
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies
# Ver la frecuencia actual establecida en mi CPU
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq
# Ver la frecuencia mínima y maxima que estan actualmente establecidas en mi CPU
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
# Controlar la frecuencia máxima de la CPU
adb -s emulator-5554 shell settings put global cpu_max_freq 2000000  # Establecer frecuencia máxima de la CPU a 2GHz
adb shell 'echo 614400 | su -c "tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq"'
adb shell 'echo 1820000 | su -c "tee /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq"'



# Controlar la frecuencia de CPU Y GPU
# Ver las frecuencias que maneja mi GPU
adb shell su -c cat /sys/class/devfreq/60000000.gpu/available_frequencies
# Ver la mínima y máxima frecuencia establecida actualmente de mi GPU
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
adb shell cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
# Configurar la mínima frecuencia de GPU
adb shell 'echo 384000000 | su -c "tee /sys/class/devfreq/60000000.gpu/min_freq"'
# Configurar la máxima frecuencia de GPU
adb shell 'echo 850000000 | su -c "tee /sys/class/devfreq/60000000.gpu/max_freq"'

# visualizar la ubicación de la gpu
u0_a255@localhost ~/proyecto_bash> adb shell su -c "find /sys -iname '*gpu*'"
/sys/kernel/tracing/events/mali/mali_jit_report_gpu_mem
/sys/kernel/tracing/events/mali/sysgraph_gpu
/sys/kernel/tracing/instances/wifi/events/mali/sysgraph_gpu
/sys/kernel/tracing/instances/wifi/events/mali/mali_jit_report_gpu_mem
/sys/class/devfreq/60000000.gpu
/sys/devices/platform/soc/soc:gpu-clk
/sys/devices/platform/soc/soc:mm/60000000.gpu
/sys/devices/platform/soc/soc:mm/60000000.gpu/devfreq/60000000.gpu
/sys/devices/platform/soc/soc:mm/60000000.gpu/gpuinfo
/sys/bus/platform/devices/soc:gpu-clk
/sys/bus/platform/devices/60000000.gpu
/sys/bus/platform/drivers/sharkl5pro-clk/soc:gpu-clk
/sys/bus/platform/drivers/mali/60000000.gpu
/sys/firmware/devicetree/base/gpu-cooling-devices
/sys/firmware/devicetree/base/gpu-cooling-devices/gpu-cooling0
/sys/firmware/devicetree/base/thermal-zones/gpu-thmzone
/sys/firmware/devicetree/base/thermal-zones/gpuank2-thmzone
/sys/firmware/devicetree/base/soc/aon/thermal@32210000/gpu-sensor@0
/sys/firmware/devicetree/base/soc/aon/spi@32100000/pmic@0/power-controller@1800/DCDC_GPU
/sys/firmware/devicetree/base/soc/aon/topdvfsctrl@322a0000/dcdc-mm/gpu-sys
/sys/firmware/devicetree/base/soc/aon/thermal@32220000/gpuaank2-sensor@0
/sys/firmware/devicetree/base/soc/mm/gpu@60000000
/sys/firmware/devicetree/base/soc/mm/gpu@60000000/gpu-supply
/sys/firmware/devicetree/base/soc/gpu-clk
/sys/firmware/devicetree/base/aliases/gpu-cooling0
/sys/firmware/devicetree/base/hwfeature/lwfq/gpu
/sys/firmware/devicetree/base/__symbols__/gpuank2_thmzone
/sys/firmware/devicetree/base/__symbols__/gpu_thmzone
/sys/firmware/devicetree/base/__symbols__/gpu
/sys/firmware/devicetree/base/__symbols__/vddgpu
/sys/firmware/devicetree/base/__symbols__/gpu_qos
/sys/firmware/devicetree/base/__symbols__/gpu_bin
/sys/firmware/devicetree/base/__symbols__/gpu_cooling0
/sys/firmware/devicetree/base/__symbols__/gpu_apb_regs
/sys/firmware/devicetree/base/__symbols__/gpu_dvfs_apb_regs
/sys/firmware/devicetree/base/__symbols__/gpu_clk
/sys/firmware/devicetree/base/__symbols__/gpu_sys
/sys/firmware/devicetree/base/efuse@15c00/gpu-bin@1b

# Verificar los governadores de mi gpu
u0_a255@localhost ~/proyecto_bash> adb shell su -c "cat /sys/class/devfreq/60000000.gpu/available_governors"
# salida:
mtx_dvfs dcam_axi_dvfs dcam_if_dvfs jpg_dvfs isp_dvfs fd_dvfs cpp_dvfs mmsys_dvfs vdsp_dvfs vsp_dvfs dpu_dvfs sprd-governor simple_ondemand


# activar tema oscuro usando adb
adb shell settings put secure ui_night_mode 1
# Para desactivar tema oscuro usando adb
adb shell settings put secure ui_night_mode 2
# Para poner en automático 
adb shell cmd power set-mode 0

# Saber si tengo driver gamer usando adb
adb shell dumpsys gpu

# Ver estadísticas de uso
adb shell dumpsys graphicsstats

# Cambia la densidad de la pantalla reemplazando <dpi> por el valor deseado (por ejemplo, 280 para densidad estándar): usando adb
adb shell wm density dpi
# Para restaurar la densidad dpi usando adb
adb shell wm density reset


# desactivar o activar, habilitar o deshabilitar los datos mobiles usando adb
#on/off datos
svc data disable
svc data enable

u0_a251@localhost ~> adb shell svc data disable
u0_a251@localhost ~> adb shell svc data enable


#WiFi on/off
if [ -x $PREFIX/share/doc/termux-api ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando termux-api"
pkg install termux-api
fi
if [ -e ${HOME}/Termux_API_0.50.1.apk ]; then 
echo "Ya esta descargado"
sleep 2
xdg-open Termux_API_0.50.1.apk
clear
else
echo -e ""
echo "Descargando Termux_API_0.50.1"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/ul0wj8yud8mq03f/Termux_API_0.50.1.apk
xdg-open Termux_API_0.50.1.apk
fi
termux-wifi-enable false
termux-wifi-enable true

# Restablecer mobil de fabrica usando adb
adb shell recovery --wipe_data


# apagar movil
# Prueba con:
adb shell reboot -p

Túneles portuarios
En caso de que el puerto  adb solo sea accesible desde localhost en el dispositivo android pero tienes acceso a través de SSH , puedes redirigir el puerto 5555 y conectarte a través de adb:
ssh -i ssh_key username@10.10.10.10 -L 5555:127.0.0.1:5555 -p 2222
adb connect 127.0.0.1:5555


adb shell settings put system rakuten_denwa 0
adb shell settings put system send_security_reports 0
adb shell settings put secure send_action_app_error 0
adb shell settings put global activity_starts_logging_enabled 0
adb shell cmd power set-fixed-performance-mode-enabled true
adb shell settings put global sem_enhanced_cpu_responsiveness 1
adb shell pm trim-caches 128G

# Los smartphones modernos ofrecen una excelente calidad de audio, que puede mejorarse aún más con aplicaciones de ecualizador. Sin embargo, también puedes disfrutar de una mejor experiencia de audio en teléfonos Android activando los efectos K2HD y Tube Amp mediante ADB.
adb shell settings put system k2hd_effect 1
adb shell settings put system tube_amp_effect 1

# El siguiente comando congelará una aplicación que se esté ejecutando en segundo plano.
adb shell cmd appops set <nombre-del-paquete> RUN_IN_BACKGROUND ignore

# Si quieres borrar la caché y los datos de todas las aplicaciones instaladas en tu  teléfono , debes usar el siguiente comando.
# adb shell cmd package list packages|cut -d -f2|while read package ;do pm clear $package;done


Administrador de Paquetes
Instalar/Desinstalar
adb install [opción] <ruta>
Copiar
adb install test.apk

adb install -l test.apk # forward lock application
adb install -r test.apk # replace existing application
adb install -t test.apk # allow test packages
adb install -s test.apk # install application on sdcard
adb install -d test.apk # allow version code downgrade
adb install -p test.apk # partial application install
adb uninstall [opciones] <PAQUETE>
adb uninstall com.test.app
adb uninstall -k com.test.app Keep the data and cache directories around after package removal.

Paquetes
Imprime todos los paquetes, opcionalmente solo aquellos cuyo nombre de paquete contiene el texto en <FILTER>.
adb shell pm lista paquetes [opciones] <FILTER-STR>
adb shell pm list packages <FILTER-STR>
adb shell pm list packages -f <FILTER-STR> #See their associated file.
adb shell pm list packages -d <FILTER-STR> #Filter to only show disabled packages.
adb shell pm list packages -e <FILTER-STR> #Filter to only show enabled packages.
adb shell pm list packages -s <FILTER-STR> #Filter to only show system packages.
adb shell pm list packages -3 <FILTER-STR> #Filter to only show third party packages.
adb shell pm list packages -i <FILTER-STR> #See the installer for the packages.
adb shell pm list packages -u <FILTER-STR> #Also include uninstalled packages.

adb shell pm list packages --user <USER_ID> <FILTER-STR> #The user space to query.
ruta pm de adb shell <PAQUETE>
Imprima la ruta al APK del dado. usando adb
adb shell pm path com.android.phone


Captura de pantalla/Grabación de pantalla
captura de pantalla de adb shell <nombre de archivo>
Tomando una captura de pantalla de la pantalla del dispositivo.
adb shell screencap /sdcard/screen.png
adb shell screenrecord [opciones] <nombre de archivo>

Grabando la pantalla de dispositivos que ejecutan Android 4.4 (nivel de API 19) y superior. usando adb
adb shell screenrecord /sdcard/demo.mp4
adb shell screenrecord --size <WIDTHxHEIGHT>
adb shell screenrecord --bit-rate <RATE>
adb shell screenrecord --time-limit <TIME> #Sets the maximum recording time, in seconds. The default and maximum value is 180 (3 minutes).
adb shell screenrecord --rotate # Rotates 90 degrees
adb shell screenrecord --verbose
(presione Ctrl-C para detener la grabación)

p.m
Los siguientes comandos se ejecutan dentro de un shell
pm list packages #List installed packages
pm path <package name> #Get the path to the apk file of tha package
am start [<options>] #Start an activity. Whiout options you can see the help menu
am startservice [<options>] #Start a service. Whiout options you can see the help menu
am broadcast [<options>] #Send a broadcast. Whiout options you can see the help menu
input [text|keyevent] #Send keystrokes to device


# comando de eventos de botón
adb shell input keyevent [--longpress] <keycode>
# Popular <keycode>s are:
3 = Home button
4 = Back button
24 = Volume up
25 = Volume down
26 = Toggle screen on/off
220 = Brightness down
221 = Brightness up

#------------------------------------------------------------------#
# Nota: Los usuarios creados no tendrán permisos para habilitar opciones de desarrollador
# crear usuarios y eliminar 
u0_a266@localhost ~ [1]> adb -s emulator-5554 shell pm create-user "Guest"
Success: created user id 10

u0_a266@localhost ~ [1]> adb -s emulator-5554 shell pm install-existing --user 10 com.rhmsoft.code
Package com.rhmsoft.code installed for user: 10

# proceder al usuario 
adb -s emulator-5554 shell am switch-user 10
# salir
adb -s emulator-5554 shell am switch-user 0

# eliminar user, primero listar
adb -s emulator-5554 shell pm list users
# salida
Users:
        UserInfo{0:Robert:c13} running
        UserInfo{10:Guest:410} running
# eliminar
adb -s emulator-5554 shell pm remove-user 10
#------------------------------------------------------------------#


# comando=1 enciende y comando=0 los desactiva
wifi_scan_always_enabled: Controla solo si el dispositivo escanea redes Wi-Fi cercanas para propósitos de ubicación cuando el Wi-Fi está apagado, pero no se conecta a ninguna red ni enciende el Wi-Fi automáticamente.
wifi_wakeup_enabled: Controla si el dispositivo enciende el Wi-Fi automáticamente cuando detecta una red conocida, permitiendo que el dispositivo se conecte a esa red automáticamente.


GitHub - saleehk/adb-wifi : una herramienta de interfaz de linea de comandos (CLI) de NPM

#Instalar:
pkg install nodejs -y
pkg install nodejs-lts -y
npm i adb-wifi -g

#Uso:
adb-wifi

Muestra

C:\> adb-wifi
[Developer options]->[Wireless debugging]->[Pair device with QR code]
###################################
# ##### ### # # ######## ## ##### #
# #   # #   ##  #### ## ### #   # #
# ##### #### ####### # #### ##### #
########### # # ##### #############
#  ######## #   ## ##  ########## #
##########  ############### ## ####
### ###### ## ######### #  # #### #
## ## ## ### #### ## # ## #  ######
### ########## ##### #   ######  ##
#####  ###  ##### # # # ## ## ## ##
# ## ### #  ## #######   ### ######
######## # ### ###### ##  ### ### #
######### ## #### ###  ## ### ## ##
# ##### ## ## # ######### ### #####
# #   # ## ############  ###  ## ##
# ##### # #########################
###################################

stdout: Successfully paired to 192.168.0.147:38629 [guid=adb-941AY0HXWG-r8Nucn]
Compatibilidad con mDNS

ADB

Android Debug Bridge (adb) es una herramienta de tipo CLI (linea de comandos) que permite comunicarse con un dispositivo con S.O android. ADB facilita una variedad de acciones en nuestro dispositivo, como instalar y depurar aplicaciones, y proporciona acceso a un shell Unix que puede usarse para ejecutar una variedad de comandos.

Prerequisitos
Windows o linux (preferiblemente linux para poder usar bash para ejecutar uno que otro script)
Android studio (software muy liviano) para descargar nuestro respectivo sdk (ver version del sistema operativo para saber que version descargar) y el adb.
Java (:S)
Habilitar el modo desarrollador en nuestro movil (dando 7 (varia segun la version de android)  veces tap en la opcion de informacion de tu telefono en la pantalla opciones). luego habilitar la depuracion.
Corremos el demonio, recomiendo hacerlo con sudo para evitar problemas.

Manos a la Obra
Si todo sale bien, continuemos.

$ sudo adb kill-server && sudo adb start-server

El ejemplo mas basico por el cual podremos empezar es input tap, el cual genera un tap en la pantalla de nuestro movil dadas unas coordenadas X y Y
$ adb shell input tap 160 225
 
El anterior comando en mi pantalla abre la aplicacion  ubicada en dicha coordenada. NO esta de mas conocer el tamano de la pantalla al igual que depurar las coordenadas cuando hacemos tap para saber (donde carajos hacemos tap) las coordenadas y asi usarlas posteriormente.

Para habilitar el debug de coordenadas:

Ahora cada vez que se haga tap sabremos la informacion de posicion (X,Y) numero de toques al tiempo, presion (estimacion), tamano (area del tap), velocidad en X y en Y [Mas informacion].

Comandos basicos:
Event codes:

Podemos enviar el evento de presionar un boton o un evento en especifico. Por ejemplo si quiero subir el volumen:

adb shell input keyevent 24
# ver lista completa de valores para mas informacion.

Tap X,Y:
adb shell input tap 500 1450
 

# Swipe X1 Y1 X2 Y2 [duracion(ms)]:
# Evento que simula  un barrido de nuestro tap desde una coordenada a otra.
$ adb shell input swipe 100 500 100 1450 100
 

# LongPress X Y:
# Podemos usar el mismo comando de swipe para generar este efecto.
adb shell input swipe 100 500 100 500 250
 

# Insertar o escribir texto en termux usando adb
adb shell input text "Elemental%sis%sAwesome%s" # Para poder insertar espacios se debe colocar el simbolo de %.

Usando los comandos anteriores podemos generar un script basico en bash para realizar algo mas interesante.
Script:
#!/bin/bash
adb shell svc power stayon true
echo -e "\e[96mStay on!"
adb shell input swipe 600 700 100 700 500
echo -e "\e[96mSwipe to menu #1!"
adb shell input swipe 600 700 100 700 500
echo -e "\e[96mSwipe to menu #2!"
adb shell input tap 400 195
echo -e "\e[96mTap over alliexpress app link!"
sleep 5
echo -e "\e[96mSleep 5secs!"
adb shell input tap 215 145
echo -e "\e[96mTap to app search box!"
adb shell input text "rubber%sDuck"
echo -e "\e[96mMost relevant search!"
adb shell input tap 160 225
echo -e "\e[96mTap on first search result!"
adb shell input tap 165 435
echo -e "\e[96mTap on product!"
adb shell svc power stayon false
echo -e "\e[96mStay on false!"
echo -e "\e[96mENJOY!"
 

Dentro de otras acciones mas interesantes estan:

# Realizar diferentes Intentos (uso de aplicaciones), por ejemplo, hacer o realizar una llamada usando adb:
adb shell am start -a android.intent.action.CALL -d tel:+12345678910
 

# Podemos usar los logs para detectar que actividad esta corriendo cuando usamos nuestro movil, asi usar los "intents" para realizar determinada accion. Por ejemplo :
adb logcat
 

El cual nos da en su salida (que es gigante, se recomienda usar grep para filtrar si estas en linux).

02-08 19:31:16.447   656 30359 I ActivityManager: START u0 {act=android.intent.action.MAIN cat=[android.intent.category.LAUNCHER] flg=0x10200000 cmp=com.xhy.plane/com.yijian.auvilink.activity.WelcomeActivity
 

# Salida que discrimina la aplicacion con la cual controlo un pequeño dron de manera remota. Entonces, para lanzar la aplicacion seria:
adb shell am start -n com.xhy.plane/com.yijian.auvilink.activity.WelcomeActivity
 

Volando el pajaro:
 Un ejemplo muy interesante (y que me habia prometido hace un par de meses) es volar un modesto drone por medio de su interfaz de android (por ahora) . Si bien, su comportamiento sera muy basico, es suficiente para divertirse un rato:

Entendemos que "volar" sera despegar del suelo y hacer un pequeno desplazamiento  horizontal y vertical para luego "aterrizar".

 

Script:
#!/bin/bash
adb shell svc power stayon true
echo -e "\e[96mStay on!"
adb shell input tap 970 630
echo -e "\e[96m#1 Tab on play option of app menu!"
adb shell input tap 980 80
echo -e "\e[96m#2 Power on controls!"
adb shell input tap 600 40
echo -e "\e[96m#2 Change Power mode to 60%!"
adb shell input swipe 250 600 250 320 500
echo -e "\e[96m#3 Motors to 95% of power!"
adb shell input swipe 250 320 250 580 8500
echo -e "\e[96m#3 shutdown!"
 

ADB Shell
HOME
COMMANDS

# ADB Debugging
adb devices
adb forward
adb kill-server

# Wireless
adb connect
adb usb

# Package Manager
adb install
adb uninstall
adb shell pm list packages
adb shell pm path
adb shell pm clear

# File Manager
adb pull
adb push
adb shell ls
adb shell cd
adb shell rm
adb shell mkdir
adb shell touch
adb shell pwd
adb shell cp
adb shell mv

# Network
adb shell netstat
adb shell ping
adb shell netcfg
adb shell ip

# Logcat
adb logcat
adb shell dumpsys
adb shell dumpstate

# Screenshot
adb shell screencap
adb shell screenrecord [4.4+]
System
adb root
adb sideload
adb shell ps
adb shell top
adb shell getprop
adb shell setprop
adb shell touch

the touch command is a standard command used in UNIX/Linux operating system which is used to create, change and modify timestamps of a file

adb shell touch /mnt/sdcard/Download/test.txt
(c)2020 ADB Shell


# calibrar la batería de Android, hazlo bajo tu propia responsabilidad
# Borrar las estadísticas de la batería
adb shell dumpsys battery reset
# Simular la carga completa
adb shell dumpsys battery set level 100
adb shell dumpsys battery set status 1
# Restaurar el estado normal de la batería
adb shell dumpsys battery reset
# Deshabilitar el estado de la batería simulada (si se ha usado alguna simulación)
adb shell dumpsys battery unplug

# Saber a qué red wifi internet estoy conectado usando adb
adb shell dumpsys wifi | grep 'mWifiInfo'


# Este método usa ssh y sirve para reanudar archivos. y si ya está completo no hace nada para no sobreescribir 
# haciendo la contraseña 
pkg install sshpass
sshpass -p '1984' rsync -avP -e "ssh -p 8022" "games.sh" u0_a376@192.168.20.35:/sdcard/Alarms/


# Súper comprimir brotli
brotli -Z -w 24 -f -k -o FL_Studio_Mobile_super.br FL_Studio_Mobile_3.4.8__2458.apk

# Súper comprimir usando zpaq siempre es más potente pero lento
pkg install zpaq
zpaq add archivo_comp.zpaq FL_Studio_Mobile_3.4.8__2458.apk -m5
# Comprimir carpeta 📂 
zpaq a archivo_comp.zpaq "./Busca-Palabras" -m5
# O
zpaq a archivo_comp.zpaq "./Busca-Palabras" -m5 -s1
# Para descomprimir 
zpaq extract archivo_comp.zpaq -to ./
zpaq x archivo_comp.zpaq -s1

cd /ruta/
# Súper comprimir usando 7z: la opción -bsp2 es para mostrar solo el porcentaje, lo puede quitar para hacerlo de forma normal.
7z a -t7z -m0=lzma2 -mx=9 -mfb=256 -md=64m -ms=on archivo_comprimido.7z FL_Studio_Mobile_3.4.8__2458.apk
7z a -t7z -m0=lzma2 -mx=9 -mfb=273 -md=512m -ms=on -mmt=on archivo_comprimido.7z FL_Studio_Mobile_3.4.8__2458.apk
# Solo muestre el porcentaje al comprimirlo usando el compresor 7z: 
7z a -t7z -m0=lzma2 -mx=9 -mfb=256 -md=64m -ms=on -bsp2 FL_Studio_Mobile_3.4.8__2458.7z FL_Studio_Mobile_3.4.8__2458.apk | tee ".log_file_7z" | grep -E '^[[:space:]]*[0-9]+%'
# Muestra el porcentaje luego hasta cuánto comprimió y borra el log .log_file_7z
7z a -t7z -m0=lzma2 -mx=9 -mfb=256 -md=512m -ms=on -bsp2 FL_Studio_Mobile_3.4.8__2458.7z FL_Studio_Mobile_3.4.8__2458.apk | tee ".log_file_7z" | grep -E '^[[:space:]]*[0-9]+%|size' && rm -rf ".log_file_7z"
# Comprimir carpeta 📂 
7z a -t7z -m0=lzma2 -mx=9 -mfb=256 -md=512m -ms=on -bsp2 "Busca-Palabras.7z" "Busca-Palabras" | tee ".log_file_7z" | grep -E '^[[:space:]]*[0-9]+%|size' && rm -rf ".log_file_7z"
# o
7z a -t7z -m0=lzma2 -mx=9 -mfb=256 -md=512m -ms=on -bsp2 "Busca-Palabras.7z" "./Busca-Palabras" | tee ".log_file_7z" | grep -E '^[[:space:]]*[0-9]+%|size' && rm -rf ".log_file_7z"
# Comando para descomprimir desde la misma ruta
7z x -bsp2 "Busca-Palabras.7z" | tee ".log_file_7z" | grep -E '^[[:space:]]*[0-9]+%|size' && rm -rf ".log_file_7z"
# Para descomprimir a una ruta destino 
7z x "${ruta}" -y -bsp2 -o"${destino}" | tee ".log_file_7z" | tr '\r' '\n' | grep -E '^[[:space:]]*[0-9]+%' && rm -rf ".log_file_7z"


# Ver la versión de una app o paquete: 
# adb shell dumpsys package net.dinglisch.android.taskerm | grep versionName | xargs | awk -F= '{print $2}' # Más rápida
# adb shell pm dump net.dinglisch.android.taskerm | grep versionName

# Tomar el peso: 
# stat --format=%s '/storage/emulated/0/Download/Apps/FL_Studio_Mobile/FL_Studio_Mobile_OBB_3.4.8.zip'

# obtener el paquete de una app usando aapt
aapt dump badging "ruta/archivo.apk" 2>/dev/null | awk -F"'" '/package: name=/{print $2}'

# obtener el versión de una app usando aapt
aapt dump badging "${archivo_path}" | sed -n "s/.*versionName='\([^']*\)'.*/\1/p"

info_apk() {
    # Limpiar residuos del tmpdir=$(mktemp -d)
    find /data/data/com.termux/files/usr/tmp -maxdepth 1 -type d -name 'tmp.*' -exec rm -rf {} +

    local apk="$1"  # Puede ser un APK, XAPK o APKS
    local tmpdir    # Directorio temporal
    trap 'if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then echo -e "\n🧹 ${YELLOW}Limpiando temporales...${NC}"; rm -rf "$tmpdir"; fi' EXIT INT TERM
    

    # Verifica si existe el archivo
    [[ ! -f "$apk" ]] && echo "❌ No se encontró el archivo en: $apk" && return 1
    # Capturar solo la extensión del archivo (sin punto)
    EXTENSION="${apk##*.}"
    # Si es un archivo XAPK o APKS, extraer el APK base
    if [[ "$EXTENSION" == 'xapk' || "$EXTENSION" == 'apks' ]]; then
        # echo "📦 Descomprimiendo XAPK/APKS para extraer APK..."
        tmpdir=$(mktemp -d)  # Crear directorio temporal
        unzip -q "$apk" -d "$tmpdir"

        # Buscar el primer APK en el archivo XAPK/APKS
        apk=$(find "$tmpdir" -name "*.apk" | head -n 1)
        if [[ -z "$apk" || ! -f "$apk" ]]; then
            echo "❌ No se encontró ningún APK dentro del XAPK/APKS."
            rm -rf "$tmpdir"  # Eliminar directorio temporal en caso de error
            return 1
        fi
    fi

    # Capturar salida de aapt (una sola vez) y quitar CR por si acaso
    local badging
    badging="$(aapt dump badging "$apk" 2>/dev/null | tr -d '\r')"

    # Extraer con awk -F"'" (campo seguro)
    local paquete version build
    paquete=$(printf '%s' "$badging" | awk -F"'" '/package: name=/{print $2}' || true)
    version=$(printf '%s' "$badging" | awk -F"'" '/versionName=/{print $6}' || true)
    build=$(printf '%s' "$badging" | awk -F"'" '/versionCode=/{print $4}' || true)

    # Mostrar resultados (N/D si vacío) con saltos de línea
    echo "📦 Paquete: ${paquete:-N/D}"
    echo "🏷️  Versión: ${version:-N/D}"
    echo "🧩 Build: ${build:-N/D}"

    # Eliminar el directorio temporal después de su uso
    if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then
        rm -rf "$tmpdir"
        echo "🧹 La extracción del $EXTENSION temporal fue eliminado."
    fi
}
# Ejecutar función con el archivo deseado
apk_apks_xapk='/storage/emulated/0/backups/apps/Flet_apk/Flet_2.0.1.xapk'
# apk_apks_xapk='/storage/emulated/0/Download/Apps/FL_Studio_Mobile/FL_Studio_Mobile_3.4.8__2458.apk'
# Capturar la salida completa y mostrarla
salida=$(info_apk "$apk_apks_xapk")
# echo "$salida"  # Imprime toda la salida con saltos de línea
# Verificar la salida línea por línea
echo "$salida" | sed -n '1p'  # Línea 1: paquete 
echo "$salida" | sed -n '2p'  # Línea 2: Versión
echo "$salida" | sed -n '3p'  # Línea 3: Build
echo "$salida" | sed -n '4p'  # Línea 4: limpieza
