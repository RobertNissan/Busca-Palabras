#!/bin/bash
#────────────────────────────────────────────#
#   INSTALADOR UNIVERSAL ADB (.apk/.apks/.xapk)
#────────────────────────────────────────────#

set -e

# Colores
GREEN='\033[1;32m'
RED='\033[1;31m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
NC='\033[0m'

# Limpiar residuos del tmpdir=$(mktemp -d)
find /data/data/com.termux/files/usr/tmp -maxdepth 1 -type d -name 'tmp.*' -exec rm -rf {} +

#───────────────────────────────#
#   FUNCIONES
#───────────────────────────────#
uso() {
    echo -e "${YELLOW}Uso:${NC} $0 <archivo.apk|archivo.apks|archivo.xapk>"
    exit 1
}

verif_adb() {
    if ! command -v adb >/dev/null 2>&1; then
        echo -e "${RED}Error:${NC} adb no está instalado o no está en PATH."
        echo -e "${YELLOW}Instálalo con:${NC} pkg install android-tools${NC}"
        exit 1
    fi
}

verif_aapt() {
    if ! command -v aapt >/dev/null 2>&1; then
        echo -e "${RED}Error:${NC} aapt no está instalado."
        echo -e "${YELLOW}Instálalo con:${NC} pkg install aapt${NC}"
        exit 1
    fi
}


# Verificar si un app está instalado usando cmd bash
verificar_app_instalada_cmd() {
    local paquete="$1"
    local paquete_instalado

    # Buscar el paquete directamente
    paquete_instalado=$(cmd package list packages "$paquete" | sed 's/^package://')

    # Comparar coincidencia exacta
    if echo "$paquete_instalado" | grep -Fxq "$paquete"; then
        echo "true"
        return 0
    else
        echo "false"
        return 0
    fi
}

# Verificar si un dispositivo está conectado a adb en mi Android prioridad emulator-5554
# =================== Verificar ADB conectado (prioridad emulator-5554) ===================


# =================== Internet check ===================
PING_TARGET="1.1.1.1"
PING_TIMEOUT=1

verificar_internet() {
    if ping -c 1 -W "$PING_TIMEOUT" "$PING_TARGET" >/dev/null 2>&1; then
        echo "true"
    else
        echo "false"
    fi
}

# =================== Obtener interfaces e IPs ===================
obtener_interfaces() {
    declare -A interfaces
    local actual linea ip

    while IFS= read -r linea; do
        # Detecta inicio de interfaz
        if [[ $linea != " "* && $linea == *:* ]]; then
            actual="${linea%%:*}"
        # Detecta IPv4 en la interfaz actual
        elif [[ $linea == *"inet "* && -n $actual ]]; then
            ip=$(echo "$linea" | grep -oE 'inet (addr:)?([0-9]{1,3}\.){3}[0-9]{1,3}' | awk '{print $2}' | sed 's/addr://')
            interfaces["$actual"]="$ip"
        fi
    done < <(ifconfig 2>/dev/null)

    # Imprimir en formato iface:ip
    for iface in "${!interfaces[@]}"; do
        echo "$iface:${interfaces[$iface]}"
    done
}

# =================== Obtener IP principal ===================
get_primary_local_ip() {
    declare -A ifaces
    while IFS=: read -r iface ip; do
        if [[ -n $iface && -n $ip ]]; then
            ifaces["$iface"]="$ip"
        fi
    done < <(obtener_interfaces)

    # Prioridad: wlan0 → tun0 → seth_lte0 → cualquier válida → fallback
    if [[ -n ${ifaces[wlan0]} && ${ifaces[wlan0]} != "127.0.0.1" ]]; then
        echo "${ifaces[wlan0]}"
        return
    fi

    if [[ -n ${ifaces[tun0]} && ${ifaces[tun0]} != "127.0.0.1" ]]; then
        echo "${ifaces[tun0]}"
        return
    fi

    if [[ -n ${ifaces[seth_lte0]} && ${ifaces[seth_lte0]} != "127.0.0.1" ]]; then
        echo "${ifaces[seth_lte0]}"
        return
    fi

    # Cualquier otra IP válida (excepto loopback)
    for ip in "${ifaces[@]}"; do
        if [[ $ip != "127.0.0.1" ]]; then
            echo "$ip"
            return
        fi
    done

    # Fallback: tratar de obtener por socket (ruta hacia 8.8.8.8)
    ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7; exit}' || echo "127.0.0.1"
}

# =================== Clasificar conexión ===================
clasificar_conexion() {
    local ifaces verif_internet tipo="Modo avión" detalles=() wlan_ip=""

    mapfile -t ifaces < <(obtener_interfaces)
    verif_internet="$1"

    # Convertir a diccionario
    declare -A iface_map
    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        iface_map["$iface"]="$ip"
    done

    # VPN
    for k in "${!iface_map[@]}"; do
        [[ $k == tun* || $k == tap* ]] && detalles+=("VPN activa")
    done

    wlan_ip="${iface_map[wlan0]}"

    # Detección del tipo de red
    if [[ -n $wlan_ip && $wlan_ip == 10.* ]] || grep -q "172\." <<<"${iface_map[@]}"; then
        tipo="Hotspot Android"
    elif grep -q "172\.20\.10\." <<<"${iface_map[@]}"; then
        tipo="Hotspot iPhone"
    elif [[ -n $wlan_ip && $wlan_ip == 192.168.* ]] && ! grep -q "10\." <<<"${iface_map[@]}"; then
        tipo="Router Wi-Fi"
    elif [[ -n $wlan_ip ]]; then
        [[ $wlan_ip == 10.* ]] && tipo="Hotspot Android" || tipo="Router Wi-Fi"
    elif printf '%s\n' "${!iface_map[@]}" | grep -Eq "^(seth|rmnet|wwan|usb)"; then
        tipo="Datos móviles"
    fi

    detalles+=($( [[ $verif_internet == "true" ]] && echo -e "${GREEN}con Internet${NC}" || echo -e "${RED}sin Internet${NC}" ))
    echo "$tipo ${NC}(${detalles[*]})"
}

# =================== Mostrar estado ===================
build_status_info() {
    local verif_internet="$1"
    local estado tipo_icon ifaces iface ip

    mapfile -t ifaces < <(obtener_interfaces)
    estado=$(clasificar_conexion "$verif_internet")
    
    # Elegir el ícono según el tipo de conexión.
    case "$estado" in
        *"Router Wi-Fi"*) tipo_icon="📡";;     # Wi-Fi / router
        *"Datos móviles"*) tipo_icon="📶";; # teléfono / datos móviles
        *"Hotspot"*) tipo_icon="🔥";;            # hotspot / tethering
        *"Modo avión"*) tipo_icon="✈️";;      # modo avión
        *) tipo_icon="🌐";;                              # genérico / desconocido
    esac

    echo -e "${tipo_icon} ${MAGENTA}$estado"

    for line in "${ifaces[@]}"; do
        iface="${line%%:*}"
        ip="${line#*:}"
        echo -e "💻 ${CYAN}$iface${NC}: $ip"
    done
}



export_var() {
    # Pasar las variables de bash() {disponible_adb, adb_conectado, adb_conectado_ip_device} al script de Python
    export ip
    export ip_device
    export adb_estado
    export disponible_adb
}
# Devuelve una sola línea: "<adb_estado>|<device_id>"
# adb_estado: "true" o "false"
# device_id: "" o "emulator-5554" o "192.168.x.x:5555" etc.
verif_dispositivo() {
    local ip=$(get_primary_local_ip)
    local adb_output connected_devices device_list candidate

    adb_output=$(adb devices -l 2>/dev/null) || adb_output=""
    # Extrae solo los IDs de dispositivos con estado 'device'
    # Los pondremos en un array
    mapfile -t device_list < <(echo "$adb_output" | awk '$2 == "device" {print $1}')

    # Si no hay dispositivos
    if [[ ${#device_list[@]} -eq 0 ]]; then
        adb_estado="false"
        dispositivo=""
        disponible_adb="true"
        # No imprimimos nada excepto la linea formateada
        printf "%s|%s\n" "$adb_estado" "$dispositivo"
        return 1
    fi

    # Prioridad 1: emulator*
    for candidate in "${device_list[@]}"; do
        if [[ $candidate == emulator* ]]; then
            dispositivo="$candidate"
            adb_estado="true"
            disponible_adb="false"
            printf "%s|%s\n" "$adb_estado" "$dispositivo"
            export_var
            return 0
        fi
    done

    # Prioridad 2: buscar dispositivo con IP:5555 igual a ip local (si existe)
    for candidate in "${device_list[@]}"; do
        if [[ -n $ip && $candidate == "${ip}:5555" ]]; then
            dispositivo="$candidate"
            adb_estado="true"
            disponible_adb="false"
            printf "%s|%s\n" "$adb_estado" "$dispositivo"
            export_var
            return 0
        fi
    done

    # Si hay exactamente 1 device -> elegirla
    if [[ ${#device_list[@]} -eq 1 ]]; then
        dispositivo="${device_list[0]}"
        adb_estado="true"
        disponible_adb="false"
        printf "%s|%s\n" "$adb_estado" "$dispositivo"
        export_var
        return 0
    fi

    # Si llegamos acá hay >1 device y no se cumplió prioridad -> no elegimos automáticamente
    adb_estado="false"
    dispositivo=""
    disponible_adb="true"
    # imprimimos la lista corta para depuración (pero como una única línea separada por ',')
    local listcsv
    listcsv=$(IFS=, ; echo "${device_list[*]}")
    printf "%s|%s|%s\n" "$adb_estado" "$dispositivo" "$listcsv"
    return 2
}
#uso de la función verif_dispositivo()
IFS='|' read -r adb_status dispositivo rest <<< "$(verif_dispositivo)"
if [[ "$adb_status" != "true" ]]; then
    if [[ -n $rest ]]; then
        echo -e "${YELLOW}Hay varios dispositivos conectados:${NC} $rest"
        echo "Conéctate solo al que deseas o desconéctalos, o especifica -s <device> manualmente."
    else
        echo "🔴 ADB desconectado"
    fi
    exit 1
fi

echo -e "🔌 ${GREEN}ADB conectado${NC}: $dispositivo"
# ahora puedes usar adb -s "$dispositivo" sin riesgo



# ask_yes_no "<prompt>" [varname]
# Retorna: 0 = sí, 1 = no
# Si pasas varname, guarda "si" o "no" en esa variable global.
ask_yes_no() {
  local prompt="${1:-¿Desea continuar? (s/n): }"
  local outvar="${2:-}"
  local resp val

  # Captura señales dentro de la función
  trap 'echo -e "\n${RED}❌ Interrupción detectada. Cancelando...${NC}"; exit 130' INT TSTP

  while true; do
    # Leer respuesta del usuario
    read -r -p "$prompt" resp || { echo; return 1; }

    # Quitar CR y espacios
    resp="${resp%%$'\r'}"
    resp="${resp#"${resp%%[![:space:]]*}"}"
    resp="${resp%"${resp##*[![:space:]]}"}"

    # Convertir a minúsculas
    resp="$(tr '[:upper:]' '[:lower:]' <<<"$resp")"

    case "$resp" in
      s|si|y|yes)
        val="si"
        ;;
      n|no)
        val="no"
        ;;
      *)
        echo "Respuesta inválida. Escriba 's' o 'si' para Sí, 'n' o 'no' para No."
        continue
        ;;
    esac

    # Si se pidió variable de salida
    if [[ -n "$outvar" ]]; then
      if ((BASH_VERSINFO[0] >= 4)); then
        declare -g "$outvar=$val"
      elif printf -v "$outvar" "%s" "$val" 2>/dev/null; then
        : # funciona
      else
        eval "$outvar=\"\$val\""
      fi
    fi

    [[ $val == "si" ]] && trap - INT TSTP && return 0 || trap - INT TSTP && return 1
  done
}
# uso
: '
if ask_yes_no "¿Desea actualizar ahora? (s/n): " resp; then
  echo "Iniciando actualización..."
else
  echo "Actualización cancelada."
  read -n 1 -r -p "Presione cualquier tecla para continuar..." _
fi

echo "valor en resp = '$resp'"

: '








firmar_apk() {
    local apk_in="$1"
    local apk_out="$2"

    if ! command -v apksigner >/dev/null 2>&1; then
        echo -e "${RED}Error:${NC} apksigner no está instalado."
        echo -e "${YELLOW}Instálalo con:${NC} pkg install apksigner"
        exit 1
    fi

    echo -e "${CYAN}🔏 Firmando APK...${NC}"

    if [ ! -f ~/.android/debug.keystore ]; then
        echo -e "${YELLOW}Creando debug.keystore...${NC}"
        mkdir -p ~/.android
        keytool -genkeypair -v \
            -keystore ~/.android/debug.keystore \
            -keyalg RSA -keysize 2048 -validity 10000 \
            -alias androiddebugkey \
            -storepass android -keypass android \
            -dname "CN=Android Debug,O=Android,C=US" >/dev/null
    fi

    apksigner sign \
        --ks ~/.android/debug.keystore \
        --ks-pass pass:android \
        --key-pass pass:android \
        --out "$apk_out" \
        "$apk_in"
}

desactivar_verificador() {
    echo -e "${YELLOW}⚙️  Desactivando verificador ADB...${NC}"
    adb -s "${dispositivo}" shell settings put global verifier_verify_adb_installs 0 >/dev/null 2>&1 || true
    adb -s "${dispositivo}" shell settings put global package_verifier_enable 0 >/dev/null 2>&1 || true
}

detectar_arquitectura() {
    local arch
    arch=$(adb -s "${dispositivo}" shell getprop ro.product.cpu.abi | tr -d '\r')

    case "$arch" in
        *arm64*) echo "arm64_v8a" ;;
        *armeabi-v7a*) echo "armeabi_v7a" ;;
        *x86_64*) echo "x86_64" ;;
        *x86*) echo "x86" ;;
        *) echo "arm64_v8a" ;; # valor por defecto
    esac
}

obtener_paquete() {
    local apk_file="$1"
    verif_aapt
    aapt dump badging "$apk_file" 2>/dev/null | awk -F"'" '/package: name=/{print $2}'
}

desinstalar_paquete() {
    local pkg="$1"
    if [[ -n "$pkg" ]]; then
        echo -e "${YELLOW}🔁 Eliminando versión anterior (${pkg}) si existe...${NC}"
        adb -s "${dispositivo}" uninstall "$pkg" >/dev/null 2>&1 || true
    fi
}

obtener_paquete_version_build() {
    # Limpiar residuos del tmpdir=$(mktemp -d)
    # find /data/data/com.termux/files/usr/tmp -maxdepth 1 -type d -name 'tmp.*' -exec rm -rf {} +
    # Nota: en este caso limpiamos solo en la instalación para no borrar los archivos prematuramente desde está función.
    
    local apk="$1"  # Puede ser un APK, XAPK o APKS
    local tmpdir    # Directorio temporal
    # trap 'if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then echo -e "\n🧹 ${YELLOW}Limpiando temporales...${NC}"; rm -rf "$tmpdir"; fi' EXIT INT TERM
    

    # Verifica si existe el archivo
    [[ ! -f "$apk" ]] && echo "❌ No se encontró el archivo en: $apk" && return 1
    # Capturar solo la extensión del archivo (sin punto)
    EXTENSION="${apk##*.}"
    # Si es un archivo XAPK o APKS, extraer el APK base
    if [[ "$EXTENSION" == 'xapk' || "$EXTENSION" == 'apks' ]]; then
        # echo "📦 Descomprimiendo XAPK/APKS para extraer APK..."
        tmpdir=$(mktemp -d)  # Crear directorio temporal
        unzip -q "$apk" -d "$tmpdir"

        # Buscar el primer APK en el archivo XAPK/APKS
        apk=$(find "$tmpdir" -name "*.apk" | head -n 1)
        if [[ -z "$apk" || ! -f "$apk" ]]; then
            echo "❌ No se encontró ningún APK dentro del XAPK/APKS."
            rm -rf "$tmpdir"  # Eliminar directorio temporal en caso de error
            return 1
        fi
    fi

    # Capturar salida de aapt (una sola vez) y quitar CR por si acaso
    local badging
    badging="$(aapt dump badging "$apk" 2>/dev/null | tr -d '\r')"

    # Extraer con awk -F"'" (campo seguro)
    local paquete version build
    paquete=$(printf '%s' "$badging" | awk -F"'" '/package: name=/{print $2}' || true)
    version=$(printf '%s' "$badging" | awk -F"'" '/versionName=/{print $6}' || true)
    build=$(printf '%s' "$badging" | awk -F"'" '/versionCode=/{print $4}' || true)

    # Mostrar resultados (N/D si vacío) con saltos de línea
    # echo "📦 Paquete: ${paquete:-N/D}"
    # echo "🏷️  Versión: ${version:-N/D}"
    # echo "🧩 Build: ${build:-N/D}"
    echo "${paquete:-N/D}"
    echo "${version:-N/D}"
    echo "${build:-N/D}"

    # Eliminar el directorio temporal después de su uso
    # if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then
        # rm -rf "$tmpdir"
        # echo "🧹 La extracción del $EXTENSION temporal fue eliminado."
    # fi
    # Nota: en este caso limpiamos solo en la instalación para no borrar los archivos prematuramente desde está función.
}
: ' 
# Modo de uso
# Ejecutar función con el archivo deseado
apk_apks_xapk='/storage/emulated/0/backups/apps/Flet_apk/Flet_2.0.1.xapk'
# apk_apks_xapk='/storage/emulated/0/Download/Apps/FL_Studio_Mobile/FL_Studio_Mobile_3.4.8__2458.apk'
# Capturar la salida completa y mostrarla
salida=$(info_apk_apks_xapk "$apk_apks_xapk")
# echo "$salida"  # Imprime toda la salida con saltos de línea
# Verificar la salida línea por línea
echo "$salida" | sed -n '1p'  # Línea 1: paquete 
echo "$salida" | sed -n '2p'  # Línea 2: Versión
echo "$salida" | sed -n '3p'  # Línea 3: Build
echo "$salida" | sed -n '4p'  # Línea 4: limpieza

# puedes ser más directo Obtener el 📦 paquete:
salida=$(info_apk_apks_xapk "$apk_apks_xapk" | sed -n '1p') # Línea 1: paquete 
: '


# ---------------------------
# Función común de manejo de errores
# ---------------------------
handle_install_error() {
    local output="$1"
    echo "output: $output"

    # --- Detección del paquete base ---
    local base_pkg="${pkg:-}"
    local base_key=""
    local family=""

    if [[ -n "$base_pkg" ]]; then
        base_key=$(echo "$base_pkg" | awk -F'.' '{print $(NF-1)}')
    fi

    # --- Familias conocidas ---
    if [[ "$base_pkg" =~ ^ru\.iiec\.pydroid3\. ]]; then
        family="pydroid"
    elif [[ "$base_pkg" =~ ^com\.termux ]]; then
        family="termux"
    elif [[ "$base_pkg" =~ ^net\.dinglisch\.android\.taskerm ]]; then
        family="tasker"
    elif [[ "$base_pkg" =~ ^com\.joaomgcd\. ]]; then
        family="tasker"  # Plugins JoaoApps
    elif [[ "$base_pkg" =~ ^com\.intangibleobject\.securesettings\.plugin ]]; then
        family="tasker"
    else
        family="generic"
    fi

    # --- Selección de búsqueda según familia ---
    local plugin_pattern=""
    case "$family" in
        pydroid)
            plugin_pattern='^ru\.iiec\.pydroid3(\.|$)|^ru\.iiec\.pydroidpermissionsplugin$'
            ;;
        termux)
            plugin_pattern="termux"
            ;;
        tasker)
            plugin_pattern="tasker\|autonotification\|autoinput\|autocontacts\|autotools\|autovoice\|securesettings"
            ;;
        *)
            plugin_pattern="$base_key"
            ;;
    esac

    # --- Manejo de errores ---
    if echo "$output" | grep -q "INSTALL_FAILED_UPDATE_INCOMPATIBLE"; then
        echo -e "${RED}❌ Firmas distintas detectadas.${NC}"

        mapfile -t plugins < <(adb -s "${dispositivo}" shell pm list packages 2>/dev/null \
            | sed 's/package://g' | tr -d '\r' | grep -Ei "$plugin_pattern" | grep -vE "^${base_pkg}$" || true)

        if [ ${#plugins[@]} -gt 0 ]; then
            echo -e "${YELLOW}Por favor desinstala la versión actual y sus plugins antes de continuar.${NC}"
            echo -e "${YELLOW}Se detectaron posibles paquetes relacionados:${NC}"
            for p in "${plugins[@]}"; do
                echo "  - $p"
            done
        else
            echo -e "${YELLOW}Por favor desinstala la versión actual antes de continuar.${NC}"
        fi

    elif echo "$output" | grep -q "INSTALL_FAILED_VERSION_DOWNGRADE"; then
        echo -e "${RED}❌ La instalación falló, no deja desactualizar.${NC}"
        echo -e "${YELLOW}🔎 Desinstala la versión actual antes de instalar una más antigua.${NC}"

        mapfile -t plugins < <(adb -s "${dispositivo}" shell pm list packages 2>/dev/null \
            | sed 's/package://g' | tr -d '\r' | grep -Ei "$plugin_pattern" | grep -vE "^${base_pkg}$" || true)

        if [ ${#plugins[@]} -gt 0 ]; then
            echo
            echo -e "${YELLOW}Se detectaron complementos relacionados:${NC}"
            for p in "${plugins[@]}"; do
                echo "  - $p"
            done
        fi
        # echo 'false'
        process_instalacion='false'
        limpiar_tmpdir
        return 0

    elif echo "$output" | grep -q "INSTALL_FAILED_SHARED_USER_INCOMPATIBLE"; then
        echo -e "${RED}❌ Error: conflicto con el usuario compartido.${NC}"
        echo -e "${YELLOW}Esto ocurre cuando aún existen plugins vinculados a la app anterior.${NC}"

        mapfile -t plugins < <(adb -s "${dispositivo}" shell pm list packages 2>/dev/null \
            | sed 's/package://g' | tr -d '\r' | grep -Ei "$plugin_pattern" | grep -vE "^${base_pkg}$" || true)

        if [ ${#plugins[@]} -eq 0 ]; then
            echo -e "${YELLOW}No se detectaron plugins adicionales.${NC}"
        else
            echo
            echo -e "${YELLOW}Se detectaron los siguientes paquetes vinculados:${NC}"
            for p in "${plugins[@]}"; do
                echo "  - $p"
            done
            echo
            if ask_yes_no "¿Deseas desinstalar TODOS estos paquetes antes de continuar? (s/n): " resp; then
                for p in "${plugins[@]}"; do
                    echo "Desinstalando $p ..."
                    adb -s "${dispositivo}" uninstall "$p" >/dev/null
                done
                echo -e "${GREEN}✔ Plugins eliminados.${NC}"
                echo -e "${CYAN}🔁 Reintentando instalación...${NC}"

                install_out=$(adb -s "${dispositivo}" install -r "$archivo" 2>&1)
                if echo "$install_out" | grep -q "Success"; then
                    ruta=$(adb -s "${dispositivo}" shell pm path "$base_pkg" 2>/dev/null)
                    echo -e "${GREEN}✔ APK instalado correctamente${NC}"
                    echo -e "Ruta de instalación:\n${CYAN}${ruta}${NC}"
                    # echo 'true'
                    process_instalacion='true'
                    limpiar_tmpdir
                    # obtiene el número de UID de la app ru.iiec.pydroid3 en el dispositivo conectado y lo guarda en la variable uid.
                    # Esto se hace para pasar el UID al ejecutar: adb -s "${dispositivo}" shell cmd appops set --uid "${uid}" MANAGE_EXTERNAL_STORAGE allow
                    # Se debe hacer afuera del EOF, lo pondré en la función obb_zip() aquí está para cuando vaya otrogar el permiso obtenga el UID
                    uid=$(adb -s "${dispositivo}" shell dumpsys package "${pack_permisos}" | grep -m1 "userId=" | sed 's/.*userId=//')
                    return 0
                else
                    echo -e "${RED}❌ Error al reinstalar:${NC}\n$install_out"
                    # echo 'false'
                    limpiar_tmpdir
                    process_instalacion='false'
                    return
                fi
            else
                echo -e "${YELLOW}Instalación cancelada. Desinstala los paquetes manualmente para continuar.${NC}"
                # echo 'false'
                limpiar_tmpdir
                process_instalacion='false'
                return
            fi
        fi
    else
        echo -e "${RED}❌ Error al instalar:${NC}\n$output"
        # echo 'false'
        limpiar_tmpdir
        process_instalacion='false'
        return
    fi
}
limpiar_tmpdir() {
    # Limpiar residuos del tmpdir=$(mktemp -d)
    find /data/data/com.termux/files/usr/tmp -maxdepth 1 -type d -name 'tmp.*' -exec rm -rf {} +
}
en_ruta() {
    # Confirmación final
    if [[ -n "$pkg" ]]; then
        echo -e "${GREEN}Ruta de instalación:${NC}"
        adb -s "${dispositivo}" shell pm path "$pkg"
    fi
}
install_apk_apks_xapk_adb() {
    
    limpiar_tmpdir
    
    #───────────────────────────────#
    #   LÓGICA PRINCIPAL
    #───────────────────────────────#
    archivo="${1}"
    adb_conectado="${2}"
    [[ -z "$archivo" ]] && uso
    
    # verif_adb
    desactivar_verificador

    ext="${archivo##*.}"
    tmpdir=""
    # trap 'if [[ -n "$tmpdir" && -d "$tmpdir" ]]; then echo -e "\n🧹 ${YELLOW}Limpiando temporales...${NC}"; rm -rf "$tmpdir"; fi' EXIT INT TERM
    
    # ---------------------------
    # Instalación según extensión
    # ---------------------------
    arch=$(detectar_arquitectura)
    echo -e "${YELLOW}🧠 Arquitectura detectada:${NC} ${arch}"
    case "$ext" in
        apk)
            
            pkg=$(obtener_paquete_version_build "$archivo" | sed -n '1p')
    
            if [[ $(verificar_app_instalada_cmd "${pkg}") == 'true' ]]; then
                if ask_yes_no "⚠️  ¿Desea desinstalar la versión actual? (s/n): " resp; then
                    echo "Iniciando desinstalación..."
                    desinstalar_paquete "$pkg"
                fi
            fi
            
            echo -e "${CYAN}📦 Instalando APK:${NC} $archivo"
            if ! output=$(adb -s "${dispositivo}" install -r "$archivo" 2>&1); then
                handle_install_error "$output"
                return 0
            fi
            echo -e "${GREEN}✔ APK instalado correctamente${NC}"
            # echo 'true'
            limpiar_tmpdir
            process_instalacion='true'
            # obtiene el número de UID de la app ru.iiec.pydroid3 en el dispositivo conectado y lo guarda en la variable uid.
            # Esto se hace para pasar el UID al ejecutar: adb -s "${dispositivo}" shell cmd appops set --uid "${uid}" MANAGE_EXTERNAL_STORAGE allow
            # Se debe hacer afuera del EOF, lo pondré en la función obb_zip() aquí está para cuando vaya otrogar el permiso obtenga el UID
            uid=$(adb -s "${dispositivo}" shell dumpsys package "${pack_permisos}" | grep -m1 "userId=" | sed 's/.*userId=//')
            ;;
    
        apks)
            
            tmpdir=$(mktemp -d)
            unzip -q "$archivo" -d "$tmpdir"
    
            base_apk=$(find "$tmpdir" -name "base.apk" | head -n 1)
            pkg=$(obtener_paquete_version_build "$base_apk" | sed -n '1p')
    
            if [[ $(verificar_app_instalada_cmd "${pkg}") == 'true' ]]; then
                if ask_yes_no "⚠️  ¿Desea desinstalar la versión actual? (s/n): " resp; then
                    echo "Iniciando desinstalación..."
                    desinstalar_paquete "$pkg"
                fi
            fi
    
            split_arch=$(find "$tmpdir" -name "split_config.${arch}.apk" | head -n 1)
            
            echo -e "${CYAN}📦 Instalando APKS (bundle):${NC} $archivo"
            if [[ -f "$base_apk" && -f "$split_arch" ]]; then
                output=$(adb -s "${dispositivo}" install-multiple -r "$base_apk" "$split_arch" 2>&1) || {
                    handle_install_error "$output"
                    return 0
                }
            else
                output=$(adb -s "${dispositivo}" install-multiple -r "$tmpdir"/*.apk 2>&1) || {
                    handle_install_error "$output"
                    return 0
                }
            fi
    
            echo -e "${GREEN}✔ APKS instalado correctamente${NC}"
            ;;
    
        xapk)
            
            tmpdir=$(mktemp -d)
            unzip -q "$archivo" -d "$tmpdir"
    
            apkfiles=($(find "$tmpdir" -name "*.apk"))
            if [ ${#apkfiles[@]} -eq 0 ]; then
                echo -e "${RED}❌ No se encontró ningún APK dentro del XAPK.${NC}"
                limpiar_tmpdir
                process_instalacion='false'
                # echo 'false'
                return 0
            fi
    
            base_apk="${apkfiles[0]}"
            pkg=$(obtener_paquete_version_build "$base_apk" | sed -n '1p')
    
            if [[ $(verificar_app_instalada_cmd "${pkg}") == 'true' ]]; then
                if ask_yes_no "⚠️  ¿Desea desinstalar la versión actual? (s/n): " resp; then
                    echo "Iniciando desinstalación..."
                    desinstalar_paquete "$pkg"
                fi
            fi
    
            split_arch=$(find "$tmpdir" -name "split_config.${arch}.apk" | head -n 1)
            
            echo -e "${CYAN}📦 Instalando XAPK:${NC} $archivo"
            if [[ -f "$base_apk" && -f "$split_arch" ]]; then
                output=$(adb -s "${dispositivo}" install-multiple -r "$base_apk" "$split_arch" 2>&1) || {
                    handle_install_error "$output"
                    return 0
                }
            else
                output=$(adb -s "${dispositivo}" install-multiple -r "${apkfiles[@]}" 2>&1) || {
                    handle_install_error "$output"
                    return 0
                }
            fi
    
            if [[ -d "$tmpdir/Android/obb" ]]; then
                echo -e "${YELLOW}📂 Copiando archivos OBB...${NC}"
                adb -s "${dispositivo}" push "$tmpdir/Android/obb" /sdcard/Android/ >/dev/null
            fi
    
            echo -e "${GREEN}✔ XAPK instalado correctamente${NC}"
            # echo 'true'
            limpiar_tmpdir
            process_instalacion='true'
            # obtiene el número de UID de la app ru.iiec.pydroid3 en el dispositivo conectado y lo guarda en la variable uid.
            # Esto se hace para pasar el UID al ejecutar: adb -s "${dispositivo}" shell cmd appops set --uid "${uid}" MANAGE_EXTERNAL_STORAGE allow
            # Se debe hacer afuera del EOF, lo pondré en la función obb_zip() aquí está para cuando vaya otrogar el permiso obtenga el UID
            uid=$(adb -s "${dispositivo}" shell dumpsys package "${pack_permisos}" | grep -m1 "userId=" | sed 's/.*userId=//')
            return 0
            ;;
    esac
}
install_apk_apks_xapk_adb "${1}"
# install=$(install_apk_apks_xapk_adb "${1}" | grep -iE "instal|pydroid|\${YELLOW}Se detectaron|true|false")
echo "$install"

: '
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid 3 v8.01_arm64 (Premium).apk"
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid Permissions Plugin v2.32 sign.apk"
bash install_xapk_apks4.sh "/sdcard/backups/apps/pydroid/pydroid_arm64_v8.1/Pydroid repository plugin v4.00 sign.apk"
pkg="ru.iiec.pydroid3"
# Permiso especial: Permitir administrar todo los archivos
# adb -s "${dispositivo}" shell am start -a android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION -d package:ru.iiec.pydroid3
uid=$(adb shell dumpsys package "$pkg" | grep -m1 "userId=" | sed 's/.*userId=//')
adb shell cmd appops set --uid "$uid" MANAGE_EXTERNAL_STORAGE allow
# PERMISOS PARA PYDROID3 (ru.iiec.pydroid3)
adb -s "${dispositivo}" shell pm grant ru.iiec.pydroid3 android.permission.READ_EXTERNAL_STORAGE

: '