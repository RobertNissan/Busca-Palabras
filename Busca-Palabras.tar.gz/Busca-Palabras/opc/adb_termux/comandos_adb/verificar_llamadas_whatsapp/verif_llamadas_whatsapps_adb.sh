#!/bin/bash

# llama_what.sh - Monitorea llamadas de WhatsApp usando adb dumpsys audio (polling).

# Está si se ejecuta en primer plano.

LOG="llamadas_what.log"

# Comprobación rápida de adb
if ! adb get-state 1>/dev/null 2>&1; then
  echo "🚫 adb no detectado. Conecta el device y habilita USB debugging."
  exit 1
fi

echo "📞 Monitoreando llamadas de WhatsApp (dumpsys audio). Ctrl+C para salir."
echo "==== Iniciado $(date '+%F %T') ====" >> "$LOG"

# --- Inicializar prev_mode con el último modo conocido (no lo mostramos) ---
initial_line=$(adb shell dumpsys audio 2>/dev/null | tr -d '\r' | grep "setMode(" | grep "com.whatsapp" | tail -n 1)

if [[ -n "$initial_line" ]]; then
  prev_mode=$(echo "$initial_line" | grep -o 'MODE_[A-Z_]\+' | head -n1)
else
  prev_mode=""
fi

# Si ya está en comunicación al iniciar, marcamos inicio ahora (opcional).
# Esto evita imprimir el evento "finalizada" viejo; la duración se medirá
# desde el momento en que inicias el script.
call_start=0
if [[ "$prev_mode" == "MODE_IN_COMMUNICATION" ]]; then
  call_start=$(date +%s)
fi

# --- Bucle principal ---
while true; do
  line=$(adb shell dumpsys audio 2>/dev/null | tr -d '\r' | grep "setMode(" | grep "com.whatsapp" | tail -n 1)

  if [[ -n "$line" ]]; then
    mode=$(echo "$line" | grep -o 'MODE_[A-Z_]\+' | head -n1)
    if [[ -z "$mode" ]]; then
      sleep 1
      continue
    fi

    ts_dump=$(echo "$line" | awk '{print $1 " " $2}')
    ts_local=$(date '+%F %T')

    # Solo reaccionamos si cambió realmente con respecto a prev_mode
    if [[ "$mode" != "$prev_mode" ]]; then
      case "$mode" in
        MODE_RINGTONE)
          echo "$ts_local - 🔔 Llamada entrante (dumpsys: $ts_dump)" | tee -a "$LOG"
          ;;
        MODE_IN_COMMUNICATION)
          echo "$ts_local - ✅ Llamada contestada / audio activo (dumpsys: $ts_dump)" | tee -a "$LOG"
          call_start=$(date +%s)
          ;;
        MODE_NORMAL)
          echo "$ts_local - 🔚 Llamada finalizada / modo normal (dumpsys: $ts_dump)" | tee -a "$LOG"
          if [[ $call_start -ne 0 ]]; then
            dur=$(( $(date +%s) - call_start ))
            printf "%s - ⏱ Duración total: %d min %d s\n" "$ts_local" $((dur/60)) $((dur%60)) | tee -a "$LOG"
            call_start=0
          fi
          ;;
        *)
          echo "$ts_local - ℹ️ Modo detectado: $mode (dumpsys: $ts_dump)" | tee -a "$LOG"
          ;;
      esac
      prev_mode="$mode"
    fi
  fi

  sleep 1
done
