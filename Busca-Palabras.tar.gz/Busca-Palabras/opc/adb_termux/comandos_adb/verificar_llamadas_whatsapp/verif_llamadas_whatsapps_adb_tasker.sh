#!/data/data/com.termux/files/usr/bin/bash
#
# ~/llama_what.sh
# Uso: ./verif_llamadas_whatsapp_adb start|stop|status|restart

# Está fues diseñado para que tasker lea la variable que devuelve este script
# usa: 
# verif_llamadas_whatsapp_adb start # Se inicia en segundo plano y se guarda en llamadas_what.log si emtra una llamada dirá: llamada entrante, y cuando contesta y cuando finaliza
# verif_llamadas_whatsapp_adb stop # para Detener 
# verif_llamadas_whatsapp_adb status # Para saber si está corriendo o no.

# En Tasker:  bash /data/data/com.termux/files/home/llama_what.sh   (sin argumentos → alterna)
#
PIDFILE="$HOME/.llama_what.pid"
RUNNER="$HOME/.llama_what_runner.sh"
LOG="$HOME/llamadas_what.log"
STATE_FILE="/sdcard/llamada_what_state.txt"   # accesible por Tasker
rm -rf $STATE_FILE
# lee el último estado guardado (si existe)
read_state() {
  if [ -f "$STATE_FILE" ]; then
    cat "$STATE_FILE"
  else
    echo "$(date '+%F %T')|NO_EVENT"
  fi
}

create_runner() {
cat > "$RUNNER" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
trap 'echo "$(date +%F\ %T) - SIGTERM recibido, saliendo" >> "$HOME/llamadas_what.log"; exit 0' TERM
LOG="$HOME/llamadas_what.log"
STATE_FILE="/sdcard/llamada_what_state.txt"

echo "==== Runner iniciado $(date '+%F %T') ====" >> "$LOG"

initial_line=$(adb shell dumpsys audio 2>/dev/null | tr -d '\r' | grep "setMode(" | grep "com.whatsapp" | tail -n 1)
if [[ -n "$initial_line" ]]; then
  prev_mode=$(echo "$initial_line" | grep -o 'MODE_[A-Z_]\+' | head -n1)
else
  prev_mode=""
fi

call_start=0
if [[ "$prev_mode" == "MODE_IN_COMMUNICATION" ]]; then
  call_start=$(date +%s)
fi

while true; do
  line=$(adb shell dumpsys audio 2>/dev/null | tr -d '\r' | grep "setMode(" | grep "com.whatsapp" | tail -n 1)
  if [[ -n "$line" ]]; then
    mode=$(echo "$line" | grep -o 'MODE_[A-Z_]\+' | head -n1)
    [[ -z "$mode" ]] && sleep 1 && continue
    ts_dump=$(echo "$line" | awk '{print $1 " " $2}')
    ts_local=$(date '+%F %T')
    if [[ "$mode" != "$prev_mode" ]]; then
      case "$mode" in
        MODE_RINGTONE)
          echo "$ts_local - 🔔 Llamada entrante (dumpsys: $ts_dump)" | tee -a "$LOG"
          llamada='llamada entrante'
          ;;
        MODE_IN_COMMUNICATION)
          echo "$ts_local - ✅ Llamada contestada / audio activo (dumpsys: $ts_dump)" | tee -a "$LOG"
          call_start=$(date +%s)
          llamada='llamada contestada'
          ;;
        MODE_NORMAL)
          echo "$ts_local - 🔚 Llamada finalizada / modo normal (dumpsys: $ts_dump)" | tee -a "$LOG"
          if [[ $call_start -ne 0 ]]; then
            dur=$(( $(date +%s) - call_start ))
            printf "%s - ⏱ Duración total: %d min %d s\n" "$ts_local" $((dur/60)) $((dur%60)) | tee -a "$LOG"
            call_start=0
          fi
          llamada='llamada finalizada'
          ;;
        *)
          echo "$ts_local - ℹ️ Modo detectado: $mode (dumpsys: $ts_dump)" | tee -a "$LOG"
          llamada="modo_$mode"
          ;;
      esac

      prev_mode="$mode"

      # escribir estado compacto en STATE_FILE (sólo 1 línea — sobreescribe)
      if [ -n "$llamada" ]; then
        echo "${llamada}" > "$STATE_FILE" 2>/dev/null || true
      fi
    fi
  fi
  sleep 0.5
done
EOF

chmod +x "$RUNNER"
}

start() {
  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "ALREADY_RUNNING|$(read_state)"
    return
  fi
  create_runner
  setsid "$RUNNER" >> "$LOG" 2>&1 &
  echo $! > "$PIDFILE"
  sleep 0.2
  # después de iniciar, devolver estado actual (si runner ya escribió algo)
  echo "STARTED|$(read_state)"
}

stop() {
  if [ ! -f "$PIDFILE" ]; then
    echo "NOT_RUNNING|$(read_state)"
    return
  fi
  PID=$(cat "$PIDFILE")
  if ! kill -0 "$PID" 2>/dev/null; then
    rm -f "$PIDFILE"
    echo "NOT_RUNNING|$(read_state)"
    return
  fi

  # intento elegante
  kill -TERM -"$PID" 2>/dev/null || kill -TERM "$PID" 2>/dev/null
  for i in $(seq 1 8); do
    if ! kill -0 "$PID" 2>/dev/null; then
      rm -f "$PIDFILE"
      echo "STOPPED|$(read_state)"
      return
    fi
    sleep 1
  done

  # forzar si no termina
  kill -KILL -"$PID" 2>/dev/null || kill -KILL "$PID" 2>/dev/null
  rm -f "$PIDFILE"
  echo "KILLED|$(read_state)"
}

status() {
  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "RUNNING|$(read_state)"
  else
    echo "STOPPED|$(read_state)"
  fi
}

# --- lógica principal ---
case "${1:-}" in
  start) start ;;
  stop) stop ;;
  status) status ;;
  restart) stop; start ;;
  "")
    # sin argumentos → toggle (útil para Tasker)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      stop
    else
      start
    fi
    ;;
  *)
    echo "USAGE|$0 [start|stop|status|restart]"
    ;;
esac
