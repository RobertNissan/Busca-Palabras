#!/bin/bash
# llama_what.sh
# Monitorea llamadas de WhatsApp usando adb dumpsys audio (polling).
LOG="llamadas_what.log"

# Comprobación rápida de adb
if ! adb get-state 1>/dev/null 2>&1; then
  echo "🚫 adb no detectado. Conecta el device y habilita USB debugging."
  exit 1
fi

echo "📞 Monitoreando llamadas de WhatsApp (dumpsys audio). Ctrl+C para salir."
echo "==== Iniciado $(date '+%F %T') ====" >> "$LOG"

prev_mode=""
call_start=0

while true; do
  # obtener la última línea setMode(…) que mencione com.whatsapp
  line=$(adb shell dumpsys audio 2>/dev/null | tr -d '\r' | grep "setMode(" | grep "com.whatsapp" | tail -n 1)

  if [[ -n "$line" ]]; then
    # extraer modo (ej. MODE_RINGTONE, MODE_IN_COMMUNICATION, MODE_NORMAL)
    mode=$(echo "$line" | grep -o 'MODE_[A-Z_]\+' | head -n1)
    # si no pudo extraer modo, saltar
    if [[ -z "$mode" ]]; then
      sleep 1
      continue
    fi

    # timestamp que incluye el dump (si existe) y el timestamp local
    ts_dump=$(echo "$line" | awk '{print $1 " " $2}')
    ts_local=$(date '+%F %T')

    # detectar cambio de estado
    if [[ "$mode" != "$prev_mode" ]]; then
      case "$mode" in
        MODE_RINGTONE)
          echo "$ts_local - 🔔 Llamada entrante (dumpsys: $ts_dump)" | tee -a "$LOG"
          ;;
        MODE_IN_COMMUNICATION)
          echo "$ts_local - ✅ Llamada contestada / audio activo (dumpsys: $ts_dump)" | tee -a "$LOG"
          # marcar inicio para medir duración
          call_start=$(date +%s)
          ;;
        MODE_NORMAL)
          echo "$ts_local - 🔚 Llamada finalizada / modo normal (dumpsys: $ts_dump)" | tee -a "$LOG"
          if [[ $call_start -ne 0 ]]; then
            dur=$(( $(date +%s) - call_start ))
            printf "%s - ⏱ Duración: %02d:%02d\n" "$ts_local" $((dur/60)) $((dur%60)) | tee -a "$LOG"
            call_start=0
          fi
          ;;
        *)
          echo "$ts_local - ℹ️ Modo detectado: $mode (dumpsys: $ts_dump)" | tee -a "$LOG"
          ;;
      esac
      prev_mode="$mode"
    fi
  fi

  sleep 1
done
