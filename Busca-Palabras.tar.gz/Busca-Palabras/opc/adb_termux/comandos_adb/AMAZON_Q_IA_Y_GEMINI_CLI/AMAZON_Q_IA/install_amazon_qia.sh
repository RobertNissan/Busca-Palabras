#!/bin/bash

#────────────────────────────────────────────#
#   INSTALACIÓN ROBUSTA AMAZON Q CLI + PHONE MCP
#────────────────────────────────────────────#

set -e  # Salir si ocurre un error no controlado

# Colores
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
RED='\033[1;31m'
RESET='\033[0m'
BLUE="\033[0;36m"

# Solución para el error de enlaces duros en dpkg/proot en Android
export PROOT_L2S_DIR="$HOME/.l2s"
mkdir -p "$PROOT_L2S_DIR" 2>/dev/null

verificar_entorno() {
    echo -e "${GREEN}✅ Iniciando verificaciones de entorno${RESET}"
}

instalar_paquetes_termux() {
    echo -e "${YELLOW}📦 Verificando paquetes de Termux...${RESET}"
    paquetes="proot-distro curl unzip"
    for paquete in $paquetes; do
        if ! command -v $paquete >/dev/null 2>&1; then
            echo -e "${YELLOW}Instalando $paquete...${RESET}"
            pkg install -y $paquete
        else
            echo -e "${GREEN}✔  $paquete ya instalado${RESET}"
        fi
    done
}

if command -v pd >/dev/null 2>&1; then
    PD_CMD="pd"
elif command -v proot-distro >/dev/null 2>&1; then
    PD_CMD="proot-distro"
else
    echo -e "${RED}No se encontró 'proot-distro'. Instalando...${RESET}"
    instalar_paquetes_termux
    PD_CMD="proot-distro"
fi

REPARAR_MCP_ERROR() {
    $PD_CMD login ubuntu -- bash -c "
    source /root/myenv31014/bin/activate 2>/dev/null
    if [ -f ~/.aws/amazonq/mcp.json ] && grep -q 'uvx' ~/.aws/amazonq/mcp.json 2>/dev/null; then
        echo -e '✅ MCP ya está configurado correctamente'
        exit 0
    fi
    " 2>/dev/null && return 0
    
    echo -e "${YELLOW}🔧 Detectado error MCP, iniciando reparación automática...${RESET}"
    
    $PD_CMD login ubuntu << 'REPAIR_EOF'
    source /root/myenv31014/bin/activate 2>/dev/null || true
    export PATH="$HOME/.local/bin:$PATH"
    
    GREEN='\033[1;32m'
    YELLOW='\033[1;33m'
    RESET='\033[0m'
    
    echo -e "${YELLOW}📱 Reparando phone-mcp...${RESET}"
    
    pip uninstall -y phone-mcp 2>/dev/null || true
    pip install phone-mcp
    
    mkdir -p ~/.aws/amazonq
    
    cat > "$HOME/.aws/amazonq/mcp.json" << 'MCP_EOF'
{
  "mcpServers": {
    "phone-mcp": {
      "type": "stdio",
      "command": "uvx",
      "args": ["phone-mcp"],
      "timeout": 120000,
      "disabled": false
    }
  }
}
MCP_EOF
    
    echo -e "${GREEN}✅ MCP reparado${RESET}"
REPAIR_EOF
}

CONFIGURACION_COMPLETA_UBUNTU() {
    echo -e "${YELLOW}🔍 Verificando Ubuntu y configuración...${RESET}"
    
    if ! $PD_CMD login ubuntu -- echo ok >/dev/null 2>&1; then
        echo -e "La distribución \"${RED}ubuntu${RESET}\" no está instalada."
        echo -e "Instalando: ${GREEN}ubuntu${RESET}."
        $PD_CMD install ubuntu
    fi
    
    # Limpiar estado previo de dpkg para evitar bloqueos
    $PD_CMD login ubuntu -- bash -c "rm -f /var/lib/dpkg/status-old /var/lib/dpkg/status-new" 2>/dev/null || true

    $PD_CMD login ubuntu -- bash -c '
        GREEN="\\033[1;32m"
        YELLOW="\\033[1;33m"
        RED="\\033[1;31m"
        RESET="\\033[0m"
        BLUE="\\033[0;36m"
        
        trap "echo \"Instalación interrumpida. Limpiando archivos temporales...\"; rm -rf q q.zip; exit 130" SIGHUP SIGINT SIGTERM
        
        # Corregir rutas relativas en /root/.bashrc
        sed -i "/myenv31014/d" /root/.bashrc 2>/dev/null || true
        echo "source /root/myenv31014/bin/activate" >> /root/.bashrc

        if ! command -v q >/dev/null 2>&1; then
            echo -e "⚙️  ${YELLOW}Iniciando configuración completa de Amazon Q CLI${RESET}..."
            
            echo "📅 Configurando zona horaria..."
            export DEBIAN_FRONTEND=noninteractive
            ln -fs /usr/share/zoneinfo/America/Bogota /etc/localtime
            dpkg-reconfigure --frontend noninteractive tzdata >/dev/null 2>&1
            
            echo -e "📦 ${YELLOW}Actualizando lista de paquetes${RESET}..."
            apt update >/dev/null 2>&1
            
            echo -e "🔧 ${YELLOW}Instalando paquetes esenciales${RESET}..."
            apt install -y curl unzip python3 python3-pip python3-venv >/dev/null 2>&1
            
            if [ ! -d "/root/myenv31014" ]; then
                echo -e "🐍 ${YELLOW}Creando entorno virtual${RESET}..."
                python3 -m venv /root/myenv31014
            fi
            
            echo -e "🔄 ${YELLOW}Activando entorno virtual${RESET}..."
            source /root/myenv31014/bin/activate
            
            echo -e "⬆️  ${YELLOW}Actualizando pip${RESET}..."
            pip install --upgrade pip >/dev/null 2>&1
            
            echo -e "${YELLOW}🔍 Verificando descarga de Amazon Q CLI...${RESET}"
            if ! command -v q >/dev/null 2>&1; then
                tamanio_actual=$(stat --format=%s "q.zip" 2>/dev/null || echo 0)
                tamanio_esperado=188202277
                
                if [ "$tamanio_actual" -ge "$tamanio_esperado" ]; then
                    echo -e "✅ ${GREEN}q.zip ya existe (${tamanio_actual} bytes)${RESET}"
                else
                    echo -e "📥 ${YELLOW}Descargando Amazon Q CLI...${RESET}"
                    [[ -f "q.zip" ]] && rm -rf q q.zip
                    
                    intentos=0
                    while [ $intentos -lt 5 ]; do
                        curl -L --progress-bar "https://desktop-release.q.us-east-1.amazonaws.com/latest/q-aarch64-linux.zip" -o "q.zip"
    
                        if [ -f "q.zip" ] && [ $(stat --format=%s "q.zip" 2>/dev/null || echo 0) -gt 100000000 ] && unzip -t q.zip >/dev/null 2>&1; then
                            echo -e "✅ ${GREEN}Descarga exitosa${RESET}"
                            break
                        else
                            echo -e "❌ ${RED}Descarga fallida. Reintentando... ($((intentos+1))/5)${RESET}"
                            rm -f q.zip
                            sleep 2
                            intentos=$((intentos+1))
                        fi
                    done
                    
                    if [ $intentos -eq 5 ]; then
                        echo -e "❌ ${RED}Error: No se pudo descargar después de 5 intentos${RESET}"
                        exit 1
                    fi
                fi
                
                echo -e "📦 ${YELLOW}Instalando Amazon Q CLI${RESET}..."
                unzip -o q.zip >/dev/null 2>&1
                cd q
                
                ./install.sh --force
                source /root/.bashrc
                
                if command -v q >/dev/null 2>&1 || [ -f "/root/.local/bin/q" ]; then
                    echo -e "✅ ${GREEN}Amazon Q CLI instalado correctamente${RESET}"
                else
                    echo -e "❌ ${RED}Error instalando Amazon Q CLI${RESET}"
                    exit 1
                fi
            else
                echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado${RESET}"
            fi
            
            if ! command -v uv >/dev/null 2>&1; then
                echo -e "📥 ${YELLOW}Instalando UV package manager${RESET}..."
                curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
                export PATH="$HOME/.local/bin:$PATH"
                
                if ! grep -q "export PATH=\"\$HOME/.local/bin:\$PATH\"" ~/.bashrc; then
                    echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc
                fi
            else
                echo -e "✅ ${GREEN}UV ya está instalado${RESET}"
            fi
            
            export PATH="$HOME/.local/bin:$PATH"
            source /root/myenv31014/bin/activate
            if python3 -c "import phone_mcp" 2>/dev/null; then
                version=$(pip show phone-mcp | grep Version | awk "{print \$2}" 2>/dev/null || echo "desconocida")
                echo -e "✅ ${GREEN}Phone MCP ya está instalado (versión $version)${RESET}"
            else
                echo -e "📱 ${YELLOW}Instalando Phone MCP${RESET}..."
                pip install phone-mcp >/dev/null 2>&1
            fi
            
            echo -e "⚙️ ${YELLOW}Configurando integración MCP${RESET}..."
            if command -v q >/dev/null 2>&1; then
                q mcp add --name "phone-mcp" --command uvx --args phone-mcp --force >/dev/null 2>&1 || true
                echo -e "✅ ${GREEN}Integración MCP configurada${RESET}"
            fi
        else
            echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado${RESET}"
        fi
    '
    
    if [ $? -eq 0 ]; then
        echo -e "🎉 ${GREEN}Configuración completa exitosa${RESET}"
        return 0
    else
        echo -e "${RED}❌ Error en la configuración${RESET}"
        return 1
    fi
}

CONFIGURADOR_AUTO_INICIO() {
    echo -e "${CYAN}🔍 Configurando inicio automático...${RESET}"
    
    TARGET_BIN="${PREFIX:-/data/data/com.termux/files/usr}/bin/start_q"
    
    echo -e "${YELLOW}📝 Creando ejecutable start_q en ${TARGET_BIN}...${RESET}"
    cat > "$TARGET_BIN" << 'SCRIPT_EOF'
#!/data/data/com.termux/files/usr/bin/bash

export PROOT_L2S_DIR="$HOME/.l2s"
mkdir -p "$PROOT_L2S_DIR" 2>/dev/null

presentacion() {
    local terminal_width=$(tput cols 2>/dev/null || echo 80)
    local title="🚀 INICIANDO"
    local padding=$(( (terminal_width - 15) / 2 ))
    [[ $padding -lt 0 ]] && padding=0
    echo -e "\033[1;36m"
    printf "%*s%s\n" $padding "" "$title"
    echo ""  
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║                                                       ║"
    echo "  ║                   🤖 Amazon Q CLI                     ║"
    echo "  ║                   with Phone MCP 📱                   ║"
    echo "  ║                                                       ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "\033[0m"
    echo ""
}

nuclear_cleanup() {
    echo -e "\n\n💥 CERRANDO SESIÓN..."
    local processes=("q chat" "proot-distro login ubuntu" "proot-distro" "ubuntu" "python.*q" "mcp")
    for proc in "${processes[@]}"; do
        pkill -9 -f "$proc" 2>/dev/null || true
    done
    exit 1
}

trap nuclear_cleanup SIGINT SIGTERM
    
if [ -n "$PROOT_TMP_DIR" ] || [ -f "/etc/debian_version" ]; then
    presentacion
    echo "🔧 Ejecutando en entorno Ubuntu..."
    source /root/myenv31014/bin/activate 2>/dev/null || true
    export PATH="$HOME/.local/bin:$PATH"
    exec q chat    
else
    presentacion
    echo "🔧 Ejecutando en Ubuntu vía proot..."
    exec proot-distro login ubuntu -- bash -c "source /root/myenv31014/bin/activate 2>/dev/null; export PATH=\"\$HOME/.local/bin:\$PATH\"; exec q chat"
fi

echo -e "\n✅ Amazon Q finalizado correctamente."
SCRIPT_EOF

    chmod +x "$TARGET_BIN"
    echo -e "${GREEN}✅ Comando start_q creado exitosamente en ${TARGET_BIN}${RESET}"
    
    echo -e "${YELLOW}🐟 Configurando integración con Fish Shell...${RESET}"
    $PD_CMD login ubuntu -- bash -c '
        if command -v fish >/dev/null 2>&1; then
            mkdir -p ~/.config/fish
            if ! grep -q "Amazon Q CLI + Phone MCP functions" ~/.config/fish/config.fish 2>/dev/null; then
                cat >> ~/.config/fish/config.fish << "FISH_EOF"

# Amazon Q CLI + Phone MCP functions
if status is-interactive
    set -x PATH "$HOME/.local/bin" $PATH

    function phone
        if test -n "$PROOT_TMP_DIR"; or test "$USER" = "root"
            set -x PATH "$HOME/.local/bin" $PATH
            phone-cli $argv
        else
            proot-distro login ubuntu -- bash -c "export PATH=\"\$HOME/.local/bin:\$PATH\" && phone-cli $argv"
        end
    end

    function start_q
        if command -v start_q >/dev/null
            command start_q $argv
        else
            proot-distro login ubuntu -- bash -c "source /root/myenv31014/bin/activate 2>/dev/null; export PATH=\"\$HOME/.local/bin:\$PATH\"; q chat"
        end
    end

    function q-phone
        start_q $argv
    end
end
FISH_EOF
                echo "✅ Configuración Fish agregada en Ubuntu"
            fi
        fi
    ' 2>/dev/null || true
    
    echo -e "${GREEN}✅ Configuración de inicio completada${RESET}"
}

MOSTRAR_INFO() {
    echo -e "${CYAN}"
    echo "╔═════════════════════════════════════════════════════════╗"
    echo "║              🎉 INSTALACIÓN COMPLETADA                  ║"
    echo "╚═════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    
    echo -e "${GREEN}📋 COMANDOS DISPONIBLES:${RESET}"
    echo -e "${YELLOW}• start_q${RESET}                    - Iniciar Amazon Q CLI"
    echo -e "${YELLOW}• q-phone${RESET}                   - Alias para Q CLI"
    echo -e "${YELLOW}• phone <comando>${RESET}           - Ejecutar comandos phone-cli"
    echo ""
}

main() {
    echo -e "${CYAN}🚀 Iniciando instalación de Amazon Q CLI + Phone MCP${RESET}"
    
    verificar_entorno
    instalar_paquetes_termux
    CONFIGURACION_COMPLETA_UBUNTU
    REPARAR_MCP_ERROR
    CONFIGURADOR_AUTO_INICIO
    MOSTRAR_INFO
}

main "$@"
