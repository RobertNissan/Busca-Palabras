#!/bin/bash

#────────────────────────────────────────────#
#   INSTALACIÓN ROBUSTA AMAZON Q CLI + PHONE MCP
#   (con verificación y monitoreo de internet)
#────────────────────────────────────────────#

set -e  # Salir si ocurre un error no controlado

# Colores
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
RED='\033[1;31m'
RESET='\033[0m'
BLUE="\033[0;36m"

# Solución para el error de enlaces duros en dpkg/proot en Android
export PROOT_L2S_DIR="$HOME/.l2s"
mkdir -p "$PROOT_L2S_DIR" 2>/dev/null

#────────────────────────────────────────────#
#   VERIFICACIÓN / MONITOREO DE INTERNET
#────────────────────────────────────────────#

INTERNET_CHECK_SCRIPT="$HOME/Busca-Palabras/config/verif_conex_internet"
MONITOR_STATE_FILE="/tmp/.internet_monitor_state_$$"
MONITOR_PID=""

if [ -f "$INTERNET_CHECK_SCRIPT" ]; then
    source "$INTERNET_CHECK_SCRIPT"
else
    echo -e "${RED}❌ No se encontró el script de verificación de internet en:${RESET}"
    echo -e "${RED}   $INTERNET_CHECK_SCRIPT${RESET}"
    exit 1
fi

# Limpieza al recibir Ctrl+C (SIGINT) o Ctrl+Z (SIGTSTP)
manejar_interrupcion() {
    echo -e "\n${RED}⛔ Señal recibida. Cancelando instalación...${RESET}"
    if [[ -n "$MONITOR_PID" ]]; then
        kill "$MONITOR_PID" 2>/dev/null || true
        wait "$MONITOR_PID" 2>/dev/null || true
    fi
    rm -f "$MONITOR_STATE_FILE" 2>/dev/null
    exit 130
}
trap manejar_interrupcion SIGINT SIGTSTP

# Proceso en segundo plano: reintenta verif_tipo_con hasta detectar internet
monitor_internet_bg() {
    while true; do
        verif_tipo_con
        echo "$conect_internet" > "$MONITOR_STATE_FILE"
        if [[ "$conect_internet" == "true" ]]; then
            break
        fi
        sleep 3
    done
}

# Verifica internet; si no hay, lanza el monitoreo en segundo plano
# y espera (mostrando estado) hasta que cambie a "true".
esperar_conexion_internet() {
    echo -e "${YELLOW}🔍 Verificando conexión a internet...${RESET}"
    verif_tipo_con

    if [[ "$conect_internet" == "true" ]]; then
        echo -e "${GREEN}✅ Conexión a internet detectada (${mi_ip_ex})${RESET}"
        return 0
    fi

    echo -e "${RED}❌ No hay conexión a internet.${RESET}"
    echo -e "${YELLOW}⏳ Monitoreando en segundo plano hasta que se restablezca la conexión...${RESET}"
    echo -e "${YELLOW}   (Ctrl+C o Ctrl+Z para cancelar)${RESET}"

    rm -f "$MONITOR_STATE_FILE" 2>/dev/null
    monitor_internet_bg &
    MONITOR_PID=$!

    local spinner='|/-\'
    local i=0
    while true; do
        if [[ -f "$MONITOR_STATE_FILE" ]]; then
            estado=$(cat "$MONITOR_STATE_FILE" 2>/dev/null)
            if [[ "$estado" == "true" ]]; then
                wait "$MONITOR_PID" 2>/dev/null || true
                MONITOR_PID=""
                rm -f "$MONITOR_STATE_FILE" 2>/dev/null
                echo -e "\n${GREEN}✅ Conexión restablecida. Continuando con la instalación...${RESET}"
                return 0
            fi
        fi
        i=$(( (i + 1) % 4 ))
        printf "\r${YELLOW}Esperando conexión %s${RESET}" "${spinner:$i:1}"
        sleep 1
    done
}

verificar_entorno() {
    echo -e "${GREEN}✅ Iniciando verificaciones de entorno${RESET}"
}

instalar_paquetes_termux() {
    echo -e "${YELLOW}📦 Verificando paquetes de Termux...${RESET}"
    paquetes="proot-distro curl unzip"
    for paquete in $paquetes; do
        if ! command -v $paquete >/dev/null 2>&1; then
            echo -e "${YELLOW}Instalando $paquete...${RESET}"
            pkg install -y $paquete
        else
            echo -e "${GREEN}✔  $paquete ya instalado${RESET}"
        fi
    done
}

if command -v pd >/dev/null 2>&1; then
    PD_CMD="pd"
elif command -v proot-distro >/dev/null 2>&1; then
    PD_CMD="proot-distro"
else
    echo -e "${RED}No se encontró 'proot-distro'. Instalando...${RESET}"
    instalar_paquetes_termux
    PD_CMD="proot-distro"
fi

REPARAR_MCP_ERROR() {
    $PD_CMD login ubuntu -- bash -c "
    source /root/myenv31014/bin/activate 2>/dev/null
    if [ -f ~/.aws/amazonq/mcp.json ] && grep -q 'uvx' ~/.aws/amazonq/mcp.json 2>/dev/null && grep -q 'mcp<2' ~/.aws/amazonq/mcp.json 2>/dev/null; then
        echo -e '✅ MCP ya está configurado correctamente'
        exit 0
    fi
    " 2>/dev/null && return 0

    echo -e "${YELLOW}🔧 Detectado error MCP, iniciando reparación automática...${RESET}"

    $PD_CMD login ubuntu << 'REPAIR_EOF'
    source /root/myenv31014/bin/activate 2>/dev/null || true
    export PATH="$HOME/.local/bin:$PATH"

    GREEN='\033[1;32m'
    YELLOW='\033[1;33m'
    RESET='\033[0m'

    echo -e "${YELLOW}📱 Reparando phone-mcp...${RESET}"

    pip uninstall -y phone-mcp 2>/dev/null || true
    # phone-mcp requiere "mcp<2": desde que "mcp" publicó su versión 2.x,
    # "pip install mcp" instala 2.x por defecto y rompe la API que usa phone-mcp.
    pip install "phone-mcp" "mcp<2" "requests"

    mkdir -p ~/.aws/amazonq

    cat > "$HOME/.aws/amazonq/mcp.json" << 'MCP_EOF'
{
  "mcpServers": {
    "phone-mcp": {
      "type": "stdio",
      "command": "uvx",
      "args": ["--with", "mcp<2", "--with", "requests", "phone-mcp"],
      "timeout": 120000,
      "disabled": false
    }
  }
}
MCP_EOF

    echo -e "${GREEN}✅ MCP reparado${RESET}"
REPAIR_EOF
}

CONFIGURACION_COMPLETA_UBUNTU() {
    echo -e "${YELLOW}🔍 Verificando Ubuntu y configuración...${RESET}"

    if ! $PD_CMD login ubuntu -- echo ok >/dev/null 2>&1; then
        echo -e "La distribución \"${RED}ubuntu${RESET}\" no está instalada."
        echo -e "Instalando: ${GREEN}ubuntu${RESET}."
        $PD_CMD install ubuntu
    fi

    # Limpiar estado previo de dpkg para evitar bloqueos
    $PD_CMD login ubuntu -- bash -c "rm -f /var/lib/dpkg/status-old /var/lib/dpkg/status-new" 2>/dev/null || true

    $PD_CMD login ubuntu -- bash -c '
        GREEN="\\033[1;32m"
        YELLOW="\\033[1;33m"
        RED="\\033[1;31m"
        RESET="\\033[0m"
        BLUE="\\033[0;36m"

        trap "echo \"Instalación interrumpida. Limpiando archivos temporales...\"; rm -rf q q.zip; exit 130" SIGHUP SIGINT SIGTERM

        # Corregir rutas relativas en /root/.bashrc
        sed -i "/myenv31014/d" /root/.bashrc 2>/dev/null || true
        echo "source /root/myenv31014/bin/activate" >> /root/.bashrc

        # Asegurar PATH desde el inicio: si ya se instaló uv/q en una corrida anterior,
        # deben poder detectarse aquí sin importar qué rama se ejecute después.
        export PATH="$HOME/.local/bin:$PATH"

        if ! command -v q >/dev/null 2>&1; then
            echo -e "⚙️  ${YELLOW}Iniciando configuración completa de Amazon Q CLI${RESET}..."

            echo "📅 Configurando zona horaria..."
            export DEBIAN_FRONTEND=noninteractive
            ln -fs /usr/share/zoneinfo/America/Bogota /etc/localtime
            dpkg-reconfigure --frontend noninteractive tzdata >/dev/null 2>&1

            echo -e "📦 ${YELLOW}Actualizando lista de paquetes${RESET}..."
            apt update >/dev/null 2>&1

            echo -e "🔧 ${YELLOW}Instalando paquetes esenciales${RESET}..."
            apt install -y curl unzip python3 python3-pip python3-venv >/dev/null 2>&1

            if [ ! -d "/root/myenv31014" ]; then
                echo -e "🐍 ${YELLOW}Creando entorno virtual${RESET}..."
                python3 -m venv /root/myenv31014
            fi

            echo -e "🔄 ${YELLOW}Activando entorno virtual${RESET}..."
            source /root/myenv31014/bin/activate

            echo -e "⬆️  ${YELLOW}Actualizando pip${RESET}..."
            pip install --upgrade pip >/dev/null 2>&1

            echo -e "${YELLOW}🔍 Verificando descarga de Amazon Q CLI...${RESET}"

            Q_ZIP="q.zip"
            Q_ZIP_URL="https://desktop-release.q.us-east-1.amazonaws.com/latest/q-aarch64-linux.zip"
            # Metadata persistente: sobrevive entre ejecuciones del instalador
            Q_ZIP_META_DIR="$HOME/.cache/amazonq_installer"
            Q_ZIP_META_FILE="$Q_ZIP_META_DIR/q.zip.size"
            mkdir -p "$Q_ZIP_META_DIR"

            # Verdadero si el zip presente es un paquete válido y descargado por completo
            verificar_zip_valido() {
                local zip_path="$1"
                [ -f "$zip_path" ] || return 1

                local tamanio_actual
                tamanio_actual=$(stat --format=%s "$zip_path" 2>/dev/null || echo 0)

                # Umbral mínimo de cordura por si el archivo quedó truncado
                [ "$tamanio_actual" -gt 100000000 ] || return 1

                # Integridad real del zip (detecta truncados/corruptos aunque el tamaño "parezca" ok)
                unzip -t "$zip_path" >/dev/null 2>&1 || return 1

                return 0
            }

            if command -v q >/dev/null 2>&1 || [ -f "/root/.local/bin/q" ]; then
                echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado. No se reinstalará.${RESET}"
            else
                if verificar_zip_valido "$Q_ZIP"; then
                    tamanio_actual=$(stat --format=%s "$Q_ZIP")
                    echo -e "✅ ${GREEN}Se encontró un q.zip válido (${tamanio_actual} bytes). Reutilizando descarga previa, sin volver a descargar.${RESET}"
                else
                    if [ -f "$Q_ZIP" ]; then
                        echo -e "${YELLOW}⚠️  El q.zip existente está incompleto o corrupto. Se eliminará y se descargará de nuevo.${RESET}"
                        rm -rf q "$Q_ZIP"
                    fi

                    echo -e "📥 ${YELLOW}Descargando Amazon Q CLI...${RESET}"
                    intentos=0
                    while [ $intentos -lt 5 ]; do
                        curl -L --progress-bar "$Q_ZIP_URL" -o "$Q_ZIP"

                        if verificar_zip_valido "$Q_ZIP"; then
                            echo -e "✅ ${GREEN}Descarga exitosa${RESET}"
                            break
                        else
                            echo -e "❌ ${RED}Descarga fallida. Reintentando... ($((intentos+1))/5)${RESET}"
                            rm -f "$Q_ZIP"
                            sleep 2
                            intentos=$((intentos+1))
                        fi
                    done

                    if [ $intentos -eq 5 ]; then
                        echo -e "❌ ${RED}Error: No se pudo descargar después de 5 intentos${RESET}"
                        exit 1
                    fi
                fi

                # Guardar el tamaño real ya verificado, para consulta/depuración en próximas ejecuciones
                stat --format=%s "$Q_ZIP" > "$Q_ZIP_META_FILE"

                echo -e "📦 ${YELLOW}Instalando Amazon Q CLI${RESET}..."
                unzip -o "$Q_ZIP" >/dev/null 2>&1
                cd q

                ./install.sh --force
                source /root/.bashrc

                if command -v q >/dev/null 2>&1 || [ -f "/root/.local/bin/q" ]; then
                    echo -e "✅ ${GREEN}Amazon Q CLI instalado correctamente${RESET}"
                else
                    echo -e "❌ ${RED}Error instalando Amazon Q CLI${RESET}"
                    exit 1
                fi
            fi
        else
            echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado${RESET}"
            # Aunque Q ya exista, aseguramos que el venv esté disponible para los pasos siguientes
            if [ -d "/root/myenv31014" ]; then
                source /root/myenv31014/bin/activate
            else
                echo -e "🐍 ${YELLOW}Creando entorno virtual (no existía)${RESET}..."
                apt update >/dev/null 2>&1
                apt install -y python3 python3-pip python3-venv >/dev/null 2>&1
                python3 -m venv /root/myenv31014
                source /root/myenv31014/bin/activate
            fi
        fi

        # ── A partir de aquí, esto SIEMPRE se ejecuta, sin importar si Q ya
        #    estaba instalado o se acaba de instalar en este paso ──

        echo -e "${YELLOW}🔍 Verificando UV package manager...${RESET}"
        if command -v uv >/dev/null 2>&1; then
            uv_version=$(uv --version 2>/dev/null || echo "versión desconocida")
            echo -e "✅ ${GREEN}UV ya está instalado ($uv_version). No se reinstalará.${RESET}"
        else
            echo -e "📥 ${YELLOW}UV no encontrado. Instalando...${RESET}"
            curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
            export PATH="$HOME/.local/bin:$PATH"

            if ! grep -q "export PATH=\"\$HOME/.local/bin:\$PATH\"" ~/.bashrc; then
                echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc
            fi

            if command -v uv >/dev/null 2>&1; then
                echo -e "✅ ${GREEN}UV instalado correctamente${RESET}"
            else
                echo -e "❌ ${RED}Error instalando UV${RESET}"
                exit 1
            fi
        fi

        export PATH="$HOME/.local/bin:$PATH"
        source /root/myenv31014/bin/activate

        # Verifica que phone-mcp esté realmente operativo: el binario phone-cli
        # (entry point del paquete) es la forma oficial de comprobarlo, no basta
        # con "import phone_mcp" porque puede fallar en tiempo de ejecución si
        # el paquete "mcp" instalado es incompatible (ver nota abajo).
        phone_mcp_operativo() {
            command -v phone-cli >/dev/null 2>&1 || return 1
            phone-cli --help >/dev/null 2>&1 || return 1
            return 0
        }

        echo -e "${YELLOW}🔍 Verificando Phone MCP...${RESET}"
        if phone_mcp_operativo; then
            version=$(pip show phone-mcp 2>/dev/null | grep -i "^Version" | awk "{print \$2}")
            [ -z "$version" ] && version="desconocida"
            echo -e "✅ ${GREEN}Phone MCP ya está instalado y operativo (versión $version). No se reinstalará.${RESET}"
        else
            echo -e "📱 ${YELLOW}Phone MCP no encontrado o incompleto. Instalando...${RESET}"

            # phone-mcp requiere fijar "mcp<2": desde que el paquete "mcp" publicó
            # su versión 2.x, "pip install mcp" instala 2.x por defecto y rompe la
            # API que usa phone-mcp. El propio proyecto recomienda instalar así:
            # pip install phone-mcp "mcp<2" requests
            PHONE_MCP_LOG="/tmp/phone_mcp_install.log"
            pip install "phone-mcp" "mcp<2" "requests" >"$PHONE_MCP_LOG" 2>&1

            if phone_mcp_operativo; then
                echo -e "✅ ${GREEN}Phone MCP instalado correctamente${RESET}"
            else
                echo -e "❌ ${RED}Error instalando Phone MCP. Últimas líneas del log:${RESET}"
                tail -n 20 "$PHONE_MCP_LOG"
                echo -e "${YELLOW}Log completo en: $PHONE_MCP_LOG${RESET}"
                exit 1
            fi
        fi

        echo -e "⚙️ ${YELLOW}Verificando integración MCP (phone-mcp)...${RESET}"
        MCP_CONFIG_FILE="$HOME/.aws/amazonq/mcp.json"
        if [ -f "$MCP_CONFIG_FILE" ] && grep -q "\"phone-mcp\"" "$MCP_CONFIG_FILE" 2>/dev/null && grep -q "uvx" "$MCP_CONFIG_FILE" 2>/dev/null; then
            echo -e "✅ ${GREEN}La integración MCP ya está configurada. No se modificará.${RESET}"
        elif command -v q >/dev/null 2>&1; then
            q mcp add --name "phone-mcp" --command uvx --args phone-mcp --force >/dev/null 2>&1 || true
            echo -e "✅ ${GREEN}Integración MCP configurada${RESET}"
        else
            echo -e "${RED}❌ No se pudo configurar MCP: el comando '"'"'q'"'"' no está disponible${RESET}"
        fi
    '

    if [ $? -eq 0 ]; then
        echo -e "🎉 ${GREEN}Configuración completa exitosa${RESET}"
        return 0
    else
        echo -e "${RED}❌ Error en la configuración${RESET}"
        return 1
    fi
}

CONFIGURADOR_AUTO_INICIO() {
    echo -e "${CYAN}🔍 Configurando inicio automático...${RESET}"

    TARGET_BIN="${PREFIX:-/data/data/com.termux/files/usr}/bin/start_q"

    echo -e "${YELLOW}📝 Creando ejecutable start_q en ${TARGET_BIN}...${RESET}"
    cat > "$TARGET_BIN" << 'SCRIPT_EOF'
#!/data/data/com.termux/files/usr/bin/bash

export PROOT_L2S_DIR="$HOME/.l2s"
mkdir -p "$PROOT_L2S_DIR" 2>/dev/null

presentacion() {
    local terminal_width=$(tput cols 2>/dev/null || echo 80)
    local title="🚀 INICIANDO"
    local padding=$(( (terminal_width - 15) / 2 ))
    [[ $padding -lt 0 ]] && padding=0
    echo -e "\033[1;36m"
    printf "%*s%s\n" $padding "" "$title"
    echo ""
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║                                                       ║"
    echo "  ║                   🤖 Amazon Q CLI                     ║"
    echo "  ║                   with Phone MCP 📱                   ║"
    echo "  ║                                                       ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "\033[0m"
    echo ""
}

nuclear_cleanup() {
    echo -e "\n\n💥 CERRANDO SESIÓN..."
    local processes=("q chat" "proot-distro login ubuntu" "proot-distro" "ubuntu" "python.*q" "mcp")
    for proc in "${processes[@]}"; do
        pkill -9 -f "$proc" 2>/dev/null || true
    done
    exit 1
}

trap nuclear_cleanup SIGINT SIGTERM SIGTSTP

if [ -n "$PROOT_TMP_DIR" ] || [ -f "/etc/debian_version" ]; then
    presentacion
    echo "🔧 Ejecutando en entorno Ubuntu..."
    source /root/myenv31014/bin/activate 2>/dev/null || true
    export PATH="$HOME/.local/bin:$PATH"
    exec q chat
else
    presentacion
    echo "🔧 Ejecutando en Ubuntu vía proot..."
    exec proot-distro login ubuntu -- bash -c "source /root/myenv31014/bin/activate 2>/dev/null; export PATH=\"\$HOME/.local/bin:\$PATH\"; exec q chat"
fi

echo -e "\n✅ Amazon Q finalizado correctamente."
SCRIPT_EOF

    chmod +x "$TARGET_BIN"
    echo -e "${GREEN}✅ Comando start_q creado exitosamente en ${TARGET_BIN}${RESET}"

    echo -e "${YELLOW}🐟 Configurando integración con Fish Shell...${RESET}"
    $PD_CMD login ubuntu -- bash -c '
        if command -v fish >/dev/null 2>&1; then
            mkdir -p ~/.config/fish
            if ! grep -q "Amazon Q CLI + Phone MCP functions" ~/.config/fish/config.fish 2>/dev/null; then
                cat >> ~/.config/fish/config.fish << "FISH_EOF"

# Amazon Q CLI + Phone MCP functions
if status is-interactive
    set -x PATH "$HOME/.local/bin" $PATH

    function phone
        if test -n "$PROOT_TMP_DIR"; or test "$USER" = "root"
            set -x PATH "$HOME/.local/bin" $PATH
            phone-cli $argv
        else
            proot-distro login ubuntu -- bash -c "export PATH=\"\$HOME/.local/bin:\$PATH\" && phone-cli $argv"
        end
    end

    function start_q
        if command -v start_q >/dev/null
            command start_q $argv
        else
            proot-distro login ubuntu -- bash -c "source /root/myenv31014/bin/activate 2>/dev/null; export PATH=\"\$HOME/.local/bin:\$PATH\"; q chat"
        end
    end

    function q-phone
        start_q $argv
    end
end
FISH_EOF
                echo "✅ Configuración Fish agregada en Ubuntu"
            fi
        fi
    ' 2>/dev/null || true

    echo -e "${GREEN}✅ Configuración de inicio completada${RESET}"
}

MOSTRAR_INFO() {
    echo -e "${CYAN}"
    echo "╔═════════════════════════════════════════════════════════╗"
    echo "║              🎉 INSTALACIÓN COMPLETADA                  ║"
    echo "╚═════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"

    echo -e "${GREEN}📋 COMANDOS DISPONIBLES:${RESET}"
    echo -e "${YELLOW}• start_q${RESET}                    - Iniciar Amazon Q CLI"
    echo -e "${YELLOW}• q-phone${RESET}                   - Alias para Q CLI"
    echo -e "${YELLOW}• phone <comando>${RESET}           - Ejecutar comandos phone-cli"
    echo ""
}

main() {
    echo -e "${CYAN}🚀 Iniciando instalación de Amazon Q CLI + Phone MCP${RESET}"

    verificar_entorno
    esperar_conexion_internet
    instalar_paquetes_termux
    CONFIGURACION_COMPLETA_UBUNTU
    REPARAR_MCP_ERROR
    CONFIGURADOR_AUTO_INICIO
    MOSTRAR_INFO
}

main "$@"
