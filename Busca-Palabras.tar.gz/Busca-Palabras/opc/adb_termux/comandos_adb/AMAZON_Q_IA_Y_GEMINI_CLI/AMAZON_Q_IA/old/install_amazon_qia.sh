#!/bin/bash

#────────────────────────────────────────────#
#   INSTALACIÓN ROBUSTA AMAZON Q CLI + PHONE MCP
#────────────────────────────────────────────#

set -e  # Exit on any error

# Colores
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
RED='\033[1;31m'
RESET='\033[0m'
BLUE="\033[0;36m"

# Verificar entorno básico
verificar_entorno() {
    echo -e "${GREEN}✅ Iniciando verificaciones de entorno${RESET}"
}

# Instalar paquetes necesarios en Termux
instalar_paquetes_termux() {
    echo -e "${YELLOW}📦 Verificando paquetes de Termux...${RESET}"
    paquetes="proot-distro curl unzip"
    for paquete in $paquetes; do
        if ! command -v $paquete >/dev/null 2>&1; then
            echo -e "${YELLOW}Instalando $paquete...${RESET}"
            pkg install -y $paquete
        else
            echo -e "${GREEN}✔  $paquete ya instalado${RESET}"
        fi
    done
}

# Comando para proot-distro
if command -v pd >/dev/null 2>&1; then
    PD_CMD="pd"
elif command -v proot-distro >/dev/null 2>&1; then
    PD_CMD="proot-distro"
else
    echo -e "${RED}No se encontró 'proot-distro'. Instalando...${RESET}"
    instalar_paquetes_termux
    PD_CMD="proot-distro"
fi

REPARAR_MCP_ERROR() {
    $PD_CMD login ubuntu -- bash -c "
    source myenv31014/bin/activate
    if [ -f ~/.aws/amazonq/mcp.json ] && grep -q 'uvx' ~/.aws/amazonq/mcp.json 2>/dev/null; then
        echo -e '✅ MCP ya está configurado correctamente'
        exit 0
    fi
    " 2>/dev/null && return 0
    
    echo -e "${YELLOW}🔧 Detectado error MCP, iniciando reparación automática...${RESET}"
    
    $PD_CMD login ubuntu << 'REPAIR_EOF'
    source myenv31014/bin/activate
    export PATH="$HOME/.local/bin:$PATH"
    
    GREEN='\033[1;32m'
    YELLOW='\033[1;33m'
    RED='\033[1;31m'
    RESET='\033[0m'
    
    echo -e "${YELLOW}📱 Reparando phone-mcp...${RESET}"
    
    pip uninstall -y phone-mcp 2>/dev/null || true
    pip install phone-mcp
    
    mkdir -p ~/.aws/amazonq
    
    cat > "$HOME/.aws/amazonq/mcp.json" << 'MCP_EOF'
{
  "mcpServers": {
    "phone-mcp": {
      "type": "stdio",
      "command": "uvx",
      "args": ["phone-mcp"],
      "timeout": 120000,
      "disabled": false
    }
  }
}
MCP_EOF
    
    echo -e "${GREEN}✅ MCP reparado${RESET}"
REPAIR_EOF
}

CONFIGURACION_COMPLETA_UBUNTU() {
    echo -e "${YELLOW}🔍 Verificando Ubuntu y configuración...${RESET}"
    
    if ! proot-distro login ubuntu -- echo ok >/dev/null 2>&1; then
        echo -e "La distribución \"${RED}ubuntu${RESET}\" no está instalada."
        echo -e "Instalando: ${GREEN}ubuntu${RESET}."
        $PD_CMD install ubuntu
    fi
    
    $PD_CMD login ubuntu -- bash -c '
        GREEN="\\033[1;32m"
        YELLOW="\\033[1;33m"
        RED="\\033[1;31m"
        RESET="\\033[0m"
        BLUE="\\033[0;36m"
        
        trap "echo \"Instalación interrumpida. Limpiando archivos temporales...\"; rm -rf q q.zip; exit 130" SIGHUP SIGINT SIGTERM
        
        if ! grep -q "source myenv31014/bin/activate" /root/.bashrc || ! command -v q >/dev/null 2>&1; then
            echo -e "⚙️  ${YELLOW}Iniciando configuración completa de Amazon Q CLI${RESET}..."
            
            echo "📅 Configurando zona horaria..."
            export DEBIAN_FRONTEND=noninteractive
            ln -fs /usr/share/zoneinfo/America/Bogota /etc/localtime
            dpkg-reconfigure --frontend noninteractive tzdata >/dev/null 2>&1
            
            echo -e "📦 ${YELLOW}Actualizando lista de paquetes${RESET}..."
            apt update >/dev/null 2>&1
            
            echo -e "🔧 ${YELLOW}Instalando paquetes esenciales${RESET}..."
            apt install -y curl unzip python3 python3-pip python3-venv >/dev/null 2>&1
            
            if [ ! -d "/root/myenv31014" ]; then
                echo -e "🐍 ${YELLOW}Creando entorno virtual${RESET}..."
                python3 -m venv myenv31014
            fi
            
            echo -e "🔄 ${YELLOW}Activando entorno virtual${RESET}..."
            source myenv31014/bin/activate
            
            echo -e "⬆️  ${YELLOW}Actualizando pip${RESET}..."
            pip install --upgrade pip >/dev/null 2>&1
            
            echo -e "${YELLOW}🔍 Verificando descarga de Amazon Q CLI...${RESET}"
            if ! command -v q >/dev/null 2>&1; then
                tamanio_actual=$(stat --format=%s "q.zip" 2>/dev/null || echo 0)
                tamanio_esperado=188202277
                
                if [ "$tamanio_actual" -ge "$tamanio_esperado" ]; then
                    echo -e "✅ ${GREEN}q.zip ya existe (${tamanio_actual} bytes)${RESET}"
                else
                    echo -e "📥 ${YELLOW}Descargando Amazon Q CLI...${RESET}"
                    [[ -f "q.zip" ]] && rm -rf q q.zip
                    
                    intentos=0
                    while [ $intentos -lt 5 ]; do
                        curl -L --progress-bar "https://desktop-release.q.us-east-1.amazonaws.com/latest/q-aarch64-linux.zip" -o "q.zip"
    
                        if [ -f "q.zip" ] && [ $(stat --format=%s "q.zip" 2>/dev/null || echo 0) -gt 100000000 ] && unzip -t q.zip >/dev/null 2>&1; then
                            echo -e "✅ ${GREEN}Descarga exitosa${RESET}"
                            break
                        else
                            echo -e "❌ ${RED}Descarga fallida. Reintentando... ($((intentos+1))/5)${RESET}"
                            rm -f q.zip
                            sleep 2
                            intentos=$((intentos+1))
                        fi
                    done
                    
                    if [ $intentos -eq 5 ]; then
                        echo -e "❌ ${RED}Error: No se pudo descargar después de 5 intentos${RESET}"
                        exit 1
                    fi

                fi
                
                echo -e "📦 ${YELLOW}Instalando Amazon Q CLI${RESET}..."
                unzip -o q.zip >/dev/null 2>&1
                cd q
                
                if q whoami >/dev/null 2>&1; then
                    echo -e "✅ ${GREEN}Already logged in${RESET}"
                else                                                       
                    echo -e "⚙️ ${BLUE}A continuación press Enter y Enter${RESET}."                                                      
                    echo -e "⚙️ ${BLUE}Y regístrate con tu cuenta Google${RESET}."                                                       
                    # q login
                fi
                
                ./install.sh --force
                source /root/.bashrc
                
                # Intentar instalar hasta que se detecte el comando 'q'
                while true; do
                    if q whoami >/dev/null 2>&1; then
                        # echo -e "✅ ${GREEN}Amazon Q CLI instalado correctamente${RESET}"
                        break
                    else
                        # echo -e "❌ ${RED}Error instalando Amazon Q CLI. Reintentando...${RESET}"
                        sleep 2
                    fi
                done
                # if command -v q >/dev/null 2>&1; then
                if q whoami >/dev/null 2>&1; then
                    echo -e "✅ ${GREEN}Amazon Q CLI instalado correctamente${RESET}"
                else
                    echo -e "❌ ${RED}Error instalando Amazon Q CLI${RESET}"
                    exit 1
                fi
            else
                echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado${RESET}"
            fi
            
            if ! command -v uv >/dev/null 2>&1; then
                echo -e "📥 ${YELLOW}Instalando UV package manager${RESET}..."
                curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
                export PATH="$HOME/.local/bin:$PATH"
                
                if ! grep -q "export PATH=\"\$HOME/.local/bin:\$PATH\"" ~/.bashrc; then
                    echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc
                fi
            else
                echo -e "✅ ${GREEN}UV ya está instalado${RESET}"
            fi
            
            export PATH="$HOME/.local/bin:$PATH"
            if python3 -c "import phone_mcp" 2>/dev/null; then
                version=$(pip show phone-mcp | grep Version | awk "{print \$2}" 2>/dev/null || echo "desconocida")
                echo -e "✅ ${GREEN}Phone MCP ya está instalado (versión $version)${RESET}"
            else
                echo -e "📱 ${YELLOW}Instalando Phone MCP${RESET}..."
                pip install phone-mcp >/dev/null 2>&1
            fi
            
            echo -e "⚙️ ${YELLOW}Configurando integración MCP${RESET}..."
            if command -v q >/dev/null 2>&1; then
                q mcp add --name "phone-mcp" --command uvx --args phone-mcp --force >/dev/null 2>&1 || true
                echo -e "✅ ${GREEN}Integración MCP configurada${RESET}"
            fi
            
            if ! grep -q "source myenv31014/bin/activate" /root/.bashrc; then
                echo -e "⚙️ ${YELLOW}Configurando activación automática del entorno${RESET}..."
                echo "source myenv31014/bin/activate" >> /root/.bashrc
            fi
        else
            echo -e "✅ ${GREEN}Amazon Q CLI ya está instalado${RESET}"
        fi
    '
    
    if [ $? -eq 0 ]; then
        echo -e "🎉 ${GREEN}Configuración completa exitosa${RESET}"
        return 0
    else
        echo -e "${RED}❌ Error en la configuración${RESET}"
        return 1
    fi
}

CONFIGURADOR_AUTO_INICIO() {
    echo -e "${CYAN}🔍 Configurando inicio automático...${RESET}"
    
    echo -e "${YELLOW}📝 Creando comando start_q ejecutable...${RESET}"
    cat > "/data/data/com.termux/files/usr/bin/start_q" << 'SCRIPT_EOF'
#!/data/data/com.termux/files/usr/bin/bash

presentacion() {
    local terminal_width=$(tput cols)
    local title="🚀 INICIANDO"
    local padding=$(( (terminal_width - 15) / 2 ))
    echo -e "\033[1;36m"
    printf "%*s%s%*s\n" $padding "" "$title" $padding ""
    echo ""  
    echo "  ╔═══════════════════════════════════════════════════════╗"
    echo "  ║                                                       ║"
    echo "  ║                   🤖 Amazon Q CLI                     ║"
    echo "  ║                   with Phone MCP 📱                   ║"
    echo "  ║                                                       ║"
    echo "  ╚═══════════════════════════════════════════════════════╝"
    echo -e "\033[0m"
    echo ""
}
# Función nuclear - mata TODO
nuclear_cleanup() {
    echo -e "\n\n💥 DETONANDO LIMPIEZA NUCLEAR..."
    # Lista de procesos a matar
    local processes=("q chat" "proot-distro login ubuntu" "proot-distro" "ubuntu" "python.*q" "mcp")
    for proc in "${processes[@]}"; do
        pkill -9 -f "$proc" 2>/dev/null && echo "☠️  Matado: $proc"
    done
    # Matar todos los procesos hijos
    kill -9 -P $$ 2>/dev/null
    # Forzar salida
    exit 1
}
# Configurar trap
trap nuclear_cleanup SIGINT SIGTERM
    
if [ -n "$PROOT_TMP_DIR" ] || [ -f "/etc/debian_version" ]; then
    presentacion
    # Entorno nativo
    echo "🔧 Ejecutando en entorno nativo..."
    source ~/myenv31014/bin/activate 2>/dev/null || true
    export PATH="$HOME/.local/bin:$PATH"
    # Usar exec para reemplazar el proceso actual
    exec q chat    
else
    presentacion
    # Entorno proot - usar exec también
    echo "🔧 Ejecutando en Ubuntu via proot..."
    exec proot-distro login ubuntu -- bash -c "q chat"
fi
# Nunca deberíamos llegar aquí debido al exec
echo -e "\n✅ Amazon Q finalizado correctamente."
SCRIPT_EOF
    chmod +x "/data/data/com.termux/files/usr/bin/start_q"
    echo -e "${GREEN}✅ Comando start_q creado en /data/data/com.termux/files/usr/bin${RESET}"
    
    # Configurar Fish shell en Ubuntu si existe
    echo -e "${YELLOW}🐟 Configurando Fish shell en Ubuntu...${RESET}"
    proot-distro login ubuntu -- bash -c '
        if command -v fish >/dev/null 2>&1; then
            mkdir -p ~/.config/fish
            
            if ! grep -q "Amazon Q CLI + Phone MCP functions" ~/.config/fish/config.fish 2>/dev/null; then
                cat >> ~/.config/fish/config.fish << "FISH_EOF"
# Amazon Q CLI + Phone MCP functions
if status is-interactive
    # Ajustes interactivos (PATH, alias/funciones)
    set -x PATH "$HOME/.local/bin" $PATH

    # Si quieres ejecutar 'q' automáticamente cuando estés dentro de proot/ubuntu,
    # lo dejamos aquí (sin banner).
    if test -n "$PROOT_TMP_DIR"; or test "$USER" = "root"
        # estamos en Ubuntu (proot) o root: nada que mostrar
        # (puedes agregar aquí configuraciones adicionales)
    else
        # Si prefieres que no entre automáticamente a ubuntu, comenta esto:
        # proot-distro login ubuntu -- bash -c "export PATH=\"\$HOME/.local/bin:\$PATH\" && q"
    end

    # Función phone (sin banner)
    function phone
        if test -n "$PROOT_TMP_DIR"; or test "$USER" = "root"
            set -x PATH "$HOME/.local/bin" $PATH
            phone-cli $argv
        else
            proot-distro login ubuntu -- bash -c "export PATH=\"\$HOME/.local/bin:\$PATH\" && phone-cli $argv"
        end
    end

    # start_q: muestra el banner y luego ejecuta el ejecutable real 'start_q'
    function start_q
        # --- Banner (aparecerá SOLO cuando ejecutes start_q) ---
        echo ""
        echo "                      🚀 INICIANDO"
        echo ""
        printf "  ╔═══════════════════════════════════════════════════════╗\n"
        printf "  ║                                                       ║\n"
        printf "  ║                   🤖 Amazon Q CLI                     ║\n"
        printf "  ║                   with Phone MCP 📱                   ║\n"
        printf "  ║                                                       ║\n"
        printf "  ╚═══════════════════════════════════════════════════════╝\n"
        echo ""

        # --- Ejecutar el binario/script real ---
        if command -v start_q >/dev/null
            # 'command' fuerza la ejecución del ejecutable y evita llamar a esta función recursivamente
            command start_q $argv
        else
            echo "⚠️  No se encontró el ejecutable 'start_q' en PATH."
            echo "   Comprueba la ruta o instala/coloca el script en \$HOME/.local/bin o en PATH."
        end
    end

    # q-phone como función ligera que llama a start_q
    function q-phone
        start_q $argv
    end
end
FISH_EOF
                echo "✅ Configuración Fish agregada en Ubuntu"
            else
                echo "✅ Configuración Fish ya existe en Ubuntu"
            fi
        else
            echo "ℹ️ Fish no está instalado en Ubuntu"
        fi
    ' 2>/dev/null || echo "⚠️ No se pudo configurar Fish en Ubuntu"
    
    echo -e "${GREEN}✅ Configuración de inicio completada${RESET}"
}






MOSTRAR_INFO() {
    echo -e "${CYAN}"
    echo "╔═════════════════════════════════════════════════════════╗"
    echo "║              🎉 INSTALACIÓN COMPLETADA                  ║"
    echo "╚═════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    
    echo -e "${GREEN}📋 COMANDOS DISPONIBLES:${RESET}"
    echo -e "${YELLOW}• start_q${RESET}                    - Iniciar Amazon Q CLI"
    echo -e "${YELLOW}• q-phone${RESET}                   - Alias para Q CLI"
    echo -e "${YELLOW}• phone <comando>${RESET}           - Ejecutar comandos phone-cli"
    echo -e "${YELLOW}• phone_cmd <comando>${RESET}       - Función para phone-cli"
    echo ""
    
    echo -e "${GREEN}📱 EJEMPLOS DE USO:${RESET}"
    echo -e "${CYAN}phone-cli check check${RESET}                  - Verificar conexión del dispositivo"
    echo -e "${CYAN}phone-cli check screenshot${RESET}             - Tomar captura de pantalla"
    echo -e "${CYAN}phone-cli check call 1234567890${RESET}        - Hacer llamada"
    echo -e "${CYAN}phone-cli check send-sms 1234567890 'Hola'${RESET}    - Enviar SMS"
    echo ""
    
    echo -e "${GREEN}🚀 PARA EMPEZAR:${RESET}"
    echo -e "${YELLOW}1.${RESET} Ejecuta: ${CYAN}start_q${RESET}"
    echo -e "${YELLOW}2.${RESET} Regístrate con tu cuenta Google"
    echo -e "${YELLOW}3.${RESET} Usa ${CYAN}/mcp${RESET} en Q CLI para acceder a controles del teléfono"
    echo ""
    
    echo -e "${BLUE}💡 TIP: Reinicia Termux para cargar los nuevos comandos${RESET}"
}

main() {
    echo -e "${CYAN}🚀 Iniciando instalación de Amazon Q CLI + Phone MCP${RESET}"
    
    verificar_entorno
    instalar_paquetes_termux
    CONFIGURACION_COMPLETA_UBUNTU
    REPARAR_MCP_ERROR
    CONFIGURADOR_AUTO_INICIO
    MOSTRAR_INFO
    # sed -i '/^function start_q$/,/^end$/d' /data/data/com.termux/files/home/.config/fish/config.fish
}

main "$@"


: '
# PARA ELIMINAR TODO AMAZON Q
echo "🧹 Eliminando Amazon Q CLI completamente..."

# 1️⃣ Matar procesos relacionados
pkill -f 'qchat' 2>/dev/null || true
pkill -f 'amazon-q' 2>/dev/null || true
pkill -f '/usr/bin/q' 2>/dev/null || true
pkill -f '/data/data/com.termux/files/usr/bin/q' 2>/dev/null || true

# 2️⃣ Rutas comunes (Termux + Ubuntu dentro de proot)
BIN_PATHS=(
  "$PREFIX/bin/q"
  "$PREFIX/bin/qchat"
  "$PREFIX/bin/amazon-q"
  "$HOME/.local/bin/q"
  "$HOME/.local/bin/qchat"
  "/usr/local/bin/q"
  "/usr/bin/q"
  "/bin/q"
  "/root/.local/bin/q"
  "/data/data/com.termux/files/usr/bin/q"
  "/data/data/com.termux/files/home/.local/bin/q"
)

for f in "${BIN_PATHS[@]}"; do
  [[ -f "$f" ]] && echo "🗑️  Eliminando binario: $f" && rm -f "$f"
done

# 3️⃣ Directorios de configuración y caché
rm -rf \
  "$HOME/.config/q" \
  "$HOME/.cache/q" \
  "$HOME/.local/share/q" \
  "$HOME/q" \
  "$HOME/.q" \
  "/root/.config/q" \
  "/root/.cache/q" \
  "/root/.local/share/q" \
  "/usr/local/share/q" \
  "/usr/share/q" \
  "/opt/amazon-q" \
  "/opt/q"

# 4️⃣ Limpiar archivos de configuración de shells
for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.config/fish/config.fish" "/root/.bashrc"; do
  [[ -f "$rc" ]] && sed -i "/qchat/d;/amazon-q/d;/q /d" "$rc"
done

# 5️⃣ Refrescar entorno y alias
unalias q 2>/dev/null || true
unalias qchat 2>/dev/null || true
hash -r 2>/dev/null || true

# 6️⃣ Borrar posibles binarios residuales
find "$PREFIX" -type f \( -name q -o -name qchat \) 2>/dev/null | while read -r f; do
  echo "🗑️  Eliminando residual: $f"
  rm -f "$f"
done

# 7️⃣ Verificar resultado
if command -v q >/dev/null 2>&1 || command -v qchat >/dev/null 2>&1; then
    echo "⚠️  Amazon Q CLI todavía presente en: $(command -v q || command -v qchat)"
else
    echo "✅ Amazon Q CLI eliminado completamente del sistema."
fi
: '
