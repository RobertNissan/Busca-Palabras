# Link: https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/command-line-installing-ssh-setup-autocomplete.html

# debes tener instalado Ubuntu 
pd sh ubuntu
curl --proto '=https' --tlsv1.2 -sSf "https://desktop-release.q.us-east-1.amazonaws.com/latest/q-aarch64-linux.zip" -o "q.zip"
unzip q.zip
cd q
./install.sh --force
# luego Enter y regístrate con Google 
# vuelve nuevamente al terminal Termux, sal de Ubuntu con exit, y vuelve a ingresar
# Para iniciar solo escribe q en el terminal y listo, habla con AI y puede decir que busque en tus archivos locales

# OTROS comandos adb para integrar a la AI
pip install phone-mcp
# Verificar Dispositivo y conexión
# Check device connection
phone-cli check
# Get screen size
phone-cli screen-interact find method=clickable
# en una sesión nueva puedes integra mcp así:
curl -LsSf https://astral.sh/uv/install.sh | sh
q mcp add --name "phone-mcp" --command uvx --args phone-mcp --force
# luego en la sesión de la AI de Amazon puedes integrar directamente con: /mcp


# Dispositivo y conexión
# Check device connection
phone-cli check
# Get screen size
phone-cli screen-interact find method=clickable

# Comunicación 
# Make a call
phone-cli call 1234567890
# End current call
phone-cli hangup
# Send SMS
phone-cli send-sms 1234567890 "Hello"
# Get received messages (with pagination)
phone-cli messages --limit 10
# Get sent messages (with pagination)
phone-cli sent-messages --limit 10
# Get contacts (with pagination)
phone-cli contacts --limit 20
# Create a new contact with UI automation
phone-cli create-contact "John Doe" "1234567890"

# Medios y aplicaciones 
# Take screenshot
phone-cli screenshot

# Record screen
phone-cli record --duration 30

# Launch app (may not work on all devices)
phone-cli app camera

# Alternative app launch method using open_app (if app command doesn't work)
phone-cli open_app camera

# Close app
phone-cli close-app com.android.camera

# List installed apps (basic info, faster)
phone-cli list-apps
# List apps with pagination
phone-cli list-apps --page 1 --page-size 10
# List apps with detailed info (slower)
phone-cli list-apps --detailed
# Launch specific activity (reliable method for all devices)
phone-cli launch com.android.settings/.Settings
# Launch app by package name (may not work on all devices)
phone-cli app com.android.contacts
# Alternative launch by package name (if app command doesn't work)
phone-cli open_app com.android.contacts
# Launch app by package and activity (most reliable method)
phone-cli launch com.android.dialer/com.android.dialer.DialtactsActivity
# Open URL in default browser
phone-cli open-url google.com

# Análisis e interacción de pantalla 
# Analyze current screen with structured information
phone-cli analyze-screen
# Unified interaction interface
phone-cli screen-interact <action> [parameters]
# Tap at coordinates
phone-cli screen-interact tap x=500 y=800
# Tap element by text
phone-cli screen-interact tap element_text="Login"
# Tap element by content description
phone-cli screen-interact tap element_content_desc="Calendar"
# Swipe gesture (scroll down)
phone-cli screen-interact swipe x1=500 y1=1000 x2=500 y2=200 duration=300
# Press key
phone-cli screen-interact key keycode=back
# Input text
phone-cli screen-interact text content="Hello World"
# Find elements
phone-cli screen-interact find method=text value="Login" partial=true
# Wait for element
phone-cli screen-interact wait method=text value="Success" timeout=10
# Scroll to find element
phone-cli screen-interact scroll method=text value="Settings" direction=down max_swipes=5
# Monitor UI for changes
phone-cli monitor-ui --interval 0.5 --duration 30
# Monitor UI until specific text appears
phone-cli monitor-ui --watch-for text_appears --text "Welcome"
# Monitor UI until specific element ID appears
phone-cli monitor-ui --watch-for id_appears --id "login_button"
# Monitor UI until specific element class appears
phone-cli monitor-ui --watch-for class_appears --class-name "android.widget.Button"
# Monitor UI changes with output as raw JSON
phone-cli monitor-ui --raw