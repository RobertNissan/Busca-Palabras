#!/bin/bash

# Instalador mejorado: Node.js, Gemini CLI, ADB y phone-mcp
# Compatible con Termux / Ubuntu en Android

# COLORES
C_CYAN='\033[0;36m'
C_GREEN='\033[0;32m'
C_YELLOW='\033[1;33m'
C_RED='\033[0;31m'
C_NONE='\033[0m'

print_header() { echo -e "\n${C_CYAN}--- $1 ---${C_NONE}"; }
print_success() { echo -e "${C_GREEN}✅ $1${C_NONE}"; }
print_warning() { echo -e "${C_YELLOW}⚠️ $1${C_NONE}"; }
print_error_exit() { echo -e "${C_RED}❌ Error: $1${C_NONE}"; exit 1; }

command_exists() { command -v "$1" &>/dev/null; }

#────────────────────────────────────────────#
#  VERIFICACIÓN / MONITOREO DE INTERNET
#────────────────────────────────────────────#

MONITOR_STATE_FILE="/tmp/.gemini_installer_internet_$$"
MONITOR_PID=""

manejar_interrupcion() {
    echo -e "\n${C_RED}⛔ Señal recibida. Cancelando instalación...${C_NONE}"
    [ -n "$MONITOR_PID" ] && kill "$MONITOR_PID" 2>/dev/null
    rm -f "$MONITOR_STATE_FILE" 2>/dev/null
    exit 130
}
trap manejar_interrupcion SIGINT SIGTSTP

# Prueba varios endpoints HTTP planos (más rápidos que HTTPS) y devuelve la IP externa
hay_internet() {
    local endpoints=("http://api.ipify.org" "http://icanhazip.com" "http://checkip.amazonaws.com")
    local url res
    for url in "${endpoints[@]}"; do
        res=$(curl -s4 -m 2 --connect-timeout 1.5 "$url" 2>/dev/null)
        if [[ "$res" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
            echo "$res"
            return 0
        fi
    done
    return 1
}

monitor_internet_bg() {
    while true; do
        if ip=$(hay_internet); then
            echo "$ip" > "$MONITOR_STATE_FILE"
            break
        fi
        sleep 3
    done
}

esperar_conexion_internet() {
    print_header "Verificando conexión a internet"
    local ip
    if ip=$(hay_internet); then
        print_success "Conexión a internet detectada ($ip)"
        return 0
    fi

    print_warning "No hay conexión a internet."
    echo -e "${C_YELLOW}⏳ Monitoreando en segundo plano hasta que se restablezca la conexión... (Ctrl+C o Ctrl+Z para cancelar)${C_NONE}"

    rm -f "$MONITOR_STATE_FILE" 2>/dev/null
    monitor_internet_bg &
    MONITOR_PID=$!

    local spinner='|/-\'
    local i=0
    while true; do
        if [ -f "$MONITOR_STATE_FILE" ]; then
            wait "$MONITOR_PID" 2>/dev/null
            ip=$(cat "$MONITOR_STATE_FILE" 2>/dev/null)
            rm -f "$MONITOR_STATE_FILE"
            MONITOR_PID=""
            echo ""
            print_success "Conexión restablecida ($ip). Continuando..."
            return 0
        fi
        i=$(( (i + 1) % 4 ))
        printf "\r${C_YELLOW}Esperando conexión %s${C_NONE}" "${spinner:$i:1}"
        sleep 1
    done
}

# --- PASO 1 ---
install_dependencies() {
    print_header "Paso 1: Instalando Dependencias (Node.js y NVM)"

    # nvm es una FUNCIÓN de shell (no un binario), así que "command -v nvm"
    # solo la detecta si nvm.sh ya fue "source-ado" en esta sesión. Por eso
    # hay que cargar nvm.sh ANTES de comprobar si ya está instalado.
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"

    if command_exists nvm; then
        print_success "NVM ya está instalado."
    else
        echo "Instalando NVM..."
        apt update -y && apt install -y curl || print_error_exit "No se pudo instalar curl."
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash || print_error_exit "Fallo instalando NVM."
        [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
    fi

    if nvm ls 20 2>/dev/null | grep -q "v20"; then
        print_success "Node.js v20 ya está instalado."
    else
        echo "Instalando Node.js v20..."
        nvm install 20 || print_error_exit "Fallo al instalar Node.js v20."
    fi

    nvm use 20 >/dev/null
    nvm alias default 20 >/dev/null

    print_success "Node.js $(node -v), NPM $(npm -v)"
}

# --- PASO 2 ---
install_gemini_cli() {
    print_header "Paso 2: Instalando Gemini CLI"

    if command_exists gemini; then
        print_success "Gemini CLI ya está instalado."
    else
        npm install -g @google/gemini-cli || print_error_exit "Falló la instalación de Gemini CLI."
        print_success "Gemini CLI instalado correctamente."
    fi
    gemini --version
}

# --- PASO 3 ---
configure_api_key() {
    print_header "Paso 3: Configurando la API Key de Gemini"

    if grep -q "export GEMINI_API_KEY=" "$HOME/.bashrc" 2>/dev/null; then
        print_success "API key ya configurada en ~/.bashrc."
    else
        echo "Obtén tu API Key en: https://aistudio.google.com/app/api-keys"
        read -p "Pega tu API Key aquí: " api_key
        [ -z "$api_key" ] && print_error_exit "No se ingresó ninguna API key."
        echo -e "\n# Google Gemini API Key\nexport GEMINI_API_KEY=\"$api_key\"" >> "$HOME/.bashrc"
        print_success "API key guardada en ~/.bashrc."
        source "$HOME/.bashrc"
    fi
}

# --- PASO 4 ---

# phone-mcp requiere fijar "mcp<2": desde que el paquete "mcp" publicó su
# versión 2.x, "pip install mcp" instala 2.x por defecto y rompe la API que
# usa phone-mcp. Además, lo instalamos en un venv PERSISTENTE en vez de
# depender de "uvx phone-mcp": uvx crea un entorno nuevo y reinstala todo
# cada vez que arranca, lo que en un teléfono tarda más que el timeout de
# inicialización del cliente MCP (Gemini/Amazon Q) y hace que se reporte
# como "fallido" aunque el paquete esté bien. Si ya existe el venv del
# instalador de Amazon Q (/root/myenv31014) lo reutilizamos para no duplicar
# la instalación de phone-mcp en el mismo sistema.

# Ubuntu recientes traen Python 3.14+ por defecto, y paquetes con extensiones
# en Rust (pydantic-core, requerido por mcp) todavía no publican wheels
# precompilados para versiones tan nuevas. Pip entonces intenta compilarlo
# con maturin, que en Termux/proot detecta (mal) que está compilando para
# Android y exige ANDROID_API_LEVEL, y la compilación falla. Por eso el venv
# de phone-mcp se fuerza a una versión de Python con wheels disponibles.
PHONE_MCP_PY_VERSION="3.12"

phone_mcp_venv_compatible() {
    local py="$1/bin/python3"
    [ -x "$py" ] || return 1
    local minor
    minor=$("$py" -c 'import sys; print(sys.version_info[1] if sys.version_info[0]==3 else 99)' 2>/dev/null)
    [ -n "$minor" ] && [ "$minor" -lt 13 ]
}

asegurar_uv_disponible() {
    if ! command_exists uv; then
        curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
        export PATH="$HOME/.local/bin:$PATH"
    fi
}

crear_venv_phone_mcp() {
    local venv_dir="$1"
    asegurar_uv_disponible
    if command_exists uv; then
        uv python install "$PHONE_MCP_PY_VERSION" >/dev/null 2>&1
        uv venv --python "$PHONE_MCP_PY_VERSION" "$venv_dir"
    else
        python3 -m venv "$venv_dir"
    fi
}

resolve_phone_mcp_venv() {
    if [ -x "/root/myenv31014/bin/python" ] && phone_mcp_venv_compatible "/root/myenv31014"; then
        PHONE_MCP_VENV="/root/myenv31014"
    elif [ -d "/root/myenv31014" ]; then
        print_warning "El venv compartido usa una versión de Python sin wheels disponibles para las dependencias de phone-mcp. Se recreará con Python $PHONE_MCP_PY_VERSION..."
        rm -rf "/root/myenv31014"
        crear_venv_phone_mcp "/root/myenv31014" || print_error_exit "No se pudo recrear el entorno virtual compartido."
        PHONE_MCP_VENV="/root/myenv31014"
    else
        PHONE_MCP_VENV="$HOME/.phone_mcp_venv"
        if [ ! -x "$PHONE_MCP_VENV/bin/python" ] || ! phone_mcp_venv_compatible "$PHONE_MCP_VENV"; then
            echo "Creando entorno virtual dedicado para phone-mcp (Python $PHONE_MCP_PY_VERSION)..."
            rm -rf "$PHONE_MCP_VENV"
            apt install -y python3 python3-pip python3-venv >/dev/null 2>&1
            crear_venv_phone_mcp "$PHONE_MCP_VENV" || print_error_exit "No se pudo crear el entorno virtual para phone-mcp."
        fi
    fi
    PHONE_MCP_PYTHON="$PHONE_MCP_VENV/bin/python"
    PHONE_MCP_CLI="$PHONE_MCP_VENV/bin/phone-cli"
}

# La forma confiable de verificar que phone-mcp está operativo es el
# comando phone-cli (su entry point real), no "import phone_mcp": ese
# import puede fallar en tiempo de ejecución si el paquete "mcp" instalado
# es incompatible, aunque phone-mcp esté técnicamente instalado.
phone_mcp_operativo() {
    [ -x "$PHONE_MCP_CLI" ] || return 1
    "$PHONE_MCP_CLI" --help >/dev/null 2>&1
}

integrate_mcp() {
    print_header "Paso 4: Integrando con MCP (phone-mcp)"

    # Verificar ADB
    if ! command_exists adb; then
        print_warning "ADB no está instalado. Instalando..."
        apt install -y adb || print_error_exit "No se pudo instalar ADB."
        print_success "ADB instalado correctamente."
    else
        print_success "ADB ya está instalado."
    fi

    print_header "Verificando conexión ADB"
    adb start-server >/dev/null 2>&1
    sleep 1
    devices=$(adb devices | sed '1d')

    if echo "$devices" | grep -q "unauthorized"; then
        print_warning "Dispositivo no autorizado. Autorízalo en el teléfono y presiona ENTER para continuar..."
        read -r
        adb devices
    elif echo "$devices" | grep -Eq "(emulator-5554|192\.168\.|device$)"; then
        print_success "Dispositivo ADB conectado correctamente:"
        echo "$devices" | grep -E "(emulator-5554|192\.168\.|device$)"
    else
        print_warning "No se detectó un dispositivo válido. Conéctalo y presiona ENTER..."
        read -r
        adb devices
    fi

    # Verificar UV (Package Manager) — ya no se usa para ejecutar phone-mcp,
    # pero se deja disponible por si alguna otra herramienta lo necesita.
    if command_exists uv; then
        print_success "UV ya está instalado ($(uv --version 2>/dev/null))."
    else
        print_warning "UV no encontrado. Instalando..."
        curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1 || print_error_exit "No se pudo instalar UV."
        export PATH="$HOME/.local/bin:$PATH"
        grep -q 'export PATH="\$HOME/.local/bin:\$PATH"' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
        print_success "UV instalado correctamente."
    fi

    # Verificar / instalar phone-mcp en su venv persistente
    resolve_phone_mcp_venv

    if phone_mcp_operativo; then
        version=$(uv pip show --python "$PHONE_MCP_PYTHON" phone-mcp 2>/dev/null | awk '/^Version/ {print $2}')
        print_success "Phone MCP ya está instalado y operativo (versión ${version:-desconocida}). No se reinstalará."
    else
        print_warning "Phone MCP no encontrado o incompleto. Instalando (con mcp<2 y requests)..."
        PHONE_MCP_LOG="/tmp/phone_mcp_install_gemini.log"
        uv pip install --python "$PHONE_MCP_PYTHON" "phone-mcp" "mcp<2" "requests" 2>&1 | tee "$PHONE_MCP_LOG"

        if phone_mcp_operativo; then
            print_success "Phone MCP instalado correctamente."
        else
            echo -e "${C_RED}Últimas líneas del log de instalación:${C_NONE}"
            tail -n 20 "$PHONE_MCP_LOG"
            print_error_exit "No se pudo instalar phone-mcp. Log completo en: $PHONE_MCP_LOG"
        fi
    fi

    # Configurar el servidor MCP en Gemini apuntando directo al venv
    # persistente (python -m phone_mcp), en vez de "uvx phone-mcp".
    print_header "Configurando integración MCP en Gemini CLI"
    if gemini mcp list 2>/dev/null | grep -q "phone-mcp" && \
       grep -rq "myenv31014\|.phone_mcp_venv" "$HOME/.gemini" 2>/dev/null; then
        print_success "La integración MCP ya está configurada. No se modificará."
    else
        gemini mcp remove --scope user phone-mcp &>/dev/null || true
        gemini mcp add --scope user phone-mcp "$PHONE_MCP_PYTHON" -m phone_mcp \
            || print_error_exit "Error al añadir el servidor MCP a Gemini CLI."
        print_success "Servidor MCP phone-mcp configurado (venv persistente, sin uvx)."
    fi

    # Nota: NO se lanza manualmente "uvx phone-mcp &" en segundo plano.
    # Un servidor MCP por stdio no se puede "adjuntar" desde un proceso ya
    # corriendo: cada cliente (Gemini, Amazon Q, etc.) lanza su propia
    # instancia del comando configurado cuando la necesita. Mantener un
    # proceso en background aparte no cumplía ninguna función real.

    print_header "Estado de los servidores MCP en Gemini"
    # Justo después de registrar el servidor, Gemini todavía no intentó
    # conectarlo (lo hace la primera vez que se usa en una sesión de chat),
    # así que "gemini mcp list" puede mostrar "Disconnected" sin que eso
    # signifique un problema real. Reintentamos unos segundos para dar
    # tiempo a que arranque antes de reportar el estado final.
    MCP_LIST_LOG="/tmp/gemini_mcp_list.log"
    MCP_LISTO=0
    for intento in $(seq 1 8); do
        gemini mcp list > "$MCP_LIST_LOG" 2>&1
        if ! grep -q "✗" "$MCP_LIST_LOG"; then
            MCP_LISTO=1
            break
        fi
        sleep 2
    done

    cat "$MCP_LIST_LOG"

    if [ "$MCP_LISTO" -eq 1 ]; then
        print_success "phone-mcp conectado correctamente."
    else
        print_warning "phone-mcp todavía no confirma conexión en este chequeo puntual. No es necesariamente un error: abre 'gemini' y corre '/mcp' para ver el estado real dentro de una sesión de chat."
    fi

    source "$HOME/.bashrc" 2>/dev/null || true
}

# --- MAIN ---
main() {
    esperar_conexion_internet
    install_dependencies
    install_gemini_cli
    configure_api_key
    integrate_mcp
    print_header "🎉 Instalación completada correctamente 🎉"
    print_warning "Ejecuta 'source ~/.bashrc' o reinicia la terminal para aplicar cambios."
}

main

# En caso de errores:
# rm -rf /root/.nvm/versions/node/v20.19.5/lib/node_modules/@google/gemini-cli
# npm cache clean --force
