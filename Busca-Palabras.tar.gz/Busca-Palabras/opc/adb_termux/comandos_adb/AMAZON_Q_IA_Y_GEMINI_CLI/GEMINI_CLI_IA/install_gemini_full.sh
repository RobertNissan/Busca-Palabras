#!/bin/bash

# Instalador mejorado: Node.js, Gemini CLI, ADB y phone-mcp
# Compatible con Termux / Ubuntu en Android

# COLORES
C_CYAN='\033[0;36m'
C_GREEN='\033[0;32m'
C_YELLOW='\033[1;33m'
C_RED='\033[0;31m'
C_NONE='\033[0m'

print_header() { echo -e "\n${C_CYAN}--- $1 ---${C_NONE}"; }
print_success() { echo -e "${C_GREEN}✅ $1${C_NONE}"; }
print_warning() { echo -e "${C_YELLOW}⚠️ $1${C_NONE}"; }
print_error_exit() { echo -e "${C_RED}❌ Error: $1${C_NONE}"; exit 1; }

command_exists() { command -v "$1" &>/dev/null; }

# --- PASO 1 ---
install_dependencies() {
    print_header "Paso 1: Instalando Dependencias (Node.js y NVM)"

    if ! command_exists nvm; then
        echo "Instalando NVM..."
        apt update -y && apt install -y curl || print_error_exit "No se pudo instalar curl."
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash || print_error_exit "Fallo instalando NVM."
    else
        print_success "NVM ya está instalado."
    fi

    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"

    if nvm ls 20 | grep -q "v20"; then
        print_success "Node.js v20 ya está instalado."
    else
        echo "Instalando Node.js v20..."
        nvm install 20 || print_error_exit "Fallo al instalar Node.js v20."
    fi

    nvm use 20 >/dev/null
    nvm alias default 20 >/dev/null

    print_success "Node.js $(node -v), NPM $(npm -v)"
}

# --- PASO 2 ---
install_gemini_cli() {
    print_header "Paso 2: Instalando Gemini CLI"

    if command_exists gemini; then
        print_success "Gemini CLI ya está instalado."
    else
        npm install -g @google/gemini-cli || print_error_exit "Falló la instalación de Gemini CLI."
        print_success "Gemini CLI instalado correctamente."
    fi
    gemini --version
}

# --- PASO 3 ---
configure_api_key() {
    print_header "Paso 3: Configurando la API Key de Gemini"

    if grep -q "export GEMINI_API_KEY=" ~/.bashrc; then
        print_success "API key ya configurada en ~/.bashrc."
    else
        echo "Obtén tu API Key en: https://aistudio.google.com/app/api-keys"
        read -p "Pega tu API Key aquí: " api_key
        [ -z "$api_key" ] && print_error_exit "No se ingresó ninguna API key."
        echo -e "\n# Google Gemini API Key\nexport GEMINI_API_KEY=\"$api_key\"" >> ~/.bashrc
        print_success "API key guardada en ~/.bashrc."
        source /root/.bashrc
    fi
}

# --- PASO 4 ---
integrate_mcp() {
    print_header "Paso 4: Integrando con MCP (phone-mcp)"

    # Verificar ADB
    if ! command_exists adb; then
        print_warning "ADB no está instalado. Instalando..."
        apt install -y adb || print_error_exit "No se pudo instalar ADB."
        print_success "ADB instalado correctamente."
    fi

    print_header "Verificando conexión ADB"
    adb start-server >/dev/null 2>&1
    sleep 1
    devices=$(adb devices | sed '1d')

    if echo "$devices" | grep -q "unauthorized"; then
        print_warning "Dispositivo no autorizado. Autorízalo en el teléfono y presiona ENTER para continuar..."
        read
        adb devices
    elif echo "$devices" | grep -Eq "(emulator-5554|192\.168\.)"; then
        print_success "Dispositivo ADB conectado correctamente:"
        echo "$devices" | grep -E "(emulator-5554|192\.168\.)"
    else
        print_warning "No se detectó un dispositivo válido (ni IP local ni emulador). Conéctalo y presiona ENTER..."
        read
        adb devices
    fi

    # Verificar UV (Package Manager)
    if ! command_exists uv; then
        print_warning "UV no encontrado. Instalando..."
        curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1 || print_error_exit "No se pudo instalar UV."
        export PATH="$HOME/.local/bin:$PATH"
        grep -q 'export PATH="\$HOME/.local/bin:\$PATH"' ~/.bashrc || echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    else
        print_success "UV ya instalado."
    fi

    # Verificar phone-mcp
    if python3 -c "import phone_mcp" 2>/dev/null; then
        version=$(pip show phone-mcp 2>/dev/null | awk '/Version/ {print $2}')
        print_success "Phone MCP ya está instalado (versión $version)."
    else
        print_warning "Instalando phone-mcp..."
        pip install phone-mcp -q || print_error_exit "No se pudo instalar phone-mcp."
        print_success "Phone MCP instalado correctamente."
    fi

    # Configurar Gemini MCP
    gemini mcp remove --scope user phone-mcp &>/dev/null
    gemini mcp add --scope user phone-mcp uvx phone-mcp || print_error_exit "Error al añadir servidor MCP."

    print_header "Iniciando servidor phone-mcp..."
    pkill -f "uvx phone-mcp" 2>/dev/null
    nohup uvx phone-mcp >/tmp/phone-mcp.log 2>&1 &
    MCP_PID=$!

    if ps -p "$MCP_PID" >/dev/null 2>&1; then
        print_success "Servidor phone-mcp iniciado (PID $MCP_PID)."
        sleep 3
        gemini mcp list
    else
        print_error_exit "No se pudo iniciar el servidor phone-mcp."
    fi
    source /root/.bashrc
}

# --- MAIN ---
main() {
    install_dependencies
    install_gemini_cli
    configure_api_key
    integrate_mcp
    print_header "🎉 Instalación completada correctamente 🎉"
    print_warning "Ejecuta 'source ~/.bashrc' o reinicia la terminal para aplicar cambios."
}

main


: '
echo "--- Configurando MCP en Gemini CLI ---"

# Paso 1: Asegurarse de que ADB esté conectado
echo "Verificando conexión ADB..."
adb devices
if [ $? -ne 0 ]; then
    echo "Error: ADB no está configurado o no hay dispositivos conectados. Por favor, asegúrate de que ADB esté instalado y un dispositivo esté conectado."
    exit 1
fi
echo "Dispositivo ADB conectado."

# Paso 2: Eliminar configuraciones MCP previas (opcional, para limpieza)
echo "Eliminando configuraciones MCP previas (si existen)..."
gemini mcp remove --scope user my-mcp-server 2>/dev/null
gemini mcp remove --scope user phone-mcp 2>/dev/null

# Paso 3: Añadir la configuración del servidor phone-mcp a Gemini CLI
echo "Añadiendo la configuración del servidor phone-mcp a Gemini CLI..."
gemini mcp add --scope user phone-mcp uvx phone-mcp

# Paso 4: Iniciar el servidor phone-mcp en segundo plano
echo "Iniciando el servidor phone-mcp en segundo plano..."
uvx phone-mcp &
MCP_PID=$!
echo "Servidor phone-mcp iniciado con PID: $MCP_PID"

# Paso 5: Verificar el estado de la conexión MCP
echo "Verificando el estado de la conexión MCP (espera unos segundos)..."
sleep 5
gemini mcp list

echo "--- Configuración MCP completada ---"
echo "Asegúrate de que el servidor phone-mcp aparezca como 'Connected' en la lista."
echo "Si necesitas detener el servidor, usa: kill $MCP_PID"
: '

# En caso de errores:
# rm -rf /root/.nvm/versions/node/v20.19.5/lib/node_modules/@google/gemini-cli
# npm cache clean --force


