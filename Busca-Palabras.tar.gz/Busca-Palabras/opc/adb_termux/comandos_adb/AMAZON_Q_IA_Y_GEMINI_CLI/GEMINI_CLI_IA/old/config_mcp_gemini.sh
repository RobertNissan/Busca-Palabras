#!/bin/bash

echo "--- Configurando MCP en Gemini CLI ---"

# Paso 1: Asegurarse de que ADB esté conectado
echo "Verificando conexión ADB..."
adb devices
if [ $? -ne 0 ]; then
    echo "Error: ADB no está configurado o no hay dispositivos conectados. Por favor, asegúrate de que ADB esté instalado y un dispositivo esté conectado."
    exit 1
fi
echo "Dispositivo ADB conectado."

# Paso 2: Eliminar configuraciones MCP previas (opcional, para limpieza)
echo "Eliminando configuraciones MCP previas (si existen)..."
gemini mcp remove --scope user my-mcp-server 2>/dev/null
gemini mcp remove --scope user phone-mcp 2>/dev/null

# Paso 3: Añadir la configuración del servidor phone-mcp a Gemini CLI
echo "Añadiendo la configuración del servidor 'phone-mcp' a Gemini CLI..."
gemini mcp add --scope user phone-mcp uvx phone-mcp

# Paso 4: Iniciar el servidor phone-mcp en segundo plano
echo "Iniciando el servidor 'phone-mcp' en segundo plano..."
uvx phone-mcp &
MCP_PID=$!
echo "Servidor 'phone-mcp' iniciado con PID: $MCP_PID"

# Paso 5: Verificar el estado de la conexión MCP
echo "Verificando el estado de la conexión MCP (espera unos segundos)..."
sleep 5
gemini mcp list

echo "--- Configuración MCP completada ---"
echo "Asegúrate de que el servidor 'phone-mcp' aparezca como 'Connected' en la lista."
echo "Si necesitas detener el servidor, usa 'kill $MCP_PID'"
