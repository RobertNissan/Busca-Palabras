#!/bin/bash

# instalador nvm y nodejs offline para descargar gemini sin bugs
# https://mega.nz/file/nBgz0CpQ#HFUsw53Acn16w_jgBl7CmrWDh-da56e8cS6jXqEwdQA

# COLORES
C_CYAN='\033[0;36m'
C_GREEN='\033[0;32m'
C_YELLOW='\033[1;33m'
C_RED='\033[0;31m'
C_NONE='\033[0m'

# --- FUNCIONES AUXILIARES ---

# Imprime un encabezado
print_header() {
    echo -e "\n${C_CYAN}--- $1 ---${C_NONE}"
}

# Imprime un mensaje de éxito
print_success() {
    echo -e "${C_GREEN}✅ $1${C_NONE}"
}

# Imprime una advertencia
print_warning() {
    echo -e "${C_YELLOW}⚠️ $1${C_NONE}"
}

# Imprime un error y sale
print_error_exit() {
    echo -e "${C_RED}❌ Error: $1${C_NONE}"
    exit 1
}

# Verifica si un comando existe
command_exists() {
    command -v "$1" &> /dev/null
}

# --- LÓGICA PRINCIPAL ---

# 1. INSTALACIÓN DE DEPENDENCIAS (NVM Y NODE.JS)
install_dependencies() {
    print_header "Paso 1: Instalando Dependencias (Node.js y NVM)"
    
    if ! command_exists nvm; then
        echo "Instalando Node.js y NVM (Node Version Manager)..."
        # Actualizar paquetes e instalar dependencias
        apt update && apt install -y curl
        
        # Instalar NVM
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
        
        # Cargar NVM en la sesión actual
        export NVM_DIR="$HOME/.nvm"
        [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
        
        print_success "NVM instalado."
    else
        print_success "NVM ya está instalado."
        export NVM_DIR="$HOME/.nvm"
        [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    fi

    # Instalar y usar Node.js v20
    if ! nvm ls 20 | grep -q "N/A"; then
        echo "Node.js v20 ya está instalado."
    else
        echo "Instalando Node.js v20..."
        nvm install 20 || print_error_exit "Falló la instalación de Node.js v20."
        # nvm install 20 --reinstall-packages
    fi
    
    nvm use 20
    nvm alias default 20
    
    echo -n "Verificando versiones: Node -> "
    node -v
    echo -n "NPM -> "
    npm -v
    print_success "Node.js configurado."
}

# 2. INSTALACIÓN DE GEMINI CLI
install_gemini_cli() {
    print_header "Paso 2: Instalando Gemini CLI"
    if command_exists gemini; then
        print_success "Gemini CLI ya está instalado."
    else
        echo "Instalando @google/gemini-cli globalmente..."
        npm install -g @google/gemini-cli || print_error_exit "Falló la instalación de Gemini CLI."
        print_success "Gemini CLI instalado correctamente."
    fi
    which gemini
    gemini --version
}

# 3. CONFIGURACIÓN DE LA API KEY
configure_api_key() {
    print_header "Paso 3: Configurando la API Key de Gemini"
    
    # Verificar si la API key ya está en .bashrc
    if grep -q "export GEMINI_API_KEY=" ~/.bashrc; then
        print_success "La variable GEMINI_API_KEY ya está configurada en ~/.bashrc."
    else
        echo -e "${C_YELLOW}Necesitas una API key de Google AI Studio.${C_NONE}"
        echo "Puedes obtenerla aquí: https://aistudio.google.com/app/api-keys"
        read -p "Por favor, pega tu API key y presiona Enter: " api_key
        
        if [ -z "$api_key" ]; then
            print_error_exit "No se ingresó ninguna API key. Abortando."
        fi
        
        # Añadir la key al .bashrc
        echo '' >> ~/.bashrc
        echo '# Google Gemini CLI API Key' >> ~/.bashrc
        echo "export GEMINI_API_KEY=\"$api_key\"" >> ~/.bashrc
        
        print_success "API key guardada en ~/.bashrc."
        # print_warning "Por favor, ejecuta 'source ~/.bashrc' o reinicia tu terminal para aplicar los cambios."
        source /root/.bashrc
    fi
}

# 4. INTEGRACIÓN CON MCP
integrate_mcp() {
    print_header "Paso 4: Integrando con MCP (phone-mcp)"

    # Verificar si adb está instalado
    if ! command -v adb >/dev/null 2>&1; then
        print_warning "ADB no está instalado. Instalando ADB..."
        apt install -y adb
        if [ $? -ne 0 ]; then
            print_warning "No se pudo instalar ADB. Verifica tu conexión a internet o repositorios."
        else
            print_success "ADB instalado correctamente." >/dev/null
        fi
    fi

    echo "Verificando conexión ADB..."
    adb devices
    if [ $? -ne 0 ]; then
        print_warning "ADB no parece estar funcionando. Asegúrate de que tu dispositivo esté conectado y accesible."
        # No salimos, permitimos que el usuario lo arregle y continúe si es posible.
    else
        print_success "Dispositivo ADB detectado."
    fi

    if ! command_exists uvx; then
        print_warning "'uvx' no encontrado. Asegúrate de tener 'phone-mcp' instalado (ej. 'pip install phone-mcp')."
    fi

    echo "Limpiando configuraciones MCP previas..."
    gemini mcp remove --scope user my-mcp-server &>/dev/null
    gemini mcp remove --scope user phone-mcp &>/dev/null

    echo "Añadiendo servidor 'phone-mcp' a Gemini..."
    gemini mcp add --scope user phone-mcp uvx phone-mcp || print_error_exit "No se pudo añadir el servidor MCP."

    echo "Iniciando servidor 'phone-mcp' en segundo plano..."
    # Matar procesos anteriores si existen
    pkill -f "uvx phone-mcp"
    sleep 2
    
    if ! command -v uv >/dev/null 2>&1; then
        echo -e "📥 ${YELLOW}Instalando UV package manager${RESET}..."
        curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
        export PATH="$HOME/.local/bin:$PATH"         
        if ! grep -q "export PATH=\"\$HOME/.local/bin:\$PATH\"" ~/.bashrc; then
            echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc
        fi
    else
        echo -e "✅ ${GREEN}UV ya está instalado${RESET}"
    fi
            
    export PATH="$HOME/.local/bin:$PATH"
    if python3 -c "import phone_mcp" 2>/dev/null; then
        version=$(pip show phone-mcp | grep Version | awk "{print \$2}" 2>/dev/null || echo "desconocida")
        echo -e "✅ ${GREEN}Phone MCP ya está instalado (versión $version)${RESET}"
    else
        echo -e "📱 ${YELLOW}Instalando Phone MCP${RESET}..."
        pip install phone-mcp >/dev/null 2>&1
    fi
    MCP_PID=$!

    if ps -p $MCP_PID > /dev/null; then
        print_success "Servidor 'phone-mcp' iniciado con PID: $MCP_PID"
        echo "Verificando estado de la conexión (esperando 5 segundos)..."
        sleep 5
        gemini mcp list
        print_warning "Si necesitas detener el servidor, usa 'kill $MCP_PID'"
    else
        print_error_exit "No se pudo iniciar el servidor 'phone-mcp'."
    fi
}

# --- EJECUCIÓN DEL SCRIPT ---
main() {
    install_dependencies
    install_gemini_cli
    configure_api_key
    integrate_mcp
    
    print_header "🎉 ¡Instalación y configuración completadas! 🎉"
    echo -e "${C_YELLOW}Recuerda ejecutar 'source ~/.bashrc' o reiniciar tu terminal para que la API key esté disponible.${C_NONE}"
}

main


: '
echo "--- Configurando MCP en Gemini CLI ---"

# Paso 1: Asegurarse de que ADB esté conectado
echo "Verificando conexión ADB..."
adb devices
if [ $? -ne 0 ]; then
    echo "Error: ADB no está configurado o no hay dispositivos conectados. Por favor, asegúrate de que ADB esté instalado y un dispositivo esté conectado."
    exit 1
fi
echo "Dispositivo ADB conectado."

# Paso 2: Eliminar configuraciones MCP previas (opcional, para limpieza)
echo "Eliminando configuraciones MCP previas (si existen)..."
gemini mcp remove --scope user my-mcp-server 2>/dev/null
gemini mcp remove --scope user phone-mcp 2>/dev/null

# Paso 3: Añadir la configuración del servidor phone-mcp a Gemini CLI
echo "Añadiendo la configuración del servidor phone-mcp a Gemini CLI..."
gemini mcp add --scope user phone-mcp uvx phone-mcp

# Paso 4: Iniciar el servidor phone-mcp en segundo plano
echo "Iniciando el servidor phone-mcp en segundo plano..."
uvx phone-mcp &
MCP_PID=$!
echo "Servidor phone-mcp iniciado con PID: $MCP_PID"

# Paso 5: Verificar el estado de la conexión MCP
echo "Verificando el estado de la conexión MCP (espera unos segundos)..."
sleep 5
gemini mcp list

echo "--- Configuración MCP completada ---"
echo "Asegúrate de que el servidor phone-mcp aparezca como 'Connected' en la lista."
echo "Si necesitas detener el servidor, usa: kill $MCP_PID"
: '