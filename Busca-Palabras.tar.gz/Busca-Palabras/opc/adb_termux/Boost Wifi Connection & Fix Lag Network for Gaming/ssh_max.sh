# redirige el puerto 8022 del dispositivo al PC
adb devices
adb forward tcp:8022 tcp:8022

# conéctate vía SSH al servidor Termux
# reemplaza `u0_aNNN` por el valor que te devolvió `whoami` en Termux
ssh -p 8022 u0_a275@127.0.0.1


# En el  celular servidor 
usr_server=$(whoami)
sshd -D -e -p 2222 -4
sshd -D -e -p 2222 -4 -o ListenAddress=192.168.20.114
Server listening on 192.168.20.114 port 2222.
# En otra sesión o cliente 
# En el  celular servidor 
ssh -p 2222 ${usr_server}@192.168.20.114
# puedes hacer forward en el cliente si quieres 
adb forward tcp:2222 tcp:2222


sshd -p 2222
ps aux | grep sshd
u0_a275  31422  0.0  0.0 10777380 1796 ?       S<s   1970   0:00 sshd -p 2222
u0_a275  31477  0.0  0.0 10772092 2828 pts/4   S<+   1970   0:00 grep sshd
# Antes de volver a hacer adb forward, elimina cualquier reenvío previo:

adb forward --remove tcp:2222
# o limpia todos los reenvíos de golpe:
adb forward --remove-all
# Luego puedes volver a poner:
adb forward tcp:2222 tcp:2222
adb forward tcp:2222 tcp:2222
ssh -p 2222 u0_a275@127.0.0.1
u0_a275@127.0.0.1's password: