#!/data/data/com.termux/files/usr/bin/bash
# wifi_latency_no_anim.sh — aplicar tweaks Wi-Fi (sin animaciones ni cambios de rutas)
set -euo pipefail

ADB=$(command -v adb || true)
if [ -z "$ADB" ]; then
  echo "ERROR: adb no está en PATH. Instala adb en Termux y vuelve a intentar."
  exit 1
fi

if ! adb get-state 1>/dev/null 2>&1; then
  echo "ERROR: no se detecta dispositivo ADB. Conecta el teléfono y habilita depuración."
  exit 1
fi

# Obtener IP wlan0
IP=$(adb shell ip -f inet addr show wlan0 2>/dev/null | awk '/inet /{print $2}' | cut -d'/' -f1 | tr -d '\r' || true)
if [ -z "$IP" ]; then
  echo "No se detectó IP en wlan0. Asegúrate de que el Wi-Fi esté conectado."
  exit 1
fi

# Calcular gateway asumiendo .1 si no hay default via wlan0
# Intentamos obtener gateway real; si no, usamos x.y.z.1
GW=$(adb shell ip route | awk '/default/ && /wlan0/ {for(i=1;i<=NF;i++) if($i=="via") print $(i+1)}' | tr -d '\r' || true)
if [ -z "$GW" ]; then
  # asumir .1
  GW=$(printf "%s\n" "$IP" | awk -F'.' '{print $1"."$2"."$3".1"}')
fi

echo "IP detectada: $IP"
echo "Gateway asumido/seleccionado: $GW"
echo

# función que ejecuta ping en el dispositivo y devuelve la línea rtt (min/avg/max/mdev)
ping_stats() {
  TARGET="$1"
  COUNT="${2:-20}"
  OUT=$(adb exec-out ping -c "$COUNT" "$TARGET" 2>/dev/null || true)
  printf "%s\n" "$OUT"
  # devolver la línea rtt si existe
  echo "$OUT" | awk -F' = ' '/rtt|round-trip/ {print $2; exit}'
}

# función extrae avg y mdev de "min/avg/max/mdev" o "min/avg/max/stddev"
parse_avg_mdev() {
  LINE="$1" # ejemplo: "2.943/3.800/5.788/1.089 ms" o "min/avg/max/mdev = 2.943/3.800/5.788/1.089 ms"
  if [ -z "$LINE" ]; then
    echo "N/A N/A"
    return
  fi
  # quitar sufijos
  # separar por '/'
  AVG=$(printf "%s" "$LINE" | awk -F'/' '{print $2}')
  MDEV=$(printf "%s" "$LINE" | awk -F'/' '{print $4}' | sed 's/[^0-9.\-]//g')
  if [ -z "$AVG" ]; then AVG="N/A"; fi
  if [ -z "$MDEV" ]; then MDEV="N/A"; fi
  echo "$AVG" "$MDEV"
}

echo "== Test inicial: ping al gateway ($GW) y a Internet (8.8.8.8) =="
R1=$(ping_stats "$GW" 10)
R1_line=$(echo "$R1" | awk '/rtt|round-trip/ {print $0}' | sed 's/.*= //')
read AVG_GATE_BEFORE MDEV_GATE_BEFORE < <(parse_avg_mdev "$R1_line")
R2=$(ping_stats "8.8.8.8" 10)
R2_line=$(echo "$R2" | awk '/rtt|round-trip/ {print $0}' | sed 's/.*= //')
read AVG_INT_BEFORE MDEV_INT_BEFORE < <(parse_avg_mdev "$R2_line")

echo
echo "== Aplicando tweaks Wi-Fi (sin tocar animaciones) =="
# reducir scans y evitar roaming agresivo; no fallará si key inexistente
adb shell settings put global wifi_scan_always_enabled 0 || true
adb shell settings put global network_avoid_bad_wifi 1 || true
adb shell settings put global wifi_watchdog_on 0 || true

echo "Reiniciando Wi-Fi para aplicar cambios..."
adb shell svc wifi disable
sleep 2
adb shell svc wifi enable
# esperar reconexión moderada
sleep 8

echo
echo "== Test final: ping al gateway ($GW) y a Internet (8.8.8.8) =="
R3=$(ping_stats "$GW" 10)
R3_line=$(echo "$R3" | awk '/rtt|round-trip/ {print $0}' | sed 's/.*= //')
read AVG_GATE_AFTER MDEV_GATE_AFTER < <(parse_avg_mdev "$R3_line")
R4=$(ping_stats "8.8.8.8" 10)
R4_line=$(echo "$R4" | awk '/rtt|round-trip/ {print $0}' | sed 's/.*= //')
read AVG_INT_AFTER MDEV_INT_AFTER < <(parse_avg_mdev "$R4_line")

echo
echo "=== Resumen ==="
printf "Gateway (%s): antes avg=%s ms  mdev=%s ms -> ahora avg=%s ms  mdev=%s ms\n" \
  "$GW" "${AVG_GATE_BEFORE:-N/A}" "${MDEV_GATE_BEFORE:-N/A}" "${AVG_GATE_AFTER:-N/A}" "${MDEV_GATE_AFTER:-N/A}"
printf "Internet:      antes avg=%s ms  mdev=%s ms -> ahora avg=%s ms  mdev=%s ms\n" \
  "${AVG_INT_BEFORE:-N/A}" "${MDEV_INT_BEFORE:-N/A}" "${AVG_INT_AFTER:-N/A}" "${MDEV_INT_AFTER:-N/A}"
echo
echo "Si quieres revertir los cambios (activar scans/roaming/watchdog):"
echo "adb shell settings put global wifi_scan_always_enabled 1"
echo "adb shell settings put global network_avoid_bad_wifi 0"
echo "adb shell settings put global wifi_watchdog_on 1"
echo
echo "Notas:"
echo "- Si el avg al gateway ya está en ~3–5 ms, difícilmente podrás mejorar esa cifra por Wi-Fi."
echo "- Para mejorar latencia a Internet (avg >20 ms), tendrás que mirar ISP/backhaul o usar USB tethering/Ethernet."
adb shell settings put global private_dns_mode hostname
adb shell settings put global private_dns_specifier one.one.one.one

: '
# Si ya te sirve: mantén los tweaks aplicados. Para revertir tienes estos comandos:
adb shell settings put global wifi_scan_always_enabled 1
adb shell settings put global network_avoid_bad_wifi 0
adb shell settings put global wifi_watchdog_on 1

# verificar dns
adb shell settings get global private_dns_mode
adb shell settings get global private_dns_specifier
: '
