#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# ========== CONFIG ==========
RESOLVERS=(
  "1.1.1.1"         # Cloudflare
  "8.8.8.8"         # Google
  "9.9.9.9"         # Quad9
  "208.67.222.222"  # OpenDNS
  "94.140.14.14"    # AdGuard
  "94.140.15.15"    # AdGuard
)
QUERIES=${QUERIES:-5}
DOMAIN="${1:-google.com}"
TOP_N=5
TIMEOUT_CMD=${TIMEOUT_CMD:-timeout}   # en caso de que uses busybox/coreutils

# Mapa IP -> hostname DoT
declare -A DOT_HOST=(
  ["1.1.1.1"]="one.one.one.one"
  ["8.8.8.8"]="dns.google"
  ["9.9.9.9"]="dns.quad9.net"
  ["208.67.222.222"]="resolver1.opendns.com"
  ["94.140.14.14"]="dns.adguard.com"
  ["94.140.15.15"]="dns.adguard.com"
)

# ========== FUNCIONES ==========
print_header() {
  echo "🌐 DNS benchmark · dominio: $DOMAIN"
  echo "   Consultas por resolver: $QUERIES  · Mostrar top $TOP_N"
  echo
}

# Detectar y elegir dispositivo ADB (si adb está presente)
detect_adb_device() {
  if ! command -v adb >/dev/null 2>&1; then
    echo "⚠️  adb no encontrado en PATH. No se aplicará Private DNS automáticamente."
    return 1
  fi

  # lista de dispositivos conectados (ids)
  device_list=$(adb devices | sed '1d' | awk '{print $1}' | sed '/^$/d' || true)

  if [[ -z "$device_list" ]]; then
    echo "❌ No hay dispositivos/emuladores conectados (adb devices vacío)."
    return 1
  fi

  # obtener IP local (varios métodos, toma la primera que funcione)
  LOCAL_IP=""
  LOCAL_IP=$(ip route get 1.1.1.1 2>/dev/null | awk '/src/ {for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}' || true)
  if [[ -z "$LOCAL_IP" ]]; then
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || true)
  fi
  if [[ -n "${MY_IP:-}" ]]; then
    LOCAL_IP="$MY_IP"
  fi

  preferred=""

  # 1) dispositivo que empiece con la IP local (por ejemplo: 192.168.1.10:5555)
  if [[ -n "$LOCAL_IP" ]]; then
    preferred=$(echo "$device_list" | grep -E "^${LOCAL_IP}" | head -n1 || true)
  fi

  # 2) probar emulator-5554
  if [[ -z "$preferred" ]] && echo "$device_list" | grep -qx "emulator-5554"; then
    preferred="emulator-5554"
  fi

  # 3) primer emulator-*
  if [[ -z "$preferred" ]]; then
    preferred=$(echo "$device_list" | grep -E '^emulator-' | head -n1 || true)
  fi

  # 4) primer dispositivo de la lista
  if [[ -z "$preferred" ]]; then
    preferred=$(echo "$device_list" | head -n1)
  fi

  if [[ -z "$preferred" ]]; then
    echo "❌ No pude seleccionar un dispositivo ADB válido."
    return 1
  fi

  # exportar variable para adb
  export ANDROID_SERIAL="$preferred"
  echo "🔌 Usando dispositivo ADB: $ANDROID_SERIAL"

  # comprobar estado del dispositivo seleccionado
  if ! adb -s "$ANDROID_SERIAL" get-state >/dev/null 2>&1; then
    echo "❌ El dispositivo seleccionado ($ANDROID_SERIAL) no responde."
    return 1
  fi

  # comprobar si es emulador
  is_emulator=$(adb -s "$ANDROID_SERIAL" shell getprop ro.kernel.qemu 2>/dev/null || echo "0")
  if [[ "$is_emulator" = "1" ]]; then
    echo "⚠️  Detectado EMULADOR (ro.kernel.qemu=1). Las mediciones pueden no reflejar la latencia real."
  fi

  return 0
}

# Ejecuta una única consulta y obtiene el tiempo en ms (entero)
query_time_ms() {
  local resolver_ip="$1"
  local target="$2"
  # dig +stats escribe "Query time: 23 msec" -> extraer números
  local out
  out=$($TIMEOUT_CMD 3 dig @"$resolver_ip" "$target" +time=2 +tries=1 +stats 2>/dev/null || true)
  if [[ -z "$out" ]]; then
    echo 9999
    return
  fi
  local q
  q=$(echo "$out" | awk -F': ' '/Query time/ {print $2; exit}' | grep -oE '[0-9]+' || true)
  if [[ -z "$q" ]]; then
    echo 9999
  else
    echo "$q"
  fi
}

# ========== MAIN ==========
print_header

tmpfile=$(mktemp)
trap 'rm -f "$tmpfile"' EXIT

for ip in "${RESOLVERS[@]}"; do
  sum=0
  echo "🔹 Probando $ip ..."
  for i in $(seq 1 $QUERIES); do
    q=$(query_time_ms "$ip" "$DOMAIN")
    # q es entero en ms o 9999 si fallo
    sum=$((sum + q))
    # pequeño sleep para no saturar
    sleep 0.15
  done
  avg=$((sum / QUERIES))
  printf "   ➤ Promedio: %d ms\n" "$avg"
  # almacenar: avg ip
  printf "%06d %s\n" "$avg" "$ip" >> "$tmpfile"
done

echo
echo "📋 Top $TOP_N resolvers (más rápidos primero):"
# ordenar numérico ascendente y mostrar top N
sort -n "$tmpfile" | head -n "$TOP_N" | nl -w2 -s'. ' -v1 | while read -r line; do
  # line: " 1. 000023 1.1.1.1"
  # limpiar ceros y mostrar hostname DoT si existe
  avg=$(echo "$line" | awk '{print $2}' | sed 's/^0*//')
  [[ -z "$avg" ]] && avg=0
  ip=$(echo "$line" | awk '{print $3}')
  hostdot="${DOT_HOST[$ip]:-}"
  if [[ -n "$hostdot" ]]; then
    echo "   $line  → ${avg}ms  (DoT: $hostdot)"
  else
    echo "   $line  → ${avg}ms"
  fi
done

# Mejor IP (la primera línea del archivo ordenado)
best_line=$(sort -n "$tmpfile" | head -n1 || true)
if [[ -z "$best_line" ]]; then
  echo "❌ No se obtuvieron resultados válidos."
  exit 1
fi
best_ip=$(echo "$best_line" | awk '{print $2}')
best_avg=$(echo "$best_line" | awk '{print $1}' | sed 's/^0*//')
[[ -z "$best_avg" ]] && best_avg="0"

echo
echo "⚡ Fastest DNS: $best_ip (${best_avg}ms)"

# Intentar detectar un dispositivo ADB y aplicar DoT si hay mapping
if detect_adb_device >/dev/null 2>&1; then
  hostdot="${DOT_HOST[$best_ip]:-}"
  if [[ -n "$hostdot" ]]; then
    echo "🔗 Mapeado $best_ip -> DoT hostname: $hostdot"
    echo "🛠 Aplicando Private DNS (DoT) en dispositivo $ANDROID_SERIAL..."

    # aplicar settings en el dispositivo seleccionado
    adb -s "$ANDROID_SERIAL" shell settings put global private_dns_mode hostname || true
    adb -s "$ANDROID_SERIAL" shell settings put global private_dns_specifier "$hostdot" || true

    # intentar rebind de Wi-Fi para forzar reload (si aplica)
    echo "🔄 Rebinding Wi-Fi (si está disponible en el dispositivo)..."
    adb -s "$ANDROID_SERIAL" shell svc wifi disable || true
    sleep 2
    adb -s "$ANDROID_SERIAL" shell svc wifi enable || true
    sleep 1

    echo
    echo "✅ Private DNS aplicado. Valores actuales en el dispositivo:"
    echo "Mode:      $(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_mode 2>/dev/null || true)"
    echo "Specifier: $(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_specifier 2>/dev/null || true)"
  else
    echo "⚠️ No hay hostname DoT mapeado para $best_ip. No se aplicó Private DNS automáticamente."
    echo "   Si quieres forzar uno, añade DOT_HOST[\"$best_ip\"]=\"tu.hostname\" en el script."
  fi

else
  echo
  echo "ℹ️ adb no disponible o no hay dispositivo operativo. Solo se mostraron los top $TOP_N resolvers."
fi

echo
echo "💡 Cómo revertir Private DNS en Android (en el mismo dispositivo):"
echo "adb -s \$ANDROID_SERIAL shell settings put global private_dns_mode off"
echo
echo "📌 Verificar configuración actual (ejemplo):"
echo "adb -s \$ANDROID_SERIAL shell settings get global private_dns_mode"
echo "adb -s \$ANDROID_SERIAL shell settings get global private_dns_specifier"