#!/data/data/com.termux/files/usr/bin/bash
# mejorar_latencia_wifi_sin_animaciones.sh
set -euo pipefail

# detectar gateway Wi-Fi
GW=$(adb shell ip route | awk '/wlan0/ {print $1}' | tr -d '\r')
GW=${GW:-192.168.20.1}

# mostrar info
echo "== Info actual =="
adb shell ip addr show wlan0
adb shell ip route show
echo "Gateway detectado para Wi-Fi: $GW"
echo

# redirigir ruta por defecto a Wi-Fi
echo "== Redirigiendo ruta por defecto a Wi-Fi..."
adb shell ip route add default via $GW dev wlan0 || echo "(ya existe o fallo)"
adb shell ip route del default dev seth_lte0 || echo "(se omite si no hay ruta LTE)"
adb shell ip route show
echo

# tweaks sin root (solo Wi-Fi, sin tocar animaciones)
echo "== Aplicando tweaks Wi-Fi sin tocar animaciones..."
adb shell settings put global wifi_scan_always_enabled 0 || true
adb shell settings put global network_avoid_bad_wifi 1 || true

# reiniciar Wi-Fi para aplicar cambios
echo "== Reiniciando Wi-Fi..."
adb shell svc wifi disable
sleep 2
adb shell svc wifi enable
sleep 5
echo "IP tras reconexión:"
adb shell ip addr show wlan0
adb shell ip route show
echo

# test de ping
echo "== Test ping al router ($GW) =="
adb exec-out ping -c 10 $GW
echo
echo "== Test ping a Internet (8.8.8.8) =="
adb exec-out ping -c 10 8.8.8.8
echo
echo "== Listo! Ahora tu tráfico debería ir por Wi-Fi con tweaks aplicados."
