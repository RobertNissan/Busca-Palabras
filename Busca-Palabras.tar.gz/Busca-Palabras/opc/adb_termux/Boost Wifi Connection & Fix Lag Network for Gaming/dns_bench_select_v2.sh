# Ping a un servidor rápido
adb exec-out ping -c 10 8.8.8.8

# Ping a tu router para ver latencia local
adb exec-out ping -c 10 192.168.0.1


# Verificar la IP del router al que estoy conectado
root@localhost /s/D/clasificar_textos# adb shell ip addr show wlan0                                                             
63: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000                             
link/ether de:c9:30:01:b6:cb brd ff:ff:ff:ff:ff:ff
    inet 192.168.20.28/24 brd 192.168.20.255 scope global wlan0        
valid_lft forever preferred_lft forever
    inet6 2800:484:b38a:b900:b858:d9ac:e411:76d8/64 scope global temporary dynamic
       valid_lft 598447sec preferred_lft 79561sec                   
inet6 2800:484:b38a:b900:dcc9:30ff:fe01:b6cb/64 scope global dynamic mngtmpaddr                                                    
valid_lft 1116107sec preferred_lft 511307sec                 
inet6 fe80::dcc9:30ff:fe01:b6cb/64 scope link                      
valid_lft forever preferred_lft forever

#Verificar
adb exec-out ping -c 5 192.168.20.1


# Evitar escaneos frecuentes
adb shell settings put global wifi_scan_always_enabled 0
adb shell settings put global network_avoid_bad_wifi 1
# Reducir animaciones UI
adb shell settings put global window_animation_scale 0
adb shell settings put global transition_animation_scale 0
adb shell settings put global animator_duration_scale 0

# refrescar conexión 
adb shell svc wifi disable
sleep 2
adb shell svc wifi enable


adb shell settings put global wifi_scan_always_enabled 0
adb shell settings put global network_avoid_bad_wifi 1

# medir latencia externa 
adb exec-out ping -c 10 8.8.8.8





adb shell ip addr show wlan0
adb shell ip route show default


# mejor dns
adb shell settings put global private_dns_mode hostname
adb shell settings put global private_dns_specifier one.one.one.one

adb -s 192.168.20.22:5555 shell settings put global private_dns_mode hostname
adb -s 192.168.20.22:5555 shell settings put global private_dns_specifier one.one.one.one
adb -s 192.168.20.22:5555 shell svc wifi disable
sleep 2
adb -s 192.168.20.22:5555 shell svc wifi enable


Si usas Google Chrome para jugar en tu Android, hay un método más detallado para limpiar la caché del DNS:
Abre Chrome.
En la barra de direcciones, escribe chrome://net-internals/#dns.
En el panel izquierdo, haz clic en DNS.
En el panel derecho, haz clic en Clear host cache (borrar caché de host).






# aquí un script para usar el mejor dns
#!/data/data/com.termux/files/usr/bin/bash
: '
Requisitos:
  pkg install dnsutils -y
  Si timeout no existe: pkg install coreutils o pkg install busybox
'
set -euo pipefail

# Config – solo resolvers confiables con DoT
RESOLVERS=(
  "1.1.1.1"         # Cloudflare primary
  "1.0.0.1"         # Cloudflare secondary
  "8.8.8.8"         # Google primary
  "8.8.4.4"         # Google secondary
  "9.9.9.9"         # Quad9 primary
  "149.112.112.112" # Quad9 secondary
)

QUERIES=${1:-5}            # número de intentos por resolver (por omisión 5)
DOMAIN=${2:-google.com}   # dominio a medir (por omisión example.com)

# Mapa IP -> hostname DoT (hostnames válidos para DoT / SNI)
declare -A DOT_HOST
DOT_HOST["1.1.1.1"]="one.one.one.one"
DOT_HOST["1.0.0.1"]="one.one.one.one"
DOT_HOST["8.8.8.8"]="dns.google"
DOT_HOST["8.8.4.4"]="dns.google"
DOT_HOST["9.9.9.9"]="dns.quad9.net"
DOT_HOST["149.112.112.112"]="dns.quad9.net"

# Penalización para timeouts/fallos
PENALTY=9999

echo "🌐 Benchmarking DNS — dominio: $DOMAIN — intentos por resolver: $QUERIES"
echo

declare -A AVG_RESULTS
declare -A FAIL_COUNT
declare -A TOTALS

for ip in "${RESOLVERS[@]}"; do
  total=0
  fails=0
  echo "🔹 Testing $ip ..."
  for i in $(seq 1 $QUERIES); do
    # Ejecutamos dig con time y tries; intentamos extraer solo el número de ms
    out=$(dig @"$ip" "$DOMAIN" +time=2 +tries=1 +stats 2>/dev/null || true)
    q=$(echo "$out" | awk -F': ' '/Query time:/ {print $2; exit}' | grep -oE '[0-9]+' || true)

    if [[ -z "$q" ]]; then
      q=$PENALTY
      fails=$((fails+1))
      echo "   intento $i: timeout/fallo → ${q}ms"
    else
      echo "   intento $i: ${q}ms"
    fi

    total=$((total + q))
    # pequeña pausa para no saturar
    sleep 0.15
  done

  avg=$(( total / QUERIES ))
  echo "   ➤ Average query time: ${avg}ms (failures: ${fails}/${QUERIES})"
  echo

  AVG_RESULTS["$ip"]=$avg
  FAIL_COUNT["$ip"]=$fails
  TOTALS["$ip"]=$total
done

# Mostrar ranking ordenado (menor avg primero)
echo "📊 Ranking de resolvers (menor tiempo = mejor):"
for ip in "${!AVG_RESULTS[@]}"; do
  echo "${AVG_RESULTS[$ip]} $ip ${FAIL_COUNT[$ip]}"
done | sort -n | while read -r avg ip fails; do
  succ=$(( QUERIES - fails ))
  if (( QUERIES > 0 )); then
    pct=$(( 100 * succ / QUERIES ))
  else
    pct=0
  fi
  echo "   $ip → ${avg}ms  (exitos: ${succ}/${QUERIES} — ${pct}% )"
done

# Seleccionar el mejor
best_ip=""
best_avg=9999999
for ip in "${!AVG_RESULTS[@]}"; do
  a=${AVG_RESULTS[$ip]}
  if (( a < best_avg )); then
    best_avg=$a
    best_ip=$ip
  fi
done

echo
echo "⚡ Mejor DNS según benchmark: $best_ip (${best_avg}ms)"

hostdot="${DOT_HOST[$best_ip]:-}"

if [[ -z "$hostdot" ]]; then
  echo "⚠️ No hay mapping DoT para $best_ip. No se aplicará Private DNS."
  exit 0
fi

echo "🔗 Mapped to DoT hostname: $hostdot"
# ----------------------------
# Comprobar si hay adb y un dispositivo (prefiere emulator-5554 si existe)
# ----------------------------
if command -v adb >/dev/null 2>&1; then
  # lista de dispositivos conectados (ids)
  device_list=$(adb devices | sed '1d' | awk '{print $1}' | sed '/^$/d')

  if [[ -z "$device_list" ]]; then
    echo "❌ No hay dispositivos/emuladores conectados (adb devices vacío)."
    exit 1
  fi

  # --- obtener IP local (varios métodos, toma la primera que funcione) ---
  LOCAL_IP=""
  LOCAL_IP=$(ip route get 1.1.1.1 2>/dev/null | awk '/src/ {for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
  if [[ -z "$LOCAL_IP" ]]; then
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
  fi
  # permite forzar la IP desde el entorno (opcional)
  if [[ -n "${MY_IP:-}" ]]; then
    LOCAL_IP="$MY_IP"
  fi

  # --- elegir dispositivo preferido (AHORA: emulator-5554 tiene máxima prioridad) ---
  preferred=""

  # 0) si existe emulator-5554 lo usamos siempre
  if echo "$device_list" | grep -qx "emulator-5554"; then
    preferred="emulator-5554"
  fi

  # 1) si no hay emulator-5554, intentar dispositivo que empiece exactamente con la IP local
  if [[ -z "$preferred" && -n "$LOCAL_IP" ]]; then
    # escapar puntos en la IP para usar en regex
    escaped_ip=${LOCAL_IP//./\\.}
    preferred=$(echo "$device_list" | grep -E "^${escaped_ip}" | head -n1 || true)
  fi

  # 2) si no, primer emulator-* conectado
  if [[ -z "$preferred" ]]; then
    preferred=$(echo "$device_list" | grep -E '^emulator-' | head -n1 || true)
  fi

  # 3) si aún no hay, tomar el primer dispositivo de la lista
  if [[ -z "$preferred" ]]; then
    preferred=$(echo "$device_list" | head -n1)
  fi

  export ANDROID_SERIAL="$preferred"
  echo "🔌 Usando dispositivo ADB: $ANDROID_SERIAL"

  # comprobar que el dispositivo realmente responde antes de aplicar cambios
  if ! adb -s "$ANDROID_SERIAL" get-state 1>/dev/null 2>&1; then
    echo "❌ No hay conexión ADB al dispositivo seleccionado ($ANDROID_SERIAL)."
    exit 1
  fi

  # seguridad: comprobar que hostdot esté definido (variable usada más abajo)
  if [[ -z "${hostdot:-}" ]]; then
    echo "⚠️ Variable 'hostdot' vacía. Asegúrate de definir hostdot con el hostname DoT."
    exit 1
  fi

  echo "🛠 Aplicando Private DNS (DoT) vía adb..."

  applied_ok=1

  # aplicar settings (usamos -s para forzar el dispositivo seleccionado)
  if ! adb -s "$ANDROID_SERIAL" shell settings put global private_dns_mode hostname >/dev/null 2>&1; then
    echo "⚠️ Falló: settings put global private_dns_mode"
    applied_ok=0
  fi

  if ! adb -s "$ANDROID_SERIAL" shell settings put global private_dns_specifier "$hostdot" >/dev/null 2>&1; then
    echo "⚠️ Falló: settings put global private_dns_specifier"
    applied_ok=0
  fi

  # verificar inmediatamente ANTES de tocar Wi-Fi (para no perder la conexión antes de comprobar)
  mode=$(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_mode 2>/dev/null | tr -d '\r' || echo "n/a")
  spec=$(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_specifier 2>/dev/null | tr -d '\r' || echo "n/a")

  # si ya están correctos, marque applied_ok; si no, lo dejamos como fallo
  if [[ "$mode" = "hostname" && "$spec" = "$hostdot" ]]; then
    applied_ok=1
  else
    applied_ok=0
  fi

  echo "🔄 Intentando rebinding Wi-Fi (si falla, puede desconectar adb temporariamente)..."

  # Intentamos toggle Wi-Fi (no lo tratamos como fatal: puede desconectar adb en dispositivos Wi-Fi)
  if adb -s "$ANDROID_SERIAL" shell svc wifi disable >/dev/null 2>&1; then
    sleep 2
    if ! adb -s "$ANDROID_SERIAL" shell svc wifi enable >/dev/null 2>&1; then
      echo "⚠️ Aviso: no se pudo volver a habilitar Wi-Fi."
    fi
  else
    echo "⚠️ Aviso: no se pudo deshabilitar Wi-Fi (posible restricción)."
  fi

  # -------------------------
  # Comportamiento especial si el dispositivo era remoto (ip:port)
  # -------------------------
  original_serial="$ANDROID_SERIAL"
  if ! adb -s "$ANDROID_SERIAL" get-state 1>/dev/null 2>&1; then
    echo "ℹ️ ADB no responde tras intentar el rebinding."

    if [[ "$original_serial" == *:* ]]; then
      echo "ℹ️ Dispositivo remoto ($original_serial) detectado y desapareció tras apagar Wi-Fi."
      # relist devices y buscar emulator fallback (emulator-5554 tiene prioridad)
      device_list=$(adb devices | sed '1d' | awk '{print $1}' | sed '/^$/d')
      if echo "$device_list" | grep -qx "emulator-5554"; then
        ANDROID_SERIAL="emulator-5554"
        export ANDROID_SERIAL
        echo "🔁 Cambiando al fallback: $ANDROID_SERIAL"
      else
        fallback=$(echo "$device_list" | grep -E '^emulator-' | head -n1 || true)
        if [[ -n "$fallback" ]]; then
          ANDROID_SERIAL="$fallback"
          export ANDROID_SERIAL
          echo "🔁 Cambiando al fallback: $ANDROID_SERIAL"
        else
          echo "❌ No hay ningún emulator disponible como fallback."
          echo "   Puedes reconectar manualmente con: adb connect $original_serial"
          exit 1
        fi
      fi
    else
      # si NO era ip:port (p.ej. usb), intentamos un par de reconexiones rápidas
      attempts=0
      reconnected=0
      while [[ $attempts -lt 3 ]]; do
        attempts=$((attempts+1))
        sleep 1
        if adb -s "$ANDROID_SERIAL" get-state 1>/dev/null 2>&1; then
          reconnected=1
          break
        fi
      done
      if [[ $reconnected -ne 1 ]]; then
        echo "❌ El dispositivo seleccionado ($ANDROID_SERIAL) no respondió tras rebinding."
        exit 1
      fi
    fi
  fi

  # leer valores finales en el ANDROID_SERIAL actual (puede haber cambiado al fallback)
  mode=$(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_mode 2>/dev/null | tr -d '\r' || echo "n/a")
  spec=$(adb -s "$ANDROID_SERIAL" shell settings get global private_dns_specifier 2>/dev/null | tr -d '\r' || echo "n/a")

  echo
  if [[ "$mode" = "hostname" && "$spec" = "$hostdot" ]]; then
    echo "✅ Private DNS aplicado correctamente en $ANDROID_SERIAL."
    echo "Mode:      $mode"
    echo "Specifier: $spec"
  else
    echo "❌ No se pudieron aplicar correctamente los cambios en $ANDROID_SERIAL."
    echo " Mode:      $mode"
    echo " Specifier: $spec"
    # si el dispositivo original era remoto, sugerimos reconectar manualmente
    if [[ "$original_serial" == *:* ]]; then
      echo "ℹ️ Si deseas intentar aplicarlo al dispositivo remoto original intenta:"
      echo "   adb connect $original_serial && adb -s $original_serial shell settings get global private_dns_mode"
    fi
    exit 1
  fi
fi

echo
echo "💡 Revertir Private DNS:"
echo "   adb shell settings put global private_dns_mode off"
echo -e "   O\nadb shell settings put global private_dns_mode hostname\n
   adb shell settings put global private_dns_specifier one.one.one.one
"


: '
# lista dispositivos
adb devices

# ver valores actuales
adb -s emulator-5554 shell settings get global private_dns_mode
adb -s emulator-5554 shell settings get global private_dns_specifier



# Para arreglar el uso de Focus vpn por cambio de dns
adb -s emulator-5554 shell settings put global private_dns_mode off
adb -s emulator-5554 shell settings delete global private_dns_specifier
adb -s emulator-5554 shell svc wifi enable

echo "Valores finales:"
adb -s emulator-5554 shell settings get global private_dns_mode
adb -s emulator-5554 shell settings get global private_dns_specifier
: '












