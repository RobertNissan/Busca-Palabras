#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se ha proporcionado un argumento para el dispositivo
if [ $# -ne 1 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase un argumento:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}dispositivo_adb${NC}\n"
    exit 1
fi

dispositivo="$1"

# Ruta al archivo donde se encuentran los comandos (usando $HOME)
archivo_comandos="$HOME/Busca-Palabras/opc/deshabiltar_habiltar_apps_adb_v3.sh"

# Función para buscar los comandos en el archivo
# buscar_comandos() {
    # local patron=$1
    # grep -Eiw "\b$patron\b" "$archivo_comandos" | grep -oP '(?<=\b'"$patron"'\s)[^\s]+'
# }

# Función para buscar los comandos en el archivo, excluyendo líneas con "0"
buscar_comandos() {
    local patron=$1
    grep -Eiw "^\s*(setprop|adb\s+shell|adb\s+-s\s+\S+).*?\b$patron\b" "$archivo_comandos" | grep -v "0" | grep -oP '(?<=\b'"$patron"'\s)[^\s]+'
}

# Función para mostrar configuraciones en las tablas setedit
mostrar_configuraciones() {
    local tabla=$1
    local comando=$2
    local color=$3
    salida=$(adb -s "$dispositivo" shell settings list "$tabla" | grep -Eiw "\b$comando\b")
    
    # Verifica si la salida no está vacía
    if [ -n "$salida" ]; then
        echo -e "\n${color}Dispositivo: ${dispositivo}${NC}"
        echo -e "${color}Configuraciones de la tabla ${tabla}${NC}"
        echo "$salida"
        echo -e "${YELLOW}---------------------------------------------------${NC}"
    fi
}

# Función que recorre y muestra configuraciones para cada comando encontrado
procesar_comandos() {
    local comandos="$1"
    local color="$2"
    shift 2
    local tablas=("$@")
    local repetidos=()
    local dispositivo_impreso=false
    local impreso=false

    for cmd in $comandos; do
        # Evitar comandos repetidos y vacíos, y descartar el valor "0"
        if [[ " ${repetidos[@]} " =~ " ${cmd} " ]] || [[ -z "$cmd" ]] || [[ "$cmd" == "0" ]]; then
            continue
        fi
        repetidos+=("$cmd")
        
        for tabla in "${tablas[@]}"; do
            # Ejecutar el comando y capturar la salida
            salida=$(adb -s "$dispositivo" shell settings list "$tabla" | grep -Eiw "\b$cmd\b")
            
            # Si hay resultados, imprimir información del dispositivo y la tabla solo una vez
            if [ -n "$salida" ]; then
                if [ "$dispositivo_impreso" == false ]; then
                    echo -e "\n${color}Dispositivo: ${dispositivo}${NC}"
                    dispositivo_impreso=true
                fi
                if [ "$impreso" == false ]; then
                    echo -e "${color}Configuraciones de la tabla ${tabla}${NC}"
                    impreso=true
                fi
                echo "$salida"
                # Separador para comandos
                if [ "$impreso" == true ]; then
                    echo -e "${YELLOW}---------------------------------------------------${NC}"
                fi
            fi
        done
        
    done
}

# Buscar los comandos relevantes en el archivo
setprop_comandos=$(buscar_comandos "setprop")
# buscar_comandos "setprop"
# read
secure_comandos=$(buscar_comandos "secure")
# buscar_comandos "secure"
# read
system_comandos=$(buscar_comandos "system")
# buscar_comandos "system"
# read
global_comandos=$(buscar_comandos "global")
# buscar_comandos "global"
# read

# Procesar cada grupo de comandos encontrado
procesar_comandos "$setprop_comandos" $CYAN "global" "secure" "system"
procesar_comandos "$global_comandos" $YELLOW "global"
procesar_comandos "$secure_comandos" $GREEN "secure"
procesar_comandos "$system_comandos" $BLUE "system"

echo ""

# Salida ejemplo:
: '
u0_a255@localhost ~/proyecto_bash> bash mostrar_tablas_setedit_final.sh emulator-5554

Dispositivo: emulator-5554
Configuraciones de la tabla global
game_driver_all_apps=1
---------------------------------------------------
game_driver_opt_out_apps=1
---------------------------------------------------
game_driver_opt_in_apps=xyz.aethersx2.android,org.ppsspp.ppssppgold,org.dolphinemu.mmjr3,org.citra.emu
---------------------------------------------------
wifi_max_dhcp_retry_count=9
---------------------------------------------------
network_scoring_ui_enabled=1
---------------------------------------------------
activity_manager_constants=max_cached_processes=8
max_cached_processes=24
---------------------------------------------------
sustained_performance_mode_enabled=1
---------------------------------------------------
display_refresh_rate=90.0
---------------------------------------------------
user_refresh_rate=90.0
---------------------------------------------------
screen_refresh_rate=90.0
---------------------------------------------------
min_refresh_rate=60.0
---------------------------------------------------
max_refresh_rate=90.0
---------------------------------------------------
peak_refresh_rate=90.0
---------------------------------------------------
game_driver_framerate=90.0
---------------------------------------------------
gpu_rendering=1
---------------------------------------------------
force_gpu_rendering=1
---------------------------------------------------
com.qc.hardware=true
---------------------------------------------------
gpu_debug_app=org.citra.emu:org.ppsspp.ppssppgold:xyz.aethersx2.android:org.dolphinemu.mmjr3:com.facebook.lite:app.rvx.android.youtube
---------------------------------------------------
enable_gpu_debug_layers=1
---------------------------------------------------
enable_vulkan=1
---------------------------------------------------
development_settings_enabled=1
---------------------------------------------------
enable_msaa=1
---------------------------------------------------
HIGH_PERFORMANCE_MODE_ON=1
---------------------------------------------------
battery_saver_constants=vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0
---------------------------------------------------
adb_enabled=1
---------------------------------------------------
adb_wifi_enabled=0
---------------------------------------------------

Dispositivo: emulator-5554
Configuraciones de la tabla system
display_refresh_rate=90.0
---------------------------------------------------
user_refresh_rate=90.0
---------------------------------------------------
screen_refresh_rate=90.0
---------------------------------------------------
min_refresh_rate=60.0
---------------------------------------------------
max_refresh_rate=90.0
---------------------------------------------------
peak_refresh_rate=90.0
---------------------------------------------------
touch.size.calibration=geometric
---------------------------------------------------
touch.pressure.calibration=amplitude
---------------------------------------------------
touch.size.scale=1
---------------------------------------------------
: '
