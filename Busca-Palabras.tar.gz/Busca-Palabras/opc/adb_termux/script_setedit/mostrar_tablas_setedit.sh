#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se han proporcionado los dos argumentos
if [ $# -ne 2 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase dos argumentos:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}dispositivo_adb comando_a_buscar${NC}\n"
    exit 1
fi

dispositivo="$1"
comando="$2"

impreso='false'
# Función para mostrar configuraciones
mostrar_configuraciones() {
    local tabla=$1
    local color=$2

    # Ejecutar el comando y guardar la salida
    salida=$(adb -s "$dispositivo" shell settings list "$tabla" | grep --color=always -i "$comando")
    
    if [ -n "$salida" ]; then
        if [ "$impreso" == "false" ]; then
            echo -e "\n${color}Dispositivo: ${dispositivo}${NC}"
            impreso='true'
        fi
        echo -e "${color}Configuraciones de la tabla ${tabla}${NC}"
        echo "$salida"
        echo -e "${YELLOW}---------------------------------------------------${NC}"
    else
        echo -e "${RED}No se encontraron configuraciones coincidentes en la tabla ${tabla}.${NC}" >/dev/null
    fi
}

# Recorrer cada tabla
mostrar_configuraciones "global" $CYAN
mostrar_configuraciones "secure" $GREEN
mostrar_configuraciones "system" $BLUE
echo ""