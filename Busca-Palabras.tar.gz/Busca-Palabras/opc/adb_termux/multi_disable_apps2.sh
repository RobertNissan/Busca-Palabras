function multi_disable {
    dispositivo="emulator-5554"
    archivo="packages.txt"

    # Obtener la lista de todos los paquetes de usuario 3
    packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

    # Aplicaciones que siempre deben estar en el archivo
    echo "com.facebook.katana" > "$archivo"
    echo "com.google.android.videos" >> "$archivo"
    echo "com.google.android.apps.photos" >> "$archivo"
    echo "com.google.android.apps.docs" >> "$archivo"

    excluidos=(
        "com.termux"
        "com.termux.api"
        "com.android.chrome"
        "com.rhmsoft.edit.pro"
        "ich.andre.partialscreen"
        "com.topjohnwu.magisk"
        "com.touchtype.swiftkey"
        "app.rvx.android.youtube"
        "com.estrongs.android.pop"
        "com.mgoogle.android.gms"
        "com.google.android.youtube"
    )

    # Filtrar paquetes excluidos
    for excluded_package in "${excluidos[@]}"; do
        packages=$(echo "$packages" | grep -v "$excluded_package")
    done

    echo "$packages" >> "$archivo"

    # Deshabilitar aplicaciones utilizando xargs y paralelismo
    cat "$archivo" | xargs -P 4 -n 1 sh -c 'for package do adb -s "${dispositivo}" shell pm disable-user --user 0 "$package" >/dev/null 2>&1 && echo "Aplicacion $package deshabilitada correctamente." || echo "Aplicacion $package no deshabilitada."; done' _

    # Mostrar el recuento al final
    contador=$(grep -c . "$archivo")
    if [ "$contador" -eq 0 ]; then
        echo "No se deshabilitaron aplicaciones."
    else
        echo "Se deshabilitaron $contador aplicaciones."
    fi
}

multi_disable
