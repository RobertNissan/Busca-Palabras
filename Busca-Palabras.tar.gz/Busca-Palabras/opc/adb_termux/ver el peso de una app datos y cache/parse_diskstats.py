import re, os

os.system("adb shell dumpsys diskstats > diskstats.txt")

# Leer archivo generado con: adb shell dumpsys diskstats > diskstats.txt
with open("diskstats.txt", "r", encoding="utf-8") as f:
    data = f.read()

# Extraer arrays
app_sizes = re.findall(r"App Sizes:\s*\[([0-9, ]+)\]", data)
data_sizes = re.findall(r"App Data Sizes:\s*\[([0-9, ]+)\]", data)
cache_sizes = re.findall(r"Cache Sizes:\s*\[([0-9, ]+)\]", data)
packages = re.findall(r"Package Names:\s*\[([^\]]+)\]", data)

if not (app_sizes and data_sizes and cache_sizes and packages):
    raise ValueError("No se pudieron extraer los datos, revisa que diskstats.txt esté completo.")

# Convertir a listas
app_sizes = [int(x.strip()) for x in app_sizes[0].split(",")]
data_sizes = [int(x.strip()) for x in data_sizes[0].split(",")]
cache_sizes = [int(x.strip()) for x in cache_sizes[0].split(",")]
packages = [p.strip().strip('"') for p in packages[0].split(",")]

# Guardar en archivo apps_storage.csv (texto plano)
with open("apps_storage.csv", "w", encoding="utf-8") as out:
    for pkg, app, dat, cache in zip(packages, app_sizes, data_sizes, cache_sizes):
        out.write(f"{pkg} app_peso={app/1024/1024:.2f}MB datos={dat/1024/1024:.2f}MB cache={cache/1024/1024:.2f}MB\n")

print("Archivo 'apps_storage.csv' generado con éxito 🚀")
