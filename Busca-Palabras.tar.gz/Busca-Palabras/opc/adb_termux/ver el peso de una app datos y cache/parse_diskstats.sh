#!/usr/bin/env bash
# parse_diskstats2.sh
# Uso:
#   ./parse_diskstats2.sh localhost 100MB
#   ./parse_diskstats2.sh 192.168.20.22:5555 200GB

# ver el peso, datos y cache de una o mas apps usando adb

set -euo pipefail

# -- comprobación mínima de argumentos --
if [[ $# -lt 2 ]]; then
  echo "Uso: $0 <local|ip:puerto> <UMBRAL_MB>"
  echo ""
  echo "Ejemplos:"
  echo "  $0 192.168.20.22:5555 200MB"
  exit 1
fi
# --------------------------------------

# ---- inicio: parseo de TARGET y umbral con unidades (KB/MB/GB/TB) ----
TARGET="${1:-local}"
RAW_THRESH="${2:-100}"

# parsear formatos: 100  |  200mb  |  1.5GB  | 500k  | 0.5tb
if [[ $RAW_THRESH =~ ^([0-9]+([.][0-9]+)?)([[:space:]]*([kKmMgGtT][bB]?))?$ ]]; then
  num="${BASH_REMATCH[1]}"
  unit="${BASH_REMATCH[4]}"  # puede estar vacío

  # convertir a MB (float) usando awk
  case "${unit,,}" in
    k|kb)
      THRESH_MB=$(awk "BEGIN{printf \"%.6f\", ($num/1024)}")
      ;;
    m|mb|'')
      THRESH_MB=$(awk "BEGIN{printf \"%.6f\", $num}")
      ;;
    g|gb)
      THRESH_MB=$(awk "BEGIN{printf \"%.6f\", ($num*1024)}")
      ;;
    t|tb)
      THRESH_MB=$(awk "BEGIN{printf \"%.6f\", ($num*1024*1024)}")
      ;;
    *)
      echo "Unidad no soportada: '$unit'. Usa KB, MB, GB o TB."
      exit 1
      ;;
  esac
else
  echo "Umbral inválido: '$RAW_THRESH'. Ejemplos válidos: 100, 200mb, 1.5GB, 500k, 0.5tb"
  exit 1
fi

# valor formateado para mostrar (2 decimales)
THRESH_MB_DISPLAY=$(printf "%.2f" "$THRESH_MB")
echo "Umbral normalizado: ${THRESH_MB_DISPLAY} MB (entrada: ${RAW_THRESH})"
# ---- fin del parseo ----

ADB_CMD="adb"
if [[ "$TARGET" != "local" ]]; then
  echo "Conectando a $TARGET ..."
  adb connect "$TARGET" >/dev/null 2>&1 || true
  ADB_CMD="adb -s $TARGET"
fi

WORKDIR="$(pwd)"
DISKTXT="$WORKDIR/diskstats.txt"
OUTCSV="$WORKDIR/apps_storage.csv"
TMPDIR="$(mktemp -d)"
APPS="$TMPDIR/appsizes.txt"
DATA="$TMPDIR/datasizes.txt"
CACHE="$TMPDIR/cachesizes.txt"
PKGS="$TMPDIR/packages.txt"

cleanup(){ rm -rf "$TMPDIR"; }
trap cleanup EXIT

echo "Capturando dumpsys diskstats desde '$TARGET' (esto puede tardar)..."
# Capturamos la salida remota/local en un archivo local
$ADB_CMD shell dumpsys diskstats > "$DISKTXT" || { echo "Error: adb falló o dispositivo no autorizado."; exit 1; }

# Extraer las cuatro líneas principales (si aparecen en múltiples líneas, esto toma la primera aparición de cada etiqueta)
app_line=$(sed -n 's/.*App Sizes:\s*\[\(.*\)\]/\1/p' "$DISKTXT" || true)
data_line=$(sed -n 's/.*App Data Sizes:\s*\[\(.*\)\]/\1/p' "$DISKTXT" || true)
cache_line=$(sed -n 's/.*Cache Sizes:\s*\[\(.*\)\]/\1/p' "$DISKTXT" || true)
pkg_line=$(sed -n 's/.*Package Names:\s*\[\(.*\)\]/\1/p' "$DISKTXT" || true)

if [[ -z "$app_line" || -z "$data_line" || -z "$cache_line" || -z "$pkg_line" ]]; then
  echo "No se pudieron extraer todas las secciones desde diskstats.txt. Revisa '$DISKTXT' (ver primeras 200 líneas):"
  head -n 200 "$DISKTXT"
  exit 2
fi

# Convertir a archivos con un valor por línea (local)
echo "$app_line"  | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' > "$APPS"
echo "$data_line" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' > "$DATA"
echo "$cache_line"| tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' > "$CACHE"

# Packages: separar por '", "' o por comas, quitar comillas
echo "$pkg_line" \
  | sed -e 's/\",[[:space:]]*\"/\n/g' -e 's/^"//g' -e 's/"$//g' -e 's/,/\
/g' \
  | sed '/^$/d' \
  | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
  > "$PKGS"
sed -i 's/^"//; s/"$//' "$PKGS"
sed -i '/^$/d' "$PKGS"

# comprobar tamaños
len_pkg=$(wc -l < "$PKGS" | tr -d ' ')
len_app=$(wc -l < "$APPS" | tr -d ' ')
len_data=$(wc -l < "$DATA" | tr -d ' ')
len_cache=$(wc -l < "$CACHE" | tr -d ' ')

if [[ "$len_pkg" -ne "$len_app" || "$len_pkg" -ne "$len_data" || "$len_pkg" -ne "$len_cache" ]]; then
  echo "Advertencia: longitudes diferentes: packages=$len_pkg apps=$len_app data=$len_data cache=$len_cache"
  echo "Se emparejará por el mínimo para evitar errores."
fi

min_lines=$len_pkg
for n in "$len_app" "$len_data" "$len_cache"; do
  if (( n < min_lines )); then min_lines=$n; fi
done

# generar apps_storage.csv local
: > "$OUTCSV"
paste -d '|' <(head -n "$min_lines" "$PKGS") <(head -n "$min_lines" "$APPS") <(head -n "$min_lines" "$DATA") <(head -n "$min_lines" "$CACHE") \
  | awk -F'|' '{
      pkg=$1;
      app=$2+0;
      dat=$3+0;
      cache=$4+0;
      appMB = app/1024/1024;
      datMB = dat/1024/1024;
      cacheMB = cache/1024/1024;
      printf "%s app_peso=%.2fMB datos=%.2fMB cache=%.2fMB\n", pkg, appMB, datMB, cacheMB;
  }' > "$OUTCSV"

echo "Generado: $OUTCSV (paquetes: $min_lines)"

# Mostrar los que superan el umbral
echo
echo "Apps con total > ${THRESH_MB} MB:"
awk -v thresh="$THRESH_MB" -F' ' '{
    split($2,a,"="); gsub("MB","",a[2]); app=a[2]+0
    split($3,b,"="); gsub("MB","",b[2]); datos=b[2]+0
    split($4,c,"="); gsub("MB","",c[2]); cache=c[2]+0
    total = app + datos + cache
    if (total > thresh) {
      printf "%.6f|%s|%.2f|%.2f|%.2f\n", total, $1, app, datos, cache
    }
}' "$OUTCSV" \
  | sort -t'|' -nr \
  | awk -F'|' '{ printf "%-55s TOTAL=%.2fMB (app=%.2fMB datos=%.2fMB cache=%.2fMB)\n", $2, $1, $3, $4, $5 }'

# Opcional: si quieres también dejar el apps_storage.csv en el dispositivo remoto en /sdcard:
# Uncomment siguiente línea para subirlo
# $ADB_CMD push "$OUTCSV" /sdcard/apps_storage.csv >/dev/null && echo "También subido a /sdcard/apps_storage.csv en $TARGET"

echo
echo "Hecho. Archivo local: $OUTCSV"
