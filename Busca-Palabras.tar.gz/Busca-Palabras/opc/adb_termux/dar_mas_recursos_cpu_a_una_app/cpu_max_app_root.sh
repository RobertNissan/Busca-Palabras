# Nota: necesita root
adb shell su -c "pidof com.android.chrome"
25055
adb shell su -c "renice -n -20 -p 25055"

~ $ adb shell ps | grep com.android.chrome
u0_a208       25734    466 31026008 69640 0                   0 S com.android.chrome_zygote
u0_a208       27355    466 31516404 335684 0                  0 S com.android.chrome
u0_a208       27443    466 31107420 180272 0                  0 S com.android.chrome:privileged_process0
u0_i5         27506  25734 268651912 430460 0                 0 S com.android.chrome:sandboxed_process0:org.chromium.content.app.SandboxedProcessService0:1


# Aplica renice a los demás procesos de Chrome:
# Proceso com.android.chrome_zygote (PID 25734):
adb shell su -c "renice -n -20 -p 25734"
# Proceso com.android.chrome (PID 27355):
adb shell su -c "renice -n -20 -p 27355"
# Proceso com.android.chrome:privileged_process0 (PID 27443):
adb shell su -c "renice -n -20 -p 27443"
# Proceso com.android.chrome:sandboxed_process0 (PID 27506):
adb shell su -c "renice -n -20 -p 27506"
#Esto ajustará la prioridad de todos los procesos relacionados con Chrome, lo que debería mejorar su rendimiento.


# script para facilitar y automatizar 
#!/bin/bash
# Nombre de la aplicación max_cpu_app.sh
# Archivo de log para prioridades
LOG_FILE="priority_log.txt"
# Verificar si la aplicación está instalada
if adb shell pm list packages | grep -q "com.android.chrome"; then
    # Compilar la aplicación en modo de perfil de velocidad
    echo "Optimizando la aplicación..."
    adb -s emulator-5554 shell cmd package compile -m speed-profile com.android.chrome
else
    echo "La aplicación com.android.chrome no está instalada."
    exit 1
fi
impreso='false'
impreso1='false'
esperando='false'
# Función para aplicar optimización de CPU
optimize_cpu() {
    for process in com.android.chrome com.android.chrome_zygote com.android.chrome:privileged_process0 com.android.chrome:sandboxed_process0; do
        pid=$(adb shell pidof $process)
        if [ -n "$pid" ]; then
            if [ "$impreso1" != 'true' ]; then
                echo "Ajustando prioridad para $process (PID $pid)"
                impreso1='true'
            fi 
            adb shell su -c "renice -n -20 -p $pid"
        fi
    done
}
# Función para verificar y ajustar la prioridad de los procesos
check_and_optimize() {
    if adb shell ps | grep -q com.android.chrome; then
        if [ "$impreso" != 'true' ]; then
            echo "La aplicación está abierta."
            impreso='true'
        fi
        optimize_cpu
        esperando='false'
    else
        impreso='false'
        impreso1='false'
        if [ "$esperando" != 'true' ]; then
            echo "La aplicación está cerrada. Esperando a que se inicie nuevamente..."
            esperando='true'
        fi
    fi
}
# Función para registrar la prioridad de los procesos
log_priorities() {
    adb shell ps -o pid,ni,cmdline | grep com.android.chrome  >> "$LOG_FILE"
    rm -rf "$LOG_FILE"
}
# Ejecutar la verificación, optimización y registro en bucle
while true; do
    check_and_optimize
    log_priorities
    sleep 5  # Esperar 5 segundos antes de volver a verificar
done






# Para verificar que el cambio se aplicó correctamente, puedes comprobar el proceso nuevamente con:
adb shell ps -o pid,ni,cmdline | grep com.android.chrome





# script2 para facilitar y automatizar full
#!/bin/bash
# Nombre de la aplicación max_cpu_app.sh
# Archivo de log para prioridades
LOG_FILE="priority_log.txt"
# Verificar si la aplicación está instalada
if adb shell pm list packages | grep -q "com.android.chrome"; then
    # Compilar la aplicación en modo de perfil de velocidad
    echo "Optimizando la aplicación..."
    adb -s emulator-5554 shell cmd package compile -m speed-profile com.android.chrome
else
    echo "La aplicación com.android.chrome no está instalada."
    exit 1
fi
impreso='false'
impreso1='false'
esperando='false'
# Función para aplicar optimización de CPU
optimize_cpu() {
    # Obtener PIDs de los procesos relacionados con com.android.chrome
    local pids=$(adb shell ps -o pid,cmdline | grep com.android.chrome | awk '{print $1}')
    if [ -n "$pids" ]; then
        if [ "$impreso1" != 'true' ]; then
            echo "Ajustando prioridad para los procesos con PIDs: $pids"
            impreso1='true'
        fi
        
        # Ajustar la prioridad para cada PID
        for pid in $pids; do
            adb shell su -c "renice -n -20 -p $pid" >/dev/null 2>&1
        done
    fi
}
# Función para verificar y ajustar la prioridad de los procesos
check_and_optimize() {
    if adb shell ps | grep -q com.android.chrome; then
        if [ "$impreso" != 'true' ]; then
            echo "La aplicación está abierta."
            impreso='true'
        fi
        optimize_cpu
        esperando='false'
    else
        impreso='false'
        impreso1='false'
        if [ "$esperando" != 'true' ]; then
            echo "La aplicación está cerrada. Esperando a que se inicie nuevamente..."
            esperando='true'
        fi
    fi
}
# Función para registrar la prioridad de los procesos
log_priorities() {
    adb shell ps -o pid,ni,cmdline | grep com.android.chrome > "$LOG_FILE"
    rm -rf "$LOG_FILE"
}
# Ejecutar la verificación, optimización y registro en bucle
while true; do
    check_and_optimize
    log_priorities
    sleep 5  # Esperar 5 segundos antes de volver a verificar
done










