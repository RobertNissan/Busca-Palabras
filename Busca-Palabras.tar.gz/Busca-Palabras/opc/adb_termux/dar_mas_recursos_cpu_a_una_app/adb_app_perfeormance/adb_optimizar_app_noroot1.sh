#!/bin/bash
# dar dar a la tabla globa de setedit
pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
echo "Para ejecutar bien pase el argumento:"
echo "script.sh <paquete>"
# Verificar que se haya pasado el nombre del paquete como argumento
if [ -z "$1" ]; then
    echo "Uso: $0 <nombre_del_paquete>"
    exit 1
fi
PAQUETE="$1"
# Lista de paquetes que no deben ser afectados
EXCEPTIONS=("com.termux" "com.whatsapp" "com.facebook.lite" "com.facebook.orca" "com.whatsapp.w4b")

# Función para verificar si un paquete está en las excepciones
es_excepcion() {
    local paquete=$1
    for exception in "${EXCEPTIONS[@]}"; do
        if [ "$exception" = "$paquete" ]; then
            return 0  # Verdadero: el paquete está en las excepciones
        fi
    done
    return 1  # Falso: el paquete no está en las excepciones
}

# Función para activar optimización
activar() {
    echo "Activando optimización para $PAQUETE..."
    # Añadir a la whitelist de Doze
    dumpsys deviceidle whitelist +$PAQUETE
    # Desactivar actividad en segundo plano para todas las apps de terceros (las instaladas manualmente) excepto las excepciones
    packages=$(pm list packages -3 | cut -d':' -f2 | grep -v "$PAQUETE")
    for package in $packages; do
        if ! es_excepcion "$package"; then
            am set-inactive "$package" true
            # Este comando configura la operación de la app para que no pueda ejecutarse en segundo plano. Al establecer RUN_IN_BACKGROUND ignore, se evita que la aplicación se ejecute cuando no está en primer plano, lo que puede ayudar a ahorrar batería y mejorar el rendimiento del dispositivo.
            cmd appops set "$package" RUN_IN_BACKGROUND ignore
        else
            echo "Excepción: No se desactiva el fondo para $package"
        fi
    done
    cmd package compile -m speed-profile $package
    # Configurar Battery Saver para mejorar el rendimiento
    settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"
    echo "Optimización activada para $PAQUETE."
}

# Función para revertir optimización
revertir() {
    echo "Revirtiendo optimización para $PAQUETE..."
    # Eliminar de la whitelist de Doze
    dumpsys deviceidle whitelist -$PAQUETE
    # Reactivar actividad en segundo plano para todas las apps
    packages=$(pm list packages -3 | cut -d':' -f2 | grep -v "$PAQUETE")
    for package in "$packages"; do
        am set-inactive "$package" false
        cmd appops set "$package" RUN_IN_BACKGROUND allow
    done
    # Eliminar la configuración de Battery Saver
    settings delete global battery_saver_constants
    echo "Optimización revertida para $PAQUETE."
}

# Mostrar el menú
echo "Seleccione una opción para $PAQUETE:"
echo "1. Activar optimización"
echo "2. Revertir optimización"
echo -n "Opción: "
read opcion

case $opcion in
    1)
        activar
        ;;
    2)
        revertir
        ;;
    *)
        echo "Opción no válida."
        exit 1
        ;;
esac

: '
# tranferir a un dispositivo
# mi celular colocó ip:port destino ruta_de_mi_archivo_a_enviar ruta_destino
adb -s 192.168.20.94:5555 push /sdcard/Download/adb_optimizar_app_noroot1.sh /sdcard/adb_optimizar_app_noroot1.sh
# para corregir
# /sdcard/Documents/adb_optimizar_app_noroot1.sh[9]: syntax error:'unexpected '
adb -s 192.168.20.44:5555 shell "sed -i 's/\r$//' /sdcard/Documents/adb_optimizar_app_noroot1.sh"
# ejecutar el script remoto usando como argumento el nombre del paquete
adb -s 192.168.20.44:5555 shell sh /sdcard/Documents/optimizar_app_noroot.sh com.android.mgstv

# verificar que el cambio en la global table se agrego aun sin la app setedit.apk
adb -s 192.168.20.44:5555 shell settings get global battery_saver_constants

# 1. Verificar la whitelist de Doze:
# Puedes usar el siguiente comando para confirmar que la aplicación fue añadida a la whitelist de Doze:
adb -s 192.168.20.44:5555 shell dumpsys deviceidle whitelist
# 2. Verificar el estado de la aplicación:
# Puedes verificar el estado de la aplicación (si está activa en segundo plano o no) con este comando:
adb -s 192.168.20.44:5555 shell am get-inactive com.android.mgstv
# 3. Verificar las operaciones en segundo plano:
# Verifica si las aplicaciones están restringidas en sus operaciones en segundo plano:
adb -s 192.168.20.44:5555 shell cmd appops get com.android.mgstv

: '