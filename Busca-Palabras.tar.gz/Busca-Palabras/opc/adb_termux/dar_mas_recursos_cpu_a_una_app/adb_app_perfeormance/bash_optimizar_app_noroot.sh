# script selector 
#!/bin/bash
echo "Para ejecutar bien pase el argumento:"
echo "script.sh <ip:port>"
app=()  # Inicializa el array
echo "Ingrese los paquetes a habilitar, presione CTRL+D cuando termine:"
while IFS= read -r linea; do
    # Salir del bucle si la línea está vacía
    [[ -z $linea ]] && break
    app+=("$linea")
done

# Verifica si se ingresaron paquetes
if [ ${#app[@]} -eq 0 ]; then
    echo "Error: No se ha ingresado ningún paquete."
    exit 1
fi

# Verificar que se haya pasado el dispositivo como argumento
if [ -z "$1" ]; then
    echo "Uso: $0 <ip:port>"
    exit 1
fi
DISPOSITIVO="$1"

# Verificar si los paquetes están instalados en el dispositivo
echo "Verificando si los paquetes están instalados en el dispositivo ${DISPOSITIVO}..."
for PAQUETE in "${app[@]}"; do
    INSTALADO=$(adb -s "${DISPOSITIVO}" shell pm list packages | grep "$PAQUETE")
    if [ -z "$INSTALADO" ]; then
        echo "Error: El paquete '$PAQUETE' no está instalado en el dispositivo."
        exit 1
    else
        echo "Paquete '$PAQUETE' está instalado."
    fi
done

# Dar permisos de edición a la tabla global de SetEdit
adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS

# Lista de paquetes que no deben ser afectados
EXCEPTIONS=("com.termux" "com.whatsapp" "com.whatsapp.w4b" "com.facebook.lite" "com.facebook.orca" "com.android.chrome")

# Función para activar optimización para varios paquetes
activar() {
    echo "Activando optimización para las apps ingresadas..."
    # Desactivar actividad en segundo plano para todas las apps de terceros (las instaladas manualmente) excepto las excepciones
    packages=$(adb -s "${DISPOSITIVO}" shell pm list packages -3 | cut -d':' -f2)
    for package in $packages; do
        if [[ ! " ${EXCEPTIONS[@]} " =~ " ${package} " ]]; then
            adb -s "${DISPOSITIVO}" shell am set-inactive $package true
            adb -s "${DISPOSITIVO}" shell cmd appops set $package RUN_IN_BACKGROUND ignore
        else
            echo "Excepción: No se desactiva el fondo para $package"
        fi
    done

    # Mejorar el rendimiento en los paquetes ingresados
    for PAQUETE in "${app[@]}"; do
        adb -s "${DISPOSITIVO}" shell cmd package compile -m speed-profile $PAQUETE
    done
    # Configurar Battery Saver para mejorar el rendimiento
    adb -s "${DISPOSITIVO}" shell settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"
    echo "Optimización activada para $PAQUETE."
}

# Función para revertir optimización para varios paquetes
revertir() {
    echo "Revirtiendo optimización para las apps ingresadas..."
    # Reactivar actividad en segundo plano para todas las apps
    packages=$(adb -s "${DISPOSITIVO}" shell pm list packages -3 | cut -d':' -f2)
    for package in $packages; do
        adb -s "${DISPOSITIVO}" shell am set-inactive $package false
        adb -s "${DISPOSITIVO}" shell cmd appops set $package RUN_IN_BACKGROUND allow
    done

    
    adb -s "${DISPOSITIVO}" shell settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"
    echo "Optimización revertida para $PAQUETE."
}

# Mostrar el menú
echo "Dispositivo: ${DISPOSITIVO}"
echo "Seleccione una opción para las apps ingresadas:"
echo "1. Activar optimización"
echo "2. Revertir optimización"
read -p "Opción: " opcion
case $opcion in
    1)
        activar
        ;;
    2)
        revertir
        ;;
    *)
        echo "Opción no válida."
        exit 1
        ;;
esac



: '
# Obtener la lista de todos los paquetes de usuario 3
packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

# Controlar el uso de la app (limitar background processes)
# Puedes reducir la cantidad de procesos en segundo plano para que el dispositivo use menos recursos y las apps principales se carguen más rápido:
adb shell settings put global limit_background_processes 2

# Desactivar la actividad en segundo plano para una app específica
# Este comando evita que una aplicación se ejecute en segundo plano, lo que puede mejorar el rendimiento general del sistema:
adb shell am set-inactive <nombre_del_paquete> true

# Habilitar o deshabilitar Doze y App Standby
# Doze y App Standby pueden reducir la actividad de las aplicaciones en segundo plano, lo que mejora la duración de la batería y el rendimiento general:
# Para activar Doze inmediatamente (mientras la pantalla está apagada):
adb shell dumpsys deviceidle force-idle

# Para permitir que una app evite ser afectada por Doze:
adb shell dumpsys deviceidle whitelist +<nombre_del_paquete>


# Desactivar la recolección de datos innecesaria por apps en segundo plano
# Esto puede evitar que las apps ejecuten tareas innecesarias mientras están en segundo plano, lo que podría afectar al rendimiento del sistema:
adb shell settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"

# Reducir los servicios en segundo plano de apps específicas
# Esto limita los servicios que una aplicación puede ejecutar en segundo plano:
adb shell cmd appops set <nombre_del_paquete> RUN_IN_BACKGROUND ignore



: '
