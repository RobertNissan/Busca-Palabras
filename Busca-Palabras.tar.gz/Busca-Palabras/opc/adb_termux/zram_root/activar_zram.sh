# Optimización critica 

# El siguiente comando congelará una aplicación que se esté ejecutando en segundo plano.
# adb shell cmd appops set <nombre-paquete> RUN_IN_BACKGROUND ignore
#  Desactivar el servicio de optimización de juegos (Samsung)
# Cuando está activado, el Servicio de Optimización de Juegos (GOS) impide que los dispositivos Samsung limiten drásticamente el rendimiento de la CPU y la GPU durante los juegos. Si bien esto se traduce en una mayor velocidad de fotogramas en juegos con gráficos exigentes, también reduce el rendimiento del dispositivo. Afortunadamente, puedes desactivar el GOS en teléfonos Samsung mediante comandos ADB.
adb shell settings put secure gamesdk_version 0
adb shell settings put secure game_home_enable 0
adb shell settings put secure game_bixby_block 1
adb shell settings put secure game_auto_temperature_control 0
adb shell pm clear --user 0 com.samsung.android.game.gos # no failed 
# 4. Borrar la caché y los datos de la aplicación
# Borrar regularmente la caché y los datos de las aplicaciones garantiza que tu dispositivo responda mejor y funcione más rápido. Esto no solo libera espacio de almacenamiento, sino que también ayuda a que las aplicaciones se ejecuten con mayor fluidez. El siguiente comando ADB toma el parámetro de espacio libre deseado en K/M/G (kilo/mega/gigabytes) y ajusta la caché según el espacio definido. Por lo tanto, si agregas un tamaño excesivo en MB o GB, ADB borrará la caché hasta alcanzar ese tamaño. Como nunca se alcanza dicho tamaño, se borra toda la caché.
adb shell pm trim-caches 128G
# 10. Mejorar la calidad del audio
# Los smartphones modernos ofrecen una excelente calidad de audio, que se puede mejorar aún más con aplicaciones de ecualizador. Sin embargo, también puedes disfrutar de una mejor experiencia de audio en teléfonos Android activando los efectos K2HD y Tube Amp mediante ADB.
adb shell settings put system k2hd_effect 1
adb shell settings put system tube_amp_effect 1
# Eleva el límite de procesos en caché a un nivel normal (Android administrará dinámicamente)
adb shell settings put global activity_manager_constants max_cached_processes=20 # o 32
# Desactiva el asesino de procesos en segundo plano
adb shell su -c "device_config put activity_manager max_phantom_processes 2147483647"
adb shell su -c "settings put global settings_enable_monitor_phantom_procs false"
# 2. Aceleración estricta de video y gráficos por hardware
adb shell su -c "setprop video.accelerate.hw 1"

# ==========================================
# OPTIMIZACIÓN Y ACELERACIÓN DE LA GPU
# ==========================================
# 1. Forzar optimización de rendimiento general en la GPU/HWUI
adb shell setprop debug.performance.tuning 1
# 3. Priorizar el hilo de renderizado de la interfaz gráfica en la GPU
adb shell setprop debug.hwui.render_thread true
# 4. Forzar el motor de renderizado Skia por hardware (Acelera la UI en Android moderno)
adb shell setprop debug.hwui.renderer skiahw

# Entra a modo Root en Termux:
su
cat <<EOF > /data/adb/service.d/zram_4gb.sh
#!/system/bin/sh
sleep 30
# Verificar si ZRAM está activo antes de intentar desactivarlo
if grep -q "/dev/block/zram0" /proc/swaps; then
    swapoff /dev/block/zram0
fi

# Resetear para permitir el cambio de tamaño
echo 1 > /sys/block/zram0/reset

# Configurar el algoritmo ZRAM
echo lz4 > /sys/block/zram0/comp_algorithm

# Configurar los 4GB (4294967296 bytes)
echo 4294967296 > /sys/block/zram0/disksize

# Formatear y encender con prioridad alta
mkswap /dev/block/zram0
swapon /dev/block/zram0 -p 100

echo 400 > /proc/sys/vm/dirty_writeback_centisecs
echo 30 > /proc/sys/kernel/panic
echo 2048 > /proc/sys/kernel/max_lock_depth
echo 40 > /proc/sys/vm/dirty_background_ratio
echo 9000000 > /proc/sys/kernel/sched_latency_ns
echo 4000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 150 > /proc/sys/vm/vfs_cache_pressure
echo 32768 > /proc/sys/vm/min_free_kbytes
echo 15 > /proc/sys/vm/dirty_ratio
echo 800000 > /proc/sys/kernel/sched_migration_cost_ns


echo 30 > /proc/sys/kernel/panic
echo 20 > /proc/sys/fs/lease-break-time
echo 32000 > /proc/sys/fs/inotify/max_queued_events
echo 1000 > /proc/sys/vm/dirty_expire_centisecs
echo 256 > /proc/sys/fs/inotify/max_user_instances
echo 3 > /proc/sys/vm/page-cluster
echo 1048576 > /proc/sys/fs/file-max
echo 10 > /proc/sys/vm/vfs_cache_pressure
echo 95 > /proc/sys/vm/dirty_ratio
echo 524288 > /proc/sys/kernel/threads-max
echo 200 > /proc/sys/vm/dirty_writeback_centisecs
echo 10240 > /proc/sys/fs/inotify/max_user_watches
echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 60 > /proc/sys/vm/dirty_background_ratio
echo 150 > /proc/sys/vm/direct_swappiness
echo 8192 > /proc/sys/vm/min_free_kbytes


echo 2 > /proc/sys/kernel/panic
echo 64000 > /proc/sys/fs/inotify/max_queued_events
echo 512 > /proc/sys/fs/inotify/max_user_instances
echo 8 > /proc/sys/vm/page-cluster
echo 5048576 > /proc/sys/fs/file-max
echo 400000 > /proc/sys/fs/mount-max
echo 40 > /proc/sys/vm/vfs_cache_pressure
echo 30 > /proc/sys/vm/dirty_ratio
echo 16384 > /proc/sys/kernel/threads-max
echo 2048 > /proc/sys/kernel/max_lock_depth
echo 5760 > /proc/sys/fs/inotify/max_user_watches
echo 65536 > /proc/sys/kernel/perf_cpu_time_max_percent
echo 15 > /proc/sys/vm/dirty_background_ratio
echo 5120 > /proc/sys/vm/min_free_kbytes
echo 75536 > /proc/sys/fs/aio-max-nr
echo 7048576 > /proc/sys/fs/nr_open



echo 786432 > /proc/sys/fs/file-max
echo 74000 > /proc/sys/fs/inotify/max_queued_events
echo 512 > /proc/sys/fs/inotify/max_user_instances
echo 9192 > /proc/sys/fs/inotify/max_user_watches
echo 25 > /proc/sys/fs/lease-break-time
echo 7048576 > /proc/sys/fs/nr_open
echo 2 > /proc/sys/kernel/panic
echo 1 > /proc/sys/kernel/panic_on_oops
echo 0 > /proc/sys/kernel/sched_child_runs_first
echo 9000000 > /proc/sys/kernel/sched_latency_ns
echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 4000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 16384 > /proc/sys/kernel/threads-max
echo 0 > /proc/sys/vm/block_dump
echo 15 > /proc/sys/vm/dirty_background_ratio
echo 800 > /proc/sys/vm/dirty_expire_centisecs
echo 15 > /proc/sys/vm/dirty_ratio
echo 500 > /proc/sys/vm/dirty_writeback_centisecs
echo 0 > /proc/sys/vm/laptop_mode
echo 4096 > /proc/sys/vm/min_free_kbytes
echo 0 > /proc/sys/vm/laptop_mode
echo 4096 > /proc/sys/vm/min_free_kbytes
echo 0 > /proc/sys/vm/oom_kill_allocating_task
echo 8 > /proc/sys/vm/page-cluster
echo 0 > /proc/sys/vm/panic_on_oom
echo 200 > /proc/sys/vm/swappiness
echo 120 > /proc/sys/vm/vfs_cache_pressure


EOF



# Dale permisos de ejecución para que Magisk pueda iniciarlo:
chmod +x /data/adb/service.d/zram_4gb.sh

su
sh /data/adb/service.d/zram_4gb.sh


# Para que no tengas que escribir sh /data/adb/service.d/zram_4gb.sh cada vez que prendas el celular, ejecuta estos últimos tres comandos en Termux:
su
chown root:root /data/adb/service.d/zram_4gb.sh
chmod 755 /data/adb/service.d/zram_4gb.sh
chcon u:object_r:magisk_file:s0 /data/adb/service.d/zram_4gb.sh


# revisar memoria ram y swap, manejando el uso de free -m
# revisar 
free -m | column -t











# Crea el archivo del script (usaremos un comando que escribe todo de una vez):
# (Copia y pega este bloque completo, pero asegúrate de que sea solo el código):
cat <<EOF > /data/adb/service.d/zram_4gb.sh
#!/system/bin/sh
# Esperar a que el sistema inicie un poco
# sleep 100
# Forzar el apagado de la ZRAM actual
# swapoff /dev/block/zram0
# Verificar si ZRAM está activo antes de intentar desactivarlo
if grep -q "/dev/block/zram0" /proc/swaps; then
    # Forzar el apagado de la ZRAM actual
    swapoff /dev/block/zram0
fi

mkswap /dev/block/zram0
swapon /dev/block/zram0
# 2. Paginación y retención en caché (Mantiene tus procesos vivos)
# echo 200 > /proc/sys/vm/swappiness
echo 100 > /proc/sys/vm/vfs_cache_pressure
# 3. Manejo de datos temporales "sucios" (Evita cuellos de botella al guardar archivos)
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 15 > /proc/sys/vm/dirty_ratio
# 4. Reservas de memoria (El colchón de seguridad para que el procesador no colapse)
echo 27648 > /proc/sys/vm/extra_free_kbytes
echo 4096 > /proc/sys/vm/min_free_kbytes
echo 65536 > /proc/sys/vm/user_reserve_kbytes

# Resetear para permitir el cambio de tamaño
echo 1 > /sys/block/zram0/reset
# max_user_instances
echo 768 > /proc/sys/fs/inotify/max_user_instances # o 512
# Configurar el algoritmo ZRAM
echo lz4 > /sys/block/zram0/comp_algorithm # O lzo
# echo 2147483648 > /sys/block/zram0/disksize # 2048
# Configurar los 4GB (4294967296 bytes)
echo 4294967296 > /sys/block/zram0/disksize
# Formatear y encender con prioridad alta
mkswap /dev/block/zram0
swapon /dev/block/zram0 -p 100
# bajar o subir swappiness
echo 200 > /proc/sys/vm/swappiness # 190 o 200

# 3. EL DETALLE CLAVE: Optimiza la velocidad de lectura de la Z-RAM
echo 0 > /proc/sys/vm/page-cluster
# 4. Tu paginación agresiva (la que te dio la estabilidad)
echo 200 > /proc/sys/vm/swappiness
echo 100 > /proc/sys/vm/vfs_cache_pressure
# 5. Manejo de datos temporales "sucios"
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 15 > /proc/sys/vm/dirty_ratio
# Reducir la agresividad con la que se limpia la caché del sistema de archivos:
echo 100 > /proc/sys/vm/vfs_cache_pressure
echo 65536 > /proc/sys/vm/user_reserve_kbytes
echo 4096 > /proc/sys/vm/min_free_kbytes # 8192
# 6. Tus reservas de memoria intactas (El colchón de seguridad)
echo 27648 > /proc/sys/vm/extra_free_kbytes
echo 4096 > /proc/sys/vm/min_free_kbytes
echo 65536 > /proc/sys/vm/user_reserve_kbytes
# Mejora la multitarea, aún cuando la pantalla está apagada y aumenta la duración de la batería 
echo 84000 > /proc/sys/fs/inotify/max_queued_events
echo 70240 > /proc/sys/fs/inotify/max_user_watches
echo 9048576 > /proc/sys/fs/file-max
EOF

# O si no quieres crear con cat, usa: sudo nano /data/adb/service.d/zram_4gb.sh
# nano /data/data/com.termux/files/usr/bin/nano /data/adb/service.d/zram_4gb.sh
# Dale permisos de ejecución para que Magisk pueda iniciarlo:
chmod +x /data/adb/service.d/zram_4gb.sh

# Activar zram
sh /data/adb/service.d/zram_4gb.sh


# Para que no tengas que escribir sh /data/adb/service.d/zram_4gb.sh cada vez que prendas el celular, ejecuta estos últimos tres comandos en Termux:
su
chown root:root /data/adb/service.d/zram_4gb.sh
chmod 755 /data/adb/service.d/zram_4gb.sh
chcon u:object_r:magisk_file:s0 /data/adb/service.d/zram_4gb.sh


su -c '
echo 2 > /proc/sys/kernel/panic
echo 64000 > /proc/sys/fs/inotify/max_queued_events
echo 512 > /proc/sys/fs/inotify/max_user_instances
echo 8 > /proc/sys/vm/page-cluster
echo 5048576 > /proc/sys/fs/file-max
echo 400000 > /proc/sys/fs/mount-max
echo 40 > /proc/sys/vm/vfs_cache_pressure
echo 30 > /proc/sys/vm/dirty_ratio
echo 16384 > /proc/sys/kernel/threads-max
echo 2048 > /proc/sys/kernel/max_lock_depth
echo 5760 > /proc/sys/fs/inotify/max_user_watches
echo 65536 > /proc/sys/kernel/perf_cpu_time_max_percent
echo 15 > /proc/sys/vm/dirty_background_ratio
echo 5120 > /proc/sys/vm/min_free_kbytes
echo 75536 > /proc/sys/fs/aio-max-nr
echo 7048576 > /proc/sys/fs/nr_open
'

########################################
# Optimización critica 
# Eleva el límite de procesos en caché a un nivel normal (Android administrará dinámicamente)
adb shell settings put global activity_manager_constants max_cached_processes=32
# Desactiva el asesino de procesos en segundo plano
adb shell su -c "device_config put activity_manager max_phantom_processes 2147483647"
adb shell su -c "settings put global settings_enable_monitor_phantom_procs false"

su
# Reducir la agresividad con la que se limpia la caché del sistema de archivos:
echo 100 > /proc/sys/vm/vfs_cache_pressure
echo 65536 > /proc/sys/vm/user_reserve_kbytes
echo 8192 > /proc/sys/vm/min_free_kbytes
mkswap /dev/block/zram0
swapon /dev/block/zram0
# 2. Paginación y retención en caché (Mantiene tus procesos vivos)
echo 200 > /proc/sys/vm/swappiness
echo 100 > /proc/sys/vm/vfs_cache_pressure

# 3. Manejo de datos temporales "sucios" (Evita cuellos de botella al guardar archivos)
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 15 > /proc/sys/vm/dirty_ratio

# 4. Reservas de memoria (El colchón de seguridad para que el procesador no colapse)
echo 27648 > /proc/sys/vm/extra_free_kbytes
echo 8192 > /proc/sys/vm/min_free_kbytes
echo 65536 > /proc/sys/vm/user_reserve_kbytes


# GEMINI
# 1. Comandos ADB
adb shell settings put global activity_manager_constants max_cached_processes=32
adb shell su -c "device_config put activity_manager max_phantom_processes 2147483647"
adb shell su -c "settings put global settings_enable_monitor_phantom_procs false"

su
# 2. Reinicio LIMPIO de la Z-RAM (CRÍTICO para evitar lag)
swapoff /dev/block/zram0 2>/dev/null

# Volver a encender Z-RAM "hazlo paso a paso"
echo 1 > /sys/block/zram0/reset
mkswap /dev/block/zram0
swapon /dev/block/zram0

# 3. EL DETALLE CLAVE: Optimiza la velocidad de lectura de la Z-RAM
echo 0 > /proc/sys/vm/page-cluster

# 4. Tu paginación agresiva (la que te dio la estabilidad)
echo 200 > /proc/sys/vm/swappiness
echo 100 > /proc/sys/vm/vfs_cache_pressure

# 5. Manejo de datos temporales "sucios"
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 15 > /proc/sys/vm/dirty_ratio

# 6. Tus reservas de memoria intactas (El colchón de seguridad)
echo 27648 > /proc/sys/vm/extra_free_kbytes
echo 8192 > /proc/sys/vm/min_free_kbytes
echo 65536 > /proc/sys/vm/user_reserve_kbytes

########################################

# revisar memoria ram y swap, manejando el uso de free -m
# revisar 
free -m | column -t


# script
# Entra a modo Root en Termux:
su

# Crea el archivo del script (usaremos un comando que escribe todo de una vez):
# (Copia y pega este bloque completo, pero asegúrate de que sea solo el código):
cat <<EOF > /data/adb/service.d/zram_4gb.sh
#!/system/bin/sh
# Esperar a que el sistema inicie un poco
sleep 20
# Forzar el apagado de la ZRAM actual
swapoff /dev/block/zram0
# Resetear para permitir el cambio de tamaño
echo 1 > /sys/block/zram0/reset
# echo 2147483648 > /sys/block/zram0/disksize # 2048
# Configurar los 4GB (4294967296 bytes)
echo 4294967296 > /sys/block/zram0/disksize
# Formatear y encender con prioridad alta
mkswap /dev/block/zram0
swapon /dev/block/zram0 -p 100
# bajar o subir swappiness
echo 170 > /proc/sys/vm/swappiness
EOF

# Dale permisos de ejecución para que Magisk pueda iniciarlo:
chmod +x /data/adb/service.d/zram_4gb.sh

su
sh /data/adb/service.d/zram_4gb.sh


# Para que no tengas que escribir sh /data/adb/service.d/zram_4gb.sh cada vez que prendas el celular, ejecuta estos últimos tres comandos en Termux:
su
chown root:root /data/adb/service.d/zram_4gb.sh
chmod 755 /data/adb/service.d/zram_4gb.sh
chcon u:object_r:magisk_file:s0 /data/adb/service.d/zram_4gb.sh


# revisar memoria ram y swap, manejando el uso de free -m
# revisar 
free -m | column -t


# script
#!/usr/bin/env python3
import shutil
import subprocess


def leer_memoria():
    salida = subprocess.run(["free", "-m"], capture_output=True, text=True).stdout.splitlines()
    mem_line = next(line for line in salida if line.startswith("Mem:"))
    swap_line = next(line for line in salida if line.startswith("Swap:"))
    mem = mem_line.split()
    swap = swap_line.split()
    return mem, swap

def calcular_widths(headers, rows, total_cols):
    # ancho mínimo por contenido
    widths = []
    for i, h in enumerate(headers):
        m = len(h)
        for r in rows:
            m = max(m, len(str(r[i])))
        widths.append(m)
    # ancho actual total
    base_width = sum(widths) + len(widths) + 1
    # si sobra espacio → distribuirlo
    extra = total_cols - base_width
    if extra > 0:
        i = 0
        while extra > 0:
            widths[i % len(widths)] += 1
            extra -= 1
            i += 1
    return widths

def armar_tabla(headers, rows, total_cols):
    widths = calcular_widths(headers, rows, total_cols)
    def linea(tipo):
        if tipo == "top":
            return "╒" + "╤".join("═" * w for w in widths) + "╕"
        elif tipo == "mid":
            return "╞" + "╪".join("═" * w for w in widths) + "╡"
        elif tipo == "sep":
            return "├" + "┼".join("─" * w for w in widths) + "┤"
        elif tipo == "bot":
            return "╘" + "╧".join("═" * w for w in widths) + "╛"
    def fila(values):
        celdas = []
        for i, v in enumerate(values):
            v_str = str(v)
            if v_str.isdigit() or v_str == "-":
                celdas.append(f"{v_str:>{widths[i]}}")  # derecha
            else:
                celdas.append(f"{v_str:<{widths[i]}}")  # izquierda
        return "│" + "│".join(celdas) + "│"
    
    # centra encabezados y alineas a la derecha los dígitos
    def fila(values, header=False):
        celdas = []
        for i, v in enumerate(values):
            v_str = str(v)
            if header:
                # centrado
                celdas.append(f"{v_str:^{widths[i]}}")
            else:
                # datos
                if v_str.isdigit() or v_str == "-":
                    celdas.append(f"{v_str:>{widths[i]}}")  # derecha
                else:
                    celdas.append(f"{v_str:<{widths[i]}}")  # izquierda
        return "│" + "│".join(celdas) + "│"
    
    print(linea("top"))
    # print(fila(headers))
    print(fila(headers, header=True)) # centra encabezados
    print(linea("mid"))
    for i, row in enumerate(rows):
        print(fila(row))
        if i != len(rows) - 1:
            print(linea("sep"))
    print(linea("bot"))

def ancho_necesario(headers, rows):
    widths = []
    for i, h in enumerate(headers):
        m = len(h)
        for r in rows:
            m = max(m, len(str(r[i])))
        widths.append(m)
    return sum(widths) + len(widths) + 1

# =========================
# MAIN
# =========================
mem, swap = leer_memoria()
cols = shutil.get_terminal_size(fallback=(80, 20)).columns
# Versiones
rows_full = [
    ["Mem",  mem[1],  mem[2],  mem[3],  mem[4],  mem[5],  mem[6]],
    ["Swap", swap[1], swap[2], swap[3], "-",     "-",     "-"],
]
headers_full = ["Tipo", "total", "used", "free", "shared", "buff/cache", "available"]
rows_mid = [
    ["Mem", mem[1], mem[2], mem[3], mem[6]],
    ["Swap", swap[1], swap[2], swap[3], "-"],
]
headers_mid = ["Tipo", "total", "used", "free", "available"]
rows_small = [
    ["Mem", mem[1], mem[2], mem[3]],
    ["Swap", swap[1], swap[2], swap[3]],
]
headers_small = ["Tipo", "total", "used", "free"]
# Elegir la mejor que quepa
if ancho_necesario(headers_full, rows_full) <= cols:
    armar_tabla(headers_full, rows_full, cols)
elif ancho_necesario(headers_mid, rows_mid) <= cols:
    armar_tabla(headers_mid, rows_mid, cols)
else:
    armar_tabla(headers_small, rows_small, cols)

    
# O

# Script
#!/usr/bin/env python3
try:
    from tabulate import tabulate
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "tabulate"])
    from tabulate import tabulate
import subprocess
output = subprocess.check_output(["free", "-m"], text=True).splitlines()
# Filtrar solo líneas válidas
mem_line = [l for l in output if l.startswith("Mem:")][0]
swap_line = [l for l in output if l.startswith("Swap:")][0]
mem = mem_line.split()
swap = swap_line.split()
data = [
    ["Mem",  mem[1],  mem[2],  mem[3],  mem[4],  mem[5],  mem[6]],
    ["Swap", swap[1], swap[2], swap[3], "-",     "-",     "-"],
]
print(tabulate(
    data,
    headers=["Tipo", "tot", "usd", "free", "shr", "buf", "ava"],
    tablefmt="fancy_grid",
    disable_numparse=True
))


    
# O

# Script
#!/usr/bin/env python3
try:
    from tabulate import tabulate
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "tabulate"])
    from tabulate import tabulate
import subprocess
output = subprocess.check_output(["free", "-m"], text=True).splitlines()
# Filtrar solo líneas válidas
mem_line = [l for l in output if l.startswith("Mem:")][0]
swap_line = [l for l in output if l.startswith("Swap:")][0]
mem = mem_line.split()
swap = swap_line.split()
data = [
    ["Mem",  mem[1],  mem[2],  mem[3],  mem[4],  mem[5],  mem[6]],
    ["Swap", swap[1], swap[2], swap[3], "-",     "-",     "-"],
]
print(tabulate(
    data,
    headers=["Tipo", "tot", "usd", "free", "shr", "buf", "ava"],
    tablefmt="fancy_grid",
    disable_numparse=True
))
