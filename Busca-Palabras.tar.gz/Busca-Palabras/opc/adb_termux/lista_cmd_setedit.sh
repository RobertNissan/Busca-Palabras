#!/bin/bash

COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Función para buscar comandos en todas las tablas
buscar_cmd_all_table() {
    read -p "Escriba su servidor ip:port (por defecto 'emulator-5554'): " servidor_adb 
    servidor_adb='emulator-5554'  # Usar valor por defecto si no se ingresa nada
    read -p "Escriba el comando a buscar: " cmd
    echo ""
    # Buscar en la tabla system
    echo -e "${COLOR_VERDE}Búsqueda de '$cmd' en la tabla system...${COLOR_RESET}"
    resultado=$(adb -s "$servidor_adb" shell settings list system | grep -i "$cmd")
    if [ -z "$resultado" ]; then
        echo -e "${COLOR_ROJO}Comando '$cmd' no encontrado en la tabla system.${COLOR_RESET}"
    else
        echo -e "${COLOR_AMARILLO}$resultado${COLOR_RESET}"
    fi
    echo ""
    # Buscar en la tabla secure
    echo -e "${COLOR_VERDE}Búsqueda de '$cmd' en la tabla secure...${COLOR_RESET}"
    resultado=$(adb -s "$servidor_adb" shell settings list secure | grep -i "$cmd")
    if [ -z "$resultado" ]; then
        echo -e "${COLOR_ROJO}Comando '$cmd' no encontrado en la tabla secure.${COLOR_RESET}"
    else
        echo -e "${COLOR_AMARILLO}$resultado${COLOR_RESET}"
    fi
    echo ""
    # Buscar en la tabla global
    echo -e "${COLOR_VERDE}Búsqueda de '$cmd' en la tabla global...${COLOR_RESET}"
    resultado=$(adb -s "$servidor_adb" shell settings list global | grep -i "$cmd")
    if [ -z "$resultado" ]; then
        echo -e "${COLOR_ROJO}Comando '$cmd' no encontrado en la tabla global.${COLOR_RESET}"
    else
        echo -e "${COLOR_AMARILLO}$resultado${COLOR_RESET}"
    fi
}

# Funciones para listar las tablas individuales
tabla1() {
    servidor_adb='emulator-5554'
    echo "Listando la tabla system..."
    adb -s "$servidor_adb" shell settings list system
}
tabla2() {
    servidor_adb='emulator-5554'
    echo "Listando la tabla secure..."
    adb -s "$servidor_adb" shell settings list secure
}
tabla3() {
    servidor_adb='emulator-5554'
    echo "Listando la tabla global..."
    adb -s "$servidor_adb" shell settings list global
}
# Menú de opciones
menu() {
    echo "Seleccione una opción:"
    echo "1. Buscar comando en todas las tablas (system, secure, global)"
    echo "2. Listar tabla system"
    echo "3. Listar tabla secure"
    echo "4. Listar tabla global"
    echo "5. Salir"
    
    read -p "Opción: " opcion
    
    case $opcion in
        1)
            buscar_cmd_all_table
            ;;
        2)
            tabla1
            ;;
        3)
            tabla2
            ;;
        4)
            tabla3
            ;;
        5)
            echo "Saliendo..."
            exit 0
            ;;
        *)
            echo "Opción no válida. Intente de nuevo."
            ;;
    esac
}

# Bucle principal del menú
while true; do
    menu
done

' :
Para cambiar la configuración de clock_seconds en un dispositivo Android usando adb, puedes intentar lo siguiente:

Verifica si el comando está disponible en las configuraciones actuales:
bash
Copiar código
adb shell settings list system | grep "clock_seconds"
Esto te mostrará si la opción clock_seconds existe en el sistema y en qué tabla está (puede estar en system, secure, o global).

Cambia el valor de clock_seconds: Si clock_seconds está en la tabla system, puedes usar el siguiente comando:
bash
Copiar código
adb shell settings put system clock_seconds 1
Si está en secure o global, ajusta el comando en consecuencia:

bash
Copiar código
adb shell settings put secure clock_seconds 1
o

bash
Copiar código
adb shell settings put global clock_seconds 1
Notas:
Si clock_seconds no existe, es posible que no sea una configuración que se pueda modificar directamente con adb.
El comando adb shell settings put permite modificar valores dentro de las tablas system, secure, y global. Estos comandos cambiarán la configuración en el dispositivo directamente.
Asegúrate de verificar el efecto del cambio en tu dispositivo, ya que no todas las configuraciones pueden ser visibles o alteradas en todas las versiones de Android.

' :