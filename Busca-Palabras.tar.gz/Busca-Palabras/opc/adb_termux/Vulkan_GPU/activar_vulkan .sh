# fuerza el renderizado de la interfaz de usuario (UI) mediante la GPU en lugar de la CPU.
adb shell settings put global debug.force_gpu_render 1

adb shell getprop | grep vulkan  # Verificar propiedades de Vulkan

adb shell setprop debug.vulkan.force true  # Forzar Vulkan
adb shell setprop debug.hwui.renderer skiavk # (Opcional) Usar Vulkan para la interfaz gráfica de Android

adb shell su -c setprop persist.vulkan.enable true  # Activar Vulkan de manera persistente
adb shell su -c setprop persist.hwui.use_vulkan true  # Usar Vulkan para la interfaz de usuario
adb shell su -c setprop persist.android.vulkan.memory 2048  # (Opcional) Aumentar memoria asignada a Vulkan


# verificar vulkan
adb -s emulator-5554 shell dumpsys gfxinfo | grep -i "pipeline"
adb -s emulator-5554 shell dumpsys | grep -i vulkan
# verificar si una app está usando vulkan, abre la app específica, ejemplo (org.citra.emu) y luego en termux escribe lo siguiente:
adb -s emulator-5554 shell dumpsys gfxinfo org.citra.emu
adb -s emulator-5554 shell dumpsys gfxinfo org.citra.emu | grep -E 'Vulkan|OpenGL'
# . Usar adb y dumpsys gfxinfo
# Este comando te da información detallada sobre el pipeline gráfico, tiempos de renderizado, y otros detalles. Para monitorear el rendimiento en tiempo real:
adb shell dumpsys gfxinfo org.citra.emu framestats

