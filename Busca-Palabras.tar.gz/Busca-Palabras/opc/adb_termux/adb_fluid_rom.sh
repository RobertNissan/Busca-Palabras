# explorar las propiedades 
# adb -s emulator-5554 shell getprop

# Disfrute de inicios mas rapidos y Ajuste inalambrico estables.
# Si no tienes root, entonces quita su -c del codigo
# Si acaso tienes root, puedes agregar los codigos al build.prop desde la app 3C All In One ToolBox desde la opcion "Administracion de rom"/Construir
adb -s emulator-5554 shell su -c setprop ro.config.hw_quickpoweron "true"
adb -s emulator-5554 shell su -c setprop boot.fps "25"
adb -s emulator-5554 shell su -c setprop debug.sf.nobootanimation "1"

# 1. Densidad de visualizacion
adb -s emulator-5554 shell su -c wm density 280

# Esto tambien puedes anadirlo en la app SetEdit
# fps min setedit System Table y Secure Table
adb -s emulator-5554 shell su -c setprop refresh_rate_mode "2"
adb -s emulator-5554 shell su -c setprop min_refresh_rate "60"
adb -s emulator-5554 shell su -c setprop max_refresh_rate "90"
# Global Table
adb -s emulator-5554 shell su -c settings put global hwui.disable_overlay 1
# System Table
# Establecer el brillo a 50
adb -s emulator-5554 shell settings put system screen_brightness 50
# Botones de navegación inferiores, Agregar deslizando "2"
adb -s emulator-5554 shell su -c setprop navigationbar_config "2" # Normal "0" Invertido "1"
# Nota de aviso, esta siempre debe estar en 1 de lo contrario se ocultan los botones de navegación inferiores
adb -s emulator-5554 shell su -c setprop show_navigationbar "1"
# Secure Table
# activar el segundero del reloj
adb -s emulator-5554 shell su -c setprop clock_seconds "1" # o "null"
adb -s emulator-5554 shell su -c setprop double_tap_to_wake "0" # o "1"
adb -s emulator-5554 shell su -c setprop hush_gesture_used "0" # o "1"
adb -s emulator-5554 shell su -c setprop immersive_mode_confirmations "0" # o "confirmed"
# agilizar el boton de multitareas
adb -s emulator-5554 shell su -c setprop long_press_timeout "400" # o "150" o "120"
adb -s emulator-5554 shell su -c setprop multi_press_timeout "400" # o "150" o "120"
# Activa el modo oscuro "0" activa, "1" para desactivar"
adb -s emulator-5554 shell su -c setprop ui_night_mode "1"

# Global Table
# 2.Llamar sin demora
adb -s emulator-5554 shell su -c settings put global ring.delay "0"

# Global Table
# 3.ahorrar bateria.
adb -s emulator-5554 shell su -c settings put global pm.sleep_mode 1
adb -s emulator-5554 shell su -c settings put global power_supply.wakeup enable

# Global Table
# 4.Juegos/rendimiento 3D.
adb -s emulator-5554 shell su -c setprop debug.enabletr true
adb -s emulator-5554 shell su -c setprop debug.qctwa.preservebuf 1
adb -s emulator-5554 shell su -c setprop dev.pm.dyn_samplingrate 1
adb -s emulator-5554 shell su -c setprop video.accelerate.hw 1
adb -s emulator-5554 shell su -c setprop debug.overlayui.enable 1
adb -s emulator-5554 shell su -c setprop debug.egl.hw 1
adb -s emulator-5554 shell su -c setprop debug.egl.profiler 1
adb -s emulator-5554 shell su -c setprop debug.sf.hw 1
adb -s emulator-5554 shell su -c setprop debug.composition.type c2d
adb -s emulator-5554 shell su -c setprop debug.composition.type gpu
adb -s emulator-5554 shell su -c setprop debug.performance.tuning 1

# System Table
# 5.Mejor velocidad de desplazamiento de navegacion
adb -s emulator-5554 shell su -c setprop windowsmgr.max_events_per_sec 90

# System Table
# 6.Desactive la animacion del lector de huellas digitales.
adb -s emulator-5554 shell su -c setprop fod_animation_type 4

# Global Table
# 7.deshabilitar logcat.
#adb -s emulator-5554 shell su -c setprop global Logcat.live disable
#correccion
adb -s emulator-5554 shell su -c setprop log.tag.update "platform"

# Secure Table
# 8. Mejorar la calidad del sonido
adb -s emulator-5554 shell su -c setprop af.resampler.quality 255
adb -s emulator-5554 shell su -c setprop mpq.audio.decode true
# 9.Habilite la aceleracion de GPU (evite habilitar esta funcion en el modo de desarrollador, se restablecera cuando el telefono se reinicie)
adb -s emulator-5554 shell su -c setprop debug.qc.hardware true
adb -s emulator-5554 shell su -c setprop debug.qctwa.statusbar 1
adb -s emulator-5554 shell su -c setprop debug.qctwa.preservebuf 1
adb -s emulator-5554 shell su -c setprop debug.composition.type vulkan
adb -s emulator-5554 shell su -c setprop hw3d.force 1
adb -s emulator-5554 shell su -c setprop hwui.render_dirty_regions false
adb -s emulator-5554 shell su -c setprop hwui.disable_vsync true

# Global Table
# 10. Retroalimentacion haptica
adb -s emulator-5554 shell su -c setprop haptic_feedback_enabled 0

# Global Table
# 11. Sensibilidad tactil
adb -s emulator-5554 shell su -c setprop touch.presure.scale 0.5
adb -s emulator-5554 shell su -c setprop debug.egl.profiler 1
adb -s emulator-5554 shell su -c "setprop persist.sys.scrollingcache 0.005"

# Global Table
# 12. Modifique la maquina virtual Dalvik.  El rendimiento general del dispositivo es mejor.
adb -s emulator-5554 shell su -c setprop dalvik.vm.checkjni "false"
adb -s emulator-5554 shell su -c setprop dalvik.vm.dexopt-data-only "1"
# "dalvik.vm.heapstartsize" Ajustar el tamano de la heap puede ser util en situaciones especificas para optimizar el rendimiento o gestionar mejor los recursos de memoria, pero tambien puede tener impactos en el rendimiento general del sistema.
adb -s emulator-5554 shell su -c setprop dalvik.vm.heapstartsize "5m"
# La propiedad dalvik.vm.heapgrowthlimit controla el limite maximo al que la region de la memoria heap de Dalvik puede crecer. En otras palabras, establece un tope en la cantidad de memoria que puede ser asignada dinamicamente a la heap de una aplicacion mientras se ejecuta.
adb -s emulator-5554 shell su -c setprop dalvik.vm.heapgrowthlimit "192m"
# "dalvik.vm.heapsize" Este ajuste es parte de la configuracion de la maquina virtual Dalvik y puede tener impacto en como se asigna y gestiona la memoria durante la ejecucion de las aplicaciones. Al establecer un limite de crecimiento, se puede controlar el uso de memoria de las aplicaciones y evitar situaciones en las que una aplicacion podria consumir una cantidad excesiva de memoria.
adb -s emulator-5554 shell su -c setprop dalvik.vm.heapsize "256m"
adb -s emulator-5554 shell su -c setprop dalvik.vm.verify-bytecode "false"
adb -s emulator-5554 shell su -c setprop dalvik.vm.execution-mode "int:jit"
adb -s emulator-5554 shell su -c setprop dalvik.vm.lockprof.threshold "250"
adb -s emulator-5554 shell su -c setprop dalvik.vm.dexopt-flags "m=v,o=y"
adb -s emulator-5554 shell su -c setprop dalvik.vm.stack-trace-file "/data/anr/traces.txt"
adb -s emulator-5554 shell su -c setprop dalvik.vm.jmiopts "forcecopy"

# System Table
# 13.Transmision de video y sintonizacion de medios mas fluidas
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-player "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-meta "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-scan "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-http "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-aac "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-qcp "true"
adb -s emulator-5554 shell su -c setprop media.stagefright.enable-record "true"

# Global Table
# 14..Ajuste inalambrico
adb -s emulator-5554 shell su -c setprop net.ipv4.ip_no_pmtu_disc 0
adb -s emulator-5554 shell su -c setprop net.ipv4.route.flush 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_ecn 0
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_fack 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_moderate_rcvbuf 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_no_metrics_save 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_rfc1337 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_sack 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_timestamps 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_window_scaling 1
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_mem "187000 187000 187000"
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_wmem "4096 39000 18700"
adb -s emulator-5554 shell su -c setprop net.ipv4.tcp_rmem "4096 39000 187000"
# si estos 3 ultimos no funcionan, entonces entra a la shell:
# adb -s emulator-5554 shell
# setprop net.ipv4.tcp_mem "187000 187000 187000"
#Si deseas verificar si la propiedad se ha actualizado correctamente, puedes usar el comando `getprop` para obtener el valor actual de la propiedad:
# getprop net.ipv4.tcp_wmem

# 15. Esto eliminara el limite de fps (INTENTE BAJO SU PROPIO RIESGO). Ejecuto este doh, esta bien.
adb -s emulator-5554 shell su -c setprop debug.gr.swapinterval "0"
# debe estar convertido a dos2unix este archivo
adb -s emulator-5554 shell su -c "setprop persist.sys.NV_FPSLIMIT 120"
adb -s emulator-5554 shell su -c "settings put global 0.0_fps_max 120"
adb -s emulator-5554 shell su -c "settings put secure refresh_rate_mode 2"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_POWERMODE 1"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_PROFVER 15"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOCTRL 0"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOSEPCHG 0"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOSEP 20"
# verificar si los fps se aplicaron
#sudo adb -s emulator-5554 shell dmesg | grep -i "fps"
adb -s emulator-5554 shell su -c dmesg | grep -i "fps"

