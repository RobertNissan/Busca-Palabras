#!/bin/bash
# debe estar convertido a dos2unix este archivo
adb -s emulator-5554 shell su -c "setprop persist.sys.NV_FPSLIMIT 120"
adb -s emulator-5554 shell su -c "settings put global 0.0_fps_max 120"
adb -s emulator-5554 shell su -c "settings put secure refresh_rate_mode 2"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_POWERMODE 1"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_PROFVER 15"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOCTRL 0"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOSEPCHG 0"
adb -s  emulator-5554 shell su -c "setprop persist.sys.NV_STEREOSEP 20"

# verificar si los fps se aplicaron
#sudo adb -s emulator-5554 shell dmesg | grep -i "fps"
adb -s emulator-5554 shell su -c dmesg | grep -i "fps"
