¿como abrir aplicacion por medio de adb? ¿como abrir app por medio de adb? ¿como abrir apk por medio de adb? ¿abrir aplicacion por medio de adb? ¿abrir app por medio de adb? ¿abrir apk por medio de adb? ¿como abrir aplicacion por adb? ¿como abrir app por adb? ¿como abrir apk por adb? ¿abrir aplicacion por adb? ¿abrir app por adb? ¿abrir apk por adb?

adb shell am start -n nombre.paquete/clase.ActividadPrincipal

# primero buscar el nombre del paquete para luego buecar la actividad por medio del paquete:
adb -s emulator-5554 shell pm list packages | grep --color=always 'edit' | sed 's/package://'

# obtener la activida principal en este ejemplo de setedit.apk
adb shell dumpsys package by4a.setedit22 | grep -A 10 "android.intent.action.MAIN" | grep "by4a.setedit22/"
adb -s emulator-5554 shell dumpsys package com.facebook.lite | grep -A 10 "android.intent.action.MAIN" | grep --color=always "com.facebook.lite/.Main" | awk '{print $2}'

# Para abrir audio relay
adb shell am start -n com.azefsw.audioconnect/com.azefsw.audioconnect.root.ui.RootActivity

# Para abrir vcl player
adb shell am start -n org.videolan.vlc/org.videolan.vlc.StartActivity

# Para abrir Facebook
adb shell am start -n com.facebook.lite/com.facebook.lite.MainActivity




#########SCRIPT-PARA-AUTOMATIZAR#########
#!/bin/bash
# Asegúrate de pasar el nombre del paquete como argumento
# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Verificar si se han proporcionado los dos argumentos
if [ $# -ne 2 ]; then
    script_name=$(basename "$0")
    echo -e "\n${YELLOW}Para ejecutar correctamente, pase dos argumentos:${NC}\n"
    echo -e "${GREEN}Uso:${NC} ${YELLOW}bash $script_name ${RED}dispositivo_adb comando_a_buscar${NC}\n"
    exit 1
fi

# Definir el emulador
EMULATOR_ID="$1"
# Guardar el nombre del paquete
PACKAGE_NAME="$2"

# Obtener solo la primera ocurrencia de la actividad principal
ACTIVIDAD=$(adb -s "$EMULATOR_ID" shell dumpsys package "$PACKAGE_NAME" | grep -A 10 "android.intent.action.MAIN" | grep "$PACKAGE_NAME" | awk '{print $2}' | head -n 1)
# Verificar si se encontró la actividad principal
if [ -z "$ACTIVIDAD" ]; then
    echo "No se pudo encontrar la actividad principal para el paquete $PACKAGE_NAME"
    exit 1
fi
# Si la actividad ya incluye el nombre completo (prefijo con el paquete), no modificar.
# Si la actividad empieza con un ".", completar con el nombre del paquete
if [[ "$ACTIVIDAD" == /* ]]; then
    ACTIVIDAD="$PACKAGE_NAME$ACTIVIDAD"
fi
# Iniciar la aplicación usando la actividad principal encontrada
echo -e "adb -s "$EMULATOR_ID" shell am start -n "$ACTIVIDAD""
# adb -s "$EMULATOR_ID" shell am start -n "$ACTIVIDAD"


chmod +x obtener_actividad_principal.sh
# se debe pasar el nombre del paquete obtenido como argumento
bash obtener_actividad_principal.sh ip:adb_port com.facebook.lite
# o
./obtener_actividad_principal.sh com.facebook.lite
