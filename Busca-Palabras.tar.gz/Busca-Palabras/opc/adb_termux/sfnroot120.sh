#!/system/bin/sh

: '
En termux trabajan solo entrando:
adb shell 
y ejecuta el script asi: 
sh script.sh
: '
start_time=$(date +%s)

echo "
"
echo "[ SurfaceFlinger Optimization Commands by Droid Everything ]"
echo ""
sleep 1
echo "You are running sfnroot"
echo "[ Does not require ROOT access ]"
sleep 1
echo "[ debug commands ready ]"
sleep 1
echo "[ Executing debug commands ]"
sleep 2
echo "
"
echo "Writing to system:"
sleep 1
setprop debug.sys.sf.color_saturation 1.0
echo "[ debug.sys.sf.color_saturation 1.0 ]"
sleep 0.5
setprop debug.sys.sf.color_mode vivid
echo "[ debug.sys.sf.color_mode vivid ]"
sleep 0.5
setprop debug.sys.sf.transition_animation_scale 0.5
echo "[ debug.sys.sf.transition_animation_scale 0.5 ]"
sleep 0.5
setprop debug.sys.sf.enable_vds 1
echo "[ debug.sys.sf.enable_vds 1 ]"
sleep 0.5
setprop debug.sys.sf.composition_type hybrid
echo "[ debug.sys.sf.composition_type hybrid ]"
sleep 0.5
setprop debug.sys.sf.frame_rate 115
echo "[ debug.sys.sf.frame_rate 115 ]"
sleep 0.5
setprop debug.sys.sf.disable_backpressure 1
echo "[ debug.sys.sf.disable_backpressure 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_buffer_shrink 0
echo "[ debug.sys.sf.disable_buffer_shrink 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_blending 1
echo "[ debug.sys.sf.disable_blending 1 ]"
sleep 0.5
setprop debug.sys.sf.max_frame_rate 115
echo "[ debug.sys.sf.max_frame_rate 115 ]"
sleep 0.5
setprop debug.sys.sf.disable_double_buffering 1
echo "[ debug.sys.sf.disable_double_buffering 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_vsync 1
echo "[ debug.sys.sf.disable_vsync 1 ]"
sleep 0.5
setprop debug.sys.sf.swap_interval 0
echo "[ debug.sys.sf.swap_interval 0 ]"
sleep 0.5
setprop debug.sys.sf.enable_debug_tracing 0
echo "[ debug.sys.sf.enable_debug_tracing 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_idle_composition 0
echo "[ debug.sys.sf.disable_idle_composition 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_hw_vsync 1
echo "[ debug.sys.sf.disable_hw_vsync 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_composition_caching 0
echo "[ debug.sys.sf.disable_composition_caching 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_fb_caching 0
echo "[ debug.sys.sf.disable_fb_caching 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_async_composition 0
echo "[ debug.sys.sf.disable_async_composition 0 ]"
sleep 0.5
setprop debug.sys.sf.enable_texture_slicer 1
echo "[ debug.sys.sf.enable_texture_slicer 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_out_of_order_optimization 0
echo "[ debug.sys.sf.disable_out_of_order_optimization 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_fallback_caching 0
echo "[ debug.sys.sf.disable_fallback_caching 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_layer_caching 0
echo "[ debug.sys.sf.disable_layer_caching 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_overlay_caching 0
echo "[ debug.sys.sf.disable_overlay_caching 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_expensive_blur 1
echo "[ debug.sys.sf.disable_expensive_blur 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_global_refresh 1
echo "[ debug.sys.sf.disable_global_refresh 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_buffer_shrink 1
echo "[ debug.sys.sf.disable_buffer_shrink 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_double_buffering 1
echo "[ debug.sys.sf.disable_double_buffering 1 ]"
sleep 0.5
setprop debug.sys.sf.frame_rate_override 115
echo "[ debug.sys.sf.frame_rate_override 115 ]"
sleep 0.5
setprop debug.sys.sf.swap_interval 0
echo "[ debug.sys.sf.swap_interval 0 ]"
sleep 0.5
setprop debug.sys.sf.use_buffer_queue 1
echo "[ debug.sys.sf.use_buffer_queue 1 ]"
sleep 0.5
setprop debug.sys.sf.use_color_management 0
echo "[ debug.sys.sf.use_color_management 0 ]"
sleep 0.5
setprop debug.sys.sf.use_hwc_2 1
echo "[ debug.sys.sf.use_hwc_2 1 ]"
sleep 0.5
setprop debug.sys.sf.use_shadow 0
echo "[ debug.sys.sf.use_shadow 0 ]"
sleep 0.5
setprop debug.sys.sf.use_trilinear 0
echo "[ debug.sys.sf.use_trilinear 0 ]"
sleep 0.5
setprop debug.sys.sf.enable_fb_early_synchronize 1
echo "[ debug.sys.sf.enable_fb_early_synchronize 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_fb_pre_post 1
echo "[ debug.sys.sf.enable_fb_pre_post 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_fb_ubwc 0
echo "[ debug.sys.sf.enable_fb_ubwc 0 ]"
sleep 0.5
setprop debug.sys.sf.enable_texture_pooling 1
echo "[ debug.sys.sf.enable_texture_pooling 1 ]"
sleep 0.5
setprop debug.sys.sf.force_flex_comp 1 
echo "[ debug.sys.sf.force_flex_comp 1 ]"
sleep 0.5
setprop debug.sys.sf.gpu_memcg.enabled 0
echo "[ debug.sys.sf.gpu_memcg.enabled 0 ]"
sleep 0.5
setprop debug.sys.sf.lss.early_completion 1
echo "[ debug.sys.sf.lss.early_completion 1 ]"
sleep 0.5
setprop debug.sys.sf.lss.enable 1
echo "[ debug.sys.sf.lss.enable 1 ]"
sleep 0.5
setprop debug.sys.sf.rc_flags 1
echo "[ debug.sys.sf.rc_flags 1 ]"
sleep 0.5
setprop debug.sys.sf.use_color_cache 1
echo "[ debug.sys.sf.use_color_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.use_image_cache 1
echo "[ debug.sys.sf.use_image_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.use_overlay_cache 1
echo "[ debug.sys.sf.use_overlay_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.use_shader_cache 1
echo "[ debug.sys.sf.use_shader_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.use_surface_cache 1
echo "[ debug.sys.sf.use_surface_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.wait_for_gpu_idle 0
echo "[ debug.sys.sf.wait_for_gpu_idle 0 ]"
sleep 0.5
setprop debug.sys.sf.disable_drop_shadow 1
echo "[ debug.sys.sf.disable_drop_shadow 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_surface_peeking 1
echo "[ debug.sys.sf.disable_surface_peeking 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_texture_retrieval 1
echo "[ debug.sys.sf.disable_texture_retrieval 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_async_texture_upload 1
echo "[ debug.sys.sf.enable_async_texture_upload 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_buffer_prefetch 1
echo "[ debug.sys.sf.enable_buffer_prefetch 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_gpu_rescale 1
echo "[ debug.sys.sf.enable_gpu_rescale 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_multi_process_composition 1
echo "[ debug.sys.sf.enable_multi_process_composition 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_perf_optimized_pipe 1
echo "[ debug.sys.sf.enable_perf_optimized_pipe 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_reduced_frame_memory 1
echo "[ debug.sys.sf.enable_reduced_frame_memory 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_surface_optimization 1
echo "[ debug.sys.sf.enable_surface_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_texture_preload 1
echo "[ debug.sys.sf.enable_texture_preload 1 ]"
sleep 0.5
setprop debug.sys.sf.use_hw_render_node 1
echo "[ debug.sys.sf.use_hw_render_node 1 ]"
sleep 0.5
setprop debug.sys.sf.use_virtual_display_surfaceless 1
echo "[ debug.sys.sf.use_virtual_display_surfaceless 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_blur 1
echo "[ debug.sys.sf.disable_blur 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_gpu_driver_blacklist 1
echo "[ debug.sys.sf.disable_gpu_driver_blacklist 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_gpu_fence_sync 1
echo "[ debug.sys.sf.disable_gpu_fence_sync 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_hwc_layer_stretch 1
echo "[ debug.sys.sf.disable_hwc_layer_stretch 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_lowmem_oom_handling 1
echo "[ debug.sys.sf.disable_lowmem_oom_handling 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_shadow_cache 1
echo "[ debug.sys.sf.disable_shadow_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_swapbuffers_compression 1
echo "[ debug.sys.sf.disable_swapbuffers_compression 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_buffer_map_cache 1
echo "[ debug.sys.sf.enable_buffer_map_cache 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_dual_layer_composition 1
echo "[ debug.sys.sf.enable_dual_layer_composition 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_post_ROT 1
echo "[ debug.sys.sf.enable_post_ROT 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_triple_buffer 1
echo "[ debug.sys.sf.enable_triple_buffer 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_turbo 1
echo "[ debug.sys.sf.enable_turbo 1 ]"
sleep 0.5
setprop debug.sys.sf.disable_legacy_input 1
echo "[ debug.sys.sf.disable_legacy_input 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_flinger_touch_input 1
echo "[ debug.sys.sf.enable_flinger_touch_input 1 ]"
sleep 0.5
setprop debug.sys.sf.enable_touch_latency_optimization 1
echo "[ debug.sys.sf.enable_touch_latency_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_threshold_ms 16
echo "[ debug.sys.sf.input_latency_threshold_ms 16 ]"
sleep 0.5
setprop debug.sys.sf.input_thread_priority 1
echo "[ debug.sys.sf.input_thread_priority 1 ]"
sleep 0.5
setprop debug.sys.sf.touch_boost 1
echo "[ debug.sys.sf.touch_boost 1 ]"
sleep 0.5
setprop debug.sys.sf.touch_input_latency_tolerance 10
echo "[ debug.sys.sf.touch_input_latency_tolerance 10 ]"
sleep 0.5
setprop debug.sys.sf.touch_processing_interval 5
echo "[ debug.sys.sf.touch_processing_interval 5 ]"
sleep 0.5
setprop debug.sys.sf.touch_sampling_interval 8
echo "[ debug.sys.sf.touch_sampling_interval 8 ]"
sleep 0.5
setprop debug.sys.sf.touch_latency_smoothing 1
echo "[ debug.sys.sf.touch_latency_smoothing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_boost 1
echo "[ debug.sys.sf.input_latency_boost 1 ]"
sleep 0.5
setprop debug.sys.sf.input_thread_affinity 1
echo "[ debug.sys.sf.input_thread_affinity 1 ]"
sleep 0.5
setprop debug.sys.sf.input_thread_scheduler_policy 1
echo "[ debug.sys.sf.input_thread_scheduler_policy 1 ]"
sleep 0.5
setprop debug.sys.sf.input_thread_vsync_alignment 0 
echo "[ debug.sys.sf.input_thread_vsync_alignment 0 ]"
sleep 0.5
setprop debug.sys.sf.input_event_rate_limit 1
echo "[ debug.sys.sf.input_event_rate_limit 1 ]"
sleep 0.5
setprop debug.sys.sf.input_thread_idle_priority 1
echo "[ debug.sys.sf.input_thread_idle_priority 1 ]"
sleep 0.5
setprop debug.sys.sf.input_post_processing_latency 1
echo "[ debug.sys.sf.input_post_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_touch_event_processing_latency 1
echo "[ debug.sys.sf.input_touch_event_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_gesture_event_processing_latency 1
echo "[ debug.sys.sf.input_gesture_event_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_scroll_event_processing_latency 1
echo "[ debug.sys.sf.input_scroll_event_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_key_event_processing_latency 1
echo "[ debug.sys.sf.input_key_event_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_pointer_event_processing_latency 1
echo "[ debug.sys.sf.input_pointer_event_processing_latency 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_scheduling 1
echo "[ debug.sys.sf.input_latency_scheduling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_reduction 1
echo "[ debug.sys.sf.input_latency_reduction 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_tuning 1
echo "[ debug.sys.sf.input_latency_tuning 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prioritization 1
echo "[ debug.sys.sf.input_latency_prioritization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_interpolation 1
echo "[ debug.sys.sf.input_latency_interpolation 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_adaptive_tuning 1
echo "[ debug.sys.sf.input_latency_adaptive_tuning 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prediction 1
echo "[ debug.sys.sf.input_latency_prediction 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_heuristics 1
echo "[ debug.sys.sf.input_latency_heuristics 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_compensation 1
echo "[ debug.sys.sf.input_latency_compensation 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_fine_tuning 1
echo "[ debug.sys.sf.input_latency_fine_tuning 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_multithreading 1
echo "[ debug.sys.sf.input_latency_multithreading 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prediction_models 1
echo "[ debug.sys.sf.input_latency_prediction_models 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_neural_networks 1
echo "[ debug.sys.sf.input_latency_neural_networks 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_quantum_processing 1
echo "[ debug.sys.sf.input_latency_quantum_processing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_resilience 1
echo "[ debug.sys.sf.input_latency_resilience 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_autocalibration 1
echo "[ debug.sys.sf.input_latency_autocalibration 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_adaptive_sampling 1
echo "[ debug.sys.sf.input_latency_adaptive_sampling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_temporal_filtering 1
echo "[ debug.sys.sf.input_latency_temporal_filtering 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_spatial_filtering
1
echo "[ debug.sys.sf.input_latency_spatial_filtering 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_preemption 1
echo "[ debug.sys.sf.input_latency_preemption 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_interpolation_interval 10
echo "[ debug.sys.sf.input_latency_interpolation_interval 10 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_event_scheduling 1
echo "[ debug.sys.sf.input_latency_event_scheduling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_control_loop 1
echo "[ debug.sys.sf.input_latency_control_loop 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prediction_window 1
echo "[ debug.sys.sf.input_latency_prediction_window 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_response_threshold 1
echo "[ debug.sys.sf.input_latency_response_threshold 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_reliability_metrics 1
echo "[ debug.sys.sf.input_latency_reliability_metrics 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prediction_accuracy 1
echo "[ debug.sys.sf.input_latency_prediction_accuracy 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_prefetching 1
echo "[ debug.sys.sf.input_latency_prefetching 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_preprocessing
1
echo "[ debug.sys.sf.input_latency_preprocessing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_smart_sampling 1
echo "[ debug.sys.sf.input_latency_smart_sampling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_multi_stage_processing 1
echo "[ debug.sys.sf.input_latency_multi_stage_processing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_accelerated_processing 1
echo "[ debug.sys.sf.input_latency_accelerated_processing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_interactive_mode 1
echo "[ debug.sys.sf.input_latency_interactive_mode 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_realtime_adjustment 1
echo "[ debug.sys.sf.input_latency_realtime_adjustment 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_heuristic_optimization 1
echo "[ debug.sys.sf.input_latency_heuristic_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_parallel_processing 1 
echo "[ debug.sys.sf.input_latency_parallel_processing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_reactive_mode 1
echo "[ debug.sys.sf.input_latency_reactive_mode 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_temporal_adjustment 1
echo "[ debug.sys.sf.input_latency_temporal_adjustment 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_priority_scheduling 1
echo "[ debug.sys.sf.input_latency_priority_scheduling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_preemptive_caching 1
echo "[ debug.sys.sf.input_latency_preemptive_caching 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_multimodal_processing
1
echo "[ debug.sys.sf.input_latency_multimodal_processing 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_hybrid_approach 1
echo "[ debug.sys.sf.input_latency_hybrid_approach 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_tuning_mode 1
echo "[ debug.sys.sf.input_latency_tuning_mode 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_noise_reduction 1
echo "[ debug.sys.sf.input_latency_noise_reduction 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_dynamic_adjustment 1
echo "[ debug.sys.sf.input_latency_dynamic_adjustment 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_multisensory_integration 1
echo "[ debug.sys.sf.input_latency_multisensory_integration 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_perceptual_optimization 1
echo "[ debug.sys.sf.input_latency_perceptual_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_adaptive_thresholding 1
echo "[ debug.sys.sf.input_latency_adaptive_thresholding 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_fuzzy_logic 1
echo "[ debug.sys.sf.input_latency_fuzzy_logic 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_autonomous_optimization 1
echo "[ debug.sys.sf.input_latency_autonomous_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_predictive_modeling 1
echo "[ debug.sys.sf.input_latency_predictive_modeling 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_multiobjective_optimization 1
echo "[ debug.sys.sf.input_latency_multiobjective_optimization 1 ]"
sleep 0.5
setprop debug.sys.sf.input_latency_power_efficiency_tradeoff 1
echo "[ debug.sys.sf.input_latency_power_efficiency_tradeoff 1 ]"
sleep 0.5
echo "
"
echo "Commands Executed"
sleep 1
echo "
"
echo "[ Script written by Droid Everything ]"
echo "
"
end_time=$(date +%s)
total_runtime=$((end_time - start_time))
echo "[ Script runtime: $total_runtime seconds ]"
echo "
"
