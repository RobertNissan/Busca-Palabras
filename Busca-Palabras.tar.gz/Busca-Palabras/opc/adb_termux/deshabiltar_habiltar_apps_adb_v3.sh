#!/bin/bash



# Definir códigos de color
NC='\033[0m'            # Sin color
RED='\033[1;31m'        # Rojo brillante
BLUE='\033[1;34m'       # Azul brillante
CYAN='\033[1;36m'       # Cian brillante
WHITE='\033[1;37m'      # Blanco brillante
GREEN='\033[1;32m'      # Verde brillante
YELLOW='\033[1;33m'     # Amarillo brillante
MAGENTA='\033[1;35m'    # Magenta brillante
COLOR_NEGRO='\033[30m'
COLOR_ROJO='\033[31m'
COLOR_VERDE='\033[32m'
COLOR_AMARILLO='\033[33m'
COLOR_AZUL='\033[34m'
COLOR_MAGENTA='\033[35m'
COLOR_CIAN='\033[36m'
COLOR_BLANCO='\033[37m'
COLOR_RESET='\033[0m'

# Muchos de estos ajustes están relacionados con la optimización a largo plazo, es decir, podrían no ser inmediatamente evidentes, ya que los cambios se aplican progresivamente a lo largo del tiempo. En particular:

# Verificar si el dispositivo tiene root
if su -c "id" > /dev/null 2>&1; then
    echo "Tienes acceso root"
    ROOT_PERMISSIONS="true"
else
    echo "No tienes acceso root" >/dev/null 2>&1
    ROOT_PERMISSIONS="false"
fi

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT


# Verificar si Python está instalado
if [ -x ${PREFIX}/bin/python ]; then
    echo "Python ya está instalado." >/dev/null
else 
    echo "Instalando python..."
    apt install python -y
    pkg install python-pip
    # dpkg --configure -a;apt list --upgradable;apt upgrade;apt-get check;apt clean
fi

# Función para instalar paquetes python si no están presentes.
instalar_paquete_pip() {
    local comando=$1
    local instalacion=$2
    local mensaje_error=$3
    if ! command -v "$comando" &> /dev/null; then
        echo -e "${YELLOW}$comando no está instalado.\nInstalando $comando${NC}..."
        eval "$instalacion" >/dev/null 2>&1
        if [ $? -ne 0 ]; then
            echo "$mensaje_error"
            exit 1
        fi
    else
        echo -e "${GREEN}$comando ya está instalado${NC}." >/dev/null 2>&1
    fi
}

# Función para instalar paquetes si no están presentes en: $PREFIX/share/doc/
instalar_paquete_share() {
    if [[ ! -x $PREFIX/share/doc/$1 ]]; then
        echo -e "${YELLOW}Instalando $2${NC}"
        pkg install -y $1 >/dev/null 2>&1
        echo -e "${GREEN}$1 instalado correctamente${NC}."
    else
        echo -e "${GREEN}$2 ya está instalado${NC}." >/dev/null
    fi
}
# Función para instalar paquetes si no están presentes en: $PREFIX/bin/
instalar_paquete_bin() {
    if [[ ! -f $PREFIX/bin/$1 ]]; then
        echo -e "${YELLOW}Instalando $2${NC}"
        pkg install -y $1 >/dev/null 2>&1
        echo -e "${GREEN}$1 instalado correctamente${NC}."
    else
        echo -e "${GREEN}$2 ya está instalado${NC}." >/dev/null
    fi
}

herramientas_termux() {
    # Instalar herramientas necesarias.
    instalar_paquete_bin "zip" "zip"
    instalar_paquete_bin "rarp" "rar"
    instalar_paquete_bin "adb" "adb"
    instalar_paquete_bin "lynx" "lynx"
    instalar_paquete_bin "unrar" "unrar"
    instalar_paquete_bin "nmap" "nmap"
    instalar_paquete_bin "busybox" "busybox"
    instalar_paquete_bin "apksigner" "apksigner"
    instalar_paquete_bin "mediainfo" "mediainfo"
    instalar_paquete_share "termux-api" "termux-api"
    instalar_paquete_pip "gdown" "pip install gdown" "Error al instalar gdown. Asegúrate de tener pip instalado."
}
herramientas_termux

# Verificar si adb está instalado
if [ -x "$PREFIX/bin/adb" ]; then
    echo "adb instalado." >/dev/null 2>&1
    adb start-server
else
    herramientas_termux
fi

# Obtener la ip wlan0 si está disponible...
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

####### FUNCIONES DE JUSTIFICACION DE TEXTO #######
# Función para eliminar secuencias ANSI (como colores)
strip_ansi() {
    # Usar tr para eliminar caracteres ANSI, más rápido que sed
    echo -e "$1" | tr -d '\033' | sed 's/\[[0-9;]*m//g'
}

# Función para justificar texto respetando caracteres UTF-8 y espacios
justify_text() {
    local width=$(tput cols) # Ancho de la terminal
    local text="$1"
    local justified=""
    local line=""
    local leading_spaces=""
    local adjusted_width

    while IFS= read -r line || [[ -n $line ]]; do
        leading_spaces="${line%%[! ]*}" # Obtener los espacios iniciales
        adjusted_width=$((width - ${#leading_spaces}))
        line="${line#"${leading_spaces}"}" # Remover espacios iniciales

        if [[ $(strip_ansi "$line" | wc -m) -le $adjusted_width ]]; then
            justified+="$leading_spaces$line\n"
        else
            local words=($line)
            local current_line=""
            for word in "${words[@]}"; do
                # Solo calcular la longitud una vez por palabra
                if [[ $(strip_ansi "$current_line $word" | wc -m) -le $adjusted_width ]]; then
                    current_line+="$word "
                else
                    justified+="$leading_spaces$(justify_line "$current_line" "$adjusted_width")\n"
                    current_line="$word "
                fi
            done
            justified+="$leading_spaces$current_line\n"
        fi
    done <<< "$text"

    printf "%b" "$justified"
}

# Función para justificar una línea
justify_line() {
    local line="$1"
    local width="$2"
    local spaces_needed=$((width - $(strip_ansi "$line" | wc -m)))
    local words=($line)
    local space_count=$(( ${#words[@]} - 1 ))

    if (( space_count == 0 )); then
        echo "$line"
        return
    fi

    local extra_spaces=$(( spaces_needed / space_count ))
    local remainder_spaces=$(( spaces_needed % space_count ))
    local justified_line=""

    # Usar un bucle para construir la línea justificada
    for i in "${!words[@]}"; do
        justified_line+="${words[i]}"
        if (( i < space_count )); then
            justified_line+="$(printf ' %.0s' $(seq 1 $((extra_spaces + (i < remainder_spaces ? 1 : 0)))))"
        fi
    done

    echo "$justified_line"
}

# Función para imprimir texto con colores
print_color() {
    local color_code
    case $1 in
        red) color_code="${RED}" ;;
        green) color_code="${GREEN}" ;;
        yellow) color_code="${YELLOW}" ;;
        blue) color_code="${BLUE}" ;;
        cyan) color_code="${CYAN}" ;;
        magenta) color_code="${MAGENTA}" ;;
        white) color_code="${WHITE}" ;;
        *) color_code="" ;;
    esac
    # Imprimir el texto con el color
    echo -e "${color_code}$2${NC}"
}

# Generador de espacios (non-breaking spaces)
generate_spaces() {
    local count="$1"
    printf '\u00A0%.0s' $(seq 1 "$count")
}
####### FIN FUNCIONES DE JUSTIFICACION DE TEXTO #######


cont_graf_active() {
    paquetes="$1"
    echo -e "${GREEN}Controlador gráfico para juegos activado.\n${YELLOW}Para la siguientes aplicaciones:\n${GREEN}$paquetes${NC}"
}
# Función para activar el controlador gráfico para juegos
activar_controlador_grafico_juegos() {
    # Verificar si se pasó el dispositivo como argumento
    if [ -z "$1" ]; then
        echo "Uso: $0 <ip:port>"
        exit 1
    fi
    
    DISPOSITIVO="$1"
    
    version_android=$(echo "$(getprop ro.build.version.release)")
    echo -e "${YELLOW}Version de Android${NC}: [$version_android]"
    
    # ACTIVANDO CONTROLADOR GRÁFICO PARA JUEGOS.
    # Puedes buscar directamente en las opciones de desarrollador.
    # Preferencias del controlador -> Controladores de juegos
     
     # activando la tabla global
     adb -s "$DISPOSITIVO" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
     
     # Array para ingresar varios paquetes en columnas o en línea
    app=()  # Inicializa el array
    echo -e "${CYAN}Ingrese el paquete o los paquetes que quieres\nque usen el controlador gráficos de juegos!.\n${YELLOW}presione ENTER después de cada paquete.\nO ingresar varios en una línea o en una columna.\nLuego CTRL+D cuando termine${NC}:"
    # Leer entrada línea por línea
    while IFS= read -r linea || [[ -n $linea ]]; do
        # Separar los paquetes en palabras si hay varios en una línea
        for paquete in $linea; do
            app+=("$paquete")
        done
    done
    
    # Crea el array 'array_app' a partir del array 'app'
    array_app=("${app[@]}")
    
    # Une los paquetes separados por comas y muestra el resultado
    paquetes=$(echo "$(IFS=,; echo "${array_app[*]}")")
    # echo "${paquetes}"
      
      # Verifica si el array está vacío
    if [[ -z "$paquetes" ]]; then
        echo -e "${RED}No se han agregaron paquetes${NC}."
        sleep 2
        mostrar_menu "$DISPOSITIVO"
        exit
    else
        echo -e "${YELLOW}Paquetes a optimizar${NC}: ${paquetes}"
    fi
    
    case $version_android in
        10)
            # Driver Game Android 10
            adb -s "$DISPOSITIVO" shell settings put global game_driver_all_apps 1
            adb -s "$DISPOSITIVO" shell settings put global game_driver_opt_out_apps 1
            adb -s "$DISPOSITIVO" shell settings put global game_driver_opt_in_apps "${paquetes}"
            cont_graf_active "${paquetes}"
            mostrar_menu "$DISPOSITIVO"
            ;;
        11)
            # Driver Game Android 11 (Global Table)
            adb -s "$DISPOSITIVO" shell settings put global game_driver_all_apps 1
            adb -s "$DISPOSITIVO" shell settings put global game_driver_opt_out_apps 1
            adb -s "$DISPOSITIVO" shell settings put global game_driver_opt_in_apps "${paquetes}" 
            cont_graf_active "${paquetes}"
            mostrar_menu "$DISPOSITIVO"
            ;;
        12)
            # Driver Game Android 12 (Global Table)
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_all_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_out_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_in_apps "${paquetes}"
            cont_graf_active "${paquetes}"
            mostrar_menu "$DISPOSITIVO"
            ;;
        13)
            # Driver Game Android 13 dan Android 14 (Global Table)
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_all_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_out_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_in_apps "${paquetes}"
            cont_graf_active "${paquetes}"
            mostrar_menu "$DISPOSITIVO"
            ;;
        14)
            # nota:
            # si tu dispositivo es android 14 y no puedes agregar los códigos a set edit entonces hazlo através de la aplicación brevent, asi de esta manera podras usar este método 
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_all_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_out_apps 1
            adb -s "$DISPOSITIVO" shell settings put global updatable_driver_production_opt_in_apps "${paquetes}"
            cont_graf_active "${paquetes}"
            mostrar_menu "$DISPOSITIVO"
            ;;
        *)
            echo "Opción inválida. Intente de nuevo."
            mostrar_menu "$DISPOSITIVO"
            ;;
    esac

}

borrar_cache_todas_apps() {
    echo -e "${YELLOW}Borrando la cache de todas las aplicaciones, espere...${NC}"
    adb -s "$dispositivo" shell pm trim-caches 99999999999
    echo -e "${GREEN}Cache de todas las aplicaciones eliminda!.${NC}"
}

function deshabilitar_aplicaciones {
    echo "Opcion seleccionada: Deshabilitar aplicaciones"
    # read -p "Ingrese el nombre del paquete de la aplicacion que desea deshabilitar (deje en blanco para volver): " paquete
    
    app=()  # Inicializa el array
    echo "Ingrese el paquete o los paquetes deshabilitar, presione CTRL+D cuando termine:"
    while IFS= read -r linea; do
        # Salir del bucle si la línea está vacía
        [[ -z $linea ]] && break
        app+=("$linea")
    done

    # Crea el array 'array_app'
    array_app=("${app[@]}")
    
    # Imprime el array 'array_app' usando un bucle for
    echo "Elementos en 'array_app':"
    for paquete in "${array_app[@]}"; do
        #echo "$paquete"
    
        if [ -z "$paquete" ]; then
            echo "Nombre del paquete vacio." 
            deshabilitar_aplicaciones
        elif [ ${#paquete} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
            deshabilitar_aplicaciones
        elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
            adb -s "$dispositivo" shell pm disable-user --user 0 "$paquete"
            echo "Aplicacion deshabilitada correctamente."
        else
            echo "Nombre del paquete $paquete no valido. Por favor, ingrese un nombre de paquete valido."
            deshabilitar_aplicaciones
        fi
    done
    mostrar_menu "$dispositivo"
}

function habilitar_aplicaciones {
    echo "Opcion seleccionada: Habilitar aplicaciones"
    # read -p "Ingrese el nombre del paquete de la aplicacion que desea habilitar (deje en blanco para volver): " paquete
    
    app=()  # Inicializa el array
    echo "Ingrese el paquete o los paquetes habilitar, presione CTRL+D cuando termine:"
    while IFS= read -r linea; do
        # Salir del bucle si la línea está vacía
        [[ -z $linea ]] && break
        app+=("$linea")
    done

    # Crea el array 'array_app'
    array_app=("${app[@]}")
    
    # Imprime el array 'array_app' usando un bucle for
    echo "Elementos en 'array_app':"
    for paquete in "${array_app[@]}"; do
        #echo "$paquete"
        if [ -z "$paquete" ]; then
            echo "Nombre del paquete vacio." 
            habilitar_aplicaciones
        elif [ ${#paquete} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
            habilitar_aplicaciones
        elif adb -s "$dispositivo" shell pm list packages | grep -q "$paquete"; then
            adb -s "$dispositivo" shell pm enable "$paquete"
            echo "Aplicacion habilitada correctamente."
        else
            echo e "Nombre del paquete $paquete no valido. Por favor, ingrese un nombre de paquete valido."
            habilitar_aplicaciones
        fi
    done
    mostrar_menu "$dispositivo"
}

function multi_disable {
    archivo="packages.txt"
    #dispositivo=""$dispositivo""
    # Obtener la lista de todos los paquetes de usuario 3
    packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

    # Aplicaciones que siempre deben estar en el archivo
    echo "com.facebook.katana" > packages.txt
    echo "com.google.android.videos" >> packages.txt
    echo "com.google.android.apps.photos" >> packages.txt
    echo "com.google.android.apps.docs" >> packages.txt

    excluidos=(
    "com.termux"
    "com.whatsapp"
    "ru.iiec.pydroid3"
    "ru.iiec.pydroid3.quickinstallrepo"
    "ru.iiec.pydroidpermissionsplugin"
    "com.termux.api"
    "com.facebook.lite"
    "com.android.chrome"
    "com.rhmsoft.edit.pro"
    "com.nequi.MobileApp"
    "flar2.exkernelmanager"
    "ich.andre.partialscreen"
    "ru.iqzfpkhw.routqwzbx"
    "com.topjohnwu.magisk"
    "com.danemadsen.maid"
    "com.touchtype.swiftkey"
    "app.rvx.android.youtube"
    "com.estrongs.android.pop"
    "app.revanced.android.gms"
    "com.mgoogle.android.gms"
    "com.google.android.youtube"
    "com.davivienda.daviplataapp"
    "com.google.android.apps.photos"
    "co.com.tcs.bancolombia.bancaalamano"
    )

    # Bucle para cada una de las aplicaciones
    pak_old=false
    for package in $packages; do
        exclude=false
        for excluded_package in "${excluidos[@]}"; do
            if [[ "$package" == "$excluded_package" ]]; then
                exclude=true
                break
            fi
        done

        if [ "$exclude" == false ]; then
            # Obtener la lista de paquetes deshabilitados y si está deshabilitado no lo guardes en el archivo
            DESHABILITADOS=$(adb -s "$dispositivo" shell pm list packages -d)
            if echo "$DESHABILITADOS" | grep -q "package:$package"; then
                if [ "$pak_old" == false ]; then
                    echo "$package" > packagesold.txt
                    pak_old=true
                fi
                echo "$package" >> packagesold.txt
                # echo "El paquete '$PAQUETE' está deshabilitado."
                continue
            fi
            echo "$package" >> packages.txt
        fi
    done

    contador=0 # Inicializa la variable contador a 0, que se usara para contar el numero de aplicaciones deshabilitadas.

    # Leer todas las lineas del archivo y almacenarlas en un array
    mapfile -t lineas < "$archivo"

    # Iterar sobre el array
    for linea in "${lineas[@]}"; do
        linea=$(echo "$linea" | tr -d '\r')  # Eliminar caracteres de retorno de carro
        #echo "Procesando paquete: $linea"
        if [ -z "$linea" ]; then
            echo "Nombre del paquete vacio."
        elif [ ${#linea} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        elif adb -s "$dispositivo" shell pm list packages | grep "$linea" >/dev/null 2>&1; then
            adb -s "$dispositivo" shell pm disable-user --user 0 "$linea" >/dev/null 2>&1
            echo -e "Aplicacion $linea deshabilitada correctamente.\n"
            ((contador++))
        else
            echo "Error al deshabilitar la aplicacion."
            continue
        fi
    done

    echo "Se deshabilitaron $contador aplicaciones."
    mostrar_menu "$dispositivo"
}

function multi_enable {
    archivo="packages.txt"
    # dispositivo=""$dispositivo""
    # Obtener la lista de todos los paquetes de usuario 3
    packages=$(adb -s "${dispositivo}" shell pm list packages -3 | cut -d':' -f2)

    # Aplicaciones que siempre deben estar en el archivo
    echo "com.facebook.katana" > packages.txt
    echo "com.google.android.videos" >> packages.txt
    echo "com.google.android.apps.photos" >> packages.txt
    echo "com.google.android.apps.docs" >> packages.txt

    excluidos=(
    "com.termux"
    "com.whatsapp"
    "ru.iiec.pydroid3"
    "ru.iiec.pydroid3.quickinstallrepo"
    "ru.iiec.pydroidpermissionsplugin"
    "com.termux.api"
    "com.facebook.lite"
    "com.android.chrome"
    "com.rhmsoft.edit.pro"
    "com.nequi.MobileApp"
    "flar2.exkernelmanager"
    "ich.andre.partialscreen"
    "ru.iqzfpkhw.routqwzbx"
    "com.topjohnwu.magisk"
    "com.danemadsen.maid"
    "com.touchtype.swiftkey"
    "app.rvx.android.youtube"
    "com.estrongs.android.pop"
    "app.revanced.android.gms"
    "com.mgoogle.android.gms"
    "com.google.android.youtube"
    "com.davivienda.daviplataapp"
    "com.google.android.apps.photos"
    "co.com.tcs.bancolombia.bancaalamano"
    )

    # Bucle para cada una de las aplicaciones
    for package in $packages; do
        exclude=false
        for excluded_package in "${excluidos[@]}"; do
            if [[ "$package" == "$excluded_package" ]]; then
                exclude=true
                break
            fi
        done

        if [ "$exclude" == false ]; then
            echo "$package" >> packages.txt
        fi
    done

    contador=0 # Inicializa la variable contador a 0, que se usara para contar el numero de aplicaciones habilitadas.

    # Leer todas las lineas del archivo y almacenarlas en un array
    mapfile -t lineas < "$archivo"

    # Iterar sobre el array
    for linea in "${lineas[@]}"; do
        linea=$(echo "$linea" | tr -d '\r')  # Eliminar caracteres de retorno de carro
        #echo "Procesando paquete: $linea"
        if [ -z "$linea" ]; then
            echo "Nombre del paquete vacio."
        elif [ ${#linea} -lt 3 ]; then
            echo "Nombre del paquete demasiado corto. Por favor, ingrese un nombre de paquete valido."
        elif adb -s "$dispositivo" shell pm list packages | grep "$linea" >/dev/null 2>&1; then
            adb -s "$dispositivo" shell pm enable "$linea" >/dev/null 2>&1
            echo -e "Aplicacion $linea habilitada correctamente.\n"
            ((contador++))
        else
            echo "Error al habilitar la aplicacion."
            continue
        fi
    done
    if [ -f packagesold.txt ]; then
        rm -rf packagesold.txt
    fi
    echo "Se habilitaron $contador aplicaciones."
    mostrar_menu "$dispositivo"
}

# Función para restaurar valores predeterminados de Wi-Fi y configuración de red
configurar_max_wifi() {
    # Configurar preferencia de banda Wi-Fi para 2.4 GHz y 5 GHz
    
    # echo -e "${CYAN}Aumentando la potencia de transmisión del Wi-Fi...${NC}"
    # adb -s "$dispositivo" shell settings delete global wifi_tx_power_adjustment

    # echo -e "${CYAN}Priorización de datos móviles cuando la red Wi-Fi es lenta...${NC}"
    # adb -s "$dispositivo" shell settings delete global wifi_watchdog_mobile_data_interval_ms

    # echo -e "${CYAN}Ajustando límite de conexiones Wi-Fi simultáneas...${NC}"
    # adb -s "$dispositivo" shell settings delete global wifi_max_num_sta
    
    # echo -e "${CYAN}Bajar la latencia de Wi-Fi...${NC}"
    # adb -s "$dispositivo" shell settings put global wifi_connection_manager_enabled 1
    
    # echo -e "${CYAN}Configurando intervalo de actualización del servicio de ubicación en segundo plano...${NC}"
    # adb -s "$dispositivo" shell settings delete secure location_background_throttle_interval_ms
    
    # echo -e "${CYAN}Optimizando tiempo de espera de la conexión Wi-Fi...${NC}"
    # adb -s "$dispositivo" shell settings put global wifi_suspend_optimizations_enabled 1
    
    # Solo esto esta por defecto )wifi_sleep_policy=2) Este es el valor predeterminado en muchos dispositivos. El Wi-Fi puede entrar en un modo de suspensión más agresivo cuando el dispositivo está inactivo, utilizando una combinación de las configuraciones de optimización de batería y la política de suspensión.
    # echo -e "${CYAN}Ajustando la política de suspensión de Wi-Fi...${NC}"
    # adb -s "$dispositivo" shell settings put global wifi_sleep_policy 0
    
    # Controlar la capacidad del dispositivo para evitar redes Wi-Fi con mal rendimiento
    # echo -e "${CYAN}Controlando la capacidad del dispositivo para evitar redes Wi-Fi con mal rendimiento...${NC}"
    # adb -s "$dispositivo" shell settings put global network_avoid_bad_wifi 1

    # Ajustar la supervisión de redes problemáticas (Wi-Fi Watchdog)
    # echo -e "${CYAN}Ajustando la supervisión de redes problemáticas (Wi-Fi Watchdog)...${NC}"
    # adb -s "$dispositivo" shell settings put global wifi_watchdog_background 1
    
    # Elija la mejor banda (2.4 GHz o 5 GHz) según la situación actual de la red
    echo -e "${CYAN}Configurando la mejor banda (2.4 GHz o 5 GHz) de la red Wi-Fi en automático...${NC}"
    adb -s "$dispositivo" shell settings put global wifi_frequency_band 0

    # Establecer intervalo de escaneo Wi-Fi
    echo -e "${CYAN}Estableciendo intervalo de escaneo Wi-Fi a 20 segundos...${NC}"
    adb -s "$dispositivo" shell settings put global wifi_wpa_supplicant_scan_interval 20

    # Ajustar la sensibilidad de la conexión Wi-Fi
    echo -e "${CYAN}Ajustando la sensibilidad de la conexión Wi-Fi...${NC}"
    adb -s "$dispositivo" shell settings put global wifi_supplicant_scan_interval 20

    # Si viajas frecuentemente y necesitas acceso a datos en lugares donde no tienes cobertura de tu operador principal, entonces deberías habilitar el roaming:
    echo -e "${CYAN}Ajustando configuración de roaming de datos móviles...${NC}"
    adb -s "$dispositivo" shell settings put global mobile_data_roaming_settings 1

    echo -e "${GREEN}Configuración completada.${NC}"
    echo -e "${YELLOW}Recomendado reiniciar el celular.${NC}"
    mostrar_menu "$dispositivo"
}
restablecer_wifi_principal() {
    # restablecer
    
    # Controlar la capacidad del dispositivo para evitar redes Wi-Fi con mal rendimiento (valor predeterminado: 0)
    # echo -e "${CYAN}Restaurando la configuración de evitar redes Wi-Fi con mal rendimiento a predeterminada...${NC}"
    # adb -s "$dispositivo" shell settings delete global network_avoid_bad_wifi

    # Ajustar la supervisión de redes problemáticas (Wi-Fi Watchdog) (valor predeterminado: 0)
    # echo -e "${CYAN}Restaurando la supervisión de redes problemáticas a predeterminada...${NC}"
    # adb -s "$dispositivo" shell settings delete global wifi_watchdog_background
    
    # Este comando cambia un ajuste global en Android que define cuántas veces el sistema intentará obtener una dirección IP a través de DHCP (Dynamic Host Configuration Protocol) antes de rendirse. En este caso, se establece el número máximo de reintentos a 9.
    adb -s "$dispositivo" shell settings put global wifi_max_dhcp_retry_count 9
    # Este comando habilita la interfaz de usuario de puntuación de red en Android. La puntuación de red es una característica que ayuda al sistema a decidir cuál red (Wi-Fi o móvil) es la mejor para conectarse, basándose en varios criterios de rendimiento. Al establecer este ajuste en `1`, estás activando esa funcionalidad.
    adb -s "$dispositivo" shell settings put global network_scoring_ui_enabled 1
    
    # Elija la mejor banda (2.4 GHz o 5 GHz) (valores de fábrica: manual o según el dispositivo)
    echo -e "${CYAN}Restaurando la configuración de la banda Wi-Fi (2.4 GHz o 5 GHz) a predeterminada...${NC}"
    adb -s "$dispositivo" shell settings delete global wifi_frequency_band

    # Establecer intervalo de escaneo Wi-Fi (valor predeterminado: depende del dispositivo, por lo general entre 15-30 segundos)
    echo -e "${CYAN}Restaurando el intervalo de escaneo Wi-Fi a predeterminado...${NC}"
    adb -s "$dispositivo" shell settings delete global wifi_wpa_supplicant_scan_interval

    # Ajustar la sensibilidad de la conexión Wi-Fi (valor predeterminado: manejado por el sistema)
    echo -e "${CYAN}Restaurando la sensibilidad de la conexión Wi-Fi a predeterminada...${NC}"
    adb -s "$dispositivo" shell settings delete global wifi_supplicant_scan_interval

    # Desactivar roaming de datos móviles (valor predeterminado: 0)
    echo -e "${CYAN}Restaurando la configuración de roaming de datos móviles a predeterminada...${NC}"
    adb -s "$dispositivo" shell settings delete global mobile_data_roaming_settings

    echo -e "${GREEN}Restauración completada.${NC}"
    echo -e "${YELLOW}Recomendado reiniciar el celular.${NC}"

    mostrar_menu "$dispositivo"
}


# Función para verificar si la app se actualizó hoy
app_actualizada_hoy() {
    local dispositivo="$1"
    local paquete="$2"
    # Obtener la fecha de la última actualización directamente en formato YYYY-MM-DD
    lastUpdate=$(adb -s "$dispositivo" shell dumpsys package "$paquete" | grep -E "lastUpdateTime" | sed 's/lastUpdateTime=\([0-9\-]*\).*/\1/' | head -n 1 | xargs)
    # Verificar si se obtuvo la fecha correctamente
    if [ -z "$lastUpdate" ]; then
        echo -e "${RED}[X] No se pudo obtener la fecha de última actualización para $paquete.${NC}"
        return 1
    fi
    # Convertir el timestamp de milisegundos a formato YYYY-MM-DD
    # lastUpdateFormatted=$(date -d @"$((lastUpdate / 1000))" +%Y-%m-%d 2>/dev/null)
    # Obtener la fecha actual en formato YYYY-MM-DD
    currentDate=$(date +%Y-%m-%d)
    # Mostrar las fechas para depuración
    #echo -e "${YELLOW}Verificando aplicación: $paquete${NC}"
    #echo -e "Fecha última actualización: ${lastUpdateFormatted}"
    #echo -e "Fecha actual: ${currentDate}"
    # Comparar las fechas
    if [ "$lastUpdate" = "$currentDate" ]; then
        return  # Actualizada hoy
    else
        return  # No actualizada hoy
    fi
}
# Función para listar aplicaciones actualizadas hoy
listar_apps_actualizadas_hoy_otimizar() {
    local dispositivo="$1"
    echo -e "${YELLOW}Obteniendo lista de todas las aplicaciones para el dispositivo:${NC} $dispositivo"
    # Obtener todas las aplicaciones instaladas (sistema y usuario)
    apps=$(adb -s "$dispositivo" shell pm list packages)
    aplicaciones_actualizadas=0
    # Verificar cada aplicación para ver si fue actualizada hoy
    for app in $apps; do
        if app_actualizada_hoy "$dispositivo" "${app#*:}"; then
            echo -en "${GREEN}[OPTIMIZANDO]${NC} - ${CYAN}Mejorando el inicio de ${app#*:} (Actualizada hoy):${NC} "
            adb -s "$dispositivo" shell cmd package compile -m speed-profile "${app#*:}"
            echo -e "${GREEN}[✓]${NC} - Optimización de $app completada."
            aplicaciones_actualizadas=1
        fi
    done
    # Mensaje si no hay aplicaciones actualizadas hoy
    if [ $aplicaciones_actualizadas -eq 0 ]; then
        echo -e "${RED}No se encontraron aplicaciones actualizadas hoy.${NC}"
    fi
}



# Función para verificar si la app se actualizó recientemente
app_actualizada_recientemente() {
    local dispositivo="$1"
    local paquete="$2"
    local dias="$3"
    
    # Obtener la fecha de la última actualización
    # lastUpdate=$(adb -s "$dispositivo" shell dumpsys package "$paquete" | grep -E "lastUpdateTime" | awk -F= '{print $2}' | tr -d ' ')
    lastUpdate=$(adb -s "$dispositivo" shell dumpsys package "$paquete" | grep -E "lastUpdateTime" | sed 's/lastUpdateTime=\([0-9\-]*\).*/\1/' | head -n 1 | xargs)
    # Verificar si se obtuvo la fecha correctamente
    if [ -z "$lastUpdate" ]; then
        echo -e "${RED}[X] No se pudo obtener la fecha de última actualización para $paquete.${NC}"
        return 1
    fi
    # Obtener la fecha actual en formato YYYY-MM-DD
    currentDate=$(date +%Y-%m-%d)
    # Comparar las fechas
    if [ "$lastUpdate" == "$currentDate" ]; then
        return 0  # Reciente
    else
        return 1  # No reciente
    fi
}
# Función para optimizar una app si fue actualizada recientemente
optimizar_app() {
    local dispositivo="$1"
    local paquete="$2"
    # Verificar si el paquete está instalado
    if adb -s "$dispositivo" shell pm list packages | grep "$paquete"; then
        # Verificar si la app fue actualizada recientemente
        if app_actualizada_recientemente "$dispositivo" "$paquete"; then
            echo -en "${GREEN}[OPTIMIZANDO]${NC} - ${CYAN}Mejorando el inicio de $paquete (Actualizada hoy):${NC} "
            adb -s "$dispositivo" shell cmd package compile -m speed-profile "$paquete"
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}[✓]${NC} - Optimización de $paquete completada."
            else
                echo -e "${RED}[!]${NC} - Error al optimizar $paquete."
            fi
        else
            echo -e "${YELLOW}[!]${NC} - ${CYAN}$paquete no fue actualizada hoy. No se optimiza.${NC}"
        fi
    else
        echo -e "${RED}[X]${NC} - ${CYAN}$paquete no está instalado.${NC}"
    fi
}
# Función para mostrar el menú de optimización
mostrar_menu_optimizar() {
    dispositivo="$1"
    while true; do
        echo -e "${CYAN}--- Menú de Optimización de Aplicaciones ---${NC}"
        echo -e "${GREEN}01) Optimizar Google Chrome${NC}"
        echo -e "${GREEN}02) Optimizar Google Maps${NC}"
        echo -e "${GREEN}03) Ingresar uno o más paquetes personalizados para optimizar${NC}"
        echo -e "${GREEN}04) Optimizar todas las app actualizadas hoy!.${NC}"
        echo -e "${GREEN}05) Salir${NC}"
        echo -n "Selecciona una opción: "
        read opcion

        case $opcion in
            1|01)
                optimizar_app "$dispositivo" "com.android.chrome"
                ;;
            2|02)
                optimizar_app "$dispositivo" "com.google.android.apps.maps"
                ;;
            3|03)
                echo "Has seleccionado: Optimizar aplicaciones personalizadas"
                echo "Introduce los nombres de los paquetes de las aplicaciones que deseas optimizar, presiona CTRL+D cuando termines:"
                # Inicializar array para almacenar los paquetes
                app=()
                # Leer múltiples líneas de entrada del usuario
                while IFS= read -r linea; do
                    [[ -n $linea ]] && app+=("$linea")
                done
                # Optimizar cada paquete ingresado
                for paquete in "${app[@]}"; do
                    optimizar_app "$dispositivo"
                done
                ;;
            4|04)
                listar_apps_actualizadas_hoy_otimizar "$dispositivo" "$paquete"
                ;;
            5|05)
                mostrar_menu "$dispositivo"
                exit 0
                ;;
            *)
                echo -e "${RED}Opción no válida. Intenta de nuevo.${NC}"
                mostrar_menu_optimizar "$dispositivo"
                ;;
        esac
    done
}


function optimizar_ram {
    # Definir códigos de color
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    CYAN='\033[0;36m'
    NC='\033[0m' # Sin color
    
    echo -e "${GREEN}[1]${NC} - ${CYAN}Desactivando características de seguridad adicionales...${NC}"
    adb -s "$dispositivo" shell setprop debug.secure 0 

    echo -e "${GREEN}[2]${NC} - ${CYAN}Habilitando FHA (Fast High Availability)...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.fha_enable true 

    echo -e "${GREEN}[3]${NC} - ${CYAN}Limitando el número de aplicaciones en segundo plano a 3...${NC}"
    adb -s "$dispositivo" shell setprop debug.sys.fw.bg_apps_limit 3 

    echo -e "${GREEN}[4]${NC} - ${CYAN}Definiendo el número máximo de aplicaciones en caché a 24...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.dha_cached_max 24 

    echo -e "${GREEN}[5]${NC} - ${CYAN}Ajustando la escala del 'Low Memory Killer' a 0.4...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.dha_lmk_scale 0.4 

    echo -e "${GREEN}[6]${NC} - ${CYAN}Controlando la tasa de activación del 'Dynamic Handling Algorithm' a 2.0...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.dha_th_rate 2.0 

    echo -e "${GREEN}[7]${NC} - ${CYAN}Definiendo el número máximo de aplicaciones en segundo plano bajo 'Super Dynamic Handling Algorithm' a 48...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.sdha_apps_bg_max 48 

    echo -e "${GREEN}[8]${NC} - ${CYAN}Definiendo el número mínimo de aplicaciones en segundo plano bajo 'Super Dynamic Handling Algorithm' a 12...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.sdha_apps_bg_min 12 

    echo -e "${GREEN}[9]${NC} - ${CYAN}Aceleración por hardware...${NC}"
    adb -s "$dispositivo" shell setprop debug.config.disable.hw_accel false 

    echo -e "${GREEN}[10]${NC} - ${CYAN}Desactivando la renderización de regiones 'sucias' en la interfaz de usuario...${NC}"
    adb -s "$dispositivo" shell setprop debug.hwui.render_dirty_regions false
    adb -s "$dispositivo" shell setprop debug.hwui.disabledither false
    

    echo -e "${GREEN}[11]${NC} - ${CYAN}Desactivando la sincronización vertical (vsync)...${NC}"
    adb -s "$dispositivo" shell setprop debug.hwui.disable_vsync true 

    echo -e "${GREEN}[12]${NC} - ${CYAN}Desactivando el profiler de muestreo persistente...${NC}"
    adb -s "$dispositivo" shell setprop debug.persist.sampling_profiler 0 

    echo -e "${GREEN}[13]${NC} - ${CYAN}Activando el uso de canal alfa de 8 bits...${NC}"
    adb -s "$dispositivo" shell setprop debug.persist.sys.use_8bpp_alpha 1 
    
    echo -e "${GREEN}[14]${NC} - ${CYAN}Limitar el número máximo de procesos en caché a 24 para liberar algo de RAM sin afectar demasiado la multitarea.${NC}"
    # Si deseas un valor más conservador (para liberar más RAM), puedes bajar este número, por ejemplo, a 24: normalmente es 32 o un poquito mas!!!.
    adb -s "$dispositivo" shell settings put global max_cached_processes 24

    echo -e "${GREEN}[15]${NC} - ${CYAN}Habilitar el modo de rendimiento sostenido para mantener la estabilidad en aplicaciones exigentes.${NC}"
    adb -s "$dispositivo" shell settings put global sustained_performance_mode_enabled 1
    
    # echo -e "${GREEN}[16]${NC} - ${CYAN}Reservar 128MB de memoria.${NC}"
    # adb -s "$dispositivo" shell settings put global mem_reserved 128 
   
    echo -e "${BLUE}Optimización de RAM completada.${NC}"

    # Pruebas incrementales: Si encuentras que algunas aplicaciones aún se cierran inesperadamente o el sistema se ralentiza bajo carga, podrías experimentar ajustando:
    # debug.config.dha_lmk_scale o debug.sys.fw.bg_apps_limit
    mostrar_menu "$dispositivo"
}

modo_doze() {
    # matar el proceso si esta aogono en segundo plano
    pkill -f activar_modo_doze.sh || true
    # Forzar el modo Doze inmediatamente:
    # Este comando pone al dispositivo en modo Doze de inmediato. No modifica la lista blanca de Doze; simplemente activa el modo Doze aplicando las restricciones a todas las aplicaciones excepto a aquellas que están en la lista blanca.
    # adb -s "$dispositivo" shell dumpsys deviceidle force-idle
    # nohup bash modo_doze/activar_modo_doze.sh "$dispositivo" > /dev/null 2>&1 &
    
    # echo -e "${YELLOW}[!] - Script no encontrado. Transfiriendo carpeta modo_doze...${NC}" >/dev/null
    # adb -s "$dispositivo" push modo_doze /sdcard/modo_doze
    # nohup bash modo_doze/activar_modo_doze.sh "${dispositivo}" > /dev/null 2>&1 &
    bash modo_doze/activar_modo_doze.sh "${dispositivo}" # > /dev/null 2>&1 &
    # adb -s "$dispositivo" shell rm -r /sdcard/modo_doze
    # ps aux | grep activar_modo_doze.sh
    echo -e "${GREEN}[✓] - Modo Doze Activado...${NC}"
}
set_highest_refresh_rate() {
    # Obtener el FPS más bajo disponible
    min_fps=$(adb -s "${dispositivo}" shell dumpsys display | grep -Po 'refreshRate=\K[0-9]+(\.[0-9]+)?' | sort -n | head -n 1)
    # Obtener el FPS más alto disponible
    highest_fps=$(adb -s "${dispositivo}" shell dumpsys display | grep -i "refreshRate=" | awk -F 'refreshRate=' '{print $2}' | awk '{print $1}' | sed 's/,//g' | sort -nr | head -n 1)

    # Comprobar si se encontró una tasa de refresco
    if [ -n "$highest_fps" ]; then
        echo -e "\n${YELLOW}Estableciendo la tasa de refresco más alta${NC}: $highest_fps fps"
        
        # Borrar primero
        adb -s "${dispositivo}" shell settings delete system display_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete system user_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete system screen_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete system min_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete system max_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete system peak_refresh_rate >/dev/null
        # adb -s "${dispositivo}" shell setprop debug.hwui.refresh_rate "" >/dev/null
        adb -s "${dispositivo}" shell settings delete global display_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete global user_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete global screen_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete global min_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete global max_refresh_rate >/dev/null
        adb -s "${dispositivo}" shell settings delete global peak_refresh_rate >/dev/null

        
        # Comando para establecer la tasa de refresco más alta usando Settings
        adb -s "${dispositivo}" shell settings put system display_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put system user_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put system screen_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put system min_refresh_rate "$min_fps"
        adb -s "${dispositivo}" shell settings put system max_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put system peak_refresh_rate "$highest_fps"
        
        adb -s "${dispositivo}" shell settings put global display_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put global user_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put global screen_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put global min_refresh_rate "$min_fps"
        adb -s "${dispositivo}" shell settings put global max_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put global peak_refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell setprop debug.hwui.refresh_rate "$highest_fps"
        adb -s "${dispositivo}" shell settings put global game_driver_framerate "$highest_fps"  # Establecer framerate máximo para juegos
        
        # Nuevos, estabilizadores
        adb -s "$dispositivo" shell settings put global gpu_rendering 1
        adb -s "$dispositivo" shell setprop debug.force_gpu_render 1
        adb -s "${dispositivo}" shell setprop debug.hwui.use_gpu true
        adb -s "${dispositivo}" shell setprop debug.hwui.force_gpu_rendering 1
        adb -s "${dispositivo}" shell setprop debug.gpu_freq_index 15
        # Aumentar el tamaño de la caché de GPU Render Thread
        # Aumentar el tamaño de caché en el hilo de renderizado de la GPU puede ayudar en situaciones de gráficos intensivos:
        adb -s "${dispositivo}" shell setprop debug.hwui.raster_cache_size 24
        # Mejorar la velocidad de renderizado de la interfaz con una mayor frecuencia de cuadros (fps):
        # Aunque no siempre es recomendable forzar un cambio aquí, este comando puede ser útil si deseas una mayor frecuencia de cuadros (fps) en la interfaz de usuario.
        # adb -s "${dispositivo}" shell setprop debug.sf.framebuffer.format rgba8888 
        
    
        # Este comando fuerza a las aplicaciones a utilizar la GPU para el renderizado en lugar de la CPU:
        adb -s "${dispositivo}" shell settings put global force_gpu_rendering 1
        adb -s "${dispositivo}" shell setprop debug.hwui.use_cpu false
        
        # configuración de escala de animación Android 
        # 1. Configurar la escala de animación de ventanas
        # (Valores comunes: 0.5, 1.0, 1.5, 2.0, etc. 0.5 es más rápido, 2.0 es más lento)
        adb -s "${dispositivo}" shell settings put global window_animation_scale 0.5
        # 2. Configurar la escala de animación de transición
        adb -s "${dispositivo}" shell settings put global transition_animation_scale 0.5
        # 3. Configurar la escala de duración de animación
        adb -s "${dispositivo}" shell settings put global animator_duration_scale 0.5

        # Mensaje de éxito
        echo -e "[ ${GREEN}Vulkan+$highest_fps FPS Renderizado Habilitado!${NC} ] "
        echo ""
        sleep 0.05
        echo -e "${GREEN}[ COMPLETADO...${NC} ] "
        sleep 0.05
        echo ""
        echo -e "${YELLOW}POR FAVOR NO REINICIAR TU TELÉFONO!!!${NC}"

        #echo "La tasa de refresco se ha establecido correctamente a $highest_fps fps."
    else
        echo "No se pudo encontrar una tasa de refresco."
    fi
}
function activar_vulkan {
    # verificar compatibilidad vulkan, opengl y más 
    # adb -s "$dispositivo" shell pm list features
    # adb -s "$dispositivo" shell pm list features | grep vulkan
    
    # Desactivar actualizaciones del sistema Android
    adb -s "$dispositivo" shell settings put global auto_update_system 0
    
    # Verificar compatibilidad con Vulkan
    if adb -s "$dispositivo" shell pm list features | grep -i vulkan >/dev/null; then
        # Verificar si Vulkan ya está activado
        # if adb -s "$dispositivo" shell getprop debug.hwui.renderer | grep -i 'vulkan'; then
        if adb -s "$dispositivo" shell getprop debug.hwui.renderer | grep -i 'skiavk' >/dev/null; then
            echo -e "${GREEN}[✓] - Vulkan ya está activado.${NC}"
            print_color yellow "$(justify_text "${GREEN}[✓] - ${YELLOW}Muchos de estos ajustes están relacionados con la optimización a largo plazo, y podrían no ser inmediatamente evidentes, ya que los cambios se aplican progresivamente a lo largo del tiempo.${NC}")"
            sleep 5
            mostrar_menu "$dispositivo"  
        fi
    else
        echo -e "${RED}[✗] - El dispositivo no es compatible con Vulkan.${NC}"
        mostrar_menu "$dispositivo" 
    fi
    echo -e "${GREEN}[✓] - Dispositivo compatible con Vulkan. Activando...${NC}"
    # Modificar la configuración para usar Vulkan como renderer
    # adb -s "$dispositivo" shell "setprop debug.hwui.renderer skiavk; for a in \$(pm list packages | grep -v ia.mo | cut -f2 -d:); do am force-stop \"\$a\" & done" >/dev/null 2>&1 &
    # ajustar el buffer correctamente de los videos
    # Otorgar permisos y ajustar configuraciones
    adb -s "$dispositivo" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
    # adb -s "$dispositivo" shell settings put global media_cache_size 52428800

    # Verificar si el script de instalación existe en el dispositivo
    if adb -s "$dispositivo" shell sh /sdcard/vulkan/install.sh >/dev/null 2>&1; then
        echo -e "${GREEN}[✓] - Script de instalación encontrado y ejecutado.${NC}" >/dev/null
    else
        echo -e "${YELLOW}[!] - Script no encontrado. Transfiriendo carpeta vulkan...${NC}" >/dev/null
        #adb -s "$dispositivo" push vulkan /sdcard/vulkan
        #adb -s "$dispositivo" shell sh /sdcard/vulkan/install.sh
        #adb -s "$dispositivo" shell rm -r /sdcard/vulkan
    fi
    # Render skiavk
    # Configuración para Vulkan
    adb -s "$dispositivo" shell setprop debug.vulkan.force true  # Forzar Vulkan
    adb -s "$dispositivo" shell setprop debug.sf.latch_unsignaled 1
    adb -s "$dispositivo" shell setprop debug.egl.hw 1
    adb -s "$dispositivo" shell setprop debug.egl.profiler 1
    adb -s "$dispositivo" shell settings put global com.qc.hardware true
    adb -s "$dispositivo" shell setprop debug.composition.type gpu
    adb -s "$dispositivo" shell setprop debug.hwui.renderer skiavk
    adb -s "$dispositivo" shell setprop debug.sf.hw 1
    adb -s "$dispositivo" shell setprop debug.sf.enable_hwc_vds 1
    # Establecer la aplicaciones para depuración de GPU (citra:psp) y mas
    adb -s "$dispositivo" shell settings put global gpu_debug_app org.citra.emu:org.ppsspp.ppssppgold:xyz.aethersx2.android:org.dolphinemu.mmjr3:com.facebook.lite:app.rvx.android.youtube
    adb -s "$dispositivo" shell settings put global enable_gpu_debug_layers 1
    adb -s "$dispositivo" shell setprop debug.hwui.use_vulkan true
    # Establecer las capas de depuración de Vulkan (combinar todas las capas en un solo comando)
    # adb -s "$dispositivo" shell setprop debug.vulkan.layers VK_LAYER_KHRONOS_validation
    # adb -s "$dispositivo" shell settings put global gpu_debug_layers "VK_LAYER_KHRONOS_validation:VK_KHR_shared_presentable_image:VK_KHR_16bit_storage:VK_KHR_android_surface"
    # Establecer las capas de depuración de OpenGL ES
    # adb -s "$dispositivo" shell settings put global gpu_debug_layers_gles "EGL_KHR_gl_texture_cubemap_image:EGL_KHR_gl_texture_3D_image:EGL_KHR_gl_renderbuffer_image"
    
    # adb -s "$dispositivo" shell "setprop debug.hwui.renderer skiavk; for a in \$(pm list packages | grep -Ev 'ia.mo|android|com.google.android') ; do am force-stop \"\$a\" & done" > /dev/null 2>&1
    adb -s "$dispositivo" shell settings put global enable_vulkan 1
    # Este se utiliza para ajustar el intervalo de actualización del swap buffer cuando se usa la API Vulkan para el renderizado gráfico en Android.
    adb -s "${dispositivo}" shell setprop debug.vulkan.swapinterval 1
    adb -s "$dispositivo" shell settings put global development_settings_enabled 1
    # echo -e "${GREEN}[15]${NC} - ${CYAN}Reducir la frecuencia de actualización de gráficos.${NC}"
    adb -s "$dispositivo" shell setprop debug.hwui.profile true
    # echo -e "${GREEN}[15]${NC} - ${CYAN}Activar aceleración gráfica.${NC}"
    adb -s "$dispositivo" shell setprop debug.hwui.force_draw true
    adb -s "$dispositivo" shell settings put global enable_msaa 1
    adb -s "$dispositivo" shell setprop debug.egl.force_msaa true
    adb -s "$dispositivo" shell settings put global HIGH_PERFORMANCE_MODE_ON 1
    adb -s "$dispositivo" shell setprop debug.performance.tuning 1
    # Aumentar el tamaño del buffer de comandos de la GPU
    adb -s "$dispositivo" shell setprop debug.hwui.gpu_tile_size 2048
    # Configuración agresiva para Vulkan
    # adb shell setprop debug.vulkan.layers VK_LAYER_KHRONOS_validation
    adb -s "$dispositivo" shell setprop debug.vulkan.swap_chain.image_count 3  # Aumentar imágenes en buffer
    adb -s "$dispositivo" shell setprop debug.vulkan.swap_chain.max_fps 60  # Sincronizar FPS a 60 (ajustable)
    # Desactivar optimizaciones de GPU innecesarias (depuración avanzada)
    adb -s "$dispositivo" shell setprop debug.sys.gpu_debug_layers all
    adb -s "$dispositivo" shell setprop debug.sys.gpu_layers_optimize 0
    adb -s "$dispositivo" shell setprop debug.sf.disable_framebuffer 0
    

    # Configurar el touch
    adb -s "$dispositivo" shell settings put system touch.size.calibration geometric
    adb -s "$dispositivo" shell settings put system touch.pressure.calibration amplitude
    adb -s "$dispositivo" shell settings put system touch.pressure.scale 0.001
    adb -s "$dispositivo" shell settings put system touch.distance.scale 0
    adb -s "$dispositivo" shell settings put system touch.size.scale 1
    # Ajustar el tiempo de renderizado táctil (mejora la respuesta del sistema):
    adb -s "$dispositivo" shell setprop debug.touch.resampling 1
    adb -s "$dispositivo" shell setprop debug.touch.average_filter 0
    adb -s "$dispositivo" shell setprop debug.touch.prediction 1
    adb -s "$dispositivo" shell setprop debug.egl.disable_gl_compression 1
    

    
    # Desactivar la recolección de datos innecesaria por apps en segundo plano
    # Esto puede evitar que las apps ejecuten tareas innecesarias mientras están en segundo plano, lo que podría mejorar el rendimiento del sistema:
    adb -s "$dispositivo" shell settings put global battery_saver_constants "vibration_disabled=true,animator_disabled=true,fullbackup_interval_ms=0"
    
    # Activar la función de la mejor tasa de refresco fps 
    set_highest_refresh_rate "$dispositivo"
    
    # Activar modo doze
    modo_doze "$dispositivo"
    
    # Borrar la cache de todas las apps, solo se ejecuta si la cache a aumentado mas de 5mb aproximadamente en cualquier app.
    borrar_cache_todas_apps
    
    echo -e "${YELLOW}Reiniciando las apps\nEspere por favor...${NC}"
    force_stop_apps_ini_vulkan "$dispositivo"
    
    if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
        # hacer vulkan mas fluido, se necesita root
        # Establecimiento de la propiedad:
        echo -e "${GREEN}Tienes acceso root!!!.\nOptimizando Vulkan con 2048MB${NC}"
        adb -s "$dispositivo" shell su -c setprop persist.android.vulkan.memory 2048  # (Opcional) Aumentar memoria asignada a Vulkan o 4096
        adb -s "$dispositivo" shell su -c setprop persist.hwui.use_vulkan true  # Usar Vulkan para la interfaz de usuario
        adb -s "$dispositivo" shell su -c setprop persist.vulkan.enable true  # Activar Vulkan de manera persistente
        adb -s "$dispositivo" shell su -c setprop enable_gpu_debug_layers 1
        
        # Ver la frecuencia mínima y maxima que estan actualmente establecidas en mi CPU
        gpu_min=$(adb -s "$dispositivo" shell "echo 384000000 | su -c tee /sys/class/devfreq/60000000.gpu/min_freq")
        gpu_max=$(adb -s "$dispositivo" shell "echo 850000000 | su -c tee /sys/class/devfreq/60000000.gpu/max_freq")
        # Configurar la mínima frecuencia de GPU
        adb -s "$dispositivo" shell "echo $gpu_min | su -c tee /sys/class/devfreq/60000000.gpu/min_freq" > /dev/null
        echo "Frecuencia mínima de GPU configurada a: $gpu_min"
        # Configurar la máxima frecuencia de GPU
        adb -s "$dispositivo" shell "echo $gpu_max | su -c tee /sys/class/devfreq/60000000.gpu/max_freq" > /dev/null
        echo "Frecuencia máxima de GPU configurada a: $gpu_max"

        
        # Optimizar el compilador jit
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.gc.type sticky"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dex2oat-cgc 1"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dex2oat-extra-opts --compiler-filter=speed"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.jit true"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.jit.initial.threshold 300"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dex2oatthreads 4"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.art.optimization true"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dexopt-flags verify"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.jit.count 8"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dexopt-data-only true"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.dexopt-flags speed"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.usejitprofiles 1"
        adb -s "$dispositivo" shell su -c "setprop dalvik.vm.jit.threshold 800"
        adb -s "$dispositivo" shell su -c "dalvikvm -Xmx512m -Xms256m -Xbootclasspath:/system/framework/core-libart.jar -cp /data/dalvik-cache /system/bin/dex2oat"
        # adb shell su -c "pm list packages -3 | cut -d: -f2 | while read pkg; do am force-stop \$pkg; done"

    else
        adb -s "$dispositivo" shell setprop debug.android.vulkan.memory 2048  # Memoria asignada a Vulkan
        adb -s "$dispositivo" shell setprop debug.hwui.gpu_memory 2048    # Aumentar la memoria asignada a gráficos
        adb -s "$dispositivo" shell setprop debug.graphics.vulkan 1          # Activar Vulkan en gráficos
        adb -s "$dispositivo" shell setprop debug.hwui.use_vulkan true       # Usar Vulkan para la interfaz de usuario
        adb -s "$dispositivo" shell setprop debug.sys.opengles.vulkan.force 1 # Forzar OpenGL ES con Vulkan
        adb -s "$dispositivo" shell setprop debug.vulkan.enable true         # Habilitar Vulkan
        adb -s "$dispositivo" shell setprop debug.hwui.use_vulkan true       # Usar Vulkan en HWUI
    fi
    
    echo -e "${GREEN}[✓] - Vulkan activado correctamente.${NC}"
    echo -e "${YELLOW}[Nota:] - Si algunas apps no abren,\nlimpia la cache de la app y forzar detención.${NC}"
    print_color yellow "$(justify_text "${GREEN}[✓] - ${YELLOW}Muchos de estos ajustes están relacionados con la optimización a largo plazo, y podrían no ser inmediatamente evidentes, ya que los cambios se aplican progresivamente a lo largo del tiempo.${NC}")"
    sleep 5
    mostrar_menu "$dispositivo"
}


function restablecer_opengl {
    dispositivo="$1"
    # Verificar si OpenGL ya está activado
    if adb -s "$dispositivo" shell getprop debug.hwui.renderer | grep -q 'opengl'; then
        echo -e "${YELLOW}[!] - OpenGL ya está activado.${NC}"
        mostrar_menu "$dispositivo"
    else
        echo -e "${YELLOW}[!] - Restableciendo configuración a OpenGL...${NC}"
        # Modificar la configuración para usar OpenGL como renderer
        : '
        # adb -s "$dispositivo" shell "setprop debug.hwui.renderer opengl; for a in \$(pm list packages | grep -v ia.mo | cut -f2 -d:); do am force-stop \"\$a\" & done" >/dev/null 2>&1 &
        adb -s "$dispositivo" shell setprop debug.renderengine.backend opengl
        adb -s "$dispositivo" shell setprop debug.hwui.renderer opengl
        adb -s "$dispositivo" shell setprop debug.app.performance_restricted true
        adb -s "$dispositivo" shell setprop debug.multicore.processing 0
        adb -s "$dispositivo" shell setprop debug.disable.computedata false
        adb -s "$dispositivo" shell setprop debug.cpurend.vsync true
        adb -s "$dispositivo" shell setprop debug.gr.swapinterval 1
        adb -s "$dispositivo" shell setprop debug.hwui.target_gpu_time_percent 50
        adb -s "$dispositivo" shell setprop debug.performance.tuning 0
        adb -s "$dispositivo" shell cmd power set-fixed-performance-mode-enabled false
        # Este comando fuerza a las aplicaciones a utilizar la GPU para el renderizado en lugar de la CPU: pero esta en cero, (deshabilitado)
        adb -s "${dispositivo}" shell settings put global force_gpu_rendering 0
        : '
        adb -s "$dispositivo" shell "setprop debug.hwui.renderer opengl; for a in \$(pm list packages | grep -Ev 'ia.mo|android|com.google.android') ; do am force-stop \"\$a\" & done" >/dev/null 2>&1 &
        # matar el proceso si esta en segundo plano
        pkill -f activar_modo_doze.sh || true
        
        : '
        # eliminar fps
        adb -s "${dispositivo}" shell settings delete global display_refresh_rate
        adb -s "${dispositivo}" shell settings delete global peak_refresh_rate
        adb -s "${dispositivo}" shell settings delete global user_refresh_rate
        adb -s "${dispositivo}" shell settings delete global min_refresh_rate
        adb -s "${dispositivo}" shell settings delete global max_refresh_rate
        adb -s "${dispositivo}" shell settings delete system peak_refresh_rate
        adb -s "${dispositivo}" shell settings delete system user_refresh_rate
        adb -s "${dispositivo}" shell settings delete global screen_refresh_rate
        adb -s "${dispositivo}" shell settings delete global battery_saver_constants
        adb -s "${dispositivo}" shell settings delete global power_save_mode
        adb -s "${dispositivo}" shell settings delete global high_refresh_rate_mode
        adb -s "${dispositivo}" shell settings delete global battery_saver
        adb -s "${dispositivo}" shell settings delete global adaptive_refresh_rate
        adb -s "${dispositivo}" shell settings delete global force_peak_refresh_rate
        adb -s "${dispositivo}" shell settings delete global high_refresh_rate_mode
        adb -s "${dispositivo}" shell settings delete global debug.hwui.force_gpu_rendering
        adb -s "${dispositivo}" shell settings delete global low_power_display
        : '
    
        echo -e "${GREEN}[✓] - OpenGL restablecido correctamente.${NC}"
        mostrar_menu "$dispositivo"
    fi
}

function verificar_gfxinfo {
    dispositivo=$1
    paquete=$2
    # verificar si una app está usando vulkan, abre la app específica, ejemplo (org.citra.emu) y luego en termux escribe lo siguiente:
    # adb -s "$dispositivo" shell dumpsys gfxinfo org.citra.emu
    # adb -s "$dispositivo" shell dumpsys gfxinfo org.citra.emu | grep -E 'Vulkan|OpenGL'
    # adb -s "$dispositivo" shell dumpsys gfxinfo | grep -i pipeline
    echo -e "${BLUE}[~] - Verificando el renderer usado por la aplicación ${paquete}...${NC}"
    adb -s "$dispositivo" shell dumpsys gfxinfo "$paquete" | grep -E 'Vulkan|OpenGL'
}





function is_installed {
    local dispositivo=$1
    local package=$2
    # Verificar si el paquete está instalado
    adb -s "$dispositivo" shell pm list packages | grep -q "^package:$package$"
}
function force_stop_apps {
    local dispositivo=$1
    # Lista de aplicaciones excluidas
    excluidas_app=("com.termux" "com.termux.boot" "com.quickcursor")
    # Captura el nombre del paquete de la app abierta
    app_abierta=$(adb -s "$dispositivo" shell dumpsys activity activities | grep 'mResumedActivity' | sed -E 's/.*ActivityRecord\{[^ ]+ u0 ([^/]+)\/.*/\1/')
    # Añadir aplicaciones de excluidas_app a la variable app_abierta, si no están ya en ella
    for excluida in "${excluidas_app[@]}"; do
        if ! echo "$app_abierta" | grep -q "$excluida"; then
            app_abierta+=" $excluida"
        fi
    done
    app_excluidas=() # Inicializar array para excluir paquetes
    # Obtener la lista de todos los paquetes (incluyendo paquetes de sistema y usuario)
    local packages=$(adb -s "$dispositivo" shell pm list packages | cut -d':' -f2)
    # Obtener la lista de paquetes del sistema
    local system_packages=$(adb -s "$dispositivo" shell pm list packages -s | cut -d':' -f2)
    # Obtener la lista de paquetes deshabilitados
    local disabled_packages=$(adb -s "$dispositivo" shell pm list packages -d | cut -d':' -f2)
    # Bucle para detener cada una de las aplicaciones
    for package in $packages; do
        # Verificar si el paquete está deshabilitado
        if echo "$disabled_packages" | grep -q "^$package$"; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos si está deshabilitado
            continue # Saltar la exclusión
        fi
        # Verificar si el paquete es uno de los excluidos o la app abierta
        if [[ " ${excluidas_app[@]} " =~ " $package " || "${app_abierta[@]}" =~ "$package" ]]; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos
            continue # Saltar la exclusión
        fi
        # Verificar si el paquete es del sistema
        if echo "$system_packages" | grep -q "^$package$"; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos si es del sistema
            continue # Saltar la exclusión
        fi
        # Forzar cierre de las demás aplicaciones
        adb -s "$dispositivo" shell am force-stop "$package"
        echo -e "${COLOR_AMARILLO}Cierre-forzado ${COLOR_RESET}$package"
    done

    # Filtrar aplicaciones instaladas y evitar duplicados
    INSTALADAS=()
    for app in $app_abierta; do
        # si está instalada la app
        if is_installed "$dispositivo" "$app"; then
            # Evitar duplicados antes de añadir a INSTALADAS
            if ! [[ " ${INSTALADAS[@]} " =~ " $app " ]]; then
                INSTALADAS+=("$app")
            fi
        else
            echo "Aplicación no encontrada: $app" >/dev/null
        fi
    done
    # Imprimir las apps excluidas
    if [ ${#INSTALADAS[@]} -gt 0 ]; then
        echo "apps excluidas:"
        for package in "${INSTALADAS[@]}"; do
            echo "$package"
        done
    else
        echo "No se excluyeron aplicaciones" >/dev/null
    fi
    mostrar_menu "$dispositivo"
}
function force_stop_apps_ini_vulkan {
    local dispositivo=$1
    # Lista de aplicaciones excluidas
    excluidas_app=("com.termux" "com.termux.boot" "com.quickcursor")
    # Lista de aplicaciones que quieres detener manualmente (incluidas)
    incluidas_app=("com.facebook.katana" "com.android.chrome" "com.google.android.gm" "com.netflix.ninja")
    # Captura el nombre del paquete de la app abierta
    app_abierta=$(adb -s "$dispositivo" shell dumpsys activity activities | grep 'mResumedActivity' | sed -E 's/.*ActivityRecord\{[^ ]+ u0 ([^/]+)\/.*/\1/')
    # Comprobar si la app abierta es una de las incluidas
    for incluida in "${incluidas_app[@]}"; do
        if [[ "$app_abierta" == "$incluida" ]]; then
            # Si la app abierta es una de las incluidas, no la consideramos
            app_abierta=""
            break
        fi
    done

    # Añadir aplicaciones de excluidas_app a la variable app_abierta, si no están ya en ella
    for excluida in "${excluidas_app[@]}"; do
        if ! echo "$app_abierta" | grep -q "$excluida"; then
            app_abierta+=" $excluida"
        fi
    done
    
    app_excluidas=() # Inicializar array para excluir paquetes
    
    # Obtener la lista de todos los paquetes (incluyendo paquetes de sistema y usuario)
    local packages=$(adb -s "$dispositivo" shell pm list packages | cut -d':' -f2)
    # Obtener la lista de paquetes del sistema
    local system_packages=$(adb -s "$dispositivo" shell pm list packages -s | cut -d':' -f2)
    # Obtener la lista de paquetes deshabilitados
    local disabled_packages=$(adb -s "$dispositivo" shell pm list packages -d | cut -d':' -f2)

    # Bucle para detener cada una de las aplicaciones
    for package in $packages; do
        # Verificar si el paquete está deshabilitado
        if echo "$disabled_packages" | grep -q "^$package$"; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos si está deshabilitado
            continue # Saltar la exclusión
        fi
        
        # Verificar si el paquete es uno de los excluidos o la app abierta
        if [[ " ${excluidas_app[@]} " =~ " $package " || "${app_abierta[@]}" =~ "$package" ]]; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos
            continue # Saltar la exclusión
        fi
        
        # Verificar si el paquete es del sistema
        if echo "$system_packages" | grep -q "^$package$"; then
            app_excluidas+=("$package") # Añadir a la lista de excluidos si es del sistema
            continue # Saltar la exclusión
        fi
        
        # Forzar cierre de las demás aplicaciones
        adb -s "$dispositivo" shell am force-stop "$package"
        echo -e "${COLOR_AMARILLO}Cierre-forzado ${COLOR_RESET}$package"
    done

    # Filtrar aplicaciones instaladas y evitar duplicados
    INSTALADAS=()
    for app in $app_abierta; do
        # Si está instalada la app
        if is_installed "$dispositivo" "$app"; then
            # Evitar duplicados antes de añadir a INSTALADAS
            if ! [[ " ${INSTALADAS[@]} " =~ " $app " ]]; then
                INSTALADAS+=("$app")
            fi
        else
            echo "Aplicación no encontrada: $app" >/dev/null
        fi
    done

    # Forzar cierre de las aplicaciones incluidas manualmente
    for package in "${incluidas_app[@]}"; do
        if is_installed "$dispositivo" "$package"; then
            adb -s "$dispositivo" shell am force-stop "$package"
            echo -e "${COLOR_AMARILLO}Cierre-forzado ${COLOR_RESET}$package"
        else
            echo "Aplicación no encontrada: $package"
        fi
    done
    
    # Imprimir las apps excluidas
    if [ ${#INSTALADAS[@]} -gt 0 ]; then
        echo "apps excluidas:"
        for package in "${INSTALADAS[@]}"; do
            echo "$package"
        done
    else
        echo "No se excluyeron aplicaciones" >/dev/null
    fi
    
}


function verif_conn_router {
     # Obtener la IP de wlan0 usando busybox
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Verificar si la interfaz wlan0 está disponible y tiene una dirección IP
    if [[ -n "$ip_objetivo" ]]; then
        ip0="$ip_objetivo"
    else
        # Si no se obtuvo IP de wlan0, buscar otra IP que no sea 127.0.0.1
        ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
    fi
    if [ "$ip0" ]; then
        echo "La direccion IP wlan0 es: $ip0" >/dev/null 2>&1
    else
        echo "La direccion IP datos es: $ip1" >/dev/null 2>&1
     fi
}

apagar_dispositivo() {
apagar=$(cat <<EOF
import os
import sys
import time
import signal

ip_port = "$dispositivo"

# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    # Limpiar la salida y detener el progreso
    #print("\nProceso interrumpido por el usuario.\033[K")
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y detener el progreso
    #print("\nProceso interrumpido por el usuario.\033[K")
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

def cuenta_regresiva(tiempo):
    tiempo_segundos = int(tiempo) * 60
    for i in range(tiempo_segundos, -1, -1):
        minutos_restantes, segundos_restantes = divmod(i, 60)
        tiempo_restante = f"{minutos_restantes:02}:{segundos_restantes:02}"
        sys.stdout.write("\r\033[KEl dispositivo se apagara en: {}".format(tiempo_restante))
        sys.stdout.flush()
        time.sleep(1)
    
def apagar_dispositivo(ip_port, tiempo):
    # Iniciar cuenta regresiva
    cuenta_regresiva(tiempo)

    print("")
    # Conectar al dispositivo mediante adb
    os.system(f"adb connect {ip_port} >/dev/null")
    # Apagar el dispositivo
    os.system(f"adb -s {ip_port} shell reboot -p >/dev/null 2>&1")
    print(f"Dispositivo {ip_port} apagado\n")
    os.system(f"adb disconnect {ip_port} >/dev/null 2>&1")

#ip_port = input("Ingrese la IP:PUERTO del dispositivo: ")
print("Ingrese el tiempo de apagado en minutos: ", end="")
tiempo = input()

apagar_dispositivo(ip_port, tiempo)
EOF
)
    python -c "$apagar" 
    seleccionar_dispositivo
}


#######FUNCIONES_DE_CONECCION#######
disponible_adb='false'

mi_dispositivo() {
    clear
    echo ""
    echo -e "${GREEN}Brand ID${NC}: $(getprop ro.product.system.brand)"
    echo -e "${GREEN}Modelo${NC}: $(getprop ro.product.model)"
    echo -e "${GREEN}Version de Android${NC}: $(getprop ro.build.version.release)"
    echo -e "${GREEN}Model ID${NC}: $(getprop ro.build.product)"
    echo -e "${GREEN}Kernel ID${NC}: $(uname -r)"
    echo -e "${GREEN}Chipset ID${NC}: $(getprop ro.product.board)"
    echo -e "${GREEN}Architecture${NC}: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {
    dispositivo_conectado="$1"
    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    for i in {1..10}; do
        if adb devices | grep -q "device$"; then
            break
        fi
        sleep 0.5
    done
    
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        disponible_adb='true'
    fi
    
    # Reconectar el dispositivo despues de haber establecido adb
    conn=$(adb connect "$dispositivo_conectado")
    # Rectificar la conexión. Si no está establecida, entonces volver a empareja, sino muestra el menú modificado...
    if [[ "$conn" == "failed"* ]]; then
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados...
        exit 1
    else
        : '
        # Mostrar el menú inicial modificado...
        menu_principal 2>/dev/null || {
            # echo "La función no está definida aún. Recargando el script..."
            source "$0"
            menu_principal
        }
        : '
        return
    fi
    
    
}

mostrar_dispositivos1() {
    encabezado_tabla='false'
    my_device="$1"
    mi_dispositivo
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col * 7 / 100))
    mul2=$(($col * 47 / 100))
    mul3=$(($col * 27 / 100))
    mul4=$(($col * 9 / 100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"

    printf_string="# %-${mul}s ┃ %-${mul2}s ┃ %-${mul3}s ┃ %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)

    # Ajuste responsive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done

    dispositivos=()
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    connected_count=$(echo "$connected_devices" | wc -l)  # Contar los dispositivos conectados
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}' | grep -v "$my_device")
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')

    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            if [ "$encabezado_tabla" == 'false' ]; then
                echo ""
                # Encabezado
                printf "${COLOR_VERDE}┌%s┐${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
                printf "${COLOR_VERDE}█${COLOR_BLANCO} %-${mul}s ${COLOR_VERDE}┃${COLOR_RESET} %-${mul2}s ${COLOR_VERDE}┃${COLOR_RESET} %-${mul3}s ${COLOR_VERDE}┃${COLOR_RESET} %- ${mul4}s ${COLOR_VERDE}█${COLOR_RESET}\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
                printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
                encabezado_tabla='true'
            fi
            dispositivos+=("$device")
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            # Fila de datos
            printf "${COLOR_VERDE}█${COLOR_BLANCO} %-${mul}s ${COLOR_VERDE}┃${COLOR_RESET} %-${mul2}s ${COLOR_VERDE}┃${COLOR_RESET} %-${mul3}s ${COLOR_VERDE}┃${COLOR_RESET} %- ${mul4}s ${COLOR_VERDE}█${COLOR_RESET}\n" " $id_fortmat" "$device" "$model" "v$version"

            # Línea divisoria (solo si no es la última fila)
            if [ "$id" -lt "$connected_count" ]; then
                printf "${COLOR_VERDE}█%s█${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
            fi

            id=$((id + 1))
        done
        # Línea inferior después del bucle
        printf "${COLOR_VERDE}└%s┘${COLOR_RESET}\n" "$(seq -s '═' $col | tr -d '[:digit:]')"
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo -e "${RED}Dispositivos offline${NC}:"
        echo "$offline_devices"
        # Pie de la tabla
        echo -en "${COLOR_VERDE}"
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
        echo -en "${COLOR_RESET}"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo -e "${RED}Dispositivos no autorizados${NC}:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        echo -ne "${COLOR_VERDE}"
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
        echo -ne "${COLOR_RESET}"
    fi
}
# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    # Obtener la IP de wlan0, si está disponible
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
    if [ -z "$ip" ]; then
        sleep 1
        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi

    for i in {1..10}; do
        if adb devices | grep -q "device$"; then
            break
        fi
        sleep 0.5
    done
    adb_output=$(adb devices -l)
    # Elegir entre el emulador o la ip si hay alguno.
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip}:)" |  head -n 1)
    if [[ -z "$connected_devices" ]]; then
        solicitar_emparejamiento
    fi


    ip_device="$1"
    mostrar_dispositivos1 "$ip_device"
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    # echo -en "Ingrese el número del dispositivo o 'q+enter' para salir: "
    printf "$(print_color yellow "$(justify_text "Ingrese el número del dispositivo o ${NC}'${RED}q+enter${NC}' ${YELLOW}para salir${NC}: ")")"
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        cd ~/Busca-Palabras
        bash Menu-Busca-Palabras.sh
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
    
}








# verifica que termux-api.apk esté instalado 
verifica_termux-api() {
    # pkg install apksigner
    
    EMULATOR_ID="$1"
    
    # Definir códigos de color
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    CYAN='\033[0;36m'
    NC='\033[0m' # Sin color
    
    # Verificar si los permisos de almacenamiento ya han sido concedidos
    # Ruta de prueba
    prueba_ruta="/sdcard/.prueba_permiso_termux.txt"
    # Verificar el estado del almacenamiento
    verificar_almacenamiento() {
        if [ -d "/sdcard/" ]; then
            # Intentar crear un archivo para verificar los permisos
            echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
            if [ -f "$prueba_ruta" ]; then
                echo -e "\n${GREEN}Los permisos de almacenamiento ya han sido concedidos.${NC}" >/dev/null 2>&1
                # Concediendo permisos de almacenamiento con adb para reforzar
                adb -s "$EMULATOR_ID" shell pm grant com.termux android.permission.READ_EXTERNAL_STORAGE
                adb -s "$EMULATOR_ID"  shell pm grant com.termux android.permission.WRITE_EXTERNAL_STORAGE
                rm "$prueba_ruta"  # Eliminar el archivo de prueba
                return 0
            else
                echo -e "${RED}El directorio existe, pero los permisos de escritura no están disponibles.${NC}"
            fi
        fi
    
        # Si llegamos aquí, es porque no se tienen los permisos
        echo -e "${YELLOW}Concediendo permisos de almacenamiento...${NC}"
        termux-setup-storage
        sleep 5  # Esperar un momento para permitir que se concedan los permisos
    
        # Verificar de nuevo los permisos
        if [ -d "/sdcard/" ]; then
            echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
            if [ -f "$prueba_ruta" ]; then
                echo -e "${GREEN}Permisos de almacenamiento concedidos correctamente.${NC}"
                rm "$prueba_ruta"  # Eliminar el archivo de prueba
                return 0
            else
                echo -e "${RED}No se pudieron conceder los permisos de almacenamiento. Asegúrate de aceptar la solicitud de permisos.${NC}"
                return 1
            fi
        else
            echo -e "${RED}El directorio de almacenamiento no está disponible. Asegúrate de aceptar la solicitud de permisos.${NC}"
            return 1
        fi
    }
    # Ejecutar la función
    verificar_almacenamiento
    
    # Verificar si Python está instalado
    if [ -x ${PREFIX}/bin/python ]; then
        echo "Python ya está instalado." >/dev/null 2>&1
    else 
        echo "Instalando python..."
        apt install python -y
        pkg install python-pip
        # dpkg --configure -a
        # apt list --upgradable
        # apt upgrade
        # apt-get check
        # apt clean
    fi
    
    instalar_paquete_pip() {
        local comando=$1
        local instalacion=$2
        local mensaje_error=$3

        if ! command -v "$comando" &> /dev/null; then
            echo -e "$comando no está instalado.\nInstalando $comando..."
            eval "$instalacion" >/dev/null 2>&1
            if [ $? -ne 0 ]; then
                echo "$mensaje_error"
                exit 1
            fi
        else
            echo "$comando ya está instalado." >/dev/null 2>&1
        fi
    }

    
    # Función para instalar paquetes si no están presentes
    instalar_paquete_share() {
        if [[ ! -x $PREFIX/share/doc/$1 ]]; then
            echo "Instalando $2"
            pkg install -y $1 >/dev/null 2>&1
            echo -e "$1 instalado correctamente."
        else
            echo "$2 ya está instalado" >/dev/null 2>&1
        fi
    }
    # Función para instalar paquetes si no están presentes
    instalar_paquete_bin() {
        if [[ ! -f $PREFIX/bin/$1 ]]; then
            echo "Instalando $2"
            pkg install -y $1 >/dev/null 2>&1
            echo -e "$1 instalado correctamente."
        else
            echo "$2 ya está instalado" >/dev/null 2>&1
        fi
    }
    
    # Instalar herramientas necesarias
    instalar_paquete_bin "zip" "zip"
    instalar_paquete_bin "rarp" "rar"
    instalar_paquete_bin "adb" "adb"
    instalar_paquete_bin "unrar" "unrar"
    instalar_paquete_bin "nmap" "nmap"
    instalar_paquete_bin "apksigner" "apksigner"
    instalar_paquete_bin "mediainfo" "mediainfo"
    instalar_paquete_share "termux-api" "termux-api"
    instalar_paquete_pip "gdown" "pip install gdown" "Error al instalar gdown. Asegúrate de tener pip instalado."
    
    # Buscar rastro de pkg sucios:
    # find $PREFIX -name "*rarp*" # esta relacionado con net-tools 
    
    iniciar_descarga_google_drive() {
        # ID del archivo de Google Drive
        local FILE_ID="$1"
        local archivo_zip="$2"
        local destino="$3"
        local adb_conectado="$4"
        local arc_rom_apk="$5"
        local pack_app="$6"
        
        # Ruta y nombre del archivo donde deseas guardarlo
        RUTA_DESTINO="$destino/$archivo_zip"
        echo $RUTA_DESTINO
        
    
        # Verificar si el directorio de destino existe
        if [ ! -d "$destino" ]; then
            echo -e "${YELLOW}El directorio $destino no existe. Creándolo...${NC}"
            mkdir -p "$destino"
            
            # Verificar si se creó correctamente
            if [ $? -ne 0 ]; then
                echo -e "${RED}Error al crear el directorio $destino. Saliendo...${NC}"
                exit 1
            fi
            echo -e "${YELLOW}Directorio creado con éxito.${NC}"
        fi
    
        # Descargar el archivo utilizando gdown
        echo -e "\n${YELLOW}Descargando archivo desde Google Drive...${NC}"
        gdown -O "$RUTA_DESTINO" "https://drive.google.com/uc?id=$FILE_ID"
    
        # Comprobar si la descarga fue exitosa
        if [ $? -eq 0 ]; then
            echo -e "${YELLOW}Descargado con éxito en:\n${GREEN}${destino}/${archivo_zip}${NC}"
            cd "$destino"
            unzip "${archivo_zip}"
            echo -e "${YELLOW}Extracción completada en:\n${GREEN}${destino}/${NC}"
            
        # Obtener solo el nombre del archivo y luego la extensión
        # capturar solo el archivo sin su ruta
        nombre_archivo=$(basename "$arc_rom_apk")
        # capturar solo la extensión del archivo
        extension="${nombre_archivo##*.}"
    
        # Si existe el apk o rom.
        if [ -f "${arc_rom_apk}" ]; then
            # toma la extensión del archivo a analizar.
            nombre_archivo=$(basename "${arc_rom_apk}")
            # echo $nombre_archivo
            extension="${nombre_archivo##*.}"
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
        fi
        
        app_instalada='false'
        # echo "aqui"
        # echo ${adb_conectado}
        if adb -s "$dispositivo" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
            app_instalada='true'
        fi
        echo "app_instalada: $app_instalada"
    
        # adb -s "${adb_conectado}" shell pm list package | grep -E "^package:${pack_app}$" | awk -F ':' '{print $2}'
        echo -e "${YELLOW}Verificando archivo APK...${NC}"
        APK_PATH="$arc_rom_apk"
        echo "APK_PATH: $APK_PATH"
        
        apk='false'
        result='Exception'
        # verifica el archivo si existe
        if [[ -f "${arc_rom_apk}" ]]; then
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$arc_rom_apk" 2>&1)
            tamanio_archivo=$(stat --format="%s" "${arc_rom_apk}" 2>&1)
            apk='true'
            result='Exception'
        fi
        
        # Comparar si son iguales en tamaño.
        if [[ "${tamanio_archivo}" -eq 2868448 ]] && [[ -f "$arc_rom_apk" ]]; then
            echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}" # > /dev/null
            apk_malo='false'
            if [[ "${app_instalada}" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}"
                return
            elif [[ -n "${dispositivo}" ]] && [[ -f "$arc_rom_apk" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                return
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
        else
            # echo -e "${RED}El archivo APK no coincide en tamaño. Puede estar corrupto.${NC}"
            apk_malo='true'
        fi
        
            cd - > /dev/null
        else
            echo -e "${RED}Error al descargar el archivo. Verifica el enlace de Google Drive.${NC}"
            exit 1
        fi
    }
    # Función para descargar y descomprimir archivos
    descargar_apk_rom_y_descomprimir() {
        # "$1"   "$2"                  "$3"                    "$4"               "$5"        
        # "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$adb_conectado" 
        local url="$1"
        local archivo_zip="$2"
        local ruta_destino="$3"
        local arc_rom_apk="$4"
        local dispositivo="$5"
        local pack_app="$6"
        
        # Armar la ruta completa del archivo
        local ruta_archivo="${ruta_destino}/${archivo_zip}"
        # echo $ruta_archivo
        
        echo ""   
    
        # Obtener solo el nombre del archivo y luego la extensión
        # capturar solo el archivo sin su ruta
        nombre_archivo=$(basename "$ruta_archivo")
        # capturar solo la extensión del archivo
        extension="${nombre_archivo##*.}"
    
        # Si existe el apk o rom.
        if [ -f "${arc_rom_apk}" ]; then
            # toma la extensión del archivo a analizar.
            nombre_archivo=$(basename "${arc_rom_apk}")
            # echo $nombre_archivo
            extension="${nombre_archivo##*.}"
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
        fi
        
        app_instalada='false'
        # echo "aqui"
        # echo ${adb_conectado}
        if adb -s "$dispositivo" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
            app_instalada='true'
        fi
        # echo "app_instalada: $app_instalada"
    
        # adb -s "${adb_conectado}" shell pm list package | grep -E "^package:${pack_app}$" | awk -F ':' '{print $2}'
        echo -e "${YELLOW}Verificando archivo APK...${NC}"
        APK_PATH="$arc_rom_apk"
        # echo "APK_PATH: $APK_PATH"
        
        apk='false'
        result='Exception'
        # verifica el archivo si existe
        if [[ -f "${arc_rom_apk}" ]]; then
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$arc_rom_apk" 2>&1)
            tamanio_archivo=$(stat --format="%s" "${arc_rom_apk}" 2>&1)
            apk='true'
            result='Exception'
        fi
        
        # Comparar si son iguales en tamaño.
        if [[ "${tamanio_archivo}" -eq 2868448 ]] && [[ -f "$arc_rom_apk" ]]; then
            echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}" # > /dev/null
            apk_malo='false'
            if [[ "${app_instalada}" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}"
                return
            elif [[ -n "${dispositivo}" ]] && [[ -f "$arc_rom_apk" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$arc_rom_apk" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                return
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
        else
            # echo -e "${RED}El archivo APK no coincide en tamaño. Puede estar corrupto.${NC}"
            apk_malo='true'
        fi
        # Verificar otro archivo si contiene la palabra "Exception" o "Malformed"
        if [[ "$apk" == 'false' ]]; then
            echo -e "${RED}El archivo $arc_rom_apk\nno se encuentra en su dispositivo.${NC}"
        elif echo "$result" | grep -qi "Exception"; then
            echo -e "${RED}El archivo APK es inválido o está corrupto.${NC}"
            rm -rf "${APK_PATH}"
            apk_malo='true'
        elif echo "$result" | grep -qi "Malformed"; then
            echo -e "${RED}El archivo APK está mal formado.${NC}"
            rm -rf "${APK_PATH}"
            apk_malo='true'
        else
            echo -e "${GREEN}El archivo ya está descargado en1:\n${YELLOW}${APK_PATH}${NC}"
            apk_malo='false'
       
            nombre_archivo_escapado=""
            for (( i=0; i<${#nombre_archivo}; i++ )); do
                char="${nombre_archivo:i:1}"
                case "$char" in
                    '(' | ')' | '[' | ']')
                        nombre_archivo_escapado+="\\$char"
                        ;;
                   ' ')
                       nombre_archivo_escapado=$(echo "${nombre_archivo}" | sed 's/ /\\ /g')
                       break
                       ;;
                    *)
                        nombre_archivo_escapado+="$char"
                        ;;
                esac
            done
            if [[ "$app_instalada" == "true" ]]; then
                echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}" # > /dev/null
                return
            elif [[ -n "$dispositivo" ]] && [[ "$app_instalada" == "false" ]]; then
                echo -e "${YELLOW}Instalando $APK_PATH\nen su dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
            else
                echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
            fi
            return
        fi
        if [[ "$apk_malo" == 'true' ]] && [[ -f "$ruta_archivo" ]]; then
            echo "Verificando archivo ZIP apk..."
            if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                echo "Descomprimiendo $ruta_archivo..."
                unzip -o "$ruta_archivo" -d "$ruta_destino"
                echo -e "${GREEN}Descompresión completada.${NC}"
                echo -e "${YELLOW}Instalando $APK_PATH\nen su dispositivo!!!${NC}"
                nombre_archivo=$(basename "$APK_PATH")
                nombre_archivo_escapado=""
                for (( i=0; i<${#nombre_archivo}; i++ )); do
                    char="${nombre_archivo:i:1}"
                    case "$char" in
                        '(' | ')' | '[' | ']')
                            nombre_archivo_escapado+="\\$char"
                            ;;
                       ' ')
                           nombre_archivo_escapado=$(echo "${nombre_archivo}" | sed 's/ /\\ /g')
                           break
                           ;;
                        *)
                            nombre_archivo_escapado+="$char"
                            ;;
                    esac
                done
                echo -e "${YELLOW}Instalando $APK_PATH\nsu dispositivo!!!${NC}"
                adb -s "$dispositivo" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                adb -s "$dispositivo" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                adb -s "$dispositivo" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
            else
                echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                rm -f "$ruta_archivo"
                iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$dispositivo" "$arc_rom_apk" "$pack_app"
                return
            fi
        else
            iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$dispositivo" "$arc_rom_apk" "$pack_app"
            return
        fi
    }
    
    pack_app='com.termux.api'
    # dispositivo='emulator-5554'
    ruta_destino='/sdcard/Download'
    archivo_zip='Termux_API_0.50.1.zip'
    url='1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY'
    ruta_rom_apk='/sdcard/Download/Termux_API_0.50.1.apk'
    # Verificar si hay un dispositivo conectado
    # dispositivo=$(adb devices | awk 'NR>1 && $2=="device" {print $1}')
    # dispositivo="emulator-5554"
    if [[ -z "$EMULATOR_ID" ]]; then
        echo "No hay dispositivos conectados."
        exit 1
    fi
    # Obtener el estado de la pantalla
    estado_pantalla=$(adb -s "$EMULATOR_ID" shell dumpsys power | grep -E "Display Power|mHoldingDisplay" | grep -oE "ON|OFF|true|false" | head -n 1)
    if [[ "$estado_pantalla" == "ON" || "$estado_pantalla" == "true" ]]; then
        echo "Mantenga la pantalla ENCENDIDA." # > /dev/null 2&>1
        pantalla_apagada='true'
    elif [[ "$estado_pantalla" == "OFF" || "$estado_pantalla" == "false" ]]; then
        echo "La pantalla está APAGADA."
        pantalla_apagada='false'
        return
    else
        echo "No se pudo determinar el estado de la pantalla." > /dev/null 2&>1
    fi
    
    # Función para verificar si un paquete está instalado en el dispositivo de forma exacta
    cap_nom_pack() {
        local package="$1"
        # Obtener solo el paquete exacto de la lista de paquetes instalados com esto: grep -E "^package:com.termux$" | awk -F ':' '{print $2}'
        nombre_pack=$(adb -s "${EMULATOR_ID}" shell pm list packages | grep -E "^package:${package}$" | awk -F ':' '{print $2}') > /dev/null
        echo "$nombre_pack"
    }
    # cap_nom_pack "${pack_app}"

    if ! adb -s "$EMULATOR_ID" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
        # https://drive.google.com/file/d/1UIICdllSQi-FmRuo3uOcZ_mXiWnpfPqY/view?usp=drivesdk
        descargar_apk_rom_y_descomprimir "$url" "$archivo_zip" "$ruta_destino" "$ruta_rom_apk" "$EMULATOR_ID" "$pack_app"
    else
        echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}" > /dev/null
        echo ""
    fi
}
# Función para capturar el nombre del paquete de la app
ver_paquete_app() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    echo -e "\n${YELLOW}Cuando presiones empezar, abre la app que\nquieres saber su nombre antes de 5 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"
    
    # Mostrar la notificación del tiempo
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # sleep 5
    
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2&>1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
        echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null 2&>1
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    
    # Detener la aplicación detectada (si no es Termux)
    if [[ "$nombre_paquete" != "com.termux" ]]; then
        adb -s "$dispositivo" shell am force-stop "$nombre_paquete"
    fi
    # Abrir Termux
    adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
        
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    
    # Mensaje de finalización
    echo -e "${BLUE}Proceso completado.${NC}\n"
}
# Función para iniciar una aplicación por paquete
iniciar_aplicacion() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    echo -e "Escriba \"q\" para salir..."
    while true; do
        read -p "Introduce el nombre del paquete de la app (o escribe 'salir' para terminar): " package_name

        if [[ -z "$package_name" ]]; then
            echo "El nombre del paquete no puede estar vacío. Inténtalo de nuevo."
        elif [[ "$package_name" == "q" ]]; then
            echo "Saliendo..."
            menu_ver_paquete_app "$dispositivo"
            break
        else
            echo "Nombre del paquete introducido: $package_name"
            # Aquí puedes agregar lo que desees hacer con el paquete
            break
        fi
    done
    
    if ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${package_name}$" > /dev/null; then
        echo "Nombre del paquete no existe. Inténtalo de nuevo."
        return
    fi
    
    # Obtener la actividad principal
    ACTIVIDAD=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $package_name | tail -n 1")

    if [[ -z "$ACTIVIDAD" ]]; then
        echo -e "${RED}No se encontró la actividad principal para el paquete $package_name.${NC}"
        return
    fi

    echo -e "${GREEN}Iniciando la aplicación...${NC}"
    adb -s "$dispositivo" shell am start -n "$ACTIVIDAD" > /dev/null
    echo -e "${BLUE}Aplicación iniciada con éxito.${NC}\n"
}
capturar_swipe() {
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    echo -e "${YELLOW}Cuando abra la app, haga un gesto de swipe en cualquier dirección dentro de los próximos 3 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"

    # Capturar el nombre del paquete
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2&>1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
        echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    if [[ -z "$nombre_paquete" ]]; then
        echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}"
        return
    fi
    
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    

    adb -s "$dispositivo" shell getevent -l 2>/dev/null | while read -r line; do
        # Detectar inicio del toque
        if [[ "$line" =~ BTN_TOUCH.*DOWN ]]; then
            touch_active=true
        fi

        # Detectar posición inicial
        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex)) # Convertir de hexadecimal a decimal
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex)) # Convertir de hexadecimal a decimal
        fi

        if $touch_active && [[ -n "$x_coord" && -n "$y_coord" ]]; then
            if [[ -z "$x_start" && -z "$y_start" ]]; then
                x_start="$x_coord"
                y_start="$y_coord"
                echo -e "${CYAN}Punto inicial registrado:${NC} X=$x_start, Y=$y_start"
            fi
        fi

        # Detectar fin del toque
        if [[ "$line" =~ BTN_TOUCH.*UP ]]; then
            touch_active=false
            if [[ -n "$x_coord" && -n "$y_coord" ]]; then
                x_end="$x_coord"
                y_end="$y_coord"
                echo -e "${CYAN}Punto final registrado:${NC} X=$x_end, Y=$y_end"

                # Verificar si hubo desplazamiento
                if [[ "$x_start" -eq "$x_end" && "$y_start" -eq "$y_end" ]]; then
                    echo -e "${RED}No hubo movimiento detectado. Intenta de nuevo.${NC}"
                else
                    # Calcular diferencias
                    dx=$((x_end - x_start))
                    dy=$((y_end - y_start))

                    # Determinar dirección
                    if (( dx > 0 && dx >= dy )); then
                        echo -e "${GREEN}El gesto fue hacia la derecha.${NC}"
                    elif (( dx < 0 && -dx >= dy )); then
                        echo -e "${GREEN}El gesto fue hacia la izquierda.${NC}"
                    elif (( dy > 0 && dy > dx )); then
                        echo -e "${GREEN}El gesto fue hacia abajo.${NC}"
                    elif (( dy < 0 && -dy > dx )); then
                        echo -e "${GREEN}El gesto fue hacia arriba.${NC}"
                    else
                        echo -e "${RED}El gesto no fue claro. Intenta de nuevo.${NC}"
                    fi
                fi
                echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $dispositivo shell input swipe $x_start $y_start $x_end $y_end\n"
                # Abrir Termux
                adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
                # Detener la captura
                pkill -f getevent
                break
            fi
        fi
    done
}
# Función para tomar coordenadas de una app
tomar_coordenadas() {
    dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    # echo -e "\n${YELLOW}Cuando presiones empezar, abre la app que\nquieres capturar uns coordenada.${NC}"
    echo -e "${YELLOW}Cuando abra la app, espere 3 segundos y haga click\ndonde desee capturar las coordenadas...${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"
    
    
    # Mostrar la notificación del tiempo
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # sleep 5
    
    while true; do
        # Captura el nombre del paquete
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        # Verifica si el nombre del paquete es válido
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$" > /dev/null; then
            echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n" >/dev/null
            break # Salir del bucle si el nombre del paquete es válido
        fi

       # Agrega un pequeño retraso para evitar bucles muy rápidos
        sleep 0.5
    done
    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")
    
    
    echo -e "${GREEN}El nombre del paquete detectado es${NC}:\n$nombre_paquete\n"
    # Ejecutar la actividad
    echo -e "${GREEN}Para abrir la aplicación usando adb:${NC}\nadb -s $dispositivo shell am start -n $actividad_ini_app\n"
    # adb -s "$dispositivo" shell am start -n "$actividad_ini_app"
    
    # Captura los eventos de coordenadas X e Y
    adb -s "$dispositivo" shell getevent -l 2>/dev/null | while read -r line; do
        if [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex)) # Convertir de hexadecimal a decimal
        fi

        if [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex)) # Convertir de hexadecimal a decimal
        fi

        if [[ -n "$x_coord" && -n "$y_coord" ]]; then
            # echo -e "\n${GREEN}Coordenadas capturadas:${NC}"
            echo -e "\n${COLOR_VERDE}Coordenadas capturadas (Hexadecimal)${COLOR_RESET}:\n${COLOR_AMARILLO}ABS_MT_POSITION_X${COLOR_RESET}: $x_hex\n${COLOR_AMARILLO}ABS_MT_POSITION_Y${COLOR_RESET}: $y_hex"
            echo -e "\n${COLOR_VERDE}Coordenadas capturadas (Decimal)${COLOR_RESET}:\n${COLOR_AMARILLO}ABS_MT_POSITION_X${COLOR_RESET}: $x_coord\n${COLOR_AMARILLO}ABS_MT_POSITION_Y${COLOR_RESET}: $y_coord"
            echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $EMULATOR_ID shell input tap $x_coord $y_coord"
            # Abrir Termux
            adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
            pkill -f getevent
            echo ""
            break
        fi
    done
}
capturar_tap_prolongado() {
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    
    echo -e "${YELLOW}Cuando abra la app, mantenga presionado en cualquier posición durante al menos 1 segundos.${NC}"
    read -n 1 -p "Presiona cualquier tecla para empezar..."
    echo -e "\n"

    # Capturar el nombre del paquete
    for i in {3..1}; do
        termux-toast -s "Cuenta regresiva: $i segundos" > /dev/null
        sleep 1.7
    done
    termux-toast "¡Tiempo terminado!" > /dev/null
    # Capturar el nombre del paquete de la aplicación actual
    while true; do
        local nombre_paquete=$(adb -s "$dispositivo" shell dumpsys window | grep -E 'mCurrentFocus' | awk -F' ' '{print $3}' | awk -F'/' '{print $1}')
    
        if [[ -z "$nombre_paquete" ]]; then
            echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}" >/dev/null 2>&1
        elif ! adb -s "$dispositivo" shell pm list package | grep -qE "^package:${nombre_paquete}$"; then
            echo -e "${RED}Nombre del paquete no detectado. Inténtalo de nuevo.${NC}" >/dev/null
        else
            echo -e "${GREEN}Nombre del paquete detectado:${NC} $nombre_paquete"
            break
        fi

        sleep 0.5
    done

    local actividad_ini_app=$(adb -s "$dispositivo" shell "cmd package resolve-activity --brief $nombre_paquete | tail -n 1")

    if [[ -z "$nombre_paquete" ]]; then
        echo -e "${RED}No se pudo capturar el nombre del paquete. Verifica el estado de ADB y vuelve a intentarlo.${NC}"
        return
    fi

    echo -e "${GREEN}Para abrir la aplicación usando adb${NC}:\n$actividad_ini_app"

    # Captura eventos para detectar el tap prolongado
    adb -s "$dispositivo" shell getevent -lt 2>/dev/null | while read -r line; do
        if [[ "$line" =~ BTN_TOUCH.*DOWN ]]; then
            touch_active=true
            start_time=$(date +%s%7N) # Tiempo inicial en milisegundos
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_X ]]; then
            x_hex=$(echo "$line" | awk '{print $NF}')
            x_coord=$((16#$x_hex))
        fi

        if $touch_active && [[ "$line" =~ ABS_MT_POSITION_Y ]]; then
            y_hex=$(echo "$line" | awk '{print $NF}')
            y_coord=$((16#$y_hex))
        fi

        if [[ "$line" =~ BTN_TOUCH.*UP ]]; then
            end_time=$(date +%s%7N) # Tiempo final en milisegundos
            touch_active=false

            duration=$((end_time - start_time))

            if [[ -n "$x_coord" && -n "$y_coord" ]]; then
                if ((duration >= 1000)); then
                    echo -e "${GREEN}Tap prolongado detectado en:${NC} X=$x_coord, Y=$y_coord (duración: $((duration / 1000)).$((duration % 1000))s)"
                    echo -e "\n${YELLOW}Úsalo asi${NC}:\nadb -s $EMULATOR_ID shell input swipe $x_coord $y_coord $x_coord $y_coord 2000\n"

                    # Detener la captura y salir
                    adb -s "$dispositivo" shell am start -n com.termux/.HomeActivity >/dev/null 2>&1
                    pkill -f getevent
                    break
                else
                    echo -e "${RED}El toque fue demasiado corto (${duration}ms). Intenta de nuevo.${NC}" >/dev/null
                fi
            fi
        fi
    done
}
menu_ver_paquete_app() {
    # Menú principal
    local dispositivo="$1"
    verifica_termux-api "$dispositivo"
    while true; do
        echo -e "${CYAN}MENÚ:${NC}"
        echo -e "${GREEN}01${NC} - Ver paquete de app"
        echo -e "${GREEN}02${NC} - Iniciar aplicación por paquete"
        echo -e "${GREEN}03${NC} - Capturar gesto de swipe de una app"
        echo -e "${GREEN}04${NC} - Tomar coordenadas de tap de una app"
        echo -e "${GREEN}05${NC} - Capturar coordenadas de tap prolongado"
        echo -e "${GREEN}06${NC} - Salir\n"
    
        read -p "Selecciona una opción: " opcion
    
        case $opcion in
            1|01) ver_paquete_app "$dispositivo" ;;
            2|02) iniciar_aplicacion "$dispositivo" ;;
            3|03) capturar_swipe "$dispositivo" ;;
            4|05) tomar_coordenadas "$dispositivo" ;;
            5|05) capturar_tap_prolongado "$dispositivo" ;;
            6|06) echo -e "${BLUE}Saliendo del script. Hasta luego.${NC}\n"; break ;;
            *) echo -e "${RED}Opción inválida. Intenta de nuevo.${NC}" ;;
        esac
    done
}







# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    clear
    echo ""
    echo -e "${GREEN}Dispositivo${NC}: $dispositivo"
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell << 'EOF'
            GREEN='\033[0;32m'
            NC='\033[0m'
            echo -e "${GREEN}[ ${NC}𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ${GREEN}]${NC}"
EOF
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell << 'EOF'
        GREEN='\033[0;32m'
        NC='\033[0m'
        # Mostrar mensaje con colores
        echo -e "${GREEN}[ ${NC}DEVICE: $(getprop ro.product.model) ${GREEN}]${NC}"
        echo -e "${GREEN}[ ${NC}BRAND: $(getprop ro.product.system.brand) ${GREEN}]${NC}"
        echo -e "${GREEN}[ ${NC}MODEL: $(getprop ro.build.product) ${GREEN}]${NC}"
        echo -e "${GREEN}[ ${NC}KERNEL: $(uname -r) ${GREEN}]${NC}"
EOF

    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell << 'EOF'
            GREEN='\033[0;32m'
            NC='\033[0m'
            echo -e "${GREEN}[ ${NC}GPU: $(getprop ro.hardware.gpu) ${GREEN}]${NC}"
EOF
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell << 'EOF'
            gpu_info=$(dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
            GREEN='\033[0;32m'
            NC='\033[0m'
            echo -e "${GREEN}[ ${NC}GPU: ${gpu_info} ${GREEN}]${NC}"            
EOF
    fi

    adb -s "$dispositivo" shell << 'EOF'
        GREEN='\033[0;32m'
        NC='\033[0m'
        echo -e "${GREEN}[ ${NC}CPU: $(getprop ro.hardware) ${GREEN}]${NC}"
        echo -e "${GREEN}[ ${NC}ANDROID VERSION: $(getprop ro.build.version.release) ${GREEN}]${NC}"
        echo -e "${GREEN}[ ${NC}Android ID: $(getprop ro.serialno) ${GREEN}]${NC}"
EOF
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    echo ""
    echo -e "${GREEN}Opciones disponibles${NC}:"
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  
    echo -e "01 - Activar adb permanente"
    echo -e "02 - Ver nombre del paquete de una aplicación"
    echo -e "03 - Deshabilitar aplicación"
    echo -e "04 - Habilitar aplicación"
    echo -e "05 - Multi Deshabilitar apps"
    echo -e "06 - Multi Habilitar apps"
    echo -e "07 - Optimizar (APPS)"
    echo -e "08 - Optimizar (RAM)"
    echo -e "09 - Activar Gráficos Vulkan"
    echo -e "10 - Restablecer Gráficos a OpenGL"
    echo -e "11 - Activar controlador gráfico de juegos"
    echo -e "12 - Mejorar la conexión Wi-Fi"
    echo -e "13 - Restablecer configuración Wi-Fi"
    echo -e "14 - Apagar dispositivo"
    echo -e "15 - Borrar cache (todas-apps)"
    echo -e "16 - Detener aplicaciones"
    echo -e "17 - Volver a seleccionar dispositivo"
    echo -e "18 - Salir"
    printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"  
    echo -en "Seleccione una opción: "
    # Leer opción seleccionada
    read opcion

    case $opcion in
        1|01)
            bash adb_termux/activar_adb_permanete/bash_activar_adb_root_noroot.sh "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        2|02)
            menu_ver_paquete_app "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        3|03)
            deshabilitar_aplicaciones "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        4|04)
            habilitar_aplicaciones "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        5|05)
            multi_disable "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        6|06)
            multi_enable "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        7|07)
            mostrar_menu_optimizar "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        8|08)
            optimizar_ram "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        9|09)
            activar_vulkan "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        10)
            restablecer_opengl "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        11)
            activar_controlador_grafico_juegos "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        12)
            configurar_max_wifi "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        13)
            restablecer_wifi_principal "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        14)
            apagar_dispositivo "$dispositivo"
            # exit 0
            ;;
        15)
            borrar_cache_todas_apps "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        16)
            force_stop_apps "$dispositivo"
            mostrar_menu "$dispositivo"
            ;;
        17)
            seleccionar_dispositivo
            ;;
        18)
            cd ${HOME}/Busca-Palabras/
            bash Menu-Busca-Palabras.sh
            exit 0
            ;;
        *)
            echo "Opción inválida. Intente de nuevo."
            mostrar_menu "$dispositivo"
            ;;
    esac
}

function connect {
    code="$1"
    local capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        print_color green "$(justify_text "Conectando al puerto principal adb. ¡¡¡No cierres las ventanas!!!.\nPor favor, espere...")"
    fi
    
    # Obtener la ip wlan0 si está disponible...
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed  # Asegúrate de importar ambas clases

try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap

# Dirección IP objetivo
ip_objetivo = "$ip_objetivo"
num_threads = 10  # Número de hilos

# Manejo de señales (Ctrl+C y Ctrl+Z)
def signal_handler(signum, frame):
    print("\nEscaneo interrumpido.")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)  # Ctrl+C
signal.signal(signal.SIGTSTP, signal_handler)  # Ctrl+Z

# Función para escanear puertos
def scan_ports(start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    open_ports = []

    # Ajusta el comando con opciones adicionales
    arguments = f'-p {port_range} -Pn -T5 --max-retries 3 --max-rtt-timeout 100ms'

    try:
        # result = nm.scan(ip_objetivo, arguments=f'-p {port_range} -Pn -T4')
        result = nm.scan(ip_objetivo, arguments=arguments)
        if ip_objetivo in result['scan']:
            if 'tcp' in result['scan'][ip_objetivo]:
                for port, details in result['scan'][ip_objetivo]['tcp'].items():
                    if details['state'] == 'open':
                        open_ports.append(port)
    except Exception as e:
        print(f"Error escaneando puertos: {e}")

    return open_ports

# División del rango de puertos
step = (65535 - 10000 + 1) // num_threads
port_ranges = [(i, min(i + step - 1, 65535)) for i in range(10000, 65536, step)]

# Ejecución con hilos
open_ports = []
with ThreadPoolExecutor(max_workers=num_threads) as executor:
    futures = {executor.submit(scan_ports, start, end): (start, end) for start, end in port_ranges}
    for future in as_completed(futures):
        open_ports.extend(future.result())

# Mostrar puertos abiertos
print(" ".join(map(str, sorted(set(open_ports)))))
EOF
)
    # Capturar los puertos disponibles del script python.
    ports_output=$(python -c "$python_script")
    
    # Función para habilitar ADB permanente
    habilitar_adb_permanente() {
        DISPOSITIVO="$1"
        # Verificar si el dispositivo tiene root
        if su -c "id" > /dev/null 2>&1; then
            print_color green "$(justify_text "\n${NC}[${GREEN}Tienes acceso root${NC}].")"
            ROOT_PERMISSIONS="true"
        else
            echo "No tienes acceso root" >/dev/null 2>&1
            ROOT_PERMISSIONS="false"
        fi
        # dar dar a la tabla globa de setedit
        adb -s "${DISPOSITIVO}" shell pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
        if [[ "$ROOT_PERMISSIONS" == "true" ]]; then
            print_color yellow "$(justify_text 'Habilitando ADB permanente con root...')"
            # Estos 2 comandos son los que hacen persistente aún después de reiniciar en el puerto 5555.
            adb -s "$DISPOSITIVO" shell su -c "setprop persist.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "setprop service.adb.tcp.port 5555"
            adb -s "$DISPOSITIVO" shell su -c "resetprop ro.adb.secure 0"
            adb -s "$DISPOSITIVO" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado permanentemente incluso después del reinicio.')"
        else
            print_color yellow "$(justify_text '\nHabilitando ADB temporal (sin root)...')"
            adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
            adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
            print_color green "$(justify_text 'ADB habilitado hasta el próximo reinicio.')"
        fi
    }
    
    # echo "code: $code"
    lista_port_adb=()
    # Si hay puertos disponibles, procesar los de 5 dígitos en una lista...
    if [[ -n "$ports_output" ]]; then
        echo -e "Puertos abiertos detectados:\n$ports_output"
        for port in $ports_output; do
            # Verificar si el puerto es un número de 5 dígitos
            if [[ $port =~ ^[0-9]{5}$ ]]; then
                lista_port_adb+=("$port")
            fi
        done
    fi
    
    # Mostrar todos los puertos almacenados
    # echo -e "\nLista_port_adb:\n${lista_port_adb[@]}"
    
    exito="false"
    # Iterar sobre los puertos en lista_port_adb
    for port in "${lista_port_adb[@]}"; do
        # echo "Procesando puerto: $port"
        # Intentar emparejar, y redireccionar los errore sl vacío.
        adb pair "${ip_objetivo}:${port}" "${code}" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Emparejamiento exitoso con${NC}: $ip_objetivo:$port"
            exito="true"
            port_pair="${port}"
            # Reconstruir la lista sin el puerto que se usó para emparejar...
            lista_port_adb=($(printf "%s\n" "${lista_port_adb[@]}" | grep -v "^$port_pair$"))
            break
        else
            echo -e "Falló el emparejamiento con $ip_objetivo:$port." > /dev/null
            continue
        fi
    done
    
    agilizar() {
    local dispositivo_5555="$1"
        for i in {1..10}; do
            connectar=$(adb connect "${dispositivo_5555}")
            # Rectificar la conexión. Si no está establecida, entonces volver a empareja, sino muestra el menú modificado...
            if [[ "$connectar" == *"connected"* ]]; then
                return
            else
                continue
            fi
            sleep 0.5
        done
        echo -e "${RED}No se pudo conectar a $1 después de 10 intentos.${NC}"
        return
    }

    if [[ "$exito" == 'true' ]]; then
        echo -e "${YELLOW}Conectando adb con el puerto disponible...${NC}"
        for port_connect in "${lista_port_adb[@]}"; do
            # Intentar conectar
            verif_con=$(adb connect "${ip_objetivo}:${port_connect}" 2>/dev/null)
            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}Conexión exitosa con${NC}: ${ip_objetivo}:${port_connect}"
            
                # Intentar reiniciar el modo TCP en el puerto 5555
                if adb -s "${ip_objetivo}:${port_connect}" tcpip 5555 >/dev/null 2>&1; then
                    echo -e "${YELLOW}Reiniciando el modo TCP al puerto 5555...${NC}"
                    # sleep 5  # Esperar para asegurarse de que el dispositivo esté listo.
                    # Intentar conectar al puerto 5555
                    if agilizar "${ip_objetivo}:5555"; then
                        echo -e "${GREEN}Conexión establecida en ${NC}${ip_objetivo}:5555"
                        habilitar_adb_permanente "${ip_objetivo}:5555"
                        adb disconnect "${ip_objetivo}:${port_connect}" >/dev/null 2>&1
                        killall adb >/dev/null 2>&1
                       adb kill-server >/dev/null 2>&1
                       adb start-server >/dev/null 2>&1
    
                       for i in {1..10}; do
                           if adb devices | grep -q "device$"; then
                              break
                           fi
                           sleep 0.5
                        done
                        adb connect "${ip_objetivo}:5555"
                        seleccionar_dispositivo "${ip_objetivo}:5555"
                        exit 0
                    else
                        echo -e "${RED}Fallo al conectar a ${ip_objetivo}:5555.${NC}"
                    fi
                else
                    echo -e "${RED}Error al reiniciar el modo TCP en el puerto 5555.${NC}"
                fi
            else
                echo -e "${RED}Conexión fallida con ${ip_objetivo}:${port_connect}${NC}" > /dev/null
                continue
            fi
            adb disconnect "${ip_objetivo}:${port_connect}" >/dev/null 2>&1
        done
    else
        echo -e "${RED}Falló el emparejamiento.${NC}"
        # Una función que necesita ser llamada antes de su definición
        # echo "Intentando llamar a menu_inicial..."
        menu_principal 2>/dev/null || {
            # echo "La función no está definida aún. Recargando el script..."
            source "$0"
            menu_principal
        }
    fi
    local capp_adb='true'
    connect
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {

    disponible_adb="$1"
    verif_tipo_con >/dev/null
    
    if [ "$disponible_adb" == "false" ]; then
        # Una función que necesita ser llamada antes de su definición
        # echo "Intentando llamar a menu_principal..."
        menu_principal 2>/dev/null || {
            # echo "La función no está definida aún. Recargando el script..."
            source "$0"
            menu_principal
        }
    fi
    
    # Obtener la IP de wlan0, si está disponible
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    
    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
    if [ -z "$ip" ]; then
        sleep 1
        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi
    
    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    
    # Elegir entre el emulador o la ip si hay alguno.
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip}:)" | head -n 1)
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$connected_devices"
    fi
 
    # Título e instrucciones justificados
    print_color red "$(justify_text 'Servidor adb, no encendido!!!')"
    print_color green "$(justify_text 'Siga las instrucciones:')"
    # Instrucciones para habilitar depuración USB
    print_color cyan "$(justify_text "Habilitar la depuración USB en Android, para hacer conexión adb${NC}:")"
    print_color yellow "$(justify_text "${GREEN}1${NC}.$(generate_spaces 1)${YELLOW}Abre la aplicación ${NC}[${GREEN}Configuración${NC}] ${YELLOW}en tu dispositivo Android${NC}.")"
    print_color yellow "$(justify_text "${GREEN}2${NC}. ${YELLOW}Ve a${NC} [${GREEN}Acerca del teléfono${NC} o ${GREEN}de la tablet${NC}].")"
    print_color yellow "$(justify_text "${GREEN}3${NC}.  ${YELLOW}Toca repetidamente${NC} [${GREEN}Número de compilación${NC}] ${YELLOW}hasta que se active el modo de desarrollador${NC}.")"
    print_color yellow "$(justify_text "${GREEN}4${NC}. ${YELLOW}Regresa al menú principal de [${GREEN}Configuración${NC}], ${YELLOW}busca y entra en${NC}: [${GREEN}Sistema${NC}].")"
    print_color yellow "$(justify_text "${GREEN}5${NC}. ${YELLOW} Ahora da click en: [${GREEN}Opciones avanzadas${NC}] ${YELLOW}y entra en [${GREEN}Opciones para desarrolladores${NC}].")"
    print_color yellow "$(justify_text "${GREEN}6${NC}. ${YELLOW}Habilita ${NC}[${GREEN}Depuración por USB${NC}].")"
    # Instrucciones para depuración inalámbrica
    print_color cyan "$(justify_text "Si solo necesitas que se active en tu Android, activa Depuración inalámbrica y entra${NC}.")"
    print_color yellow "$(justify_text "${GREEN}7${NC}. ${YELLOW}Selecciona donde dice${NC}:")"
    print_color green "$(justify_text " Vincular dispositivo con código de sincronización${NC}")"
    print_color yellow "$(justify_text "  Selecciona ahora en:${NC}")"
    print_color green "$(justify_text "   Vincular con dispositivo${NC}")"
    print_color blue "$(justify_text "    Código de vinculación de WI-FI${NC}: ${RED}123456${NC}")"
    print_color blue "$(justify_text "    Dirección IP y PUERTO${NC}: ${GREEN}${ip}${NC}:${MAGENTA}12345")"
    # Nota adicional
    print_color cyan "$(justify_text "Para hacer la conexión correctamente:")"
    print_color yellow "$(justify_text "Habilita la pantalla dividida entre la ventana: ${NC}(${BLUE}Depuración inalámbrica${NC}) ${YELLOW}y la ventana de ${NC}(${BLUE}Termux${NC}).")"
    # Final
    print_color green "$(justify_text "¡Sigue estos pasos para activar el servidor adb correctamente!")"
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    
    echo -en "\n${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
    read code
    echo -en "${NC}"
    while [[ ! "${code}" =~ ^[0-9]{6}$ ]]; do
        echo -e "\n${RED}Error${NC}: Debes ingresar un código válido de 6 dígitos."
        echo -en "${YELLOW}Ingrese código de vinculación WI-FI${NC}: ${RED}"
        read code
        echo -en "${NC}"
    done
    
    # Cambios Dom 19/Ene/2025
    # Ejecutar emparejamiento y conexión...
    connect "${code}"
}

wlan0() {
    adb_conectado="$1"
    # echo "adb_conectado_wlan0: $adb_conectado"
    # Obtener la IP de wlan0, si está disponible
    ip0=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Si no se encuentra IP en wlan0, buscar una IP distinta que no sea 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
    fi
    # Mostrar la IP de wlan0 si está disponible...
    if [ "$ip0" ]; then
        disponible_adb='true'
        adb_conectado='false'
        return
    fi
    # Mostrar otra IP si no se encontró en wlan0...
    if [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}):\n${YELLOW}ip: ${NC}$ip1" #  > /dev/null
        disponible_adb='false'
        adb_conectado='false'
        return
    fi
    # echo "disponible_adb: $disponible_adb"
}
verif_adb_conect() {
        
    # Capturar la ip del modem si acaso esta disponible...
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Obtener los dispositivos conectados por ADB.
    adb_output=$(adb devices -l)
    # echo $adb_output
    connected_devices=$(echo "$adb_output" | awk -v ip="$ip" '$2 == "device" {print $1}')
    # echo -e "\nDispositivos conectados:\n$connected_devices"

    # echo $connected_devices
    if [[ -n "$ip" ]]; then
        # Mostrar la IP local
        echo -e "\nIP local: $ip" > /dev/null
    fi

    # Buscar si hay un dispositivo con la ip: o el emulador-5554.
    ip_device=$(echo "$connected_devices" | grep -Ei "${ip}:[0-9]+|emulator-5554" | head -n 1)
    # echo "adb_conectado_ip_device: $ip_device"
    adb_conectado="${ip_device}"
    # Verificar, si se encontró algún dispositivo es porque $ip_device no esta vacia.
    if [[ -n "$ip_device" ]]; then
        # echo -e "${GREEN}Dispositivo conectado a adb 1${NC}: $ip_device"
        disponible_adb='false'
        adb_conectado="${ip_device}"
        adb_conectado_ip_device="${ip_device}"
        return 
    else
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0 "$adb_conectado"
    fi
}
#verif_adb_conect

verif_ip_externa() {
    proceso_ip_externa='false'
    TEMP_FILE=$(mktemp) # Archivo temporal para almacenar la salida de curl
    TIMEOUT=5 # Tiempo máximo en segundos para que curl termine

    # Ejecutar curl en segundo plano
    curl -s ipinfo.io/ip > "$TEMP_FILE" &
    CURL_PID=$! # Capturar el PID del proceso curl

    # Esperar a que curl termine con un tiempo límite
    SECONDS=0
    while kill -0 $CURL_PID 2>/dev/null; do
        if [[ $SECONDS -ge $TIMEOUT ]]; then
            echo -en "\nTimeout. ip externa curl 'PID: ($CURL_PID)'..."
            x=''
            kill -9 $CURL_PID 2>/dev/null
            rm -f "$TEMP_FILE"
            return 1
        fi
        sleep 0.5
    done

    # Verificar si curl se ejecutó correctamente
    wait $CURL_PID
    if [ $? -ne 0 ]; then
        echo "Error: curl no se ejecutó correctamente." >/dev/null
        rm -f "$TEMP_FILE"
        return 1
    fi

    proceso_ip_externa='true'
    echo "Curl se ejecutó correctamente." >/dev/null

    no_ip='<html><head><title>302 Found</title></head><body><h1>302 Found</h1><p>The document has moved <a href="https://mi.tigo.com.co/assets/captive.html?utm_source=captiveportal">here</a></p></body></html>'

    # Verificar si se captura la IP en 5 intentos
    for ((i=1; i<=1; i++)); do
        x=$(cat "$TEMP_FILE") # Leer la salida del archivo temporal

        if [[ -n "$x" && "$x" != "$no_ip" ]]; then
            echo "IP externa capturada: $x" >/dev/null
            rm -f "$TEMP_FILE" # Limpiar archivo temporal
            return 0
        else
            echo "Intento $i/5 fallido. Reintentando en 0.5 segundos..." >/dev/null
            sleep 0.5
        fi
    done

    # Si no se capturó una IP válida
    echo "No se pudo capturar una IP válida después de 5 intentos." >/dev/null
    rm -f "$TEMP_FILE" # Limpiar archivo temporal
    return 1
}
# Función para verificar el tipo tipo de conexión...
verif_tipo_con() {
        # variable que verifica adb
        disponible_adb="false"
        # variable que verifica internet 
        conect_internet="false"
        # variable que verifica modem
        disponible_modem="false"
        ##############INICIO INTERFAZ################
        # Función para obtener la IP de una interfaz
        obtener_ip() {
            local interfaz=$1
            busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
        }
        
        # Comprobamos primero si wlan0 está disponible.
        iplocal=$(obtener_ip "wlan0")
        echo "$iplocal"
        # Si no hay IP en wlan0, buscar en otras interfaces activas.
        if [ -z "$iplocal" ]; then
            echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null
            # Iterar sobre las interfaces activas y capturar la primera IP disponible.
            for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                iplocal=$(obtener_ip "$interfaz")
                ip=$(obtener_ip "$interfaz")
                # Si no capturó una interfaz, el bucle for sigue iterando.
                if [ ! -z "$iplocal" ]; then
                    # Si capturó una interfaz, detiene el bucle for.
                    echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null
                    break
                fi
            done
        else
            # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular).
            echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null
        fi
        # Si después de todas las comprobaciones no hay IP disponible
        if [ -z "$iplocal" ]; then
            echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null
        else
            ip="$iplocal"
        fi
        ############## FIN INTERFAZ################
        # echo "final: $iplocal"
        # Verificar si hay conexión externa (Internet)
        # x=$(curl -s ifconfig.me)
        verif_ip_externa >/dev/null
        ipexterna=$(echo "${x//[<>]/}")
        ipexterna=$(echo "${x}")

        ###########Zona WiFi Comprobar#########
        iplocalc=".${iplocal}"
        iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
        
        # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            if [[ "$iplocal" == "127.0.0.1" ]]; then
                echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                    ip=$(obtener_ip "$interfaz")
                    if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                        echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null
                        break
                    fi
                done
            else
                echo "Conexión a Internet activa. IP local: $ip" > /dev/null
            fi
        else
            ip="$iplocal"
            echo "No hay conexión a Internet." > /dev/null
        fi

        ###########Zona WiFi Fin#########
        
        #echo "Bienvenido"
        wlan0_verif='false'    
        # Verificar el estado de wlan0 usando ifconfig
        es_wlan0=$(busybox ifconfig wlan0 2>/dev/null)
        if echo "${es_wlan0}" | grep -q "RUNNING" && echo "${es_wlan0}" | grep -q "inet "; then
            # echo "wlan0_verif: true"
            wlan0_verif='true'
            echo "wlan0 conectada a modem" > /dev/null 2>&1
        elif echo "${es_wlan0}" | grep -q "RUNNING"; then
            #echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        else
            # echo "wlan0_verif: false"
            wlan0_verif='false'
            echo "wlan0 no está activa" > /dev/null 2>&1
        fi
        
        # echo "ip $ip"
        # echo "iplocal: $iplocal"
        # echo "iplocalc: $iplocal"
        # echo "ipexterna: $ipexterna"
        # Si no está conectado a una red externa.
        if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
            ipexterna="html"
            disponible_modem="true"
            conect_internet="false"
            disponible_adb='false'
            echo -e "\n${RED}No hay conexión wi-fi, datos ni ${NC}(${RED}zona wi-fi${NC})${nc}...\n" # > /dev/null 2>&1
            adb_conectado="$adb_conectado_ip_device"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi
  
        
        # Hay internet datos
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ ! "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Tienes internet para compartir datos por ${NC}(${GREEN}zona wi-fi${NC}).\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="true"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
                # read -n 1 -p "Presione cualquier tecla para continuar!"
        fi
        
        # No hay internet pero está la zona wi-fi activa.
        if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "\n${GREEN}Conexion por ${NC}(${GREEN}Zona WI-FI${NC}) ${GREEN}y no tienes internet,\npero puedes otorgar conexión${NC}.\n" # >/dev/null 2>&1
                disponible_modem="true"
                disponible_adb='false'
                conect_internet="false"
                print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
        
        # Verificar si ipexterna contiene una dirección IP válida.
        # Tienes datos de internet y la zona wi-fi activa.
        if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
            echo -e "\n${GREEN}Tienes datos de internet y la ${NC}(${GREEN}zona wi-fi${NC}) ${GREEN}activa${NC}.\n(${GREEN}Compartiendo datos${NC})\n"
            disponible_modem="true"
            disponible_adb="false"
            adb_conectado="$adb_conectado_ip_device"
            conect_internet="true"
            print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi
        
    if [[ "$disponible_modem" == "false" ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo -e "\n${GREEN}Tienes internet wi-fi del Módem${NC}.\n" # >/dev/null 2>&1
        conect_internet="true"
        disponible_adb="true"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
    fi
    
    # No hay internet pero estás conectado a modem.
    if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
        echo -e "\n${GREEN}No hay internet pero estás conectado al Módem${NC}.\n" # >/dev/null 2>&1
        disponible_modem="true"
        disponible_adb='true'
        conect_internet="false"
        print_color yellow "$(justify_text "Dirección ip: ${NC}$ip")"
        fi 
        
    # echo "disponible_adb: $disponible_adb"
    # echo "conect_internet: $conect_internet"
}
# verif_tipo_con
menu_principal() {
    limpiar_variables() {
        # Limpiar las varibles
        if [[ "$disponible_adb" == 'true' && "$adb_conectado" == 'false' ]]; then
            adb_conectado=''
        elif [[ "$disponible_adb" == 'false' && "$adb_conectado" == 'false' ]]; then
            adb_conectado=''
        fi
        # Limpiar la variable que contiene si acaso un dispositivo adb conectado...
        adb_conectado_ip_device=""
    }
    while true; do
        # arreglar el input read de bash cuando no ingresa nada y no borra
        # Configurar correctamente el terminal para manejar retroceso y teclas especiales
        stty erase $(tput kbs)
        stty sane
    
        verif_adb_conect
        # echo "Bienvenido"
        verif_tipo_con >/dev/null
        # Capturar la ip del modem si acaso esta disponible...
        ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
        # Obtener los dispositivos conectados por ADB
        adb_output=$(adb devices -l)
        connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
        # Buscar si hay un dispositivo con la IP o el emulador
        ip_device=$(echo "$connected_devices" | grep -Ei "${ip}:[0-9]+|emulator-5554" | head -n 1)
        # echo "$adb_output"

        # Verificar si se encontró algún dispositivo
        if [[ -n "$ip_device" ]]; then
            seleccionar_dispositivo "$ip_device"
        fi
        if [ "$disponible_adb" == 'false' ]; then
            echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            sleep 5
            cd ~/Busca-Palabras
            bash Menu-Busca-Palabras.sh
            exit
        elif [ "$disponible_adb" == 'true' ]; then     
            echo -e "\n${YELLOW}La dirección IP de wlan0 es${NC}: $ip0"
            echo -e "${GREEN}Disponible para conectar adb${NC}"
            # echo -e "\n${CYAN}Menú Principal${NC}"
            echo -e "${YELLOW}01. ${GREEN}Conectar adb${NC}"
            echo -e "${YELLOW}02. ${GREEN}Salir${NC}"
            echo -e "|"
            echo -en "--> "
        fi
        read eleccion
        case $eleccion in
        1|01)
             if [ "$disponible_adb" == 'true' ]; then
                 solicitar_emparejamiento
             fi
             ;;
        2|02)
            echo "Saliendo..."
            cd ~/Busca-Palabras
            bash Menu-Busca-Palabras.sh
            exit 0
             ;;
        *)
            echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
            ;;
        esac
        limpiar_variables
    done
}

menu_principal
