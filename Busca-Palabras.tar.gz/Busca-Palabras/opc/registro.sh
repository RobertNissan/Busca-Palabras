#!/bin/bash
while true
do
clear
echo -e ""
echo -e "   Registro de encendido mobile"
echo -en "${verde}+----------------------------------+
# [${blanco}01${verde}] | ${blanco}instalar registro            ${verde}#
#----------------------------------#
# [${blanco}02${verde}] | ${blanco}ver registro                 ${verde}#
#----------------------------------#
# [${blanco}03${verde}] | ${blanco}Eliminar registro            ${verde}#
#----------------------------------#
# [${blanco}04${verde}] | ${blanco}Volver al menu principal     ${verde}#
+----------------------------------+
|
+->>> ${blanco}"
read -r ins
case $ins in

      1|01)
if [ -f $PREFIX/bin/wget ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e ""
echo "Instalando wget"
pkg install wget -y >/dev/null 2>&1
fi

echo -e ""
echo "Para que el registro se active cada
vez que encienda el celular, debes
tener instalado temux-boot, ahora
verificaremos si esta instalado,
sino, procederemos a instalarlo!!!"
echo -e ""
echo "instala termux-api para conceder
permisos de instalacion de aplicaciones"
read -n 1 -p "Presione para proceder con termux-api"
termux-open https://play.google.com/store/apps/details?id=com.termux.api
clear
read -n 1 -p "Presione para proceder con termux-boot" 
if [ -e ${HOME}/termux-boot.apk ]; then 
echo -e ""
echo termux-boot
echo "Ya esta descargado"
sleep 2
xdg-open ${HOME}/termux-boot.apk
clear
echo -e ""
echo "Recuerde quitar la optimizacion
de bateria a termux-boot en los
ajustes de la aplicacion."
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar"
else
echo -e ""
echo "Preparando para instalar termux-boot"
cd ${HOME};wget https://www.dropbox.com/s/p6bm6zagctmzdmq/termux-boot-6-47687702-7.apk?dl=0;mv termux-boot-6-47687702-7.apk?dl=0 termux-boot.apk;xdg-open ${HOME}/termux-boot.apk;clear;echo -e "";echo "Recuerde quitar la optimizacion
de bateria a termux-boot en los
ajustes de la aplicacion.";echo -e "";read -n 1 -p "Presione cualquier tecla para continuar"
fi
clear
mkdir -p ${HOME}/.termux/boot/
#cp -r reg.sh ${HOME}/.termux/boot/
cp -r active.sh ${HOME}/.termux/boot/
echo -e ""
echo "El registro.log de encendido te dira
a que hora fue encendido tu celular.
Este archivo se encuentra en home/
con el nombre de registros.log
"
echo "Recuerde quitar la optimizacion
de bateria a termux-boot en los
ajustes de la aplicacion.
Ahora proceda a reiniciar el celular"
;;

      2|02) dia=$(date +"%A");if [ $dia = Monday ]; then d=$(echo Lunes);elif [ $dia = Tuesday ]; then d=$(echo Martes);elif [ $dia = Wednesday ]; then d=$(echo Miercoles);elif [ $dia = Thursday ]; then d=$(echo Jueves);elif [ $dia = Friday ]; then d=$(echo Viernes);elif [ $dia = Saturday ]; then d=$(echo Sabado);elif [ $dia = Sunday ]; then d=$(echo Domingo);fi;mes=$(date +"%B");if [ $mes = January ]; then m=$(echo Enero);elif [ $mes = February ]; then m=$(echo Febrero);elif [ $mes = March ]; then m=$(echo Marzo);elif [ $mes = April ]; then m=$(echo Abril);elif [ $mes = May ]; then m=$(echo Mayo);elif [ $mes = June ]; then m=$(echo Junio);elif [ $mes = July ]; then m=$(echo Julio);elif [ $mes = August ]; then m=$(echo Agosto);elif [ $mes = September ]; then m=$(echo Septiembre);elif [ $mes = October ]; then m=$(echo Octubre);elif [ $mes = November ]; then m=$(echo Noviembre);elif [ $mes = December ]; then m=$(echo Diciembre);fi;
act=$(date +%d)
if [ -e /data/data/com.termux/files/home/registros.log ]; then
sca="$(grep -E "$act de $m" ~/registros.log | head -n 1)"
fi
TODAY=$(date +"Hoy $d, %d de $m")
if [ "$sca" == "$TODAY" ]; then
clear
cat ${HOME}/registros.log
exit
fi

if [ -e ~/registros.log ]; then
#echo "Archivo esta en home"
echo "seguimos" >/dev/null 2>&1
else
clear
echo -e ""
echo "Aun no hay registro de encendido
o el archivo a sido eliminado
Reinicie su celular y vuelva a comprobar"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
bash ${HOME}/Busca-Palabras/opc/registro.sh
exit
fi    

# si el hoy, es de hace 1 dia
ahoy=$(date +'%d' -d "-1 days")
abm="$(grep -E "$ahoy de $m" ~/registros.log | head -n 1)"
ada="$(echo "$abm" | cut -d' ' -f2)"
ama="$(echo "$abm" | cut -d' ' -f5)"
afai="$(date +'Hoy %A, %d de %B' -d "-1 days")"
aop="$(echo "$afai" | cut -d' ' -f2)"
apo="$(echo "$afai" | cut -d' ' -f5)"
aes="$(echo -en "$afai" | sed "s/$aop/$ada/g")"
aesm="$(echo -en "$aes" | sed "s/$apo/$ama/g")"
if [ "$abm" == "$aesm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/Anteayer/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/Ayer/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
clear
cat ${HOME}/registros.log
exit
fi

# si Hoy es de hace dos dias
bhoy=$(date +'%d' -d "-2 days")
bbm="$(grep -E "$bhoy de $m" ~/registros.log | head -n 1)"
bda="$(echo "$bbm" | cut -d' ' -f2)"
bma="$(echo "$bbm" | cut -d' ' -f5)"
bfai="$(date +'Hoy %A, %d de %B' -d "-2 days")"
bop="$(echo "$bfai" | cut -d' ' -f2)"
bpo="$(echo "$bfai" | cut -d' ' -f5)"
bes="$(echo -en "$bfai" | sed "s/$bop/$bda/g")"
besm="$(echo -en "$bes" | sed "s/$bpo/$bma/g")"
if [ "$bbm" == "$besm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/Anteayer/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
clear
cat ${HOME}/registros.log
exit
fi

#recueda que el for debe contar hasta 28 o si no puede causar repeticion

#luego el ayer de hace 1 dia
yhoy=$(date +'%d' -d "-1 days")
ybm="$(grep -E "$yhoy de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-1 days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
TODAY=$(date +"Hoy $d, %d de $m")
if [ "$ybm" == "$yesm" ]; then
TIMENOW=$(date +"A las %r - %Y")
clear
cat ${HOME}/registros.log
exit
fi

#luego el ayer de hace dos dias
any=$(date +'%d' -d "-2 days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-2 days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
TODAY=$(date +"Hoy $d, %d de $m")
if [ "$ybm" == "$yesm" ]; then
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/Anteayer/g'
clear
cat ${HOME}/registros.log
exit
fi

#luego el Anteayer de hace 2 dias
any=$(date +'%d' -d "-2 days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Anteayer %A, %d de %B' -d "-2 days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
if [ "$ybm" == "$yesm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
clear
cat ${HOME}/registros.log
exit
fi

#si el hoy es de hace 3 dia o mas
for a in $(seq 3 28); do
clear
echo -e ""
echo "Escaneando fechas antiguas"
hoy=$(date +'%d' -d "-"$a" days")
bm="$(grep -E "$hoy de $m" ~/registros.log | head -n 1)"
da="$(echo "$bm" | cut -d' ' -f2)"
ma="$(echo "$bm" | cut -d' ' -f5)"
fai="$(date +'Hoy %A, %d de %B' -d "-"$a" days")"
op="$(echo "$fai" | cut -d' ' -f2)"
po="$(echo "$fai" | cut -d' ' -f5)"
es="$(echo -en "$fai" | sed "s/$op/$da/g")"
esm="$(echo -en "$es" | sed "s/$po/$ma/g")"
if [ "$bm" == "$esm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/El/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
clear
cat ${HOME}/registros.log
exit
fi
done

#Y el ayer de hace 3 dias o mas
for b in $(seq 3 28); do
clear
echo -e ""
echo "Escaneando fechas antiguas"
any=$(date +'%d' -d "-"$b" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-"$b" days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
TODAY=$(date +"Hoy $d, %d de $m")
if [ "$ybm" == "$yesm" ]; then
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
clear
cat ${HOME}/registros.log
exit
fi
done

#Y luego el Anteayer de hace 3 dias o mas 
for c in $(seq 3 28); do
clear
echo -e ""
echo "Escaneando fechas antiguas"
any=$(date +'%d' -d "-"$c" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Anteayer %A, %d de %B' -d "-"$c" days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
if [ "$ybm" == "$yesm" ]; then
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
clear
cat ${HOME}/registros.log
break
fi
done

#Solo El
for d in $(seq 3 28); do
clear
echo -e ""
echo "Escaneando fechas antiguas"
any=$(date +'%d' -d "-"$d" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'El %A, %d de %B' -d "-"$d" days")"
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
if [ "$ybm" == "$yesm" ]; then
TIMENOW=$(date +"A las %r - %Y")
clear
cat ${HOME}/registros.log
break
fi
done 
;;


      3|03) echo -e ""
      read -p "Desea eliminar el registro? " NS
      if [[ "$NS" == "s" || "$NS" == "S" ]]; then
      if [ -e ~/registros.log ]; then
      rm -r ${HOME}/registros.log
      sleep 2
      echo "Registro eliminado"
      sleep 2
      fi
      echo -e ""
      echo "Aun no hay registro de encendido
o el archivo a sido eliminado
Reinicie su celular y vuelva a comprobar"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
      bash ${HOME}/Busca-Palabras/opc/registro.sh
      exit
      fi
      
     if [[ "$NS" == "n" || "$NS" == "N" ]]; then
      echo "Conservando registro"
      sleep 2
      bash ${HOME}/Busca-Palabras/opc/registro.sh
      exit
     fi
   
     if [[ "$NS" != "n" || "$NS" != "N" ]]; then
      echo "Opcion invalida"
      sleep 2
     fi
;;

      4|04)
cd ..
bash Menu-Busca-Palabras.sh
exit
;;


      *) echo "opcion invalida";sleep 1;clear
;;

esac
done
exit