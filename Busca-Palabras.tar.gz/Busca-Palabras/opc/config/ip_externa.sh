#!/bin/bash

# Obtener información de la IP externa
info=$(curl -s ipinfo.io)

# Extraer la organización (org) y la IP
org=$(echo "$info" | grep -oP '(?<="org": ")[^"]+')
ip=$(echo "$info" | grep -oP '(?<="ip": ")[^"]+')

# Verificar si es conexión móvil o Wi-Fi
if [[ "$org" == *"Telmex"* || "$org" == *"Claro"* || "$org" == *"Cable"* || \
      "$org" == *"Movistar"* || "$org" == *"Tigo"* || "$org" == *"ETB"* || \
      "$org" == *"VTR"* || "$org" == *"HughesNet"* || "$org" == *"Megacable"* || \
      "$org" == *"DirecTV"* || "$org" == *"Entel"* || "$org" == *"CNT"* || \
      "$org" == *"Virgin"* || "$org" == *"Telefónica"* || "$org" == *"Inter"* || \
      "$org" == *"Fibertel"* || "$org" == *"Redes"* || "$org" == *"Wi-Fi"* || \
      "$org" == *"ISP"* || "$org" == *"Broadband"* ]]; then
    tipo_conexion="Wi-Fi (Módem/Router)"
else
    tipo_conexion="Datos móviles"
fi

# Mostrar resultados
echo "IP externa: $ip"
echo "Organización: $org"
echo "Tipo de conexión: $tipo_conexion"
