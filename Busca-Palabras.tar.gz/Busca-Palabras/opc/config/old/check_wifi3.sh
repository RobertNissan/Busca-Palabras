clear 
# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
exit
fi
fi 


if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo "No tiene conexion wifi!"
echo -e ""
else 
echo "Si hay wifi"
fi
