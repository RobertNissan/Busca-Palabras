#!/bin/bash 

sw=a
while [ "$sw" = "a" ]; do
clear
echo "Revisando conexion"
# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl -s ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
exit
fi
fi 

if [ "$iplocal" == "127.0.0.1" ]; then 
#ipexterna="html"
clear
echo -e "No tiene conexion wifi o hostpot!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active la ${rojo}zona wifi (hostpot)${blanco}" 
echo "vuelva a intentar!"
sleep 2
exit
sw=a
else
if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo "datos sin Internet"
exit
else 
echo "Si hay wifi"
exit 
fi
fi
done