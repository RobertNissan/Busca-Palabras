clear 
# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
#echo $ip
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
if [ "$iplocalc" == "192" ]; then 
ipexterna="${iplocal}"
fi

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo "No tiene conexion wifi!"
echo -e ""
else 
echo si hay wifi 
fi
