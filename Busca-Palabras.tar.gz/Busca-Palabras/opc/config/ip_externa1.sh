#!/bin/bash

# Obtener información de la IP externa
info=$(curl -s ipinfo.io)

# Extraer la organización (org) y la IP
org=$(echo "$info" | grep -oP '(?<="org": ")[^"]+')
ip=$(echo "$info" | grep -oP '(?<="ip": ")[^"]+')

# Verificar si es conexión móvil o Wi-Fi
if [[ "$org" == *"Telmex"* || "$org" == *"Claro"* || "$org" == *"Cable"* ]]; then
    tipo_conexion="Wi-Fi (Módem/Router)"
else
    tipo_conexion="Datos móviles"
fi

# Mostrar resultados
echo "IP externa: $ip"
echo "Organización: $org"
echo "Tipo de conexión: $tipo_conexion"
