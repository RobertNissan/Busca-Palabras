#!/bin/bash 

# verificar conección a internet o wifi avanzado

sw=a
while [ "$sw" = "a" ]; do
    clear
    echo "Revisando conexion"
    # Buscando la ip Android con wifi activado
    v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
    iplocal=$(echo ${v%%/*})
    # x=$(curl -s ifconfig.me)
    x=$(curl -s ipinfo.io/ip)
    ipexterna=$(echo "${x//[<>]/}")
    ipexterna=$(echo "${x}")
    echo -e ""

    clear
    #Si esta en modo avion!
    if [ "$iplocal" == "127.0.0.1" ]; then 
        ipexterna="html"
    fi
    
    iplocalc=".${iplocal}"
    iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
    
    if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
        if [ "$iplocalc" == "192" ]; then 
            echo "Conexion por Zona WI-FI" # >/dev/null 2>&1
            read
            exit
        fi
    fi 
    
    if [[ "$ipexterna" = "" ]]; then 
        if [ "$iplocalc" == "192" ]; then 
            echo "Conexion por Zona WI-FI" # >/dev/null 2>&1
            exit
        fi
    fi 
    
    if [ "$iplocal" == "127.0.0.1" ]; then 
        clear
        echo -e "No tiene conexion externa!"
        exit
    else
    
        if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
            echo "datos sin Internet"
            sleep 1
            v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
            ip=$(echo ${v%%/*})
            exit
        else 
            echo "Conexion por via Internet" # >/dev/null 2>&1
            exit
        fi
    fi 

done
