#!/bin/bash

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

cx=connection
awh=wifihost
wh=$(grep -E "$cx=" ~/Busca-Palabras/opc/acceso_ftp_python.sh | head -n 1)
#whe=$(echo "${wh##*=}")
#echo $whe
if [ "$wh" = "connection=wifihost" ]; then
echo -e "wifihost existe" >/dev/null 2>&1
else
sed -i "s%$wh%$cx=$awh%g" ~/Busca-Palabras/opc/acceso_ftp_python.sh
fi
clear
while true
do
#Matar el script http.server 8024 en segundo plano
kill=$(ps aux | grep 'http.server 8024' | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1
clear
echo -e ""
echo -e -n "            ${verde} Elige una opcion"
echo -e -n "${verde}
+---------------------------------------+
# ["$blanco"01"$verde"] | "$blanco"Acceso-ftp-python ${verde}|${blanco}HOME|SD|MSD ${verde}#
#---------------------------------------#
# ["$blanco"02"$verde"] | "$blanco"Acceso-http-python${verde}|${blanco}HOME|SD|MSD ${verde}#
#---------------------------------------#
# ["${blanco}"03"${verde}"] | "$blanco"Chat-python   ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# ["${blanco}"04"${verde}"] | "$blanco"Ngrok Forward ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# ["${blanco}"05"${verde}"] | "$blanco"Loclx Forward ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# ["${blanco}"06"${verde}"] | "$blanco"Nginx Forward ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# ["${blanco}"07"${verde}"] | "$blanco"TLSSH Forward ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# ["${blanco}"08"${verde}"] | "$blanco"Clfld Forward ${verde}|${blanco}ANDROID${verde}|${blanco}WINDOWS ${verde}#
#---------------------------------------#
# [${blanco}09${verde}] | ${blanco}Volver al menu                 ${verde}#
+---------------------------------------+
|
+->>> "${blanco}
read -r text
cd ${HOME}
echo -e ""
case $text in
      
1|01)
cd ~/Busca-Palabras/opc/
bash acceso_ftp_python.sh
cd ~/Busca-Palabras/opc/
bash acceso_local_remoto.sh
break
;;

2|02)
bash ~/Busca-Palabras/opc/acceso_http_python.sh
cd ~/Busca-Palabras/opc/
bash acceso_local_remoto.sh
break
;;

3|03)
bash ~/Busca-Palabras/opc/chat_python.sh
bash ~/Busca-Palabras/opc/acceso_local_remoto.sh
break 
;;

4|04)
cd ~/Busca-Palabras/opc/Ngrok/
bash ngrok_menu.sh
break
;;

5|05)
cd ~/Busca-Palabras/opc/Ngrok/
bash loclx_menu.sh
break
;;

6|06)
cd ~/Busca-Palabras/opc/Ngrok/termux_nginx
bash nginx.sh
bash ~/Busca-Palabras/opc/acceso_local_remoto.sh
break
;;

7|07)
cd ${HOME}/Busca-Palabras/opc/Ngrok/termux_tlssh/
bash tlssh.sh
break
;;

8|08)
cd ${HOME}/Busca-Palabras/opc/Ngrok/
bash clfld_menu.sh
break
;;

9|09)
cd ${HOME}/Busca-Palabras/
bash Menu-Busca-Palabras.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
