#!/bin/bash
#Codigo para centrar texto "nota: no funciona como super usuario este codigo, error tput
print_center(){
    local x
    local y
    text="$*"
    x=$(( ($(tput cols) - ${#text}) / 2))
    echo -ne "\E[6n";read -sdR y; y=$(echo -ne "${y#*[}" | cut -d';' -f1)
    echo -ne "\033[${y};${x}f$*"
}

PWD=$(pwd)
HOME=$(pwd)
echo "elija la ruta donde escanear"
echo "[1] Interna /sdcard/"
echo -e "[2] Externa /sdcard/"
read -p "> " esd
if [ "$esd" == "1" ]; then 
disco="/sdcard"
eval cd $disco
fi
if [ "$esd" == "2" ]; then 
if [ -f /storage/sdext/.micro ]; then
disco=sdext
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
echo -e ""
echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r disco
clear
while [ -z "$disco" ]; do
clear
echo -e ""
    echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r disco
done
fi

UserDir="$(echo /storage/"$disco"/)"
eval cd "$UserDir"
x="$(echo $PWD)"
tez=/storage/$disco

if [ "$x" == "$tez" ]; then
UserDir="$(echo /storage/$disco/)"
eval cd "$UserDir"
touch /storage/$disco/.$disco
#No modificar las lineas 11 y 12 de este script!
A=$(grep -EIris "/storage/sdext/.micro" ${HOME}/findscan.sh | head -n 1)
B=$(echo "$A" | cut -d' ' -f4)
sed -i "s%$B%/storage/$disco/.$disco%g" ${HOME}/findscan.sh
#No modificar las lineas 11 y 12 de este script!
C=$(grep -EIris "disco=sdext" ${HOME}/findscan.sh | head -n 1)
sed -i "s%$C%disco=$disco%g" ${HOME}/findscan.sh
else
clear
echo -e ""
echo "Busque bien el nombre de su SDCARD EXTERNA"
read
exit
fi
fi
echo -e ""
clear
echo -e ""Elegiste la externa sdcard-"\e[1;34m"$disco"\e[0m"

eval cd "$PWD"
rl="$PWD/"
rm -rf dirr.txt
rm -rf dirr2.txt
rm -rf dirrc.txt
rm -rf dirra.txt
rm -rf dirrar.txt 
rm -rf dirrarc.txt 
rm -rf dirrcar.txt 
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi
#eliminar los 4 ultimos caracteres
#sed -i".bak" "s/....$//p" arq
screenfetch >> ${PWD}/adq.txt
ndc=$(sed -n "5p" ~/adq.txt | cut -c 94- | sed "s/....$//g") 
#eliminar estos simbolos ()[]^,.:;\* 
ndc=$(echo "${ndc//[()\[\]\^,.:;\\*]/}")
#reemplazar los espacio entre palabras por guion _
ndc=$(echo "${ndc//[ ]/_}")
echo $ndc
#tigres="Un (tigre), dos tigres, tres tigres"
#echo "${tigres//[()]/_}" 
rm -r ${PWD}/adq.txt
clear 
echo "$rl"
echo "Escriba el nombre del archivo a buscar"
read -p "> " nombre
nombre=$(sed 's|/|\\.|g' <<<"$nombre")
echo "Escriba la extension (.ext) del archivo"
read -p "> " ext
ext=$(echo "${ext//[()\[\]\^,\.:;\\*]/}")

if [ -z "${ext}" ]; then 
echo "ok" >/dev/null 2>&1
else
ext=".$ext"
fi
if [ -z "${nombre}" ]; then 
#si la variable no empieza por un punto y luego letras, entonces repite
while [[ ! "${ext}" =~ ^[\.][a-zA-Z] ]]; do 
clear
echo "Escriba si quiera la extension del archivo a buscar"
read -p "> " ext
done
fi
echo -e "Buscando $nombre$ext\n"
#find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
find -path ./Android -prune -o -type f -iname "*$nombre*${ext}" -print | cut -c 3- > dirr.txt
find -path ./Android -prune -o -type d -iname "*$nombre*${ext}" -print | cut -c 3- >> dirr.txt
find -maxdepth 1 -type f -size 0b -iname "dirr.txt" -print0 | xargs -0I file rm -v file >/dev/null 2>&1
if [ -f dirr.txt ]; then 
echo -e "Mostrando lista con $nombre$ext\n"
grep -En "." dirr.txt
else
echo "No se encuentra $nombre$ext" 
read -n 1 -p "Presione cualquier tecla para volver al menu"
clear
cd ${HOME}/ 
bash findscan.sh
fi
#cat dirr.txt
echo -e ""
read 
port="22"
#--------------------------------------------------------------------------#

 
#Windows 
if [ "$port" == "22" ]; then
#--------------------------------------------------------------------------#
DD=1
while [ "$DD" == 1 ]; do
clear
DD="1"
if [[ "$DD" =~ "1" ]]; then 
rm -rf .userpc1984 >/dev/null 2>&1
# wd=$(cat .userpc1984)
rm -rf .userpc1984 >/dev/null 2>&1
x=$(echo -e "C:/Users/$wd/")
CPC=$(sed 's/\//\\/g' <<<"$x")
#echo "$CPC"
xyz=$DD
PCC=$(echo -e "C:/Users/$wd/")
fi
if [[ "$DD" =~ "2" ]]; then 
CPC="D:\\"
echo "$CPC"
PCC="D:/"
xyz=$DD
fi
if [[ "$DD" =~ "3" ]]; then 
bash ~/Busca-Palabras/opc/lista-server.sh
exit
fi
if [ -z "$DD" ]; then
rm -rf .userpc1984 >/dev/null 2>&1
dos2unix .userpc1984 >/dev/null 2>&1
#wd=$(cat .userpc1984)
rm -rf .userpc1984 >/dev/null 2>&1
x=$(echo -e "C:/Users/$wd/")
CPC=$(sed 's/\//\\/g' <<<"$x")
#echo "$CPC"
xyz=$DD
PCC=$(echo -e "C:/Users/$wd/")
fi

DD=y
if [[ "y" == "$DD" ]]; then 
echo -e ""
else
clear
echo -e "La ruta remota no existe"
sleep 2
DD=1
fi
done


#--------------------------------------------------------------------------#

echo -e 'Organizando las carpetas!\nPor favor espere\n'
nu=$(grep -En "." dirr.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do 
c=$(sed -n "${i}p" dirr.txt)
x=$(echo "${c%/*}")
y=$(echo "${c}")
x=$(echo "${c}")
if [ -d "${c}" ]; then
echo "${c}/" >> dirrc.txt
else
if [ ! "$x" = "$y" ]; then
echo "${c}/" >> dirra.txt
else
c=$(echo "${rl}${c}")
echo "${c%/*}/" >> dirra.txt 
fi
fi
done
if [ -f dirra.txt ]; then
awk '!seen[$0]++' dirra.txt > dirrar.txt
rm -rf dirra.txt
fi
echo -e ""



nye="$nombre"
if [ -z "$nombre" ]; then 
nye="\\$ext" 
fi
if [ -f dirrar.txt ]; then
if [ -f dirrc.txt ]; then
#echo "inicio de dirrar y dirrc"
echo "separando las carpetas con nombre $nombre"
echo "separando las carpetas que contienen archivos con nombre:
$nombre"
rl="$rl"
nu=$(grep -En "." dirrar.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do
clear
echo "Organizando las carpetas"
cd
eval cd "${rl}"
c=$(sed -n "${i}p" dirrar.txt | sed "s%${rl}%%")
echo -e "" 
IFS='
'
fe=$(grep -E "$c" dirrc.txt | tail -n 1)
nmb=$(grep -iE "$nye" dirrar.txt | tail -n 1 | sed "s%${rl}%%")
if [ -z "$nmb" ]; then 
echo "ok" >/dev/null 2>&1 
else
nnmb=$(grep -niE "$nye" dirrar.txt | tail -n 1)
bmnn=$(echo "${nnmb%:*}")
#echo "linea a borrar del archivo: dirrar.txt"
#echo $bmnn
#read
echo "$nmb" >> dirrc.txt 
sed -i "${bmnn}d" dirrar.txt 
#Elimina archivo de nombre dirra.txt si esta vacio!
#en carpeta actual 
find -maxdepth 1 -type f -size 0b -iname "dirrar.txt" -print0 | xargs -0I file rm -v file >/dev/null 2>&1
if [ -f dirrar.txt ]; then
cat dirrar.txt > dirrarc.txt
#anadir una linea en blanco al inicio de un archivo de texto 
ed -s dirrar.txt <<< $'1i\n\n.\nwq'
let suma=$num+1
sed -i "${suma}d" dirrar.txt 
qi=$(sed -n "${i}p" dirrar.txt | grep -o "$c")
qi=$(grep -o "$qi" dirrar.txt | tail -n 1)
echo -e ""
ik=$(grep -n "$qi" dirrar.txt)
ki=$(echo "${ik%:*}")
echo -e ""
fi
if [ -z "$c" ]; then 
rm -rf dirrar.txt
break
fi
if [ -f dirrar.txt ]; then
if [ "$c" == "$fe" ]; then
#echo "linea a borrar del archivo dirrar.txt:" 
#echo "$c"  
nmb=$(grep -E "$nye" dirrar.txt | tail -n 1)
sed -i "${i}d" dirrar.txt 
cat dirrar.txt > dirrarc.txt
ed -s dirrar.txt <<< $'1i\n\n.\nwq'
let suma=$num+1
sed -i "${suma}d" dirrar.txt 
fi
fi
fi
done
fi
fi

echo -e ""
echo -e "Aqui mostramos carpetas que tienen el nombre:\n${nombre}${ext}\nY carpetas que contienen el archivo con nombre:\n${nombre}${ext}\n"
if [ -f dirrar.txt ]; then 
mv dirrar.txt dirrarc.txt
sed -i '/^$/d' dirrarc.txt >/dev/null 2>&1
rm -rf dirrar.txt
cat dirrarc.txt
sleep 2
fi
if [ -f dirrc.txt ]; then 
awk '!seen[$0]++' dirrc.txt > dirrcar.txt
rm -rf dirrc.txt 
echo "dirrcar"
cat dirrcar.txt
echo -e "" 
fi
if [ -f dirra.txt ]; then 
cat dirra.txt
sleep 2
fi 



if [ -f dirrcar.txt ]; then
echo -e ""
echo -e "inicio de carpetas\ncuyo nombre tiene:\n${nombre}${ext}"
sleep 1
rl="$rl"
nu=$(grep -En "." dirrcar.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for x in $(seq 1 $num); do
cd
eval cd "${rl}"
c=$(sed -n "${x}p" dirrcar.txt)
echo -e ""
#x=$(echo "$PWD" | sed 's_\s_\\\ _g')
dir=$(echo "${c}")
wd=$(echo "$dir" | sed '1 s|^|"|' | sed '1 s|$|"|') 
wd=$(echo "${wd}" | sed 's/\//\\/g')
bin=$(echo "${c}" | sed 's/\//\\/g')
print_center '------------------------------------------------'

#echo "Cargando archivo/s de la ruta:" 
#ruta=$(echo "$c" | sed 's_\s_\\\ _g')
ruta=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
eval cd "${ruta}"
#echo "aqui estoy"
#pwd 
#echo -e ""
#find -maxdepth 1 -type f -iname "*" | cut -c 3- > .arch1984
IFS='
'
find  -maxdepth 1 -not -name .arch1984 -type f -iname "*" | cut -c 3- > .arch1984
#find -path ./Android -prune -o -type f -iname "*" -print | ls -p | grep -v / > .arch1984
#echo arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
#read 
home=$(cat .arch1984)
home=$(grep -En "." .arch1984)
rm -rf .arch1984
#c=$(echo "${c//[(tm)*]/}")
#wd=$(echo "${bin//[\(tm)*]/}")
wd=$(echo "$bin" | sed '1 s|^|"|' | sed '1 s|$|"|') 
rutl=$(echo $ndc\\${wd} | wc -m) 
if [[ "$rutl" -gt "223" ]]; then
#muestra los que esta despues del ultimo delimitador
#echo "/storage/16EB-3564/mp3/Metal/Avalanch - Llanto De Un Heroe/" | awk -F "/" '/^\// {print $(NF-1)}'
c=$(echo "$c" | sed 's_\s_\__g')
wd=$(echo "$wd" | sed 's_\s_\__g')
nombrex=$(echo "/$c" | awk -F "/" '/^\// {print $(NF-1)}')
c=$nombrex
wd=$nombrex
else
echo ok >/dev/null 2>&1
fi
if [ "$(ls -pA | grep -v /)" ]; then
echo -e ""
#echo "Transfiriendo todos los archivos de la ruta:"
pwd
rutdes=$(echo "${PCC}${ndc}/${c}") 
echo "$home"
print_center '------------------------------------------------'
echo -e ""
read
else
echo -e ""
pwd
    echo "No hay archivos en esa carpeta!"
print_center '------------------------------------------------'
echo -e ""
    sleep 2 
fi
done
if [ -f dirrar.txt ]; then
sed -i '/^$/d' dirrar.txt
fi
cd
eval cd "${rl}"
rm -rf dirrcar.txt
fi


sed -i '/^$/d' dirrarc.txt >/dev/null 2>&1 
find -maxdepth 1 -type f -size 0b -iname "dirrarc.txt" -print0 | xargs -0I file rm -v file >/dev/null 2>&1
if [ -f dirrarc.txt ]; then
echo -e ""
echo -e "inicio de archivos\ncuyo nombre tiene:\n${nombre}${ext}\n"
sed -i '/^$/d' dirrarc.txt
nu=$(grep -En "." dirrarc.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do
cd
eval cd "${rl}"
rlx=$(sed -n "${i}p" dirrarc.txt)
c=$(sed -n "${i}p" dirrarc.txt | sed "s%${rl}%%")
if [ "$rlx" == "$rl" ]; then 
c=$rl
fi
#ruta=$(echo "$c" | sed 's_\s_\\\ _g')
ruta=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
eval cd "${ruta}"
PWD=$(pwd)
print_center '------------------------------------------------'
x=$(echo "$PWD" | sed 's_\s_\\\ _g')
#bin=$(echo "${c}" | sed 's/\//\\/g')
dir=$(echo "${c}")
wd=$(echo "$dir" | sed '1 s|^|"|' | sed '1 s|$|"|') 
wd=$(echo "${wd}" | sed 's/\//\\/g')
bin=$(echo "${c}" | sed 's/\//\\/g')
IFS='
'
if [ -z "$nombre" ]; then 
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
else
#si es solo nombre
if [ -z "${ext}" ]; then 
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
#rda=$(echo -e "Transfiriendo los archivos de nombre:\n${nombre}\nde la ruta:\n$rl$c\n")
else
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|B|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi

fi
fi
home=$(cat .arch1984)
home=$(grep -En "." .arch1984)
rm -rf .arch1984
wd=$(echo "$bin" | sed '1 s|^|"|' | sed '1 s|$|"|') 
rutl=$(echo $ndc\\${wd} | wc -m) 
if [[ "$rutl" -gt "223" ]]; then
c=$(echo "$c" | sed 's_\s_\__g')
wd=$(echo "$wd" | sed 's_\s_\__g')
nombrex=$(echo "/$c" | awk -F "/" '/^\// {print $(NF-1)}')
c=$nombrex
wd=$nombrex
else
echo ok >/dev/null 2>&1
#echo ok
fi
if [ "$(ls -pA | grep -v /)" ]; then
echo -e ""
pwd
echo "$home"
print_center '------------------------------------------------'
echo -e ""
read
else
echo -e ""
pwd
    echo "No hay archivos en esa carpeta!"
print_center '------------------------------------------------'
echo -e ""
    sleep 2 
fi 
done
cd
eval cd "${rl}"
rm -rf dirr.txt
rm -rf dirr2.txt
rm -rf dirrc.txt
rm -rf dirra.txt
rm -rf dirrar.txt 
rm -rf dirrarc.txt 
rm -rf dirrcar.txt 
echo -e ""
read -n 1 -p "Presione cualquier tecla para volver al menu"
cd
exit
fi
fi


# Android 
if [ "$port" == "8022" ]; then
#----------------------------------------------------------------------------#
DD=1
while [ "$DD" == 1 ]; do
clear
echo -e ""
echo "Transferir archivos al servidor"
echo "$active"
echo -e ""
rut=$(echo "${ruta}"  | xargs echo -n)
  rut="${rut// /_}"
echo "Android"
echo "[1] Destino /home/"
echo "[2] Destino /sdcard/"
echo -e "[3] Volver al menu\n"
echo -e "Elija el disco destino!!!" 
read -p "> " DD
#rutdes=$(echo "$rutdes" | sed '1 s|^|"|' | sed '1 s|$|"|')
if [[ "$DD" =~ "1" ]]; then 
DD="/data/data/com.termux/files/home"
fi
if [[ "$DD" =~ "2" ]]; then 
DD=/sdcard
fi
if [[ "$DD" =~ "3" ]]; then 
bash ~/Busca-Palabras/opc/lista-server.sh
exit
fi
if [ -z "$DD" ]; then
DD=/data/data/com.termux/files/home
fi
c=$(echo "$DD" | sed '1 s|^|"|' | sed '1 s|$|"|') 
#verificar la existencia del disco remoto ssh
#ssh -p "$port" "$active" "echo 'if [[ -d $c ]]; then echo "existe";else echo "no existe";fi' > ~/existe.sh"
#res=$(ssh -p "$port" "$active" bash existe.sh)
res=existe
if [ "$res" == "existe" ]; then 
echo -e ""
c=$(echo "$DD" | sed '1 s|^||' | sed '1 s|$||') 
else 
clear
echo -e ""
echo "Transferir archivos al servidor"
echo "$active"
echo -e ""
rut=$(echo "${ruta}"  | xargs echo -n)
  rut="${rut// /_}"
echo "Android"
echo "[1] Destino /home/"
echo "[2] Destino /sdcard/"
echo -e "[3] Volver al menu\n"
echo -e "Elija la ruta destino!!!" 
echo -e "La ruta remota no existe"
sleep 2
DD=1
fi
done
#----------------------------------------------------------------------------#

echo -e 'Organizando las carpetas!\nPor favor espere\n'
nu=$(grep -En "." dirr.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do 
c=$(sed -n "${i}p" dirr.txt)
x=$(echo "${c%/*}")
y=$(echo "${c}")
x=$(echo "${c}")
if [ -d "${c}" ]; then
echo "${c}/" >> dirrc.txt
else
if [ ! "$x" = "$y" ]; then
echo "${c}/" >> dirra.txt
else
c=$(echo "${rl}${c}")
echo "${c%/*}/" >> dirra.txt 
fi
fi
done
if [ -f dirra.txt ]; then
awk '!seen[$0]++' dirra.txt > dirrar.txt
fi
echo -e ""

nye="$nombre"
if [ -z "$nombre" ]; then 
nye="\\$ext" 
fi
if [ -f dirrar.txt ]; then
if [ -f dirrc.txt ]; then
#echo "inicio de dirrar y dirrc"
echo "separando las carpetas con nombre $nombre"
echo "separando las carpetas que contienen archivos con nombre:
$nombre"
rl="$rl"
nu=$(grep -En "." dirrar.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do
clear
echo -e ""
echo "Transferir archivos al servidor"
echo "$active"
echo -e ""
rut=$(echo "${ruta}"  | xargs echo -n)
  rut="${rut// /_}"
echo "Windows"
echo "[1] Destino Usuario/"
echo "[2] Destino D:/"
echo "[3] Volver al menu"
echo -e ""
echo -e "Elija la ruta destino!!!" 
echo "> " $xyz
cd
eval cd "${rl}"
c=$(sed -n "${i}p" dirrar.txt | sed "s%${rl}%%")
#echo "de dirrar"
#echo "$c"
echo -e "" 
#read 
IFS='
'
fe=$(grep -E "$c" dirrc.txt | tail -n 1)
nmb=$(grep -iE "$nye" dirrar.txt | tail -n 1 | sed "s%${rl}%%")
#echo nmb
#echo $nmb
#read 
if [ -z "$nmb" ]; then 
echo "ok" >/dev/null 2>&1 
else
nnmb=$(grep -niE "$nye" dirrar.txt | tail -n 1)
bmnn=$(echo "${nnmb%:*}")
#echo "linea a borrar del archivo: dirrar.txt"
#echo $bmnn
#read
echo "$nmb" >> dirrc.txt 
sed -i "${bmnn}d" dirrar.txt 
#Elimina archivo de nombre dirra.txt si esta vacio!
#en carpeta actual 
find -maxdepth 1 -type f -size 0b -iname "dirrar.txt" -print0 | xargs -0I file rm -v file >/dev/null 2>&1
if [ -f dirrar.txt ]; then
cat dirrar.txt > dirrarc.txt
#anadir una linea en blanco al inicio de un archivo de texto 
ed -s dirrar.txt <<< $'1i\n\n.\nwq'
let suma=$num+1
sed -i "${suma}d" dirrar.txt 
#cat dirrar.txt | wc -l
#read
#qi=$(grep -w "$c" dirrar.txt)
qi=$(sed -n "${i}p" dirrar.txt | grep -o "$c")
qi=$(grep -o "$qi" dirrar.txt | tail -n 1)
#clear
#echo $qi 
echo -e ""
ik=$(grep -n "$qi" dirrar.txt)
ki=$(echo "${ik%:*}")
#echo $ki 
echo -e ""
#echo "si $c = $fe"
#sleep 1
#read
fi
if [ -z "$c" ]; then 
rm -rf dirrar.txt
break
fi
if [ -f dirrar.txt ]; then
if [ "$c" == "$fe" ]; then
echo -e ""
echo "linea a borrar del archivo dirrar.txt:" 
echo "$c"  
nmb=$(grep -E "$nye" dirrar.txt | tail -n 1)
#read 
#sed -i "${ki}d" dirrar.txt
sed -i "${i}d" dirrar.txt 
cat dirrar.txt > dirrarc.txt
ed -s dirrar.txt <<< $'1i\n\n.\nwq'
let suma=$num+1
sed -i "${suma}d" dirrar.txt 
#cat dirrar.txt | wc -l
#read
fi
fi
fi
done
fi
fi

echo -e ""
echo -e "Aqui mostramos carpetas que tienen el nombre:\n${nombre}${ext}\nY carpetas que contienen el archivo con nombre:\n${nombre}${ext}\n"
if [ -f dirrar.txt ]; then 
mv dirrar.txt dirrarc.txt
sed -i '/^$/d' dirrarc.txt >/dev/null 2>&1
rm -rf dirrar.txt
cat dirrarc.txt
sleep 2
fi
if [ -f dirrc.txt ]; then 
awk '!seen[$0]++' dirrc.txt > dirrcar.txt
rm -rf dirrc.txt 
echo "dirrcar"
cat dirrcar.txt
echo -e "" 
fi
if [ -f dirra.txt ]; then 
cat dirra.txt
sleep 2
fi 

echo -e ""
echo -e "inicio de todos los archivos\nque estan dentro cuya carpeta tiene nombre:\n$nombre"
sleep 1
if [ -f dirrcar.txt ]; then
rl="$rl"
nu=$(grep -En "." dirrcar.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for x in $(seq 1 $num); do
cd
eval cd "${rl}"
c=$(sed -n "${x}p" dirrcar.txt)
#echo "de dirrcar"
#echo "$c"
echo -e ""
echo -e ""
#x=$(echo "$PWD" | sed 's_\s_\\\ _g')
dir=$(echo "${c}")
wd=$(echo "$dir" | sed '1 s|^|"|' | sed '1 s|$|"|') 
#wd=$(echo "${wd}" | sed 's/\//\\/g')
#bin=$(echo "${c}" | sed 's/\//\\/g')
print_center '------------------------------------------------'
#echo -e ""
#echo "Cargando archivo/s de la ruta:" 
#ruta=$(echo "$c" | sed 's_\s_\\\ _g')
ruta=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
eval cd "${ruta}"
#echo "aqui estoy"
#pwd 
#find -maxdepth 1 -type f -iname "*" | cut -c 3- > .arch1984
IFS='
'
find -path ./Android -prune -o -type f -iname "*" -print | ls -p | grep -v / > .arch1984
#echo arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
#read 
home=$(cat .arch1984)
home=$(grep -En "." .arch1984)
rm -rf .arch1984
wd=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
if [ "$(ls -pA | grep -v /)" ]; then
echo -e ""
#echo "Transfiriendo todos los archivos de la ruta:"
pwd
#echo -e "hacia:"
rutdes=$(echo "${DD}/${ndc}/${c}") 
print_center '------------------------------------------------'
echo -e ""
else
pwd
    echo "No hay archivos en esa carpeta!"
print_center '------------------------------------------------'
echo -e ""
    sleep 2 
fi
done
if [ -f dirrar.txt ]; then
sed -i '/^$/d' dirrar.txt
fi
cd
eval cd "${rl}"
#cat dirrcar.txt
#cat dirrar.txt
rm -rf dirrcar.txt
#rm -rf dirrar.txt
fi
#echo "fin dirrcar"
#read 


sed -i '/^$/d' dirrarc.txt >/dev/null 2>&1 
find -maxdepth 1 -type f -size 0b -iname "dirrarc.txt" -print0 | xargs -0I file rm -v file >/dev/null 2>&1
#read 
if [ -f dirrarc.txt ]; then
echo -e ""
echo -e "inicio de los de archivo/s\ncuyo nombre tiene:\n${nombre}${ext}\n"
sed -i '/^$/d' dirrarc.txt
#awk '!seen[$0]++' dirrac.txt > dirrarc.txt
nu=$(grep -En "." dirrarc.txt | tail -n 1)
num=$(echo "${nu%%:*}")
for i in $(seq 1 $num); do
cd
eval cd "${rl}"
rlx=$(sed -n "${i}p" dirrarc.txt)
c=$(sed -n "${i}p" dirrarc.txt | sed "s%${rl}%%")
echo -e ""
echo -e ""
if [ "$rlx" == "$rl" ]; then 
c=$rl
fi
#ruta=$(echo "$c" | sed 's_\s_\\\ _g')
ruta=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
eval cd "${ruta}"
PWD=$(pwd)
print_center '------------------------------------------------'
#echo -e ""
#echo "Cargando archivo/s de la ruta:" 
#pwd
x=$(echo "$PWD" | sed 's_\s_\\\ _g')
#bin=$(echo "${c}" | sed 's/\//\\/g')
dir=$(echo "${c}")
wd=$(echo "$dir" | sed '1 s|^|"|' | sed '1 s|$|"|') 
#wd=$(echo "${wd}" | sed 's/\//\\/g')
#bin=$(echo "${c}" | sed 's/\//\\/g')
IFS='
'
#si es solo ext
if [ -z "$nombre" ]; then 
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
#rda=$(echo -e "Transfiriendo los archivos de nombre:\n${ext}\nde la ruta$rl$c\n")
else
#si es solo nombre
if [ -z "$ext" ]; then 
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
rda=$(echo -e "Transfiriendo archivo/s de nombre:\n${nombre}\nde la ruta$rl$c\n")
else
find -maxdepth 1 -not -iname .arch1984 -type f -iname "*$nombre*$ext" | cut -c 3- > .arch1984
nl=$(grep -Eino "a|B|D|g|G|l||n|o|r|T" .arch1984 | tail -n 1)
nl=$(echo "${nl%:*}")
narc=$(sed -n "${nl}p" .arch1984)
le=$(grep -Eio "a|B|D|g|G|l|n|o|r|T" .arch1984 | tail -n 1)
if [[ "$le" == "a" || "$le" == "B" || "$le" == "D" || "$le" == "g" || "$le" == "G" || "$le" == "l" || "$le" == "n" || "$le" == "o" || "$le" == "r" || "$le" == "T" ]]; then
sed -i 's/D/d/g; s/r/r/g; s/a/a/g; s/g/g/g; s/o/o/g; s/n/n/g; s/l/l/g; s/B/b/g; s/G/g/g; s/T/t/g' .arch1984
narcn=$(sed -n "${nl}p" .arch1984) 
mv "$narc" "$narcn"
fi
rda=$(echo -e "Transfiriendo los archivos de nombre y extension:\n${nombre}${ext}\nde la ruta$rl$c\n")
fi
fi
home=$(cat .arch1984)
home=$(grep -En "." .arch1984)
rm -rf .arch1984
wd=$(echo "$c" | sed '1 s|^|"|' | sed '1 s|$|"|') 
if [ "$(ls -pA | grep -v /)" ]; then
echo -e ""
pwd
rutdes=$(echo "${DD}/${ndc}/${c}") 
print_center '------------------------------------------------'
echo -e ""
else
pwd
    echo "No hay archivos en esa carpeta!"
print_center '------------------------------------------------'
echo -e ""
    sleep 2 
fi 
done
fi
fi
#echo "fin de dirrarc.txt"
cd
eval cd "${rl}"
rm -rf dirr.txt
rm -rf dirr2.txt
rm -rf dirrc.txt
rm -rf dirra.txt
rm -rf dirrar.txt 
rm -rf dirrarc.txt 
rm -rf dirrcar.txt 
cd
echo -e ""
read -n 1 -p "Presione cualquier tecla para volver al menu"

# Il
