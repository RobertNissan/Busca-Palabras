clear
while true
do
if [ -f $PREFIX/bin/git ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando wget"
pkg install git >/dev/null 2>&1
fi 
echo -e ""
echo -e "        Dibujo Y animacion Mod"
echo -e "   Elige la version para tu Android "
echo -e "${verde}+------------------------------------+"
echo -e "# [${blanco}01${verde}] | ${blanco}IbisPaint v10.0.2           ${verde}#"
echo -e "#------------------------------------#"
echo -e "# [${blanco}02${verde}] | ${blanco}FlipaClip v3.1.23.1.2       ${verde}#"
echo -e "#------------------------------------#"
echo -e "# [${blanco}03${verde}] | ${blanco}ClipStudioPaint v1.12.7     ${verde}#"
echo -e "#------------------------------------#"
echo -e "# [${blanco}04${verde}] | ${blanco}Volver al menu app premium  ${verde}#"
echo -e "+------------------------------------+"
echo -en "|"
echo -en "+->>> ${blanco}"
read -r text
cd ${HOME}
echo -e ""
case $text in

1|01)
echo -e ""
if [ -e ${HOME}/Ibis_Paint_mod_v10.1.5.1001030019.apk ]; then
echo "ibis Paint X v10.1.5.1001030019 MOD"
echo "Ya esta descargado"
sleep 2
xdg-open Ibis_Paint_mod_v10.1.5.1001030019.apk
bash ${HOME}/Busca-Palabras/opc/dibujo-animacion.sh
break
clear
else
echo -e ""
echo "Descargando ibis Paint X v10.1.5.1001030019 MOD"
echo -e ""
cd ${HOME};git clone https://github.com/RobertNissan/ibispaint
unzip ibispaint/Ibis_Paint_mod_v10.1.5.1001030019.zip -d ~/ 
rm -rf ibispaint
xdg-open Ibis_Paint_mod_v10.1.5.1001030019.apk
echo -e ""
clear
fi
;;

2|02)
echo -e ""
if [ -e ${HOME}/flipaclip.create.2d.animation.mod.v3.1.23.1.2.apk ]; then
echo "FlipaClip v3.1.23.1.2"
echo "Ya esta descargado"
sleep 2
xdg-open flipaclip.create.2d.animation.mod.v3.1.23.1.2.apk
bash ${HOME}/Busca-Palabras/opc/dibujo-animacion.sh
break
clear
else
echo -e ""
echo "Descargando FlipaClip v3.1.23.1.2"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/2pcnuffbzx1xl33/flipaclip.create.2d.animation.mod.v3.1.23.1.2.apk
xdg-open flipaclip.create.2d.animation.mod.v3.1.23.1.2.apk;
echo -e ""
clear
fi
;;

3|03)
echo -e ""
if [ -e ${HOME}/clip_studio_paint_1.12.7.apk ]; then
echo "Clip Studio Paint v1.12.7"
echo "Ya esta descargado"
sleep 2
xdg-open clip_studio_paint_1.12.7.apk
bash ${HOME}/Busca-Palabras/opc/dibujo-animacion.sh
break
clear
else
echo -e ""
echo "Descargando Clip Studio Paint v1.12.7"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/9iej515jr30jnvs/clip_studio_paint_1.12.7.apk
xdg-open clip_studio_paint_1.12.7.apk;
echo -e ""
clear
fi
;;

4|04)
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
