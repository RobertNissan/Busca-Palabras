while true
do
clear
echo -e ""
echo "config tasker dime nombre"
echo "[1] Pefil"
echo -e "[2] Tarea\n"
echo "config autoresponder"
echo "[3] Pefil"
echo -e "[4] Volver al menu anterior"

read -r config
cd ${HOME}
echo -e ""
case $config in

1|01)
xdg-open /storage/emulated/0/config_remiten_task/config_individual/dime_nombre.prj.xml
bash ${HOME}/Busca-Palabras/opc/config-ta.sh
exit
;;

2|02)
xdg-open /storage/emulated/0/config_remiten_task/config_individual/decir.tsk.xml
bash ${HOME}/Busca-Palabras/opc/config-ta.sh
exit
;;

3|03)
xdg-open /storage/emulated/0/config_remiten_task/config_individual/AutoResponder_WA_Rules_1670552851.csv
bash ${HOME}/Busca-Palabras/opc/config-ta.sh
exit
;;

4|04)
bash Busca-Palabras/opc/tasker-bot.sh
exit
;;

*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
