while true; do
    rojo='\e[1m\e[31m'
    white="\e[1;37m\e[0m"
    cd ${HOME}/ 
    clear
    #Elimina todo los archivos vacios bash
    # find -type f -size 0b -print0 | xargs -0I file rm -v file >/dev/null 2>&1
    find . -type f -size 0 -exec rm -v {} + >/dev/null 2>&1
    echo -e "              ${rojo}${blanco}Servidores-termux"
    echo -e "${verde}+------------------------------------------+"
    echo -e "#[${blanco}01${verde}] ${blanco}Acceder a un nuevo servidor          ${verde}#"
    echo -e "#[${blanco}02${verde}] ${blanco}Crear acceso sin contrasenas         ${verde}#"
    echo -e "#[${blanco}03${verde}] ${blanco}Acceder a un servidor de la lista    ${verde}#"
    echo -e "#[${blanco}04${verde}] ${blanco}Transferir archivos a un servidor    ${verde}#"
    echo -e "#[${blanco}05${verde}] ${blanco}Scanner transfer archivos a servidor ${verde}#"
    echo -e "#[${blanco}06${verde}] ${blanco}Borrar un servidor                   ${verde}#"
    echo -e "#[${blanco}07${verde}] ${blanco}Ver Servidores Creado                ${verde}#"
    echo -e "#[${blanco}08${verde}] ${blanco}Ver Mi Servidor                      ${verde}#"
    echo -e "#------------------------------------------#"
    echo -e "#[${blanco}09${verde}] ${blanco}Volver al menu OpenSSH               ${verde}#"
    echo -e "+------------------------------------------+${blanco}\n"
    r=$(echo -e "$rojo")
    b=$(echo -e "$blanco\n")
    read -p 'Selecciona lo que deseas hacer! > ' id
    case $id in
        1|01)
            port=a 
            # Bucle while
            while [ "$port" = "a" ]; do
                clear
                echo -e ""
                echo -e "Acceder a un nuevo servidor"
                echo -e "Escriba..." 
                read -p "Puerto del servidor a agregar > " port
                if [[ $port =~ ^[0-9]+$ ]] && (($port >= 10 && $port <= 65535)); then
                    echo "Puerto valido"
               else
                   clear
                   # echo "Numero fuera del rango, vuelva a intentarlo"
                   echo -e ""
                   echo -e "Acceder a un nuevo servidor"
                   echo -e "Escriba..." 
                   echo "Puerto del servidor a agregar > Escribe un puerto valido" 
                   sleep 2
                   port=a
               fi
            done

            clear
            echo -e ""
            echo "Acceder a un nuevo servidor"
            echo "Escriba..." 
            echo "Puerto del servidor a agregar > $port"
            echo -e "Puerto valido\n"
            read -p "Nombre de usuario del servidor a agregar > " usr
            while [ -z "$usr" ]; do
              clear
              echo -e ""
              echo "Acceder a un nuevo servidor"
              echo "Escriba..." 
              echo "Puerto del servidor a agregar > $port"
              echo -e "Puerto valido\n"
              read -p "Nombre de usuario del servidor a agregar > " usr
            done


            echo -e ""
            ip=1
            # Bucle while
            while [ "$ip" = "1" ]; do
                clear
                echo -e ""
                echo -e "Acceder a un nuevo servidor"
                echo -e "Escriba..." 
                echo "Puerto del servidor a agregar > $port"
                echo -e "Puerto valido\n"
                echo -e "Nombre de usuario del servidor a agregar > $usr\n"
                echo -en "Escribe la ip del servidor a agregar > "
                pattern_ngrok='^[0-9]+\.tcp\.ngrok\.io$'
                read ip
                # if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
                if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]] || [[ $ip =~ $pattern_ngrok ]]; then
                    echo "La ip es correcta"
                else
                    clear
                    echo -e ""
                    echo -e "Acceder a un nuevo servidor"
                    echo -e "Escriba..." 
                    echo "Puerto del servidor a agregar > $port"
                    echo -e "Puerto valido\n"
                    echo -e "Nombre de usuario del servidor a agregar > $usr\n"
                    echo "Escribe una IP valida"
                    echo "Ejemplo: 192.168.1.1"
                    sleep 2
                    ip=1
                fi
            done
            
            if [ -e ~/.ssh/known_hosts ]; then
                echo "existe" >/dev/null 2>&1
                #clear
                nu=$(grep -En "." ~/.ssh/known_hosts | tail -n 1)
                num=$(echo "${nu%%:*}")
                #echo ""$num" Llaves de los servidores en la lista" 
                ipkh=$(grep -o "$ip" ~/.ssh/known_hosts | tail -n 1) 
                if [ "$ip" == "$ipkh" ]; then
                    for var in $(seq 1 "$num"); do
                        ik=$(sed -n "${var}p" ~/.ssh/known_hosts | grep -o "$ip")
                        #echo "si $ip = $ik" 
                        #read 
                        if [ "$ip" == "$ik" ]; then
                            sed -i "/$ik/d" ~/.ssh/known_hosts
                            #echo "Borrada la linea $var"
                            #read
                        fi
                    done
                    sed -i '/^$/d' ~/.ssh/known_hosts  
                fi
                #else
                #echo "No hay similitud de llaves"
                #sleep 3
            fi
    
            echo -e ""
            echo "Vas a acceder al servidor"
            echo -e "ssh -p $port $usr@$ip\n"
            read -p "Es correcto Si/No " sn
            while [ -z "$sn" ]; do
                clear
                echo -e ""
                echo "Acceder a un nuevo servidor"
                echo "Escriba..." 
                echo "Puerto del servidor a agregar > $port"
                echo -e "Puerto valido\n"
                echo -e "Nombre de usuario del servidor a agregar > $usr\n"
                echo "Escribe la ip del servidor a agregar > $ip"
                echo -e "La ip es correcta\n"
                echo "Vas a acceder al servidor"
                echo -e "ssh -p $port $usr@$ip\n"
                read -p "Es correcto Si/No " sn 
            done
    
            if [[ "$sn" == "s" || "$sn" == "S" || "$sn" == "si" || "$sn" == "Si" || "$sn" == "sI" || "$sn" == "SI" ]]; then
                server=$(echo "ssh -p $port $usr@$ip")
                inserver="ssh -p $port $usr@$ip"
                if [ -e ~/Busca-Palabras/opc/.usr ]; then
                    #buscame la ultima linea de texto
                    nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
                    #Ahora solo muestrame la parte que se encuentra antes de los dos puntos (:)
                    num=$(echo "${nu%%:*}")
                    echo -e ""
                    for var in $(seq 1 "$num"); do
                        C=$(grep -Ein "." ~/Busca-Palabras/opc/.usr)
                        n=$(grep -wn "$C" ~/Busca-Palabras/opc/.usr | cut -c 1)
                        #muestrame la linea numero $var
                        ver=$(sed -n ""$var"p" ~/Busca-Palabras/opc/.usr)
                        if [ "$server" == "$ver" ]; then
                            sed -i ""$var"d" ~/Busca-Palabras/opc/.usr
                            sed -i '/^$/d' ~/Busca-Palabras/opc/.usr #elimina salto de lineas
                        fi
                    done
                fi
    
                clear
                echo -e ""
                #no usamos >/dev/null 2>&1 sino /dev/null 2>&1
                #para guardar el error en archivo 
                ifconfig > ip-error.txt /dev/null 2>&1
                #cat adri.txt
                #echo 'Warning: cannot open /proc/net/dev (Permission denied). Limited output.' > ip-error.txt
                err='Warning: cannot open /proc/net/dev (Permission denied). Limited output.'
                com=$(sed -n "1p" ip-error.txt)
                rm -r ip-error.txt >/dev/null 2>&1
                if [ "$com" == "$err" ]; then
                    usra=$(whoami)
                    #echo 'Mensaje de error!'
                    #echo 'Otra alternativa es iproute2!'
                    #read
                    if [ -x $PREFIX/share/doc/iproute2 ]; then
                        echo Existe >/dev/null 2>&1
                        # x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
                        #echo "Esta es la IP de tu android ${x%%/*}"
                        # ipa=$(echo "${x%%/*}")
                        ipa=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                        # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                        if [ -z "$ipa" ]; then
                            ipa=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                        fi
                        str="$(echo "@$ipa")"
                    else 
                        usra=$(whoami)
                        echo "Instalando iproute2"
                        pkg install iproute2
                        # x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
                        #echo "Esta es la IP de tu android ${x%%/*}"
                        # ipa=$(echo "${x%%/*}")
                        ipa=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                        # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                        if [ -z "$ipa" ]; then
                            ipa=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                        fi
                        str="$(echo "@$ipa")"
                    fi
                fi
    
                if [ "$com" != "$err" ]; then
                    usra=$(whoami)
                    #ifconfig >> ip.txt
                    #Me cituas en la ip moto g5 plus:
                    str="$(ifconfig | grep -owE 'inet 192\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)')"
                    echo -e ""
                    ipa="$(echo -e ${str:4:16})"
                    ipa=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                    if [ -z "$ipa" ]; then
                        ipa=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                    fi
                    #rm -r ip.txt >/dev/null 2>&1
                fi
    
                str="$(echo "@$ipa")"
                sleep 1
                # Si existe esa letra @, entonces haz esto primero
                # Si no esta conectado a wifi, no subir el archivo
                if [ "$str" == "@" ]; then
                    clear
                    echo -e ""
                    echo -e "No tiene conexion wifi o hostpot!\nPor favor active el ${rojo}wifi ${blanco}o la\n${rojo}zona wifi (hostpot)${blanco}" 
                    echo "vuelva a intentar!"
                    sleep 5
                    echo -e ""
                    echo "La sesion quedo guardada!!!"
                    echo "$server"
                    sleep 1 
                    echo "$server" >> ~/Busca-Palabras/opc/.usr
                    echo -e ""
                    read -n 1 -p "Presione cualquier tecla para volver al menu"
                    # Si esta conectado a wifi, haz esto segundo
                    bash ~/Busca-Palabras/opc/lista-server.sh
                    str=a
                    exit
                    echo -e "" 
                else
                    # echo "aqui estamos";read
                    # if [ "$port" >= "8022" ]; then
                    if [ "$port" -ge 8022 ]; then
                        clear
                        echo "$usr@$ip"
                        echo -e 'Si el acceso de Termux esta restringido,\nte pedira la contrasena de usuario!!!'
                        echo -e 'Si no le tiene contrasena al usuario,\nentonces abra termux remoto, y escriba\nel siguiente comando para crear una:\n'
                        echo -e 'passwd\n'
                        read -n 1 -p 'Presione cualquier tecla para continuar!!!'
                        echo -e ""
                        #Android
                        cat ~/.ssh/id_rsa.pub | ssh -p "$port" "$usr@$ip" 'mkdir -p ~/.ssh && touch ~/.ssh/authorized_keys && chmod -R go= ~/.ssh && cat >> ~/.ssh/authorized_keys'
                        echo -e ""
                        echo -e 'Se a completado el acceso sin contrasenas!!!'
                        echo -e ""
                        echo "Ingresando al nuevo servidor"
                        echo "$server"
                        sleep 1
                        echo "$server" >> ~/Busca-Palabras/opc/.usr
                        $inserver
                        #Matar el script lista-server.sh en segundo plano
                        pkill -f activar_modo_doze.sh
                        # kill=$(ps aux | grep -w 'lista-server.sh' | sed -n "1p" | awk '{print $2}')
                        #echo ${kill}
                        # kill ${kill} >/dev/null 2>&1
                        bash ~/Busca-Palabras/opc/lista-server.sh
                        exit
                    fi
    
                    if [ "$port" == "22" ]; then
                        clear
                        #Aqui estamos trayendo el archivo del PC al Android, hacia una ruta especifica.
                        echo "$usr@$ip"
                        echo -e 'Si el acceso de la Computadora esta restringido,
                        te pedira la contrasena de usuario!!!'
                        echo -e 'Si no le tiene contrasena al computador,\nentonces abra simbolo del sistema\ncomo administrador, y escriba el\nsiguiente comando para crear una:\n'
                        echo -e 'net user %username% *\n'
                        echo -e 'Para quitar la contrasena de usuario escriba el mismo\ncomando seguido de dos veces la tecla ENTER\n'
                        read -n 1 -p 'Presione cualquier tecla para continuar!!!'
                        echo -e ""
                        scp -P "$port" "$usr@$ip"":"C:/programdata/ssh/sshd_config ~/.ssh
                        kp=$(grep -o '#PubkeyAuthentication' ~/.ssh/sshd_config)
                        #echo "$kp"
                        if [ "$kp" == "#PubkeyAuthentication" ]; then
                            echo "Abriendo acceso sin contrasena"
                            sed -i 's/#PubkeyAuthentication/PubkeyAuthentication/g' ~/.ssh/sshd_config
                            #Windows
                            cd ~/.ssh
                            echo -e "Transfiriendo la llave publica para el pc\n"
                            scp -P $port "id_rsa.pub" "sshd_config" $usr@$ip":" && ssh -p "$port" "$usr@$ip" 'type nul >> C:/programdata/ssh/Administrators_authorized_keys && type id_rsa.pub >> C:/programdata/ssh/Administrators_authorized_keys && type sshd_config > C:/programdata/ssh/sshd_config &&  icacls C:/programdata/ssh/Administrators_authorized_keys /inheritance:r /grant "%username%:F" /grant "SYSTEM:F"'
                            echo -e ""
                            echo -e 'Se a completado el acceso sin contrasenas!!!'
                            echo -e ""
                            sleep 1
                            echo "Ingresando al nuevo servidor"
                            echo "$server"
                            sleep 1
                            echo "$server" >> ~/Busca-Palabras/opc/.usr
                            $inserver
                            bash ~/Busca-Palabras/opc/lista-server.sh
                            exit
                        else
                            cd ~/.ssh
                            echo "acceso abierto"
                            echo -e ""
                            echo -e "Transfiriendo la llave publica para el pc"
                            scp -P $port "id_rsa.pub" $usr@$ip":" && echo -e "" && ssh -p "$port" "$usr@$ip" 'type nul >> C:/programdata/ssh/Administrators_authorized_keys && type id_rsa.pub >> C:/programdata/ssh/Administrators_authorized_keys &&  icacls C:/programdata/ssh/Administrators_authorized_keys /inheritance:r /grant "%username%:F" /grant "SYSTEM:F"'
                            echo -e ""
                            echo -e 'Se a completado el acceso sin contrasenas!!!'
                            echo -e ""
                            echo "Ingresando al nuevo servidor"
                            echo "$server"
                            sleep 1
                            echo "$server" >> ~/Busca-Palabras/opc/.usr
                            $inserver
                            #Matar el script servidor.py en segundo plano
                            kill=$(ps aux | grep -w 'lista-server.sh' | sed -n "1p" | awk '{print $2}')
                            #echo ${kill}
                            kill ${kill} >/dev/null 2>&1
                            bash ~/Busca-Palabras/opc/lista-server.sh
                            exit
                        fi
                    fi
                fi
            fi
    
            if [[ "$sn" == "n" || "$sn" == "N" || "$sn" == "no" || "$sn" == "No" || "$sn" == "nO" || "$sn" == "NO" ]]; then
                echo "Ok no accedimos al servidor"
                echo "Y tampoco se guardaron los datos"
                sleep 3
            else
                echo "Opcion invalida"
                sleep 2
            fi
            ;;
    
    
        2|02)
            bash ~/Busca-Palabras/opc/asc.sh
            #exit
            ;;
    
        3|03) 
            if [ -e ~/Busca-Palabras/opc/.usr ]; then
                echo "existe" >/dev/null 2>&1
                echo -e ""
                nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
                num=$(echo "${nu%%:*}")
            else
                echo "No tiene servidores en la lista"
                sleep 2
                bash ~/Busca-Palabras/opc/lista-server.sh
                exit
            fi
    
    
    
            if [ -e ~/Busca-Palabras/opc/.usr ]; then
                clear 
                echo -e ""
                #no usamos >/dev/null 2>&1 sino /dev/null 2>&1
                #para guardar el error en archivo 
                ifconfig > ip-error.txt /dev/null 2>&1
                #echo 'Warning: cannot open /proc/net/dev (Permission denied). Limited output.' > ip-error.txt
                err='Warning: cannot open /proc/net/dev (Permission denied). Limited output.'
                com=$(sed -n "1p" ip-error.txt)
                rm -r ip-error.txt >/dev/null 2>&1
                if [ "$com" == "$err" ]; then
                    usr=$(whoami)
                    #echo 'Mensaje de error!'
                    #echo 'Otra alternativa es iproute2!'
                    #read
                    if [ -x $PREFIX/share/doc/iproute2 ]; then
                        echo Existe >/dev/null 2>&1
                        # x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
                        #echo "Esta es la IP de tu android ${x%%/*}"
                        # ip=$(echo "${x%%/*}")
                        ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                        # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                        if [ -z "$ip" ]; then
                            ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                        fi
                    else 
                        usr=$(whoami)
                        echo "Instalando iproute2"
                        pkg install iproute2
                        # x=$(ip -o address | grep "inet 192" | cut -d' ' -f7-)
                       # echo "Esta es la IP de tu android ${x%%/*}"
                        # ip=$(echo "${x%%/*}")
                        ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                        # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                        if [ -z "$ip" ]; then
                            ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                        fi
                    fi
                fi
            
                if [ "$com" != "$err" ]; then
                    usr=$(whoami)
                    #ifconfig >> ip.txt
                    #Me cituas en la ip moto g5 plus:
                    str="$(ifconfig | grep -owE 'inet 192\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)')"
                    echo -e ""
                    ip="$(echo -e ${str:4:16})"
                    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                    if [ -z "$ip" ]; then
                        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                    fi
                    #rm -r ip.txt >/dev/null 2>&1
                fi
                str="$(echo "@$ip")"
                sleep 1
                # Si existe esa letra @, entonces haz esto primero
                # Si no esta conectado a wifi, no subir el archivo
                if [ "$str" == "@" ]; then
                    clear
                    echo -e ""
                   echo -e "No tiene conexion wifi o hostpot!\nPor favor active el ${rojo}wifi ${blanco}o la\n${rojo}zona wifi (hostpot)${blanco}" 
                    echo "vuelva a intentar!"
                    echo -e ""
                    read -n 1 -p "Presione cualquier tecla para volver al menu"
                    bash ~/Busca-Palabras/opc/lista-server.sh
                    str=a
                    exit
                    #read
                else
                    nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
                    num=$(echo "${nu%%:*}")
                    echo "Actualmente tiene "$num" servidores en la lista"
                    echo -e ""
                    grep -En "." ~/Busca-Palabras/opc/.usr
                    echo -e ""
                    read -p "Elija el servidor para acceder! > " pc
                    #if [[ "$pc" =~ ^[0-9]+$ ]]; then
                    if [[ "$pc" =~ ^[0-9]+$ ]] && (("$pc" >= 1 && "$pc" <= "$num")); then
                        #selecciona una linea especifica
                        active=$(sed -n ""$pc"p" ~/Busca-Palabras/opc/.usr)
                        clear
                        echo -e ""
                        echo "Ingresando al servidor"
                        echo "$active"
                        $active
                        bash ~/Busca-Palabras/opc/lista-server.sh
                        exit
                     fi
                 fi
                 if [ -z "$pc" ]; then 
                      echo "Nada seleccionado"
                 sleep 3
                 else
                      echo "Opcion invalida"
                      sleep 3
                 fi
            fi
            ;;
    
        4|04)
            bash Busca-Palabras/opc/scp.sh
            exit
            ;;
    
        5|05)
            bash Busca-Palabras/opc/memory.sh
            exit
            ;;
    
        6|06)
            if [ -e ~/Busca-Palabras/opc/.usr ]; then
                echo "existe" >/dev/null 2>&1
                else
                echo "No tiene servidores en la lista"
                sleep 3
                bash Busca-Palabras/opc/lista-server.sh
                exit
            fi
    
            clear
            #borrar un servidor! 
            if [ -e ~/Busca-Palabras/opc/.usr ]; then
                echo -e ""
                nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
                num=$(echo "${nu%%:*}")
                echo "Actualmente tiene "$num" servidores en la lista"
                C=$(grep -wi "$server" ~/Busca-Palabras/opc/.usr | cut -d' ' -f4)
                #echo "$C"
                echo -e ""
                grep -En "." ~/Busca-Palabras/opc/.usr
                echo -e ""
                read -p "borrar un servidor cual?/No! > " pc
                #si es un numero
                if [[ "$pc" =~ ^[0-9]+$ ]] && (("$pc" >= 1 && "$pc" <= "$num")); then
                    bor=$(sed -n ""$pc"p" ~/Busca-Palabras/opc/.usr)
                    sed -i ""$pc"d" ~/Busca-Palabras/opc/.usr
                    #sed -i '/adrimar/d' ~/Busca-Palabras/opc/.usr
                    #elimina los saltos de lineas
                    sed -i '/^$/d' ~/Busca-Palabras/opc/.usr #/dev/null 2>&1 
                    echo -e ""
                    echo -e "Se a borrado el servidor:"
                    echo "$bor"
                    read -n 1 -p "Presione cualquier tecla para continuar!!!"
                    bash Busca-Palabras/opc/lista-server.sh
                    exit
                fi
                if [ -z "$pc" ]; then 
                    echo "Nada seleccionado"
                    sleep 3
                    bash Busca-Palabras/opc/lista-server.sh
                    exit
                fi
                if [[ "$pc" == "n" || "$pc" == "N" || "$pc" == "no" || "$pc" == "No" || "$pc" == "nO" || "$pc" == "NO" ]]; then
                    echo "Ok no se borraste ningun servidor!!!"
                    sleep 2
                    bash Busca-Palabras/opc/lista-server.sh
                    exit
                fi
                echo "Opcion invalida"
                sleep 3
            fi
            ;;
    
        7|07)
            if [ -e ~/Busca-Palabras/opc/.usr ]; then
                echo "existe" >/dev/null 2>&1
            else
                echo "No tiene servidores en la lista"
                sleep 3
                bash Busca-Palabras/opc/lista-server.sh
                exit
            fi
            clear
            echo -e ""
            nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
            num=$(echo "${nu%%:*}")
            echo "Actualmente tiene "$num" servidores en la lista"
            #nu=$(grep -En "*" ~/Busca-Palabras/opc/.usr | tail -n 1 | cut -c 1)
            nu=$(grep -En "." ~/Busca-Palabras/opc/.usr | tail -n 1)
            num=$(echo "${nu%%:*}")
            echo -e ""
            for var in $(seq 1 "$num"); do
            #C=$(grep -wi "$adrimar" ~/Busca-Palabras/opc/.usr | cut -d' ' -f4)
            C=$(grep -Ein "." ~/Busca-Palabras/opc/.usr)
            n=$(grep -wn "$C" ~/Busca-Palabras/opc/.usr | cut -c 1)
            sed -n ""$var"p" ~/Busca-Palabras/opc/.usr
            #echo -n
            done
            echo -e ""
            read -n 1 -p "Presione cualquier tecla para volver!!!"
            ;;
    
        8|08)
            echo -e "${blanco}"
            if [ ! -f $PREFIX/bin/ngrok ]; then
                verif_ngrok="false"
            else
                verif_ngrok="true"
            fi
            
            if [ ! -x ${PREFIX}/bin/sshd ]; then
                echo -e ""
                echo -e "openssh no esta instalado!!!.\nPor favor, primero instale OpenSSH..."
                read -n 1 -p "Presione cualquier tecla para volver!"
                bash ~/Busca-Palabras/opc/ssh_remote.sh
                exit
            fi
            
            sw=a
            while [ "$sw" = "a" ]; do
            clear
            echo -e ""
            echo -e "${rojo}${blanco}Creando Acceso SSH Remoto Externo:"
            echo -e ""
            echo -e "Nota: Esta conexion se debe hacer por:\n(${rojo}wi-fi modem${blanco})${blanco}\n(${rojo}Datos de internet moviles${rojo}${blanco})\n(${rojo}zona wi-fi${blanco})${rojo}${blanco}"
            echo -e "\n${amarillo}Verificando conexión disponible${blanco}..."
            # read -n 1 -p "Presione cualquier tecla para avanzar"
            #echo -e ""
            
            
            active() {
            # Sí ngrok está activo detenerlo...
            if [[ `pidof ngrok` ]]; then
                killall ngrok > /dev/null 2>&1
            fi
            # Comprobar que Python esté instalado.
            if [ -x ${PREFIX}/bin/python ]; then
                echo Existe >/dev/null 2>&1
            else 
                echo "Instalando python"
                apt install python -y
            fi
            if [ -x ${PREFIX}/bin/python3 ]; then
                echo Existe >/dev/null 2>&1
            else 
                echo "Instalando python"
                apt install python3 -y
            fi
            }
            
            ngrok() {
                conexion_zonawifi="$1"
                ipexterna="$2"
                if [[ "$verif_ngrok" == 'true' ]] && [[ "$conexion_zonawifi" == 'false' ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                    termux-chroot ngrok tcp 8022 > /dev/null 2>&1 &
                    echo "Activando Tunnel Externo SSH..."
                    sleep 10
            
                    link=$(curl -s localhost:4040/api/tunnels | jq -r .tunnels[0].public_url)
                    v=$(echo "${link##*/}")
                    p=$(echo "${link##*:}")
                    # Separar el dominio y el puerto
                    DOMAIN=$(echo $link | sed 's/tcp:\/\/\([^:]*\).*/\1/')
                    PORT=$(echo $link | sed 's/.*:\([0-9]*\)/\1/')
            
                    if [[ "$DOMAIN" != "null" ]] && [[ "$PORT" != "null" ]]; then
                        echo -e "${verde}+--------------------------------+\n# ${blanco}ACCESO SSH EXTERNO HABILITADO: ${verde}#\n+--------------------------------+\n|\n+->>> "${blanco}
                        echo -e "${azul}ssh ${blanco}${usr}${amarillo}@${morado}${DOMAIN} ${verde}-p ${PORT}${blanco}\n"
                    else
                        echo -e "No hay Tunnel Externo SSH...\n"
                    fi
                fi
            }
            
            
            # Buscando la ip Android con wifi activado
            # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
            # iplocal=$(echo ${v%%/*})
            
            conect_verificada="false"
            ##############INICIO INTERFAZ################
            # Función para obtener la IP de una interfaz
            obtener_ip() {
                local interfaz=$1
                busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
            }
            # Comprobamos primero si wlan0 está disponible
            iplocal=$(obtener_ip "wlan0")
            # Si no hay IP en wlan0, buscar en otras interfaces activas
            if [ -z "$iplocal" ]; then
                echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null 2>&1
                # Iterar sobre las interfaces activas y capturar la primera IP disponible
                for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                    iplocal=$(obtener_ip "$interfaz")
                    ip=$(obtener_ip "$interfaz")
                    # Si no capturó una interfaz, el bucle for sigue iterando
                    if [ ! -z "$iplocal" ]; then
                        # Si capturó una interfaz, detiene el bucle for
                        echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null 2>&1
                        break
                    fi
                done
            else
                # Está conectado a una red inalámbrica, ya sea (modem wi-fi) o (zona wi-fi de un celular)
                echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null 2>&1
            fi
            # Si después de todas las comprobaciones no hay IP disponible
            if [ -z "$iplocal" ]; then
                echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null 2>&1
            else
                ip="$iplocal"
            fi
            ############## FIN INTERFAZ################
            
            : '
            echo "ip: $ip"
            echo "iplocal: $iplocal"
            : '
            
            # Falta llevar una varible constante para cuando estoy conectado al modem con internet 
            # para eso debo hacer una sola variable que capture todas las verificación de conexión 
            # y si esta vacia entolves es la del modem, esa variable debe ser impresa al final vuamdo haya recolectado las verificiones de conexión
            
            # Verificar si hay conexión externa (Internet)
            # x=$(curl -s ifconfig.me)
            x=$(curl -s ipinfo.io/ip)
            ipexterna=$(echo "${x//[<>]/}")
            ipexterna=$(echo "${x}")
            # echo "ipexterna: $ipexterna"
            # read
            # echo -e ""
            
            ###########Zona WiFi Comprobar#########
            conexion_zonawifi='false'
            iplocalc=".${iplocal}"
            iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
            
            
            # Hay internet datos
            if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "127" ]]; then 
                echo -e "${verde}Tienes internet para compartir datos${blanco}.\n" # >/dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                conexion_zonawifi_si_internet='true'
                conect_verificada="true"
                echo -e "${verde}conexion_zonawifi_si_internet${blanco}: $conexion_zonawifi_si_internet\n" > /dev/null 2>&1
                read -n 1 -p "Presione cualquier tecla para continuar!"
            fi
            
            if [[ "$conexion_zonawifi_no_internet" == 'true' ]]; then
                # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo
                if [[ "$ipexterna" != "" ]]; then
                    if [[ "$iplocal" == "127.0.0.1" ]]; then
                        echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                        for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                            ip=$(obtener_ip "$interfaz")
                            if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                                echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                                break
                            fi
                        done
                    else
                        echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
                    fi
                else
                    ip="$iplocal"
                    echo "No hay conexión a Internet." > /dev/null 2>&1
                fi
            fi
            ###########Zona WiFi Fin#########
            
            # clear
            # Si no está conectado a una red externa
            sin_internet='false'
            if [[ "$ip" == "127.0.0.1" ]] && [[ "$iplocal" == "127.0.0.1" ]] && [[ "$iplocalc" == "127" ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                ipexterna="html"
                sin_conex='true'
                conect_verificada="true"
                echo -e "${rojo}No hay conexión${blanco}...\n" > /dev/null 2>&1
                # read -n 1 -p "Presione cualquier tecla para continuar!"
            fi
            
            wlan0_verif='false'    
            # Verificar el estado de wlan0 usando ifconfig
            es_wlan0=$(busybox ifconfig wlan0 2>/dev/null)
            if echo "${es_wlan0}" | grep -q "RUNNING" && echo "${es_wlan0}" | grep -q "inet "; then
                # echo "wlan0_verif: true"
                wlan0_verif='true'
                echo "wlan0 conectada a modem" > /dev/null 2>&1
            elif echo "${es_wlan0}" | grep -q "RUNNING"; then
                #echo "wlan0_verif: false"
                wlan0_verif='false'
                echo "wlan0 no está activa" > /dev/null 2>&1
            else
                # echo "wlan0_verif: false"
                wlan0_verif='false'
                echo "wlan0 no está activa" > /dev/null 2>&1
            fi
            
            # No hay internet pero está la zona wi-fi activa
            if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "false" ]]; then 
                echo -e "${verde}Conexion por Zona WI-FI y no tienes internet,\npero puedes otorgar conexión${blanco}.\n" # >/dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                conexion_zonawifi_no_internet='true'
                conect_verificada="true"
                echo -e "conexion_zonawifi_no_internet: $conexion_zonawifi_no_internet" > /dev/null 2>&1
                read -n 1 -p "Presione cualquier tecla para continuar!"
            fi 
            
            # No hay internet pero estás conectado a modem
            if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]] && [[ "$iplocalc" == "192" || "$iplocalc" == "10" ]] && [[ "$wlan0_verif" == "true" ]]; then 
                echo -e "${verde}No hay internet pero estás conectado al modem${blanco}.\n" # >/dev/null 2>&1
                conect_verificada="true"
                #ngrok="Conexion externa deshabilitada"
                read -n 1 -p "Presione cualquier tecla para continuar!"
            fi 
            
            # Esto no esta en uso
            compartiendo_datos='false'
            # Hay conexión por zona wi-fi y externa
            if [[ "$conexion_zonawifi" == "true" ]] && [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                echo -e "${verde}Tienes internet y estás compartiendo datos${blanco}.\n"
                compartiendo_datos='true'
                conect_verificada="true"
                read
            fi
            
            modem_zona_wifi='false'
            # Verificar si ipexterna contiene una dirección IP válida
            if [[ "$ipexterna" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$iplocalc" == "192" ]] && [[ "$wlan0_verif" == 'false' ]]; then
                echo -e "${verde}Tienes datos de internet y la zona wi-fi activa${blanco}.\n"
                modem_zona_wifi='true'
                conect_verificada="true"
                read -n 1 -p "Presione cualquier tecla para continuar!"
            fi
            
            if [[ "$iplocal" == "127.0.0.1" ]] && [[ "$conexion_zonawifi" == 'false' ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                #ipexterna="html"
                clear
                echo -e "No tiene conexion externa!" > /dev/null 2>&1
                #ngrok="Conexion externa deshabilitada"
                # read
            else
            
                if [[ "$iplocal" =~ [^0-9]+$ ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                    echo "datos sin Internet" > /dev/null 2>&1
                    sleep 1
                    # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
                    # ip=$(echo ${v%%/*})
                    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                    if [ -z "$ip" ]; then
                        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                    fi
                    bash ~/Busca-Palabras/opc/lista-server.sh
                    exit
                else 
                    # ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    echo "Conexion por via Internet" >/dev/null 2>&1
                    
                    # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo
                    if [[ "$ipexterna" != "" ]]; then
                        if [[ "$iplocal" == "127.0.0.1" ]]; then
                            echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                            for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                                ip=$(obtener_ip "$interfaz")
                                if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                                    echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                                    break
                                fi
                            done
                        else
                            echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
                        fi
                    else
                        echo "No hay conexión a Internet."  > /dev/null 2>&1
                    fi
                    
                    active
                    #ngrok
                    inn=ngrok
                fi
            fi 
            
            mi_server() {
                usr=$(whoami)
                echo -e ""
                sshd
                clear
                echo -e ""
                echo -e "Su puerto: ${verde}8022${blanco}"
                echo -e "Su usuario: ${azul}$usr"
                echo -e "${blanco}Su IP Android: $morado$ip${blanco}"
                echo -e "+------------------------------------+\n# Acceso Remoto ssh Creado:          #\n# Copie esta direccion y pegue en un #\n# servidor cliente para que tenga    #\n# acceso a este dispositivo          #\n+------------------------------------+\n+->>> "${verde}${verde}ssh${blanco} $azul$usr${verde}@$morado"$ip ${verde}-p 8022${blanco}"
                echo -e ""
                echo -e ""
            }
            
            
            # Buscando la ip Android con wifi activado
            # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
            # iplocal=$(echo ${v%%/*})
            ##############INTERFAZ################
            # Función para obtener la IP de una interfaz
            obtener_ip() {
                local interfaz=$1
                busybox ifconfig "$interfaz" 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}'
            }
            # Comprobamos primero si wlan0 está disponible
            iplocal=$(obtener_ip "wlan0")
            # Si no hay IP en wlan0, buscar en otras interfaces activas
            if [ -z "$iplocal" ]; then
                echo "wlan0 no tiene una IP asignada. Buscando en otras interfaces..." > /dev/null 2>&1
                # Iterar sobre las interfaces activas y capturar la primera IP disponible
                for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                    iplocal=$(obtener_ip "$interfaz")
                    if [ ! -z "$iplocal" ]; then
                        echo "Interfaz $interfaz tiene la IP: $iplocal" > /dev/null 2>&1
                        break
                    fi
                done
            else
                echo "Interfaz wlan0 tiene la IP: $iplocal" > /dev/null 2>&1
            fi
            # Si después de todas las comprobaciones no hay IP disponible
            if [ -z "$iplocal" ]; then
                echo "No se encontró ninguna IP disponible en las interfaces." > /dev/null 2>&1
            fi
            ##############INTERFAZ################
            
            #x=$(curl -s ifconfig.me)
            x=$(curl -s ipinfo.io/ip)
            ipexterna=$(echo "${x//[<>]/}")
            echo -e ""
            
            clear
            if [[ "$iplocal" == "127.0.0.1" ]] && [[ "$ipexterna" == "" ]]; then 
                ipexterna="html"
            fi
            
            iplocalc=".${iplocal}"
            iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')
            
            # Hay internet poro esta la zona wi-fi activa
            if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
                if [ "$iplocalc" == "192" ]; then 
                    echo "Conexion por Zona WI-FI" >/dev/null 2>&1
                    #ngrok="Conexion externa deshabilitada"
                    conexion_zonawifi='true'
                    echo -e "conexion_zonawifi: $conexion_zonawifi"  > /dev/null 2>&1
                    # read
                fi
            fi 
            
            # No hay internet pero está la zona wi-fi activa
            if [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                if [ "$iplocalc" == "192" ]; then 
                    echo "Conexion por Zona WI-FI" >/dev/null 2>&1
                    #ngrok="Conexion externa deshabilitada"
                    conexion_zonawifi='true'
                    echo -e "conexion_zonawifi: $conexion_zonawifi" > /dev/null 2>&1
                    # read
                fi
            fi 
            
            if [[ "$conexion_zonawifi" == 'true' ]]; then
                # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo
                if [[ "$ipexterna" != "" ]]; then
                    if [[ "$iplocal" == "127.0.0.1" ]]; then
                        echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                        for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                            ip=$(obtener_ip "$interfaz")
                            if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                                echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                                break
                            fi
                        done
                    else
                        echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
                    fi
                else
                    echo "No hay conexión a Internet." > /dev/null 2>&1
                    ip="$iplocal"
                fi
            fi
            
            if [[ "$conect_verificada" == "false" ]]; then
                echo -e "${verde}Tienes internet wi-fi del modem${blanco}.\n" # >/dev/null 2>&1
                read -n 1 -p "Presione cualquier tecla para continuar!"
            fi
            
            if [[ "$iplocal" == "127.0.0.1" ]] && [[ "$conexion_zonawifi" == 'false' ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                #ipexterna="html"
                clear
                echo -e "No tiene conexion a Internet!\nPor favor active el ${rojo}wifi ${blanco} y conecte.\no active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
                echo "vuelva a intentar!"
                sleep 5
                sw=a
                echo -e ""
                bash ~/Busca-Palabras/opc/lista-server.sh
                exit
            else
                if [[ "$iplocal" =~ [^0-9]+$ ]] && [[ "$ipexterna" == "" || "$ipexterna" == *"html"* ]]; then 
                    echo "datos sin Internet"
                    sleep 1
                    # v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
                    # ip=$(echo ${v%%/*})
                    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    # Si no se encuentra IP en wlan0, buscar una IP distinta de y que no sea 127.0.0.1
                    if [ -z "$ip" ]; then
                        ip=$(ifconfig 2>/dev/null | busybox awk '/inet / && !/127.0.0.1/ {print $2}' | busybox cut -d/ -f1 | busybox head -n 1)
                    fi
                    bash ~/Busca-Palabras/opc/lista-server.sh
                    exit
                else
                    # Ultima muestra de la conexión 
                    # echo "Conexion por via Internet"
                    # read
                    # x=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
                    clear
                    # ip=$(echo ${v%%/*})
                    # ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
                    echo -e ""
                    
                    # Si hay conexión a Internet, pero la IP local es 127.0.0.1, hacer otro escaneo
                    if [[ "$ipexterna" != "" ]]; then
                        if [[ "$iplocal" == "127.0.0.1" ]]; then
                            echo "Conexión a Internet detectada, pero la IP local es 127.0.0.1. Buscando otra IP..." > /dev/null 2>&1
                            for interfaz in $(busybox ifconfig 2>/dev/null | grep '^[a-z]' | awk '{print $1}'); do
                                ip=$(obtener_ip "$interfaz")
                                if [[ ! -z "$ip" && "$ip" != "127.0.0.1" ]]; then
                                    echo "Nueva IP local encontrada: $ip en la interfaz $interfaz" > /dev/null 2>&1
                                    break
                                fi
                            done
                        else
                            echo "Conexión a Internet activa. IP local: $ip" > /dev/null 2>&1
                        fi
                    else
                        echo "No hay conexión a Internet." > /dev/null 2>&1
                    fi
                    
                    #curl qrcode.show/http://$ip:8080
                    mi_server
                    usr=$(whoami)
                    sshd
                    $inn "$conexion_zonawifi" "$ipexterna" "$verif_ngrok"
                    read -n 1 -p "Presione cualquier tecla para detener!"
                    rm -rf ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/tunnels.json >/dev/null 2>&1
                    killall ngrok >/dev/null 2>&1
                    killall sshd >/dev/null 2>&1
                    bash ~/Busca-Palabras/opc/lista-server.sh
                    exit
                fi
            fi 
            done
            ;;
    
        9|09)
            bash Busca-Palabras/opc/ssh_remote.sh
            exit
            ;;
    
        *) echo "opcion invalida";sleep 1;clear;;
    esac
done
exit
#listar las lineas de un archivo
#for var in $(seq 1 100); do
##C=$(grep -wi "$adrimar" ~/Busca-Palabras/opc/.usr | cut -d' ' -f4)
#C=$(grep -Ei "*" ~/Busca-Palabras/opc/.usr)
#n=$(grep -wn "$C" ~/Busca-Palabras/opc/.usr | cut -c 1)
#sed -n ""$var"p" ~/Busca-Palabras/opc/.usr
#echo -n
#read
#done





#for var in $(find ~/ -type f -iname usr); do
#server=$(echo "ssh -p 22 ADRIMAR@192.168.20.24")
#server=$(echo "ssh -p 22 adrimar@192.168.20.24")
#C=$(grep -wi "$adrimar" ~/Busca-Palabras/opc/.usr | cut -d' ' -f4)
#C=$(grep -wi "adrimar" ~/Busca-Palabras/opc/.usr)
#n=$(grep -wn "$C" ~/Busca-Palabras/opc/.usr | cut -c 1)
#echo "$C"
#sed -i ""$n"d" ~/Busca-Palabras/opc/.usr
#sed -i '/adrimar/d' ~/Busca-Palabras/opc/.usr
#sed -i '/^$/d' ~/Busca-Palabras/opc/.usr
#echo "$server" >> ~/Busca-Palabras/opc/.usr
#cat usr
#done

#lista los servidores
#grep -En "*" ~/Busca-Palabras/opc/.usr
#borrar un servidor
#sed -i '4d' ~/Busca-Palabras/opc/.usr




#si es un Android 
#read -p "ingrese el nombre de usuario > " usr1
#read -p "ingrese la ip de usuario > " ip1


#echo "ssh -p 8022 $usr1@$ip1"
    #192.168.20.20
    