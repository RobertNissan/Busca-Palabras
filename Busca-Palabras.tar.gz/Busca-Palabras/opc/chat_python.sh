#!/bin/bash
if [ -x ${PREFIX}/bin/python ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python"
apt install python -y
fi
if [ -x ${PREFIX}/bin/python3 ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python3"
apt install python3 -y
fi
#if [ -x ${PREFIX}/lib/python3.11/site-packages/pyftpdlib ]; then 
if [ -x ${PREFIX}/lib/*/*/pyftpdlib ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando pyftpdlib"
pip install pyftpdlib
fi
if [ -x ${PREFIX}/lib/*/*/netaddr ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando netaddr"
pip install netaddr
fi
#cd $PREFIX
#ls lib/*/* | grep colorama
if [ -x ${PREFIX}/lib/*/*/colorama ]; then
echo Existe 
else 
echo "Instalando python"
pip3 install colorama 
fi
clear
echo -e ""
kill=$(ps aux | grep 'servidor.py' | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1


ip=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
IP=$(echo "${ip%/*}")

      #-----mod IPSERVIDOR de cliente2.py------#
bwh=$(grep -En "SERVER_HOST" ~/Busca-Palabras/opc/chat_python/cliente2/cliente2.py | head -n 1 | awk '{print $3}')
cli=$(grep -En "SERVER_HOST" ~/Busca-Palabras/opc/chat_python/cliente2/cliente2.py | head -n 1 | awk '{print $3}')
IP="'$IP'"
if [ "$bwh" = "$IP" ]; then
echo Ok >/dev/null 2>&1
cd ~/Busca-Palabras/opc/chat_python/cliente2/
zip -r9 cliente2.zip cliente2.py >/dev/null 2>&1
mv cliente2.zip bajaftp/
else
sed -i "s%$bwh%"$IP"%g" ~/Busca-Palabras/opc/chat_python/cliente2/cliente2.py
cd ~/Busca-Palabras/opc/chat_python/cliente2/
zip -r9 cliente2.zip cliente2.py >/dev/null 2>&1
mv cliente2.zip bajaftp/
fi


#Ejecutar doble script
cd  ~/Busca-Palabras/opc/chat_python/
bash baja_client.sh & bash subeftp.sh
IP=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
IP=$(echo "${ip%/*}")
echo -e ""
echo -e "     DESCARGAR SCRIPT CLIENTE"
echo -e "    http://${IP}:8024/\n"
cd ~/Busca-Palabras/opc/chat_python
python servidor.py & python cliente.py

#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep 'servidor.py' | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1

#Matar el script baja_client.sh en segundo plano
kill=$(ps aux | grep 'baja_client.sh' | sed -n "2p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1

#Matar el script baja_client.sh en segundo plano
kill=$(ps aux | grep 'baja_client.sh' | sed -n "2p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1

#Matar el proceso http.server 8024 en segundo plano
kill=$(ps aux | grep 'http.server 8024' | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1