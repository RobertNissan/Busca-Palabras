#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep -w 'index.py' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1

if [ -x ${PREFIX}/bin/python ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python"
apt install python -y
fi
if [ -x ${PREFIX}/bin/python3 ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python3"
apt install python3 -y
fi
if [ -x ${PREFIX}/lib/*/*/pyftpdlib ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando pyftpdlib"
pip install pyftpdlib
fi
if [ -x ${PREFIX}/lib/*/*/netaddr ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando netaddr"
pip install netaddr
fi

if [ -x ${PREFIX}/lib/*/*/flask ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando Flask"
pip install Flask
fi

cd python-flask-first-website
python index.py

kill=$(ps aux | grep -w 'index.py' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1