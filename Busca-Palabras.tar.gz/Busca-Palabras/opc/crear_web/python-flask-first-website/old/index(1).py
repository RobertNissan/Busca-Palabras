from flask import Flask, render_template, request
#from OpenSSL import SSL
import platform
import subprocess

if platform.system() == 'Windows':
    local = subprocess.getoutput("""for /f "tokens=2 delims=[]" %a in ('ping -n 1 -4 "%computername%"') do @echo %a""")
else:
    local = subprocess.getoutput("ifconfig | grep 'inet ' | grep -F 192.168 | awk '{print $2}'")

#context = SSL.Context(SSL.TLsv4_2_METHOD)
#context.use_certificate('public.pem')
#context.use_privatekey('private.pem')

app = Flask(__name__)

# Creating simple Routes 
@app.route('/test')
def test():
    return "Home Page"

@app.route('/test/about/')
def about_test():
    return "About Page"

# Routes to Render Something
@app.route('/')
def home():
    return render_template("home.html")

@app.route('/about', strict_slashes=False)
def about():
    return render_template("about.html")

# Make sure this we are executing this file
if __name__ == '__main__':
#    app.run(host=(local),  port='8080', debug=False, ssl_context=context)
     app.run(host=(local),  port='8080', debug=False)
