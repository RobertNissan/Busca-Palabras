curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
pip3 install Flask
pip install Flask
pip install -r requirements.txt
