from flask import Flask, render_template
import platform
import subprocess

if platform.system() == 'Windows':
    local = subprocess.getoutput("""for /f "tokens=2 delims=[]" %a in ('ping -n 1 -4 "%computername%"') do @echo %a""")
else:
    local = subprocess.getoutput("x=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}');echo ${x%%/*}")

app = Flask(__name__)

# Creating simple Routes 
@app.route('/test')
def test():
    return "Home Page"

@app.route('/test/about/')
def about_test():
    return "About Page"

# Routes to Render Something
@app.route('/')
def home():
    return render_template("home.html")

@app.route('/about', strict_slashes=False)
def about():
    return render_template("about.html")

# Make sure this we are executing this file
if __name__ == '__main__':
    app.run(host=(local), port='8021', ssl_context=('cert.pem', 'key.pem'))
