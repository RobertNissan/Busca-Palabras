#!/bin/bash

#apt update -y;apt upgrade -y;
PWD=$(pwd)
ini=$(echo ${PWD}) 
if [ -f $PREFIX/bin/wget ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando wget"
pkg install wget -y >/dev/null 2>&1
fi
if [ -f $PREFIX/bin/unrar ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando unrar"
pkg install unrar
fi
if [ -f $PREFIX/bin/rarp ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando rar"
pkg install rar
fi
if [ -f $PREFIX/bin/zip ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando zip"
pkg install zip
fi

#-------------------------------------------------------------------------#
#case `dpkg --print-architecture` in
#aarch64)
    #architectureURL="arm64" ;;
#arm)
    #architectureURL="arm" ;;
#armhf)
    #architectureURL="arm" ;;
#amd64)
    #architectureURL="amd64" ;;
#i*86)
    #architectureURL="386" ;;
#x86_64)
    #architectureURL="amd64" ;;
#*)
    #echo "unknown or unsupported architecture"
#esac
#-------------------------------------------------------------------------#

clear
while true
do
echo -e ""
echo "Instale termux-api para tener los permisos
necesarios sobre otras aplicaciones"
echo -e ""
: '
echo -en "${verde}+---------------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar termux - api - boot   ${verde}#
#---------------------------------------#
# [${blanco}02${verde}] | ${blanco}Instalar Apex Launcher v4.9.20 ${verde}#
#---------------------------------------#
# [${blanco}03${verde}] | ${blanco}Instalar Pixel Launcher vQ6    ${verde}#
#---------------------------------------#
# [${blanco}04${verde}] | ${blanco}Instalar AirDroid v4.2.9.5     ${verde}#
#---------------------------------------#
# [${blanco}05${verde}] | ${blanco}Instalar Team Viewer           ${verde}#
#---------------------------------------#
# [${blanco}06${verde}] | ${blanco}Instalar Team Host v15.19.88   ${verde}#
#---------------------------------------#
# [${blanco}07${verde}] | ${blanco}Instalar CalculadoraMod v4.3.3 ${verde}#
#---------------------------------------#
# [${blanco}08${verde}] | ${blanco}Instalar Root Explorer v4.10   ${verde}#
#---------------------------------------#
# [${blanco}09${verde}] | ${blanco}Instalar IDM Plus Mod          ${verde}#
#---------------------------------------#
# [${blanco}10${verde}] | ${blanco}Instalar Videoder Pro v14.5    ${verde}#
#---------------------------------------#
# [${blanco}11${verde}] | ${blanco}Instalar Paint Animator mod    ${verde}#
#---------------------------------------#
# [${blanco}12${verde}] | ${blanco}Instalar QuickEdit Pro v1.9.7  ${verde}#
#---------------------------------------#
# [${blanco}13${verde}] | ${blanco}Instalar WhatsApp Aero         ${verde}#
#---------------------------------------#
# [${blanco}14${verde}] | ${blanco}Instalar TTSReader Texto A Voz ${verde}#
#---------------------------------------#
# [${blanco}15${verde}] | ${blanco}Instalar MX Player Pro v1.36/8 ${verde}#
#---------------------------------------#
# [${blanco}16${verde}] | ${blanco}Instalar Universal Copy v5.3.2 ${verde}#
#---------------------------------------#
# [${blanco}17${verde}] | ${blanco}Instalar YouTube Vanced        ${verde}#
#---------------------------------------#
# [${blanco}18${verde}] | ${blanco}Instalar Afinador-Guitar_2.3.3 ${verde}#
#---------------------------------------#
# [${blanco}19${verde}] | ${blanco}Instalar Guitar Pro v1.6.4     ${verde}#
#---------------------------------------#
# [${blanco}20${verde}] | ${blanco}Instalar Music Speed Changer   ${verde}#
#---------------------------------------#
# [${blanco}21${verde}] | ${blanco}Instalar Fl Studio Mobile      ${verde}#
#---------------------------------------#
# [${blanco}22${verde}] | ${blanco}Instalar PowerAmp Pro v3-build ${verde}#
#---------------------------------------#
# [${blanco}23${verde}] | ${blanco}Instalar ES File Explorer v4.2 ${verde}#
#---------------------------------------#
# [${blanco}24${verde}] | ${blanco}Instalar Video Compressor      ${verde}#
#---------------------------------------#
# [${blanco}25${verde}] | ${blanco}Instalar Video Converter v1.5  ${verde}#
#---------------------------------------#
# [${blanco}26${verde}] | ${blanco}Instalar Audio Converter v8-0  ${verde}#
#---------------------------------------#
# [${blanco}27${verde}] | ${blanco}Instalar Android control PC    ${verde}#
#---------------------------------------#
# [${blanco}28${verde}] | ${blanco}Instalar Speechkeys SmartVoice ${verde}#
#---------------------------------------#
# [${blanco}29${verde}] | ${blanco}Instalar Galeria Mod v6.21.6   ${verde}#
#---------------------------------------#
# [${blanco}30${verde}] | ${blanco}Instalar VPN Unlimited         ${verde}#
#---------------------------------------#
# [${blanco}31${verde}] | ${blanco}Instalar ChatBot WhatsApp      ${verde}#
#---------------------------------------#
# [${blanco}32${verde}] | ${blanco}Limpiar las descargas          ${verde}#
#---------------------------------------#
# [${blanco}33${verde}] | ${blanco}Volver al menu principal       ${verde}#
+---------------------------------------+                             
              +-------------+           |
+----------<<<# [${blanco}00${verde}] | ${rojo}EXIT ${verde}#<<<--------+
|             +-------------+
|
+->>> "${blanco}
'
function count_printable_chars {
  # Elimina los codigos de escape ANSI para que no se cuenten
  stripped_string=$(echo -en "$1" | sed 's/\x1B\[[0-9;]*[mG]//g')

  # Convierte la cadena a una sucesion de caracteres hexadecimales
  hex_chars=$(echo -n "$stripped_string" | xxd -p -c 256)

  # Filtra solo los caracteres imprimibles en la secuencia hexa
  filtered_hex_chars=$(echo "$hex_chars" | sed 's/[[:xdigit:]]\{2\}/\\x&/g' | tr -d '\n' | grep -o '[[:print:]]')

  # Cuenta la cantidad de caracteres imprimibles presentes
  count=$(echo -n "$filtered_hex_chars" | wc -m)

  echo "$count"
}

# Definimos los colores
GREEN='\033[32m'
WHITE='\033[37m'
NC='\033[0m' # No Color

# Definimos la cadena
ID="${WHITE}[01]${GREEN}"
CLI="${WHITE}Busca Palabras${GREEN}"
#DEU="${WHITE}NO ROOT${GREEN}"
# array de usuarios
data=( '[01]' 'Instalar termux - api - boot'
       '[02]' 'Instalar Apex Launcher v4.9.20'
       '[03]' 'Instalar Pixel Launcher vQ6'
       '[04]' 'Instalar AirDroid v4.2.9.5'
       '[05]' 'Instalar Team Viewer'
       '[06]' 'Instalar Team Host v15.19.88'
       '[07]' 'Instalar Calculadora Mod v4.3.3'
       '[08]' 'Instalar Root Explorer v4.10'
       '[09]' 'Instalar IDM Plus Mod'
       '[10]' 'Instalar Videoder Pro v14.5'
       '[11]' 'Instalar Paint Animator mod'
       '[12]' 'Instalar QuickEdit Pro v1.9.7'
       '[13]' 'Instalar WhatsApp Aero'
       '[14]' 'Instalar TTSReader Texto A Voz'
       '[15]' 'Instalar MX Player Pro v1.36/8'
       '[16]' 'Instalar Universal Copy v5.3.2'
       '[17]' 'Instalar YouTube Vanced'
       '[18]' 'Instalar Afinador-Guitar_2.3.3'
       '[19]' 'Instalar Guitar Pro v1.6.4'
       '[20]' 'Instalar Music Speed Changer'
       '[21]' 'Instalar Fl Studio Mobile'
       '[22]' 'Instalar PowerAmp Pro v3-build'
       '[23]' 'Instalar ES File Explorer v4.2'
       '[24]' 'Instalar Video Compressor'
       '[25]' 'Instalar Video Converter v1.5'
       '[26]' 'Instalar Audio Converter v8-0'
       '[27]' 'Instalar Android control PC'
       '[28]' 'Instalar Speechkeys SmartVoice'
       '[29]' 'Instalar Galeria Mod v6.21.6'
       '[30]' 'Instalar VPN Unlimited'
       '[31]' 'Instalar ChatBot WhatsApp'
       '[32]' 'Limpiar las descargas'
       '[33]' 'Volver al menu principal'
     )
# Contar el numero de filas
# El calculo se haya dividiendo entre la 2 columnas
num_filas=$(( ${#data[@]} / 2 ))
echo $num_filas

# Calculamos los valores para imprimir correctamente
columns=$(tput cols)
col=$(($columns - 1))
mul=$(($columns*07/100))
mul2=$(($columns*98/100))
#mul3=$(($columns*15/100))

# Definimos la cadena resultante
printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
RESULT=$(printf "$printf_result" "$ID" "$CLI" "$DEU")

# Calculamos la longitud de la cadena imprimible, excluyendo los caracteres de escape
char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
#char_count=$(printf count_printable_chars "$RESULT" | wc -m)
#echo -e "\n$RESULT"

# Imprimimos la cantidad de caracteres imprimibles
#echo "La cantidad de caracteres imprimibles es: $char_count"


#echo "Aplicando ajuste resposive"
# aqui va el ajuste resposive a encabezado
for i in {1..301}; do
medida=$(($char_count + $i))
if [[ "$medida" -eq "$columns" ]]; then
    #echo "$char_count + $i = $columns"
    mul2=$(($mul2 + $i))
    CLI=$(printf  "%s%*s" "$CLI" $j "")
    break 
fi
medida=$(($char_count - $i))
if [[ "$medida" -eq "$columns" ]]; then
    #echo "$char_count - $i = $columns"
    mul2=$(($mul2 - $i))
    CLI=$(printf  "%s%*s" "$CLI" $j "")
    break
fi
done 

printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
RESULT=$(printf "$printf_result" "$ID" "$CLI")
#printf "${GREEN}+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')" 
#echo -e "$RESULT"

iter=0
linea_imprimida=false
imprimir_linea=false

for ((i=0;i<${#data[@]};i+=2)); do
    id="${WHITE}${data[i]}${GREEN}"
    cli="${WHITE}${data[i+1]}${GREEN}"
    #deu="${WHITE}${data[i+2]}${GREEN}"
iter=$((iter + 1))

 if [[ "$imprimir_linea" = true ]]; then
        printf "${GREEN}#%s#\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
    imprimir_linea=true
    
: '
mul="$mul"
mul2="$mul2"
mul3="$mul3"

echo $mul
echo $mul2
echo $mul3
'
#read
#printf "${GREEN}#%s#\n" "$(seq -s '-' $col | tr -d '[:digit:]')" 
# contar caracteres
printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
RESULT=$(printf "$printf_result" "$id" "$cli")
char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
#echo -e "fchar_count $char_count"

    # ajustar resposive a cada columna
    for j in {1..301}; do
            
     # Si es la primera vez que se ejecuta el bucle y no se ha impreso la linea
  if [[ $j -eq 1 && "$linea_imprimida" = false ]]; then
    # Imprimir la linea
    printf "${GREEN}+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    linea_imprimida=true
  fi

        medida=$(($char_count + $j))
        if [[ "$medida" -eq "$columns" ]]; then
            #echo -e "$mul3 + $j"
           # mul3=$((mul3 + $j))
# Anadir los espacios al inicio para alinear a la derecha
#deu=$(printf "%${j}s$deu")
cli=$(printf  "%s%*s" "$cli" $j "")
: '
si quieres los espacios al final puedes
hacer de esta forma:
printf  "%s%*s" "$deu" $j ""
y asi se alinea a la izquierda la 
columna 3
'


           # echo $mul3
printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
RESULT=$(printf "$printf_result" "$id" "$cli")
#echo -e "$RESULT"
char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
#echo -e "fchar_count $char_count"

break
        fi
        medida=$(($char_count - $j))
        if [[ "$medida" -eq "$columns" ]]; then
            #echo -e "$mul3 - $j"
            mul3=$(($mul3 - $j))
printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
RESULT=$(printf "$printf_result" "$id" "$cli")
#echo -e "$RESULT"
char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
#echo -e "fchar_count $char_count"

    
break
        fi 
     

    done

: ' 
for i in $(seq 1 "$num_filas"); do
  # Si es la primera iteracion, no se imprime la linea
  if [[ $i -eq 1 ]]; then
    primera_iteracion=false
    break
  else
    # A partir de la segunda iteracion, se imprime la linea
    printf "${GREEN}#%s#\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    break
  fi
 done
 '
  
    
     printf_result="${GREEN}# %-${mul}s | %-${mul2}s #${NC}\n"
    RESULT=$(printf "$printf_result" "$id" "$cli")
    echo -e "$RESULT"
        char_count=$(echo -en "$RESULT" | sed "s/\x1B\[[0-9;]*[mK]//g" | wc -m)
    #echo -e "fchar_count $char_count"





done

printf "${GREEN}+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
echo -en "|
+->>> "${blanco}
# Restaurar los colores predeterminados
printf '%b' '\033[0m'

read -r opt
#opt=("Si" "No")
cd ${HOME}
case $opt in
       
      0|00) echo -e "";echo "Saliendo del script";sleep 1.5;clear;echo -e "";
clear
exit
echo -e ""
;;

    1|01)
		echo "Yes" >/dev/null 2>&1
cd ${HOME}/Busca-Palabras/opc/
bash termux.sh
;;
     
 
      2|02)
if [ -e ${HOME}/Apex_Launcher_Pro_v4.9.20.apk ]; then
echo -e ""
echo "Apex Launcher Pro"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open Apex_Launcher_Pro_v4.9.20.apk
clear
else
echo -e ""
echo "Descargando Apex_Launcher_Pro_v4.9.20"
echo -e ""
wget https://www.dropbox.com/s/nqg1c6vmbhnixav/Apex_Launcher_Pro_v4.9.20.apk?dl=0;mv Apex_Launcher_Pro_v4.9.20.apk?dl=0 Apex_Launcher_Pro_v4.9.20.apk;xdg-open Apex_Launcher_Pro_v4.9.20.apk;
fi
clear
;;
       
       3|03)
if [ -e ${HOME}/nexuslauncher-mod.apk ]; then
echo -e ""
echo "Pixel Launcher"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open nexuslauncher-mod.apk
clear
else
echo -e ""
echo "Descargando Pixel Launcher"
echo -e ""
wget https://www.dropbox.com/s/cz1fdh0ctfs6d3p/nexuslauncher-mod.apk?dl=0;mv nexuslauncher-mod.apk?dl=0 nexuslauncher-mod.apk;xdg-open nexuslauncher-mod.apk;
fi
clear
;;
       

      4|04)
echo Verificando Arquitectura Android
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi
#
#screenfetch >> ~/adq.txt
#adq='arm|armeabi|armv7l|x86|armv8l|aarch64'
#arc="$(grep -owE "$adq" ~/adq.txt)"
#echo "$arc"
#rm -r ~/adq.txt
screenfetch >> ~/adq.txt
adq='v7|x86|v8|h64'
arc="$(grep -Eio "$adq" ~/adq.txt)"
#echo "$arc"
rm -r ~/adq.txt

#arc="$(screenfetch)"
#X="$(echo ${arc:538:9})"
# Eliminar espacios en blanco
#va="$(echo "$X" | sed  s/\ //g)"
#ve="$(echo "$X" | sed  s/\ //g)"
#vi="$(echo "$X" | sed -e "s/[ \t\n\r\v]//g")"
#echo ${va} >/dev/null 2>&1
#echo ${ve} >/dev/null 2>&1
#echo -e ${vi} >/dev/null 2>&1

if [ -e ${HOME}/AirDroid-v4.2.7.1.apk ]; then 
echo -e ""
echo "AirDroid ARMv7"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open AirDroid-v4.2.7.1.apk
clear
else
if [ "$arc" == "v7" ]; then
echo -e ""
echo "Descargando AirDroid ARMv7"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/0eagqmdxa2q44et/AirDroid-v4.2.7.1.apk?dl=0;mv AirDroid-v4.2.7.1.apk?dl=0 AirDroid-v4.2.7.1.apk;xdg-open AirDroid-v4.2.7.1.apk;
echo -e ""
clear
fi
fi


if [ -e ${HOME}/AirDroid-v4.2.7.1-X86-64.apk ]; then 
echo -e ""
echo "AirDroid x86"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open AirDroid-v4.2.7.1-X86-64.apk
clear
else
if [ "$arc" == "x86" ]; then
echo -e ""
echo "Descargando AirDroid x86"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/nd7oo2v38m6l3al/AirDroid-v4.2.7.1-X86-64.apk?dl=0;mv AirDroid-v4.2.7.1-X86-64.apk?dl=0 AirDroid-v4.2.7.1-X86-64.apk;xdg-open AirDroid-v4.2.7.1-X86-64.apk;
echo -e ""
clear
fi
fi

if [ -e ${HOME}/AirDroid-ARM64-v4.2.9.5.apk ]; then
echo -e ""
echo "AirDroid ARM64"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open AirDroid-ARM64-v4.2.9.5.apk
clear
else
if [[ "$arc" == "v8" || "$arc" == "h64" ]]; then
echo -e ""
echo "Descargando AirDroid ARMv8"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/s84tcdp9itntz2d/AirDroid-4.2.9.5.apk?dl=0;mv AirDroid-4.2.9.5.apk?dl=0 AirDroid-ARM64-v4.2.9.5.apk;xdg-open AirDroid-ARM64-v4.2.9.5.apk;
echo -e ""
clear
fi
fi

read -p "Presione cualquier tecla para seguir"
clear
;;


      5|05) termux-open https://play.google.com/store/apps/details?id=com.teamviewer.teamviewer.market.mobile
clear
;;

      6|06) 
echo -e ""
if [ -e ${HOME}/Host.ver.15.19.88.build.1519088.apk ]; then
echo "Team Host"
echo "Ya esta descargado"
sleep 2
xdg-open Host.ver.15.19.88.build.1519088.apk;
clear
else
echo -e ""
echo "Descargando TeamHost"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/yyeabcyxt8oxnym/Host.ver.15.19.88.build.1519088.apk?dl=0;mv Host.ver.15.19.88.build.1519088.apk?dl=0 Host.ver.15.19.88.build.1519088.apk;xdg-open Host.ver.15.19.88.build.1519088.apk;
echo -e ""
fi

echo -e ""
if [ -e ${HOME}/QuickSupport.Add-On.ver.10.0.3086.build.3086.apk ]; then
echo "QuickSupport.Add-On"
echo "Ya esta descargado"
echo -e ""
sleep 2
xdg-open QuickSupport.Add-On.ver.10.0.3086.build.3086.apk
clear
else
echo -e ""
echo "Descargando QuickSupport.Add"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/6qxq520bgjmmhg9/QuickSupport.Add-On.ver.10.0.3086.build.3086.apk?dl=0 >/dev/null 2>&1;mv QuickSupport.Add-On.ver.10.0.3086.build.3086.apk?dl=0 QuickSupport.Add-On.ver.10.0.3086.build.3086.apk;xdg-open QuickSupport.Add-On.ver.10.0.3086.build.3086.apk;
fi
clear
;;


       7|07)
echo -e ""
if [ -e /sdcard/Calculadora_v4.3.3.build.113.apks ]; then
echo "Calculadora_v4.3.3.build.113"
echo "Ya esta descargado"
sleep 2
xdg-open SAI.apk
clear
else
echo -e ""
echo "Descargando Calculadora Cientifica v4.3.3.build.113"
echo -e ""
cd /sdcard;wget https://www.dropbox.com/s/ztbi9i9gm9z2uj5/Calculadora_v4.3.3.build.113.apks?dl=0;mv Calculadora_v4.3.3.build.113.apks?dl=0 Calculadora_v4.3.3.build.113.apks;cd ${HOME};wget https://www.dropbox.com/s/1b1t3rz90y28zcv/SAI.apk?dl=0;mv SAI.apk?dl=0 SAI.apk;echo "Te redireccionaremos para que instales sai";echo "con esta aplicion podras instalar apks";echo "y la Calculadora v4.3.3 esta en ese formato.";echo "Cuando instales sai, lo abres y buscas";echo "en la sdcard este archivo:";echo "Calculadora_v4.3.3.build.113.apks";echo "le das click y listo prosigue a instalar";echo "sigue las instrucciones que te va indicando";read -n 1 -p "Presiona cualquier tecla para continuar";xdg-open SAI.apk;
echo -e ""
clear
fi
;;

       8|08)
echo -e ""
if [ -e ${HOME}/Root_Explorer-v4.10.apk ]; then
echo "Root_Explorer-v4.10"
echo "Ya esta descargado"
sleep 2
xdg-open Root_Explorer-v4.10.apk
clear
else
echo -e ""
echo "Descargando Root Explorer v4.10"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/u6wwzhuuc67m50f/Root_Explorer-v4.10_build_199.apk?dl=0;mv Root_Explorer-v4.10_build_199.apk?dl=0 Root_Explorer-v4.10.apk;xdg-open Root_Explorer-v4.10.apk;
echo -e ""
clear
fi
;;


       9|09) echo Verificando Arquitectura Android
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi
#
screenfetch >> adq.txt
adq='v7|x86|v8|h64'
arc="$(grep -Eio "$adq" ~/adq.txt)"
rm -r ~/adq.txt 

echo -e ""
if [ -e ${HOME}/IDM-Plus-Mod-armv7.apk ]; then
echo "IDM+ v15.2 Mod-ARMv7"
echo  "Ya esta descargado"
sleep 2
xdg-open IDM-Plus-Mod-armv7.apk
clear
else
if [[ "$arc" == "x86" || "$arc" == "v7" ]]; then
echo -e ""
echo "Descargando IDM+ v15.2 Mod-ARMv7"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/pt9t68ax5paffaa/IDM-Plus-Mod-armv7.apk?dl=0;mv IDM-Plus-Mod-armv7.apk?dl=0 IDM-Plus-Mod-armv7.apk;xdg-open IDM-Plus-Mod-armv7.apk;
echo -e ""
clear
fi
fi

echo -e ""
if [ -e ${HOME}/IDM-Plus-Mod-armv8.apk ]; then
echo "IDM+ v15.2 Mod-ARM64"
echo Ya esta descargado
sleep 2
xdg-open IDM-Plus-Mod-armv8.apk
clear
else
if [[ "$arc" == "v8" || "$arc" == "h64" ]]; then
echo -e ""
echo "Descargando IDM+ v15.2 Mod-ARM64"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/u0drfw10f4nuwnt/IDM-Plus-Mod-armv8.apk?dl=0;mv IDM-Plus-Mod-armv8.apk?dl=0 IDM-Plus-Mod-armv8.apk;xdg-open IDM-Plus-Mod-armv8.apk;
echo -e ""
clear
fi
fi
;;


       10)
echo -e ""
if [ -e ${HOME}/Videoder_Pro_14.5.apk ]; then
echo "Videoder Pro v14.5"
echo "Ya esta descargado"
sleep 2
xdg-open Videoder_Pro_14.5.apk
clear
else
echo -e ""
echo "Descargando Videoder Pro v14.5"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/64sypheacfu0wnv/Videoder_Pro_14.5.apk?dl=0;mv Videoder_Pro_14.5.apk?dl=0 Videoder_Pro_14.5.apk;xdg-open Videoder_Pro_14.5.apk;
echo -e ""
clear
fi
;;


       11)
bash Busca-Palabras/opc/dibujo-animacion.sh
;;


       
       12)
echo -e ""
if [ -e ${HOME}/QuickEdit_Pro_Mod.apk ]; then
echo "QuickEdit Pro Mod"
echo "Ya esta descargado"
sleep 2
xdg-open QuickEdit_Pro_Mod.apk
clear
else
echo -e ""
echo "Descargando QuickEdit Pro Mod"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/8l0gle4i3wfm8zg/QuickEdit_Pro_Mod.apk?dl=0;mv QuickEdit_Pro_Mod.apk?dl=0 QuickEdit_Pro_Mod.apk;xdg-open QuickEdit_Pro_Mod.apk;
echo -e ""
clear
fi
;;



 
       13)
bash Busca-Palabras/opc/whatsapp-backup.sh
;;

       14)
bash Busca-Palabras/opc/ttsreader.sh
;;


       15) echo Verificando Arquitectura Android
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi
#
screenfetch >> ~/adq.txt
adq='v7|x86|v8|h64'
arc="$(grep -Eio "$adq" ~/adq.txt)"
rm -r ~/adq.txt

echo -e ""
if [ -e ${HOME}/MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk ]; then
echo "MX Player Pro Mod Lite V1.36.11 ARMv7" 
echo "Ya esta descargado"
sleep 2
xdg-open MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk
clear
else
if [[ "$arc" == "v7" || "$arc" == "x86" ]]; then
echo -e ""
echo "Descargando MX Player Pro Mod Lite v1.36.11 arm"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/o52b9w9uo9jv6jo/MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk?dl=0;mv MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk?dl=0 MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk;xdg-open MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk;
echo -e ""
clear
fi
fi

echo -e ""
if [ -e ${HOME}/MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk ]; then
echo "MX Player Mod Lite v1.38.3 ARM64"
echo "Ya esta descargado"
sleep 2
xdg-open MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk
clear
else
if [[ "$arc" == "v8" || "$arc" == "h64" ]]; then
echo -e ""
echo "Descargando MX Player Mod Lite v1.38.3 arm64"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/08q2ej9fnxejtxj/MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk?dl=0;mv MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk?dl=0 MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk;xdg-open MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk;
echo -e ""
clear
fi
fi
;;


      16)
echo -e ""
if [ -e ${HOME}/Universal_Copy_v5.3.2_mod.apk ]; then
echo "Universal_Copy_v5.3.2_mod"
echo "Ya esta descargado"
sleep 2
xdg-open Universal_Copy_v5.3.2_mod.apk
clear
else
echo -e ""
echo "Descargando Universal Copy v5.3.2 mod"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/teubl6gczrwbxtw/Universal_Copy_v5.3.2_mod.apk?dl=0;mv Universal_Copy_v5.3.2_mod.apk?dl=0 Universal_Copy_v5.3.2_mod.apk;xdg-open Universal_Copy_v5.3.2_mod.apk;
echo -e ""
clear
fi
;;


      17)
vsa=a
while [ "$vsa" = "a" ]; do
clear
echo -e ""
echo "Nota: Proceda a instalar primero el
complemento MicroG Vanced despues
que seleccione una opcion"
echo -e ""
echo -e "            YouTube Vanced"
echo -e "   Elige la version para tu Android "
echo -en "${verde}+------------------------------------+
# "[${blanco}01${verde}] | ${blanco}YouTube v15.05.54 gama baja" ${verde}#
#------------------------------------#
# "[${blanco}02${verde}] | ${blanco}YouTube v16.29.39 gama alta" ${verde}#
#------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Volver al menu app premium"  ${verde}#
+------------------------------------+
|
+->>> "${blanco}
read -r vsa

if [ "$vsa" == "1" ]; then
echo "MicroG Vanced v0.2.6.1"
echo -e ""
if [ -e ${HOME}/microg_youtube_vanced_0.2.6.1.apk ]; then
echo "MicroG Vanced v0.2.6.1"
echo "Ya esta descargado"
sleep 2
xdg-open microg_youtube_vanced_0.2.6.1.apk
clear
else
echo -e ""
echo "Descargando MicroG Vanced v0.2.6.1"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/v3jkpcerray5flr/microg_youtube_vanced_0.2.6.1.apk?dl=0;mv microg_youtube_vanced_0.2.6.1.apk?dl=0 microg_youtube_vanced_0.2.6.1.apk;echo "Instale este complemento primero!";sleep 2;xdg-open microg_youtube_vanced_0.2.6.1.apk
fi
if [ -e /sdcard/youtube_vanced_15.05.54_black.apk ]; then
echo "YouTube Vanced v15.05.54 Black"
echo "Ya esta descargado"
sleep 2
xdg-open /sdcard/youtube_vanced_15.05.54_black.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando YouTube Vanced v15.05.54 Black"
echo -e ""
wget https://www.dropbox.com/s/gvncm6oi3zlss8m/youtube_vanced_15.05.54_black.apk?dl=0;mv youtube_vanced_15.05.54_black.apk;xdg-open /sdcard/youtube_vanced_15.05.54_black.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vsa" == "2" ]; then
echo -e ""
if [ -e ${HOME}/microg_v0.2.21.apk ]; then
echo "MicroG v0.2.21"
echo "Ya esta descargado"
sleep 2
xdg-open microg_v0.2.21.apk
clear
else
echo -e ""
echo "Descargando MicroG v0.2.21"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/irmez2lm28zzbaw/microg_v0.2.21.apk?dl=0;mv microg_v0.2.21.apk?dl=0 microg_v0.2.21.apk;echo "Instale este complemento primero!";sleep 2;xdg-open microg_v0.2.21.apk
fi
if [ -e /sdcard/youtube_vanced_16.29.39.apks ]; then
echo "YouTube Vanced v16.29.39"
echo "Ya esta descargado"
sleep 2
clear
else
echo -e ""
echo "Descargando YouTube Vanced v16.29.39"
echo -e ""
cd /sdcard;wget https://www.dropbox.com/s/gb5xasadnkvc05t/youtube_vanced_16.29.39.apks;
fi

if [ -e ${HOME}/SAI.apk ]; then
echo -e ""
echo "SAI ya esta descargado"
echo "Te redireccionaremos para que instales sai";echo "con esta aplicion podras instalar apks";echo "y el YouTube Vanced esta en ese formato.";echo "Cuando instales sai, lo abres y buscas";echo "en la sdcard este archivo:";echo "youtube_vanced_16.29.39.apks";echo "le das click y listo prosigue a instalar";echo "sigue las instrucciones que te va indicando";read -n 1 -p "Presiona cualquier tecla para continuar";xdg-open SAI.apk;bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
else
echo -e ""
echo "Descargando SAI"
wget https://www.dropbox.com/s/1b1t3rz90y28zcv/SAI.apk?dl=0;mv SAI.apk?dl=0 SAI.apk;echo "Te redireccionaremos para que instales sai";echo "con esta aplicion podras instalar apks";echo "y el YouTube Vanced esta en ese formato.";echo "Cuando instales sai, lo abres y buscas";echo "en la sdcard este archivo:";echo "youtube_vanced_16.29.39.apks";echo "le das click y listo prosigue a instalar";echo "sigue las instrucciones que te va indicando";read -n 1 -p "Presiona cualquier tecla para continuar";xdg-open SAI.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vsa" == "3" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
fi
echo -en "Opcion invalida"
sleep 2
vsa=a
done
exit
;;


      18)
echo -e ""
if [ -e ${HOME}/gstrings_2.3.3.apk ]; then
echo "Afinador-GStrings_v2.3.3"
echo "Ya esta descargado"
sleep 2
xdg-open gstrings_2.3.3.apk
clear
else
echo -e ""
echo "Descargando Afinador-GStrings_v2.3.3"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/vi7t6yr82nxbqz6/gstrings_2.3.3.apk?dl=0;mv gstrings_2.3.3.apk?dl=0 gstrings_2.3.3.apk;xdg-open gstrings_2.3.3.apk;
echo -e ""
clear
fi
;;


      19)
echo -e ""
if [ -e ${HOME}/Guitar_Pro_1.6.4.apk ]; then
echo "Guitar_Pro_1.6.4"
echo "Ya esta descargado"
sleep 2
xdg-open Guitar_Pro_1.6.4.apk
clear
else
echo -e ""
echo "Descegando Guitar Pro v1.6.4"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/dbmzhidfrf10h08/Guitar_Pro_1.6.4.apk?dl=0;mv Guitar_Pro_1.6.4.apk?dl=0 Guitar_Pro_1.6.4.apk;xdg-open Guitar_Pro_1.6.4.apk;
echo -e ""
clear
fi
;;


      20)
echo -e ""
if [ -e ${HOME}/speed-changer-pro-mod-paid-3-24-48.apk ]; then
echo "Music Speed Changer Pro v3-24-48"
echo "Ya esta descargado"
sleep 2
xdg-open speed-changer-pro-mod-paid-3-24-48.apk
clear
else
echo -e ""
echo "Descargando Music-Speed-Changer-Pro"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/3z49h6ifptw2m4m/music-speed-changer-pro-mod-paid-3-24-48.apk?dl=0;mv music-speed-changer-pro-mod-paid-3-24-48.apk?dl=0 speed-changer-pro-mod-paid-3-24-48.apk;xdg-open speed-changer-pro-mod-paid-3-24-48.apk;
echo -e ""
clear
fi
;;

      21)
flm=a
while [ "$flm" = "a" ]; do
clear
if [ -e /sdcard/Android/obb/com.imageline.FLM/main.302014.com.imageline.FLM.obb ]; then
if [ -e /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34 ]; then
echo -e ""
vin="$(echo "Datos actuales instalados v3.2.34!!")"
echo "Actualmente tiene instalado
FL-Studio-Mobile-v3.2.34!"
fi


if [ -e /sdcard/Android/obb/com.imageline.FLM/main.303012.com.imageline.FLM.obb ]; then
if [ -e /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8 ]; then
echo -e ""
vin="$(echo "Datos actuales instalados v3.4.8!!")"
echo "Actualmente tiene instalado
FL-Studio-Mobile-v3.4.8!"
fi
fi
fi

#echo -e "            Fl Studio Mobile"
echo -e ""
echo "Nota: Al elegir una opcion, primero
procedera a instalar el apk y luego 
vuelva a termux y deje que se 
descarguen los complementos!"
echo -e ""
echo "Desinstala una version para instalar otra!"
echo -e "  "$vin""
echo -e "   Elige la version para tu Android "
echo -en "${verde}+------------------------------------+
# "[${blanco}01${verde}] | ${blanco}FL Studio Mobile v3.2.34"    ${verde}#
#------------------------------------#
# "[${blanco}02${verde}] | ${blanco}FL Studio Mobile v3.4.8"     ${verde}#
#------------------------------------#
# "[${blanco}03${verde}] | ${blanco}FL Studio Mobile v3.6.6"     ${verde}#
#------------------------------------#
# "[${blanco}04${verde}] | ${blanco}Volver al menu app premium"  ${verde}#
+------------------------------------+
|
+->>> "${blanco}
read -r "flm"

if [[ "$flm" == "1" || "$flm" == "01" ]]; then
#touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34
echo -e ""
if [ -e ${HOME}/fl_studio_mobile_v3.2.34.apk ]; then
echo -e ""
echo "FL Studio Mobile v3.2.34"
echo "Ya esta descargado"
sleep 2
xdg-open fl_studio_mobile_v3.2.34.apk
else
echo -e ""
echo -e ""
echo "Descargando FL Studio Mobile v3.2.34"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/3dcjgzyqj81368i/fl_studio_mobile_v3.2.34.apk?dl=0;mv fl_studio_mobile_v3.2.34.apk?dl=0 fl_studio_mobile_v3.2.34.apk;echo "Instale esta apk y no la abra, y vuelva
a termux hasta que se descarguen
los complementos";sleep 2;xdg-open fl_studio_mobile_v3.2.34.apk;
fi
if [ -d ${HOME}/archivo-obb-v3.2.34/com.imageline.FLM ]; then
echo -e ""
echo -e ""
echo "Archivo obb v3.2.34"
echo "Ya esta descargado"
echo "Moviendo archivo obb, espere"
rm -r /sdcard/Android/obb/com.imageline.FLM
mkdir -p /sdcard/Android/obb
cp -r ${HOME}/archivo-obb-v3.2.34/* /sdcard/Android/obb/
rm -r /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8 >/dev/null 2>&1
mkdir -p /sdcard/FLM" "User" "Files
touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34
else
echo -e ""
echo -e ""
echo "Descargando archivo obb v3.2.34"
echo -e ""
wget https://www.dropbox.com/s/91e2d6f543nv6v3/com.imageline.flm.zip?dl=0;mv com.imageline.flm.zip?dl=0 com.imageline.flm.zip;mkdir -p ${HOME}/archivo-obb-v3.2.34;unzip -o com.imageline.flm.zip -d ${HOME}/archivo-obb-v3.2.34 ;rm -r com.imageline.flm.zip;mkdir -p /sdcard/Android/obb;echo "Moviendo archivo obb, espere";rm -r /sdcard/Android/obb/com.imageline.FLM;cp -r ${HOME}/archivo-obb-v3.2.34/* /sdcard/Android/obb/;rm -r /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8 >/dev/null 2>&1;mkdir -p /sdcard/FLM" "User" "Files;touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34
fi

echo -e ""
echo -e ""
read -p "Deseas incluir paquete de baterias S/N? " yn
if [[ "$yn" = "s" || "$yn" = "S" ]]; then
if [ -d ${HOME}/Drums ]; then
echo -e ""
echo -e ""
echo "FLM-DRUMS"
echo "Ya esta descargado"
echo "Moviendo archivos, espere!"
sleep 2
mkdir -p /sdcard/FLM" "User" "Files
cd ${HOME}/
cp -r Drums/* /sdcard/FLM" "User" "Files
echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.2.34 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
else
echo -e ""
echo -e ""
echo -e ""
echo -e "Descargando paquete de baterias"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/xr0ehoj48ymmdzf/drums.zip?dl=0;mv drums.zip?dl=0 FLM-DRUMS.zip;unzip -o FLM-DRUMS.zip;rm -r FLM-DRUMS.zip;mkdir -p /sdcard/FLM" "User" "Files;echo "Moviendo archivos, espere";cp -r Drums/* /sdcard/FLM" "User" "Files

echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.2.34 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
exit
fi
fi
fi

if [[ "$yn" = "n" || "$yn" = "N" ]]; then
echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.2.34 COMPLETADO
SIN PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
exit
fi

if [[ "$flm" == "2" || "$flm" == "02" ]]; then
#touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8
echo -e ""
if [ -e ${HOME}/FL_Studio_Mobile_3.4.8__2458.apk ]; then
echo -e ""
echo "FL Studio Mobile v3.4.8"
echo "Ya esta descargado"
sleep 2
xdg-open FL_Studio_Mobile_3.4.8__2458.apk
else
echo -e ""
echo -e ""
echo "Descargando FL Studio Mobile v3.4.8"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/7pvfyxxsgi3khbt/FL_Studio_Mobile_3.4.8__2458.apk?dl=0;mv FL_Studio_Mobile_3.4.8__2458.apk?dl=0 FL_Studio_Mobile_3.4.8__2458.apk;echo "Instale esta apk y no la abra, y vuelva
a termux hasta que se descarguen
los complementos";sleep 2;xdg-open FL_Studio_Mobile_3.4.8__2458.apk;
fi
if [ -e ${HOME}/archivo-obb-v3.4.8/com.imageline.FLM ]; then
echo -e ""
echo -e ""
echo "Archivo obb v3.4.8"
echo "Ya esta descargado"
echo "Moviendo archivo obb, espere!"
rm -r /sdcard/Android/obb/*
mkdir -p /sdcard/Android/obb
cp -r ${HOME}/archivo-obb-v3.4.8/* /sdcard/Android/obb/
rm -r /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34 >/dev/null 2>&1
mkdir -p /sdcard/FLM" "User" "Files
touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8
else
echo -e ""
echo -e ""
echo "Descargando archivo obb v3.4.8"
echo -e ""
wget https://www.dropbox.com/s/evo4wyyfianbv06/com.imageline.flm.zip?dl=0;mv com.imageline.flm.zip?dl=0 com.imageline.flm.zip;mkdir -p ${HOME}/archivo-obb-v3.4.8;unzip -o com.imageline.flm.zip -d ${HOME}/archivo-obb-v3.4.8;rm -r com.imageline.flm.zip;mkdir -p /sdcard/Android/obb;echo "Moviendo archivo obb, espere!";rm -r /sdcard/Android/obb/*;cp -r ${HOME}/archivo-obb-v3.4.8/* /sdcard/Android/obb/;rm -r /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.2.34 >/dev/null 2>&1;mkdir -p /sdcard/FLM" "User" "Files;touch /sdcard/FLM" "User" "Files/FL-Studio-Mobile-v3.4.8
fi

echo -e ""
echo -e ""
echo -e ""
read -p "Deseas incluir paquete de baterias S/N? " yn
if [[ "$yn" = "s" || "$yn" = "S" ]]; then
if [ -d ${HOME}/Drums ]; then
echo -e ""
echo -e ""
echo "FLM-DRUMS-SONGS"
echo "Ya esta descargado"
echo "Moviendo archivos, espere"
sleep 2
mkdir -p /sdcard/FLM" "User" "Files
cp -r Drums/* /sdcard/FLM" "User" "Files
echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.4.8 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
else
echo -e ""
echo -e ""
echo -e ""
echo -e "Descargando paquete de baterias y songs"
echo -e ""
wget https://www.dropbox.com/s/xr0ehoj48ymmdzf/drums.zip?dl=0;mv drums.zip?dl=0 FLM-DRUMS.zip;unzip -o FLM-DRUMS.zip;rm -r FLM-DRUMS.zip;mkdir -p /sdcard/FLM" "User" "Files;echo "Moviendo archivos, espere";cp -r Drums/* /sdcard/FLM" "User" "Files

echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.4.8 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
exit
fi
fi
fi

if [[ "$flm" == "3" || "$flm" == "03" ]]; then
echo -e ""
if [ -e ${HOME}/fl-studio-mobile-mod-apk-v3-6-6-306060.apk ]; then
echo -e ""
echo "FL Studio Mobile v3.6.6"
echo "Ya esta descargado"
sleep 2
xdg-open fl-studio-mobile-mod-apk-v3-6-6-306060.apk
else
echo -e ""
echo -e ""
echo "Descargando FL Studio Mobile v3.6.6"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/35r43dmgh1kp7pa/fl-studio-mobile-mod-apk-v3-6-6-306060.apk?dl=0;mv fl-studio-mobile-mod-apk-v3-6-6-306060.apk?dl=0 fl-studio-mobile-mod-apk-v3-6-6-306060.apk;xdg-open fl-studio-mobile-mod-apk-v3-6-6-306060.apk;
fi

echo -e ""
echo -e ""
echo -e ""
read -p "Deseas incluir paquete de baterias S/N? " yn
if [[ "$yn" = "s" || "$yn" = "S" ]]; then
if [ -d ${HOME}/Drums ]; then
echo -e ""
echo -e ""
echo "FLM-DRUMS-SONGS"
echo "Ya esta descargado"
echo "Moviendo archivos, espere"
sleep 2
mkdir -p /sdcard/FLM" "User" "Files
cp -r Drums/* /sdcard/FLM" "User" "Files
echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.6.6 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
else
echo -e ""
echo -e ""
echo -e ""
echo -e "Descargando paquete de baterias y songs"
echo -e ""
wget https://www.dropbox.com/s/xr0ehoj48ymmdzf/drums.zip?dl=0;mv drums.zip?dl=0 FLM-DRUMS.zip;unzip -o FLM-DRUMS.zip;rm -r FLM-DRUMS.zip;mkdir -p /sdcard/FLM" "User" "Files;echo "Moviendo archivos, espere";cp -r Drums/* /sdcard/FLM" "User" "Files

echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.6.6 COMPLETADO
MAS PAQUETE DE BATERIAS!!!"
sleep 4
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
exit
fi
fi
fi

if [[ "$yn" = "n" || "$yn" = "N" ]]; then
echo -e ""
echo -e ""
echo -e "FL STUDIO MOBILE v3.6.6 COMPLETADO
SIN PAQUETE DE BATERIAS!!!"
sleep 2
echo -e ""
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
exit
fi

if [[ "$flm" == "4" || "$flm" == "04" ]]; then
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
fi
echo -en "Opcion invalida"
sleep 2
flm=a
done
exit
;;

      22)
pwa=a
while [ "$pwa" = "a" ]; do
clear
echo -e ""
echo -e "            Poweramp Mod"
echo -e "   Elige la version para tu Android "
echo -en "${verde}+------------------------------------+
# "[${blanco}01${verde}] | ${blanco}Poweramp v3-b-853 gama baja" ${verde}#
#------------------------------------#
# "[${blanco}02${verde}] | ${blanco}Poweramp v3-b-910 gama alta" ${verde}#
#------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Volver al menu app premium"  ${verde}#
+------------------------------------+
|
+->>> "${blanco}
read -r pwa
echo -e ""

if [ "$pwa" == "1" ]; then
echo -e ""
echo "Poweramp Music Player"
if [ -e ${HOME}/poweramp-patch-full.apk ]; then
echo "PowerAmp Pro v3-build-853"
echo "Ya esta descargado"
sleep 2
xdg-open poweramp-patch-full.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando PowerAmp Pro v3-build-853"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/4bu0lhc73cqab62/poweramp-patch-full.apk?dl=0;mv poweramp-patch-full.apk?dl=0 poweramp-patch-full.apk;xdg-open poweramp-patch-full.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi



if [ "$pwa" == "2" ]; then
echo -e ""
echo "Poweramp Music Player"
if [ -e ${HOME}/Poweramp_Music_Player_v3_build_904_MOD.apk ]; then
echo "PowerAmp Pro v3-build-910"
echo "Ya esta descargado"
sleep 2
xdg-open Poweramp_Music_Player_v3_build_904_MOD.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando PowerAmp Pro v3-build-910"
echo -e ""
cd ${HOME};git clone https://github.com/RobertNissan/PowerAmpFull
unzip ~/PowerAmpFull/Poweramp_Music_Player_v3_build_904_MOD.zip -d ~/ 
rm -rf PowerAmpFull
xdg-open Poweramp_Music_Player_v3_build_904_MOD.apk
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$pwa" == "3" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
pwa=a
done
exit
;;

      23)
echo -e ""
if [ -e ${HOME}/es-file-explorer-pro-v4.2.8.1.apk ]; then
echo "Es_File_Explorer_Pro_v4.2.8.1"
echo "Ya esta descargado"
sleep 2
xdg-open es-file-explorer-pro-v4.2.8.1.apk
clear
else
echo -e ""
echo "Descargando Es_File_Explorer_Pro_v4.2.8.1"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/v91e1a10wegb6xl/es-file-explorer-pro-v4.2.8.1.apk?dl=0;mv es-file-explorer-pro-v4.2.8.1.apk?dl=0 es-file-explorer-pro-v4.2.8.1.apk;xdg-open es-file-explorer-pro-v4.2.8.1.apk;
echo -e ""
clear
fi
;;

      24)
smpa=a
while [ "$smpa" = "a" ]; do
clear
echo -e ""
echo -e "        Video Compressor Mod"
echo -e "   Elige la version para tu Android "
echo -en "${verde}+------------------------------------+
# "[${blanco}01${verde}] | ${blanco}Smart Video Compressor"      ${verde}#
#------------------------------------#
# "[${blanco}02${verde}] | ${blanco}Video  Panda Compressor"      ${verde}#
#------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Volver al menu app premium"  ${verde}#
+------------------------------------+
|
+->>> "${blanco}
read -r smpa
echo -e ""

if [ "$smpa" == "1" ]; then
echo -e ""
if [ -e ${HOME}/smart_video_compressor_and_resizer_premium_v1.8.apk ]; then
echo "Smart Video Compressor Premium v1.8"
echo "Ya esta descargado"
sleep 2
xdg-open smart_video_compressor_and_resizer_premium_v1.8.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando Smart Video Compressor Premium v1.8"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/7goeut6fycmiy6h/smart_video_compressor_and_resizer_premium_v1.8.apk?dl=0;mv smart_video_compressor_and_resizer_premium_v1.8.apk?dl=0 smart_video_compressor_and_resizer_premium_v1.8.apk;xdg-open smart_video_compressor_and_resizer_premium_v1.8.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi



if [ "$smpa" == "2" ]; then
echo -e ""
echo "Video  Panda v1.1.48 Compresor"
if [ -e ${HOME}/video-panda-v1.1.48-premium.apk ]; then
echo "Video  Panda v1.1.48"
echo "Ya esta descargado"
sleep 2
xdg-open video-panda-v1.1.48-premium.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando Video  Panda v1.1.48 Compresor"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/e4oesmfifqi2zqj/video-panda-v1.1.48-premium.apk?dl=0;mv video-panda-v1.1.48-premium.apk?dl=0 video-panda-v1.1.48-premium.apk;xdg-open video-panda-v1.1.48-premium.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$smpa" == "3" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
smpa=a
done
exit
;;


       25)
echo -e ""
if [ -e ${HOME}/video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk ]; then
echo "Video Converter v1.5.4"
echo Ya esta descargado
sleep 2
xdg-open video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk
clear
else
echo "Instalando Video Converter v1.5.4"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/6od95kt7fpptact/video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk?dl=0;mv video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk?dl=0 video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk;xdg-open video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk;
echo -e ""
clear
fi
;;


      26)
echo -e ""
if [ -e ${HOME}/audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk ]; then
echo "Audio Converter v8-0-90"
echo Ya esta descargado
sleep 2
xdg-open smart_video_compressor_and_resizer_premium_v1.8.apk
clear
else
echo "Instalando Audio Converter v8-0-90"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/f5ihdz059nf2cql/audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk?dl=0;mv audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk?dl=0 audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk;xdg-open audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk;
echo -e ""
clear
fi
;;

     27)
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
;;


      28)
echo -e ""
if [ -e ${HOME}/speechkeys-smart-voice-typing-mod.apk ]; then
echo "Speechkeys Smart Voice Typing"
echo "Ya esta descargado"
sleep 2
xdg-open speechkeys-smart-voice-typing-mod.apk
clear
else
echo -e ""
echo "Descargando Speechkeys Smart Voice Typing"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/zu7xtshql4enbxj/speechkeys-smart-voice-typing-mod.apk?dl=0;mv speechkeys-smart-voice-typing-mod.apk?dl=0 speechkeys-smart-voice-typing-mod.apk;xdg-open speechkeys-smart-voice-typing-mod.apk;
fi
echo -e ""
read -p "Deseas agregar Speechnotes S/N? " yn
if [[ "$yn" = "s" || "$yn" = "S" ]];  then
echo -e ""
clear
if [ -e ${HOME}/Speechnotes.apk ]; then
echo "Speechnotes"
echo "Ya esta descargado"
sleep 2
xdg-open Speechnotes.apk
clear
else
echo -e ""
echo "Descargando Speechnotes"
echo -e ""
wget https://www.dropbox.com/s/4z15g5zpr9icpmt/Speechnotes.apk?dl=0;mv Speechnotes.apk?dl=0 Speechnotes.apk;xdg-open Speechnotes.apk;
fi
fi

echo "necesita Google para reconocimiento
de voz"
echo "Puedes hackear Google con Lucky Patcher
para tener las voces offline"
read -n 1 -p "Presione cualquier tecla para ir"
termux-open https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox
echo -e ""
clear
;;


       29) echo Verificando Arquitectura Android
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi
#
screenfetch >> ~/adq.txt
adq='v7|x86|v8|h64'
arc="$(grep -Eio "$adq" ~/adq.txt)"
rm -r ~/adq.txt

echo -e ""
if [ -e ${HOME}/armv7_simple_gallery_pro_v6.25.0.apk ]; then
echo "Simple Galeria V6.25.0 ARMV7" 
echo "Ya esta descargado"
sleep 2
xdg-open armv7_simple_gallery_pro_v6.25.0.apk
clear
else
if [[ "$arc" == "v7" || "$arc" == "x86" ]]; then
echo -e ""
echo "Descargando Simple Galeria V6.25.0 ARMV7"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/4f9g1tj1py2oo7a/Galeria_6.25.0_x86.apk?dl=0;mv Galeria_6.25.0_x86.apk?dl=0 armv7_simple_gallery_pro_v6.25.0.apk;xdg-open armv7_simple_gallery_pro_v6.25.0.apk;
echo -e ""
clear
fi
fi

echo -e ""
if [ -e ${HOME}/arm64_simple_gallery_pro_v6.25.0.apk ]; then
echo "Simple Galeria V6.25.0 ARM64"
echo "Ya esta descargado"
sleep 2
xdg-open arm64_simple_gallery_pro_v6.25.0.apk
clear
else
if [[ "$arc" == "v8" || "$arc" == "h64" ]]; then
echo -e ""
echo "Descargando Simple Galeria V6.25.0 ARM64"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/dhmythri5juup4v/Galeria_6.25.0_x64.apk?dl=0;mv Galeria_6.25.0_x64.apk?dl=0 arm64_simple_gallery_pro_v6.25.0.apk;xdg-open arm64_simple_gallery_pro_v6.25.0.apk;
echo -e ""
clear
fi
fi
;;


      30)
vpn=a
while [ "$vpn" = "a" ]; do
clear
echo -e ""
echo -e "                VPN Mod"
echo -e "   Elige la version para tu Android "
echo -en "${verde}+------------------------------------+
# "[${blanco}01${verde}] | ${blanco}VPNhub Pro v3.16.12 Mod"     ${verde}#
#------------------------------------#
# "[${blanco}02${verde}] | ${blanco}VPN Unlimited v8.7.0"        ${verde}#
#------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Fast VPN v1.6.1"             ${verde}#
#------------------------------------#
# "[${blanco}04${verde}] | ${blanco}HTTP Custom VPN"             ${verde}#
#------------------------------------#
# "[${blanco}05${verde}] | ${blanco}Volver al menu app"          ${verde}#
+------------------------------------+
|
+->>> "${blanco}
read -r vpn
echo -e ""

if [ "$vpn" == "1" ]; then
echo -e ""
if [ -e ${HOME}/VPNhub-Pro-v3.16.12-Mod.apk ]; then
echo "VPNhub Pro v3.16.12 Mod"
echo "Ya esta descargado"
sleep 2
xdg-open VPNhub-Pro-v3.16.12-Mod.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando VPNhub Pro v3.16.12 Mod"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/iof980yqstr68dx/VPNhub-Pro-v3.16.12-Mod.apk?dl=0;mv VPNhub-Pro-v3.16.12-Mod.apk?dl=0 VPNhub-Pro-v3.16.12-Mod.apk;xdg-open VPNhub-Pro-v3.16.12-Mod.apk;
echo -e ""
clear
vpn=a
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vpn" == "2" ]; then
if [ -e ${HOME}/VPN_Unlimited_v8.7.0_Premium.apk ]; then
echo -e ""
echo "VPN Unlimited v8.7.0 Premium"
echo Ya esta descargado
sleep 2
xdg-open VPN_Unlimited_v8.7.0_Premium.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
else
echo -e ""
echo "Instalando VPN Unlimited v8.7.0"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/ujspg8clqevzsa4/VPN_Unlimited_v8.7.0_Premium.apk?dl=0;mv VPN_Unlimited_v8.7.0_Premium.apk?dl=0 VPN_Unlimited_v8.7.0_Premium.apk;xdg-open VPN_Unlimited_v8.7.0_Premium.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vpn" == "3" ]; then
echo -e ""
if [ -e ${HOME}/Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk ]; then
echo "Fast VPN v1.6.1 Mod"
echo "Ya esta descargado"
sleep 2
xdg-open Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando Fast VPN Pro v1.6.1 Mod"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/mc1lkhdma4k7mgq/Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk?dl=0;mv Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk?dl=0 Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk;xdg-open Fast_VPN_Fast_Secure_Proxy_Mod_1.6.1.apk;
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vpn" == "4" ]; then
echo -e ""
if [ -e ${HOME}/HTTP_Custom_4.2.8.apk ]; then
echo "HTTP_Custom_v4.2.8"
echo "Ya esta descargado"
sleep 2
xdg-open HTTP_Custom_4.2.8.apk
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
clear
else
echo -e ""
echo "Descargando HTTP_Custom_v4.2.8"
echo -e ""
cd ${HOME}
curl -O https://www.mediafire.com/file/32t1gp2uj9bwzoc/HTTP_Custom_4.2.8.apk/file
link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
rm -rf file
wget --no-check-certificate ${link} 
xdg-open HTTP_Custom_4.2.8.apk
echo -e ""
clear
bash ${HOME}/Busca-Palabras/opc/team-droid.sh
break
fi
fi

if [ "$vpn" == "5" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
vpn=a
done
exit
;;


 31)
bash ${HOME}/Busca-Palabras/opc/tasker-bot.sh
exit       
exit
;;


       32)
echo "Limpiando las descargas"
sleep 1
rm -r /sdcard/youtube_vanced_16.29.39.apks >/dev/null 2>&1
rm -r /sdcard/Calculadora_v4.3.3.build.113.apks >/dev/null 2>&1
rm -r Drums >/dev/null 2>&1
rm -r ${HOME}/archivo-obb-v3.2.34 >/dev/null 2>&1
rm -r ${HOME}/archivo-obb-v3.4.8 >/dev/null 2>&1
rm -r 'My Songs' >/dev/null 2>&1
cd ${HOME};rm -r termux-boot.apk Termux_API_0.50.1.apk Apex_Launcher_Pro_v4.9.20.apk nexuslauncher-mod.apk AirDroid-v4.2.7.1.apk AirDroid-v4.2.7.1-X86-64.apk AirDroid-ARM64-v4.2.9.5.apk Host.ver.15.19.88.build.1519088.apk QuickSupport.Add-On.ver.10.0.3086.build.3086.apk speed-changer-pro-mod-paid-3-24-48.apk Root_Explorer-v4.10.apk IDM-Plus-Mod-armv7.apk IDM-Plus-Mod-armv8.apk Videoder_Pro_14.5.apk ibisPaint_X_v10.0.2_Premium.apk flipaclip.create.2d.animation.mod.v3.1.23.1.2.apk clip_studio_paint_1.12.7.apk QuickEdit_Pro_Mod.apk WA_AERO_Modern_Hazar.apk TTSReader_Pro_v2.41_b25_Premium_Mod.apk Vocaqlizer_TTS_Pro3.1.11-1.apk Voice_Aloud_Reader_23.3.15_MOD.apk Voice_License_1.7.3_Patched.apk MX_Player_Pro_Mod_Lite_1.36.11_Armeabi_v7a.apk MX_Player_Mod_Lite_1.38.3_Arm64_v8a.apk Universal_Copy_v5.3.2_mod.apk youtube_vanced_15.05.54_black.apk microg_v0.2.21.apk microg_youtube_vanced_0.2.6.1.apk SAI.apk gstrings_2.3.3.apk Guitar_Pro_1.6.4.apk fl_studio_mobile_v3.2.34.apk FL_Studio_Mobile_3.4.8__2458.apk fl-studio-mobile-mod-apk-v3-6-6-306060.apk es-file-explorer-pro-v4.2.8.1.apk smart_video_compressor_and_resizer_premium_v1.8.apk audio-converter-mp3-aac-wma-opus-mp3-cutter-mod-apk-v8-0-90.apk soundwire.v.3.0.b.38crk.apk Unified_Remote_Full_com.Relmtech.RemotePaid.apk poweramp-patch-full.apk poweramp-full-910-uni-mod.apk Poweramp_Music_Player_v3_build_904_MOD.apk speechkeys-smart-voice-typing-mod.apk Speechnotes.apk armv7_simple_gallery_pro_v6.25.0.apk arm64_simple_gallery_pro_v6.25.0.apk video-to-mp3-converter-mp3-cutter-and-merger-mod-v1-5-4-unlocked-gprx-1540.apk VPN_Unlimited_v8.7.0_Premium.apk VPNhub-Pro-v3.16.12-Mod.apk AutoResponder_for_WA_v3.0.0_Premium.apk tasker.mod.apk.v5.14.6.apk Vocalizer_TTS_Pro3.1.11-1.apk Tasker_Pro_6.0.10_b5323.apk HTTP_Custom_4.2.8.apk >/dev/null 2>&1
clear
;;



       33) cd ${HOME}/Busca-Palabras;bash Menu-Busca-Palabras.sh
exit
;;

       *) echo "opcion invalida";sleep 1;clear
;;
esac
done