#!/bin/bash

# Definir códigos de color
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # Sin color

# Funcion para manejar la senal SIGTSTP (Ctrl+Z)
handler_SIGTSTP() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Funcion para manejar la senal SIGINT (Ctrl+C)
handler_SIGINT() {
    # Limpiar la salida y detener el progreso
    # printf "\nProceso interrumpido por el usuario.\033[K\n\n"
    exit 0
}

# Asignar las funciones del controlador a las senales SIGTSTP y SIGINT
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

# Verificar si los permisos de almacenamiento ya han sido concedidos
# Ruta de prueba
prueba_ruta="/sdcard/.prueba_permiso_termux.txt"
# Verificar el estado del almacenamiento
verificar_almacenamiento() {
    if [ -d "/sdcard/" ]; then
        # Intentar crear un archivo para verificar los permisos
        echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
        if [ -f "$prueba_ruta" ]; then
            echo -e "\n${GREEN}Los permisos de almacenamiento ya han sido concedidos.${NC}"
            rm "$prueba_ruta"  # Eliminar el archivo de prueba
            return 0
        else
            echo -e "${RED}El directorio existe, pero los permisos de escritura no están disponibles.${NC}"
        fi
    fi

    # Si llegamos aquí, es porque no se tienen los permisos
    echo -e "${YELLOW}Concediendo permisos de almacenamiento...${NC}"
    termux-setup-storage
    sleep 5  # Esperar un momento para permitir que se concedan los permisos

    # Verificar de nuevo los permisos
    if [ -d "/sdcard/" ]; then
        echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
        if [ -f "$prueba_ruta" ]; then
            echo -e "${GREEN}Permisos de almacenamiento concedidos correctamente.${NC}"
            rm "$prueba_ruta"  # Eliminar el archivo de prueba
            return 0
        else
            echo -e "${RED}No se pudieron conceder los permisos de almacenamiento. Asegúrate de aceptar la solicitud de permisos.${NC}"
            return 1
        fi
    else
        echo -e "${RED}El directorio de almacenamiento no está disponible. Asegúrate de aceptar la solicitud de permisos.${NC}"
        return 1
    fi
}
# Ejecutar la función
verificar_almacenamiento

# Verificar si Python está instalado
if [ -x ${PREFIX}/bin/python ]; then
    echo "Python ya está instalado." >/dev/null 2>&1
else 
    echo "Instalando python..."
    apt install python -y
    pkg install python-pip
    # dpkg --configure -a
    # apt list --upgradable
    # apt upgrade
    # apt-get check
    # apt clean
fi

# Verificar si gdown está instalado
if ! command -v gdown &> /dev/null; then
    echo "gdown no está instalado. Instalando gdown..."
    pip install gdown
    if [ $? -ne 0 ]; then
        echo "Error al instalar gdown. Asegúrate de tener pip instalado."
        exit 1
    fi
else
    echo "gdown ya está instalado." >/dev/null 2>&1
fi

# Verificar si adb está instalado
if [ -x "$PREFIX/bin/adb" ]; then
    echo "adb instalado." >/dev/null 2>&1
    adb start-server
else
    echo "Instalando adb..."
    pkg install android-tools -y >/dev/null 2>&1
    echo "adb instalado correctamente."
fi

# Verificar si nmap está instalado
if [ -x "$PREFIX/bin/nmap" ]; then
    echo "nmap instalado." >/dev/null 2>&1
else
    echo "Instalando nmap..."
    pkg install nmap -y >/dev/null 2>&1
    echo "nmap instalado correctamente."
fi
if [ -x $PREFIX/share/doc/termux-api ]; then
    echo Existe >/dev/null 2>&1
else 
    echo "Instalando termux-api"
    pkg install termux-api
fi

if [ -f $PREFIX/bin/unrar ]; then
    echo "existe" >/dev/null 2>&1
else
    echo "Instalando Repositorios:"
    echo -e "" 
    echo "Instalando unrar"
    pkg install unrar
fi

if [ -f $PREFIX/bin/rarp ]; then
    echo "existe" >/dev/null 2>&1
else
    echo "Instalando Repositorios:"
    echo -e "" 
    echo "Instalando rar"
    pkg install rar
fi

if [ -f $PREFIX/bin/zip ]; then
    echo "Ya existe" >/dev/null 2>&1
else
    echo "Instalando Repositorios:"
    echo -e "" 
    echo "Instalando zip"
    pkg install zip
fi

# Función para instalar paquetes si no están presentes
instalar_paquete() {
    if [ ! -f $PREFIX/bin/$1 ]; then
        echo "Instalando $2"
        pkg install -y $1
    else
        echo "$2 ya está instalado" >/dev/null 2>&1
    fi
}

# Instalar herramientas necesarias
instalar_paquete "zip" "zip"
instalar_paquete "rarp" "rar"
instalar_paquete "unrar" "unrar"
instalar_paquete "apksigner" "apksigner"
instalar_paquete "mediainfo" "mediainfo"

# Crear directorios necesarios
mkdir -p /sdcard/Download/Games
mkdir -p /sdcard/Download/Games/N64/ROMS
mkdir -p /sdcard/Download/Games/PSE
mkdir -p /sdcard/Download/Games/N3DS/roms
mkdir -p /sdcard/Download/Games/N3DS/texturas
mkdir -p /sdcard/Download/Games/Modern_Combat

# ip=$(ifconfig wlan0 | grep 'inet ' | awk '{print $2}')

# Con busybox
# ip=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

: '
str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
ip=$(echo "${str%%/*}")
: '

: ' 
# Si no puede obtener la IP usando ip addr, usa Termux-API
if command -v termux-wifi-connectioninfo &>/dev/null; then
    ip=$(termux-wifi-connectioninfo | grep "ip" | awk -F ':' '{print $2}' | tr -d ',')
    if [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo "IP obtenida a través de Termux-API: $ip"
    else
        echo "No se pudo obtener la IP a través de Termux-API."
    fi
else
    echo "No se pudo obtener la IP. Faltan permisos o comandos."
fi
: '


#######FUNCIONES_DE_CONEXION#######
disponible_adb='false'

mi_dispositivo() {
    echo ""
    echo "Brand ID: $(getprop ro.product.system.brand)"
    echo "Modelo: $(getprop ro.product.model)"
    echo "Version de Android: $(getprop ro.build.version.release)"
    echo "Model ID: $(getprop ro.build.product)"
    echo "Kernel ID: $(uname -r)"
    echo "Chipset ID: $(getprop ro.product.board)"
    echo "Architecture: $(uname -m)"
}

# Función para mostrar la tabla de dispositivos
mostrar_dispositivos() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        # seleccionar_dispositivo "$ip_objetivo"
        disponible_adb='true'
    fi
    
    conn=$(adb connect "$ip:5555")
    if [[ "$conn" == "failed"* ]]; then
        echo "ok" >/dev/null 2>&1
    else
        echo "Conexion a Internet a traves del enrutador WiFi1"
        conn=$(adb connect "${ip0}:5555")
        sleep 3
        # seleccionar_dispositivo
    fi
    
    encabezado_tabla='false'
    mi_dispositivo
    my_device="$1"
    columns=$(tput cols)
    col=$(($columns - 1))
    mul=$(($col*7/100))
    mul2=$(($col*47/100))
    mul3=$(($col*27/100))
    mul4=$(($col*9/100))

    ID="ID"
    CLI="SERVIDOR ADB"
    DEU="MODELO"
    VER="VER"
    
    printf_string="# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n"
    PRINTF_RESULT=$(printf "$printf_string" "$ID" "$CLI" "$DEU" "$VER")
    char_count=$(echo -n "$PRINTF_RESULT" | wc -m --char)
    #echo "Numero de caracteres (incluyendo espacios) en la fila: $char_count"
    # aqui va el ajuste resposive
    for i in {1..301}; do
        medida=$(($char_count + $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 + $i))
            break 
        fi
        medida=$(($char_count - $i))
        if [[ "$medida" -eq "$columns" ]]; then
            mul2=$(($mul2 - $i))
            break
        fi
    done 
    
    dispositivos=()
    # variable de conteo de cantidad de dispositivos a mostrar en la tabla
    id=1

    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    # offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}')
    offline_devices=$(echo "$adb_output" | grep "offline" | awk '{print $1}' | grep -v "$my_device")
    unauthorized_devices=$(echo "$adb_output" | grep "unauthorized" | awk '{print $1}')
    
    if [[ -n "$connected_devices" ]]; then
        for device in $connected_devices; do
            if [ "$encabezado_tabla" == 'false' ]; then
                echo ""
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | %-${mul4}s #\n" " ID" "SERVIDOR ADB" "MODELO" "VER"
                printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
                encabezado_tabla='true'
            fi
            dispositivos+=("$device")
            # Formatear el id con 2 dígitos
            id_fortmat=$(printf "%02d" "$id")
            model=$(adb -s "$device" shell getprop ro.product.model)
            version=$(adb -s "$device" shell getprop ro.build.version.release)
            printf "# %-${mul}s | %-${mul2}s | %-${mul3}s | v%-${mul4}s#\n" " $id_fortmat" "$device" "$model" "$version"
            printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
            id=$((id+1))
        done
    else
        solicitar_emparejamiento # Solicitar emparejamiento si no hay dispositivos conectados
        exit 1
    fi
    : '
    # Mostrar los dispositivos offline
    if [[ -n "$offline_devices" ]]; then
        echo ""
        echo "Dispositivos OFFLINE:"
        echo "$offline_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi

    # Mostrar los dispositivos no autorizados
    if [[ -n "$unauthorized_devices" ]]; then
        echo ""
        echo "Dispositivos NO AUTORIZADOS:"
        echo "$unauthorized_devices"
        # Pie de la tabla
        printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')"
    fi
    : '
}

# Función para solicitar la selección del dispositivo
seleccionar_dispositivo() {
    mostrar_dispositivos
    
    # arreglar el input read de bash cuando no ingresa nada y no borra
    # Configurar correctamente el terminal para manejar retroceso y teclas especiales
    stty erase $(tput kbs)
    stty sane
    menu_principal
    : '
    echo -en "Ingrese el número del dispositivo o 'q+enter' para salir: "
    read seleccion
    
    if [[ "$seleccion" == "q" ]]; then
        echo "Saliendo..."
        exit 0
    elif [[ "$seleccion" =~ ^[0-9]+$ ]] && [ "$seleccion" -le "${#dispositivos[@]}" ] && [ "$seleccion" -gt 0 ]; then
        dispositivo_seleccionado=${dispositivos[$((seleccion-1))]}
        mostrar_menu "$dispositivo_seleccionado"
    else
        echo "Selección inválida."
        seleccionar_dispositivo
    fi
    : '
}

# Función para mostrar el menú y ejecutar la opción seleccionada
mostrar_menu() {
    dispositivo="$1"
    echo ""
    
    # Verificar si el dispositivo está conectado
    if adb -s "$dispositivo" get-state 1 >/dev/null 2>&1; then
        adb -s "$dispositivo" shell echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼📱 ]"
        if [ $? -eq 0 ]; then
            echo "Comando ejecutado correctamente en el dispositivo $dispositivo" >/dev/null
        else
            seleccionar_dispositivo
        fi
    else
        seleccionar_dispositivo
    fi

    # Mostrar información del dispositivo
    adb -s "$dispositivo" shell echo "[ DEVICE: \$(getprop ro.product.model) ]"
    adb -s "$dispositivo" shell echo "[ BRAND: \$(getprop ro.product.system.brand) ]"
    adb -s "$dispositivo" shell echo "[ MODEL: \$(getprop ro.build.product) ]"
    adb -s "$dispositivo" shell echo "[ KERNEL: \$(uname -r) ]"
    
    gpu_info=$(adb -s "$dispositivo" shell getprop ro.hardware.gpu)
    if [ -n "$gpu_info" ]; then
        adb -s "$dispositivo" shell echo "[ GPU: \$(getprop ro.hardware.gpu) ]"
    else
        gpu_info=$(adb -s "$dispositivo" shell dumpsys SurfaceFlinger | grep GLES | awk -F, '{print $1, $2}')
        adb -s "$dispositivo" shell echo "[ GPU: $gpu_info ]"
    fi

    adb -s "$dispositivo" shell echo "[ CPU: \$(getprop ro.hardware) ]"
    adb -s "$dispositivo" shell echo "[ ANDROID VERSION: \$(getprop ro.build.version.release) ]"
    adb -s "$dispositivo" shell echo "[ Android ID: \$(getprop ro.serialno) ]"
    
}

function connect {
    capp_adb='false'
    
    if [ "$capp_adb" == "false" ]; then
        echo -e "${GREEN}Conectando al puerto principal adb.\nPor favor, espere...${NC}"
    fi
    
    # ip_objetivo=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}' | cut -d'/' -f1)
    # ip_objetivo=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
    ip_objetivo=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')
    num_threads=5

    # Definir el script de Python con threading
    python_script=$(cat <<EOF
import os
import signal
import multiprocessing
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

ip_objetivo = "$ip_objetivo"
num_processes = 10  # Puedes ajustar este valor segun tus necesidades

# Definir una funcion para manejar la senal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una funcion para manejar la senal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    # Limpiar la salida y detener el progreso
    sys.exit(0)

# Asignar la funcion del controlador a la senal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

def scan_ports(ip, start, end):
    nm = nmap.PortScanner()
    port_range = f"{start}-{end}"
    result = nm.scan(ip, arguments=f'-p {port_range} -Pn -T4')

    if 'scan' not in result or ip not in result['scan']:
        print(f"\nError al obtener los resultados del escaneo para la IP {ip} en el rango de puertos {port_range}")
        print("Asegúrate de que la IP sea válida y responda a los escaneos de puertos.")
    else:
        if nm[ip].all_protocols():
            for protocol in nm[ip].all_protocols():
                lport = sorted(nm[ip][protocol].keys())
                for port in lport:
                    print("Puerto", port, ":", nm[ip][protocol][port]['state'])
        else:
            print(f"\nNo se encontraron puertos abiertos para la IP {ip} en el rango de puertos {port_range}")

# Dividir el rango de puertos para escanear en varios subconjuntos
port_ranges = [(i, i + 65535//num_processes) for i in range(1, 65536, 65535//num_processes)]

# Crear procesos para escanear los puertos en paralelo
processes = []
for start, end in port_ranges:
    process = multiprocessing.Process(target=scan_ports, args=(ip_objetivo, start, end))
    processes.append(process)
    process.start()

# Esperar a que todos los procesos terminen
for process in processes:
    process.join()
EOF
)

    ports_output=$(python -c "$python_script")

    if echo "$ports_output" | grep -q "open"; then
        num_ports=$(echo "$ports_output" | grep "open" | awk '{print $2}')
        
        for port in $num_ports; do
            echo -e "${YELLOW}Probando puerto${NC}: $port"
            # adb start-server >/dev/null 2>&1
            verif_con=$(adb connect "${ip_objetivo}:${port}")

            if [[ "$verif_con" == *"connected"* ]]; then
                echo -e "${GREEN}La conexión fue exitosa.${NC}"
                adb -s "${ip_objetivo}:${port}" tcpip 5555
                sleep 5
                # Esperar hasta que el dispositivo esté listo en el puerto 5555
                while ! adb connect "${ip_objetivo}:5555" >/dev/null 2>&1; do
                    echo -e "${YELLOW}Esperando a que ADB esté listo en el puerto 5555...${NC}"
                    sleep 1  # Esperar un segundo antes de intentar de nuevo
                done
                
                puerto="5555"
                # Conección permanente
                adb -s "${ip_objetivo}:5555" tcpip "${puerto}"
                sleep 5
                ip=$(echo "${ip_objetivo}:5555" | cut -d: -f1)
                DISPOSITIVO="${ip_objetivo}:5555"
                # echo "${DISPOSITIVO}" 
                adb connect "${DISPOSITIVO}" 
                # adb devices
                adb -s "${DISPOSITIVO}" shell settings put global development_settings_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_wifi_enabled 1
                adb -s "$DISPOSITIVO" shell settings put global adb_port 5555
                
                seleccionar_dispositivo "$ip_objetivo"
                exit
            # Si los puerto fallan, prueba de inmediato con otro.
            elif [[ "$verif_con" == *"offline"* || "$verif_con" == *"not found"* || "$verif_con" == *"failed"* ]]; then
                continue  # No es necesario matar el servidor aquí
            else
                echo -e "${RED}La conexión falló. Mensaje: $verif_con${NC}"
            fi
        done
    fi
    connect
    capp_adb='true'
    exit 2
}

# Función para solicitar el emparejamiento del dispositivo
solicitar_emparejamiento() {

    killall adb >/dev/null 2>&1
    adb kill-server >/dev/null 2>&1
    adb start-server >/dev/null 2>&1
    sleep 5
    adb_output=$(adb devices -l)
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    if [[ -n "$connected_devices" ]]; then
        seleccionar_dispositivo "$ip_objetivo"
    fi

    #sleep 3
    echo -e "\n${RED}Servidor adb, no encendido${NC}!!!"
    echo -e "${YELLOW}Siga las instrucciones${NC}:\n"
    echo "Habilitar la depuracion USB en Android, para hacer conexion adb:"
    echo "1. Abre la aplicacion Configuracion en tu dispositivo Android."
    echo "2. Ve a 'Acerca del telefono' o 'Acerca de la tablet'."
    echo "3. Toca repetidamente 'Numero de compilacion' hasta que se active el modo de desarrollador."
    echo "4. Regresa al menu principal de Configuracion y busca 'Opciones de desarrollador' o 'Opciones del sistema'."
    echo "5. Habilita 'Depuracion USB'."
    echo ""
    echo 'Si solo necesitas que se active en tu android, activa "Depuracion inalambirca"'
    echo '6. Selecciona donde dice: "Vincular dispositivo con codigo de sincronizacion"'
    echo -e  'En esa parte se mostrara una pequeña ventana que dice:'
    echo -e "Vincular con disposivo\n${YELLOW}Codigo de vinculacion de WI-FI\n${RED}123456\n${YELLOW}Direccion IP y PUERTO\n${YELLOW}${ip}${NC}:${BLUE}12345${NC}"
    echo '7. Habilitar la pantalla dividida entre "Vincular dispositivo con codigo de sincronizacion" y "Termux"' 

    echo -e "\nIngresa el puerto:"
    echo -en "$ip:"
    read puerto
    while [ -z "$puerto" ]; do
        # echo -en "${YELLOW}$ip:${BLUE}"
        read puerto
    done
    
    echo -en "Ingrese código de vinculación WI-FI: "
    read code
    while [ -z "${code}" ]; do
        echo -en "Ingrese código de vinculación WI-FI: "
        read code
    done
    
    echo -e "${YELLOW}Ejecutando: ${NC}adb pair ${YELLOW}${ip0}:${BLUE}${puerto} ${RED}${code}${NC}"
    adb pair ${ip0}:${puerto} ${code} 2>/dev/null
    # Si se conecta entonces: connect!!!
    # if [[ "${resultado}" == *"Failed"* || "${resultado}" == *"error"* ]]; then
    if [ $? -eq 0 ]; then
        echo -e "${YELLOW}Código correcto!!!.${NC}"
        connect
    else
        echo -e "${YELLOW}La conexion adb fallo. Mensaje:\n${RED}puerto o código erroneo...${NC}"
        return
    fi    
}

wlan0() {
    : '
    # Si no puede obtener la IP usando ip addr, usa Termux-API
    if command -v termux-wifi-connectioninfo &>/dev/null; then
        ip0=$(termux-wifi-connectioninfo | grep "ip" | awk -F ':' '{print $2}' | tr -d ',')
        if [[ "$ip0" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            echo "IP obtenida a través de Termux-API: $ip0" >/dev/null 2>&1
            disponible_adb="true"
            return
        else
            echo "No se pudo obtener la IP a través de Termux-API." >/dev/null 2>&1
        fi
    else
        echo "No se pudo obtener la IP. Faltan permisos o comandos." >/dev/null 2>&1
    fi
    : '
    # Obtener la IP de wlan0, si está disponible
    ip0=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Si no se encuentra IP en wlan0, buscar una IP distinta de 127.0.0.1
    if [ -z "$ip0" ]; then
        ip1=$(ip addr | awk '/inet / && !/127.0.0.1/ {print $2}' | cut -d/ -f1 | head -n 1)
    fi
    # Mostrar la IP de wlan0 si está disponible
    if [ "$ip0" ]; then
        disponible_adb='true'
        return
    fi
    # Mostrar otra IP si no se encontró en wlan0
    if [ "$ip1" ]; then
        # echo "La dirección IP (de otro adaptador) es: $ip1"
        echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1" >/dev/null 2>&1
        disponible_adb='false'
        return
    fi
    echo "$disponible_adb"
}

if [ "$disponible_adb" == 'false' ]; then
    echo "" >/dev/null 2>&1
fi
#######FUNCIONES_FIN_CONEXION#######
# verif_adb_conect #


# Funciones de configuración de Citra
configurar_pantalla_citra() {

    if [ ! -d /sdcard/citra-emu/config ]; then
        mkdir -p /sdcard/citra-emu/config
    else
        rm -rf /sdcard/citra-emu/config/* >/dev/null 2>&1
    fi
    if [ ! -d /sdcard/citra-emu/load/configs ]; then
        mkdir -p /sdcard/citra-emu/load/configs
    else
        rm -rf /sdcard/citra-emu/load/configs/* >/dev/null 2>&1
    fi
    # Ruta del archivo
    archivo="/sdcard/citra-emu/config/input-layout.ini"
    archivo_600="/sdcard/citra-emu/load/configs/0004000000033600.ini"

    # Bloque de texto con configuración
    configuracion="// landscape layout = X[-100,100], Y[-100,100], SCALE[0,200], VISIBLE[0,1]
        c_stick_landscape=70,-50,100,0
        button_a_landscape=102,61,100,1
        dpad_landscape=-92,63,100,0
        button_r_landscape=90,-10,100,1
        button_two_landscape=50,20,100,0
        button_b_landscape=91,85,100,1
        joystick_landscape=-71,64,100,1
        button_select_landscape=37,91,100,1
        button_y_landscape=80,63,100,1
        button_zl_landscape=-90,-50,100,0
        button_start_landscape=50,91,100,1
        button_home_landscape=95,-80,100,1
        button_zr_landscape=90,-50,100,0
        button_three_landscape=70,20,100,0
        button_one_landscape=30,20,100,0
        button_x_landscape=91,39,100,1
        button_l_landscape=-90,-20,100,1
        // portrait layout
        button_zl_portrait=-90,20,100,0
        button_l_portrait=-90,40,100,1
        button_r_portrait=90,40,100,1
        button_zr_portrait=90,20,100,0
        button_x_portrait=50,60,100,1
        button_two_portrait=0,20,100,0
        joystick_portrait=-20,50,100,1
        button_home_portrait=86,96,100,1
        button_b_portrait=50,80,100,1
        button_start_portrait=15,96,100,1
        button_one_portrait=-30,20,100,0
        dpad_portrait=-55,80,100,1
        button_three_portrait=30,20,100,0
        c_stick_portrait=20,50,100,0
        button_a_portrait=75,70,100,1
        button_select_portrait=-15,96,100,1
        button_y_portrait=25,70,100,1"
        
    configuracion_600="[Controls]
        combo_key_0 = 
        combo_key_1 = 
        combo_key_2 = 
        input_joystick_relative = True
        input_overlay_alpha = 100
        input_overlay_feedback = True
        input_overlay_hide = False
        input_overlay_scale = 40
        [Core]
        language = 5
        [Debug]
        async_shader_compile = False
        force_texture_filter = 0
        hw_gs_mode = 0
        shadow_rendering = True
        skip_cpu_write = False
        skip_slow_draw = False
        skip_texture_copy = False
        use_compatible_mode = False
        use_fmv_hack = True
        [Layout]
        landscape_bottom_bottom = 1058
        landscape_bottom_left = 365
        landscape_bottom_right = 1005
        landscape_bottom_top = 578
        landscape_custom_layout = False
        landscape_top_bottom = 722
        landscape_top_left = 20
        landscape_top_right = 1400
        landscape_top_top = 7
        portrait_bottom_bottom = 960
        portrait_bottom_left = 80
        portrait_bottom_right = 720
        portrait_bottom_top = 480
        portrait_top_bottom = 480
        portrait_top_left = 0
        portrait_top_right = 800
        portrait_top_top = 0
        portrait_custom_layout = True
        [Renderer]
        accurate_mul_type = 1
        custom_textures = True
        landscape_layout_option = 2
        layout_option = 2
        resolution_factor = 3
        use_fence_sync = True
        frame_limit = 100"

   # Usar 'sed' para quitar los espacios iniciales
    echo "$configuracion" | sed 's/^[ \t]*//' > "$archivo"
    echo -e "Configuración escrita en:\n$archivo"
    # Usar 'sed' para quitar los espacios iniciales
    echo "$configuracion_600" | sed 's/^[ \t]*//' > "$archivo_600"
    echo -e "Configuración escrita en:\n$archivo_600"
}

fps_stable_cheat() {
    # Ruta del archivo con la barra inicial en sdcard
    dir_cheat="/sdcard/citra-emu/cheats/"
    archivo_cheat="/sdcard/citra-emu/cheats/0004000000033600.txt"
    
    # Crear el directorio si no existe
    if [ ! -d "$dir_cheat" ]; then
        mkdir -p "${dir_cheat}"
    fi
    
    # Bloque de texto con la configuración del cheat, indentado para legibilidad
    configuracion_fps="[60FPS+JumpFix+CrawlFix]
        *citra_enabled
        D11C8680 0000
        801C6F2D 009C
        D11C8680 0000
        801C6FA1 0003
        D31C8680 0000
        801C6F2D 00D8
        D31C8680 0000
        801C6FA1 0001

        [Draw Distance Fix]
        *citra_enabled
        8010A711 0099

        [60FPS v1.5]
        18C61A84 00000000

        [60FPS (Hold R button for 30FPS)]
        D3000000 33000000
        00F67FE8 00000002
        DD000000 00000100
        00F67FE8 00000102
        D0000000 00000000

        [Unlock FPS(Citra)]
        *citra_enabled
        1088E 58400001 A49
        1088E 5840000 EEFO

        [60 FPS]
        *citra_enabled
        18C61A84 00000000

        [60 FPS]
        *citra_enabled
        D3000000 08000000
        000002A0 0000003C
        D2000000 00000000

        [FPS]
        *citra_enabled
        0932B2A0 42700000

        [Game Speed]
        *citra_enabled
        0932B29C 41F80000

        [stable]
        *citra_enabled
        0932B2A0 42820000"
    
    # Usar 'sed' para eliminar los espacios en blanco al inicio de cada línea
    echo "$configuracion_fps" | sed 's/^[ \t]*//' > "$archivo_cheat"
    
    # Verificar si el archivo fue creado
    if [ -f "$archivo_cheat" ]; then
        echo -e "Configuración escrita en:\n$archivo_cheat"
    else
        echo "Error: No se pudo crear el archivo."
    fi
}

fps_stable_cheat_psp_gow_coo() {
    # Ruta del archivo con la barra inicial en sdcard
    dir_cheat_psp="/sdcard/PSP/Cheats/"
    archivo_cheat_fps_psp="/sdcard/PSP/Cheats/UCES00842.ini"
    dir_system_psp="/sdcard/PSP/SYSTEM/"
    archivo_system_ini_psp="/sdcard/PSP/SYSTEM/ppsspp.ini"
    
    # Crear el directorio si no existe
    if [ ! -d "$dir_cheat_psp" ]; then
        mkdir -p "${dir_cheat_psp}"
    fi
    # Crear el directorio si no existe
    if [ ! -d "$dir_system_psp" ]; then
        mkdir -p "${dir_system_psp}"
    fi
    
    # Bloque de texto con la configuración del cheat, indentado para legibilidad
    configuracion_fps_gow_coo="_S UCUS-98653 / UCES-00842
        _G GoW CoO [USA/EUR]
        _C1 60 FPS [Fixed]
        _L 0xE00E003C 0x10003800
        _L 0xE00D0200 0x0001A378//Jump-0x10
        _L 0x10003800 0x0000003C
        _L 0x20003804 0x10800003
        _L 0x20003808 0x00000000
        _L 0x2000380C 0x0E2C16F9
        _L 0x20003810 0x00000000
        _L 0x20003814 0x0E2C16F9
        _L 0x20003818 0x00000000
        _L 0x2000381C 0x8FBF0010
        _L 0x20003820 0x03E00008
        _L 0x20003824 0x27BD0020
        _L 0x2001A388 0x0A200E01//Jump
        _L 0x2001A38C 0x34040000//FPS
        _L 0x2001A390 0x00000000
        _C0 30 FPS [Fixed]
        _L 0xE00E001E 0x10003800
        _L 0xE00D0200 0x0001A378//Jump-0x10
        _L 0x10003800 0x0000001E
        _L 0x20003804 0x10800003
        _L 0x20003808 0x00000000
        _L 0x2000380C 0x0E2C16F9
        _L 0x20003810 0x00000000
        _L 0x20003814 0x0E2C16F9
        _L 0x20003818 0x00000000
        _L 0x2000381C 0x8FBF0010
        _L 0x20003820 0x03E00008
        _L 0x20003824 0x27BD0020
        _L 0x2001A388 0x0A200E01//Jump
        _L 0x2001A38C 0x34040001//FPS
        _L 0x2001A390 0x00000000
        _C0 Unlimited FPS [Default]
        _L 0xE0040E01 0x0001A388
        _L 0x2001A388 0x8FBF0010
        _L 0x2001A38C 0x03E00008
        _L 0x2001A390 0x27BD0020
        _L 0x10003800 0x00000000"
        
    # Bloque de texto con la configuración del ppsspp.ini, indentado para legibilidad
    configuracion_ppsspp_ini="[General]
        FirstRun = False
        RunCount = 42
        Enable Logging = True
        AutoRun = True
        Browse = False
        IgnoreBadMemAccess = True
        CurrentDirectory = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp
        ShowDebuggerOnLoad = False
        CheckForNewVersion = False
        Language = es_LA
        ForceLagSync = False
        NumWorkerThreads = 8
        EnableAutoLoad = False
        EnableCheats = True
        CwCheatRefreshRate = 77
        ScreenshotsAsPNG = False
        StateSlot = 2
        RewindFlipFrequency = 0
        GridView1 = True
        GridView2 = False
        GridView3 = False
        ReportingHost = default
        AutoSaveSymbolMap = False
        CacheFullIsoInRam = False
        ScreenRotation = 1
        PauseWhenMinimized = False
        DumpDecryptedEboots = False
        ForceLagSync2 = False
        DiscordPresence = True
        UISound = False
        AutoLoadSaveState = 0
        CwCheatScrollPosition = 0.000000
        GameListScrollPosition = 0.000000
        UseFFV1 = False
        DumpFrames = False
        DumpVideoOutput = False
        DumpAudio = False
        SaveLoadResetsAVdumping = False
        EnableStateUndo = False
        StateLoadUndoGame = NA
        StateUndoLastSaveGame = NA
        StateUndoLastSaveSlot = -5
        RewindSnapshotInterval = 0
        ShowOnScreenMessage = True
        ShowRegionOnGameIcon = False
        ShowIDOnGameIcon = False
        GameGridScale = 1.000000
        RightAnalogUp = 0
        RightAnalogDown = 0
        RightAnalogLeft = 0
        RightAnalogRight = 0
        RightAnalogPress = 0
        RightAnalogCustom = False
        RightAnalogDisableDiagonal = False
        SwipeUp = 0
        SwipeDown = 0
        SwipeLeft = 0
        SwipeRight = 0
        SwipeSensitivity = 1.000000
        SwipeSmoothing = 0.300000
        DoubleTapGesture = 0
        GestureControlEnabled = False
        RemoteISOPort = 0
        LastRemoteISOServer = 
        LastRemoteISOPort = 0
        RemoteISOManualConfig = False
        RemoteShareOnStartup = False
        RemoteISOSubdir = /
        RemoteDebuggerOnStartup = False
        RemoteTab = False
        RemoteISOSharedDir = 
        RemoteISOShareType = 0
        InternalScreenRotation = 1
        BackgroundAnimation = 1
        TransparentBackground = True
        UITint = 0.000000
        UISaturation = 1.000000
        ShowMenuBar = True
        MemStickInserted = True
        EnablePlugins = True
        IgnoreCompatSettings = 
        RunBehindPauseMenu = False
        [CPU]
        Jit = True
        SeparateCPUThread = False
        SeparateIOThread = True
        IOTimingMethod = 0
        FastMemoryAccess = True
        FuncReplacements = True
        CPUSpeed = 0
        SetRoundingMode = True
        ForceFlushToZero = True
        CPUCore = 1
        SeparateSASThread = True
        FunctionReplacements = True
        HideSlowWarnings = False
        HideStateWarnings = False
        PreloadFunctions = False
        JitDisableFlags = 0x00000000
        [Graphics]
        EnableCardboard = False
        CardboardScreenSize = 50
        CardboardXShift = 0
        CardboardYShift = 0
        ShowFPSCounter = 0
        GPUBackend = 0
        RenderingMode = 0
        SoftwareRendering = False
        HardwareTransform = True
        SoftwareSkinning = True
        TextureFiltering = 1
        BufferFiltering = 1
        InternalResolution = 2
        AndroidHwScale = 0
        FrameSkip = 0
        AutoFrameSkip = False
        FrameRate = 0
        FrameSkipUnthrottle = True
        ForceMaxEmulatedFPS = 60
        AnisotropyLevel = 0
        VertexCache = True
        TextureBackoffCache = True
        TextureSecondaryCache = True
        PartialStretch = False
        StretchToDisplay = False
        SmallDisplay = False
        ImmersiveMode = False
        TrueColor = True
        MipMap = True
        TexScalingLevel = 1
        TexScalingType = 0
        TexDeposterize = False
        VSyncInterval = False
        DisableStencilTest = False
        AlwaysDepthWrite = False
        DepthRangeHack = False
        BloomHack = 0
        TimerHack = False
        AlphaMaskHack = False
        SplineBezierQuality = 2
        PostShader = Off
        MemBlockTransferGPU = True
        DisableSlowFramebufEffects = True
        FragmentTestCache = True
        EnableCardboardVR = False
        iShowStatusFlags = 0
        GraphicsBackend = 3 (VULKAN)
        FailedGraphicsBackends = 
        DisabledGraphicsBackends = 
        VulkanDevice = 
        CameraDevice = 
        AndroidFramerateMode = 1
        UseGeometryShader = False
        SkipBufferEffects = False
        DisableRangeCulling = False
        SoftwareRenderer = False
        SoftwareRendererJit = True
        Smart2DTexFiltering = False
        HighQualityDepth = 1
        FrameSkipType = 0
        StereoRendering = False
        StereoToMonoShader = RedBlue
        FrameRate2 = -1
        AnalogFrameRate = 240
        UnthrottlingMode = SKIP_FLIP
        MultiSampleLevel = 0
        DisplayOffsetX = 0.500000
        DisplayOffsetY = 0.500000
        DisplayScale = 1.000000
        DisplayIntegerScale = False
        DisplayAspectRatio = 1.000000
        DisplayStretch = False
        DisplayCropTo16x9 = True
        SustainedPerformanceMode = False
        IgnoreScreenInsets = True
        ReplaceTextures = True
        SaveNewTextures = False
        IgnoreTextureFilenames = False
        TexHardwareScaling = False
        VSync = True
        HardwareTessellation = False
        TextureShader = Off
        ShaderChainRequires60FPS = False
        SkipGPUReadbackMode = 0
        LogFrameDrops = False
        InflightFrames = 3
        RenderDuplicateFrames = False
        MultiThreading = True
        GpuLogProfiler = False
        UberShaderVertex = True
        UberShaderFragment = True
        [Sound]
        Enable = True
        AudioBackend = 0
        AudioLatency = 1
        SoundSpeedHack = False
        AudioResampler = True
        ExtraAudioBuffering = False
        GlobalVolume = 10
        ReverbVolume = 10
        AltSpeedVolume = -1
        AchievementSoundVolume = 6
        AudioDevice = 
        AutoAudioDevice = True
        [Control]
        HapticFeedback = True
        ShowTouchCross = True
        ShowTouchCircle = True
        ShowTouchSquare = True
        ShowTouchTriangle = True
        ShowTouchStart = True
        ShowTouchSelect = True
        ShowTouchLTrigger = True
        ShowTouchRTrigger = True
        ShowAnalogStick = True
        ShowTouchDpad = True
        ShowTouchUnthrottle = True
        ShowTouchPause = False
        ShowTouchControls = True
        TiltBaseX = 0.000000
        TiltBaseY = 0.000000
        InvertTiltX = False
        InvertTiltY = True
        TiltSensitivityX = 100
        TiltSensitivityY = 100
        DeadzoneRadius = 0.200000
        TiltInputType = 0
        DisableDpadDiagonals = False
        TouchButtonStyle = 1
        TouchButtonOpacity = 65
        ActionButtonSpacing2 = 1.000000
        ActionButtonCenterX = 0.895379
        ActionButtonCenterY = 0.805511
        ActionButtonScale = 1.150000
        DPadX = 0.124673
        DPadY = 0.533225
        DPadScale = 1.150000
        DPadSpacing = 1.000000
        StartKeyX = 0.599826
        StartKeyY = 0.888169
        StartKeyScale = 1.150000
        SelectKeyX = 0.499564
        SelectKeyY = 0.888169
        SelectKeyScale = 1.150000
        UnthrottleKeyX = 0.399303
        UnthrottleKeyY = 0.888169
        UnthrottleKeyScale = 1.150000
        LKeyX = 0.069747
        LKeyY = 0.074554
        LKeyScale = 1.150000
        RKeyX = 0.939843
        RKeyY = 0.074554
        RKeyScale = 1.150000
        AnalogStickX = 0.124673
        AnalogStickY = 0.850891
        AnalogStickScale = 1.150000
        AnalogLimiterDeadzone = 0.600000
        Custom0Mapping = 0x0000000000000000
        Custom0Image = 0
        Custom0Shape = 0
        Custom0Toggle = False
        Custom0Repeat = False
        Custom1Mapping = 0x0000000000000000
        Custom1Image = 1
        Custom1Shape = 0
        Custom1Toggle = False
        Custom1Repeat = False
        Custom2Mapping = 0x0000000000000000
        Custom2Image = 2
        Custom2Shape = 0
        Custom2Toggle = False
        Custom2Repeat = False
        Custom3Mapping = 0x0000000000000000
        Custom3Image = 3
        Custom3Shape = 0
        Custom3Toggle = False
        Custom3Repeat = False
        Custom4Mapping = 0x0000000000000000
        Custom4Image = 4
        Custom4Shape = 0
        Custom4Toggle = False
        Custom4Repeat = False
        Custom5Mapping = 0x0000000000000000
        Custom5Image = 0
        Custom5Shape = 1
        Custom5Toggle = False
        Custom5Repeat = False
        Custom6Mapping = 0x0000000000000000
        Custom6Image = 1
        Custom6Shape = 1
        Custom6Toggle = False
        Custom6Repeat = False
        Custom7Mapping = 0x0000000000000000
        Custom7Image = 2
        Custom7Shape = 1
        Custom7Toggle = False
        Custom7Repeat = False
        Custom8Mapping = 0x0000000000000000
        Custom8Image = 3
        Custom8Shape = 1
        Custom8Toggle = False
        Custom8Repeat = False
        Custom9Mapping = 0x0000000000000000
        Custom9Image = 4
        Custom9Shape = 1
        Custom9Toggle = False
        Custom9Repeat = False
        Custom10Mapping = 0x0000000000000000
        Custom10Image = 0
        Custom10Shape = 2
        Custom10Toggle = False
        Custom10Repeat = False
        Custom11Mapping = 0x0000000000000000
        Custom11Image = 1
        Custom11Shape = 2
        Custom11Toggle = False
        Custom11Repeat = False
        Custom12Mapping = 0x0000000000000000
        Custom12Image = 2
        Custom12Shape = 2
        Custom12Toggle = False
        Custom12Repeat = False
        Custom13Mapping = 0x0000000000000000
        Custom13Image = 3
        Custom13Shape = 2
        Custom13Toggle = False
        Custom13Repeat = False
        Custom14Mapping = 0x0000000000000000
        Custom14Image = 4
        Custom14Shape = 2
        Custom14Toggle = False
        Custom14Repeat = False
        Custom15Mapping = 0x0000000000000000
        Custom15Image = 0
        Custom15Shape = 9
        Custom15Toggle = False
        Custom15Repeat = False
        Custom16Mapping = 0x0000000000000000
        Custom16Image = 1
        Custom16Shape = 9
        Custom16Toggle = False
        Custom16Repeat = False
        Custom17Mapping = 0x0000000000000000
        Custom17Image = 2
        Custom17Shape = 9
        Custom17Toggle = False
        Custom17Repeat = False
        Custom18Mapping = 0x0000000000000000
        Custom18Image = 3
        Custom18Shape = 9
        Custom18Toggle = False
        Custom18Repeat = False
        Custom19Mapping = 0x0000000000000000
        Custom19Image = 4
        Custom19Shape = 9
        Custom19Toggle = False
        Custom19Repeat = False
        fcombo0X = 0.609803
        fcombo0Y = 0.499190
        comboKeyScale0 = 1.150000
        ShowComboKey0 = False
        fcombo1X = 0.701353
        fcombo1Y = 0.499190
        comboKeyScale1 = 1.150000
        ShowComboKey1 = False
        fcombo2X = 0.792903
        fcombo2Y = 0.499190
        comboKeyScale2 = 1.150000
        ShowComboKey2 = False
        fcombo3X = 0.609803
        fcombo3Y = 0.332253
        comboKeyScale3 = 1.150000
        ShowComboKey3 = False
        fcombo4X = 0.701353
        fcombo4Y = 0.332253
        comboKeyScale4 = 1.150000
        ShowComboKey4 = False
        fcombo5X = 0.390083
        fcombo5Y = 0.499190
        comboKeyScale5 = 1.150000
        ShowComboKey5 = False
        fcombo6X = 0.298533
        fcombo6Y = 0.499190
        comboKeyScale6 = 1.150000
        ShowComboKey6 = False
        fcombo7X = 0.206983
        fcombo7Y = 0.499190
        comboKeyScale7 = 1.150000
        ShowComboKey7 = False
        fcombo8X = 0.390083
        fcombo8Y = 0.332253
        comboKeyScale8 = 1.150000
        ShowComboKey8 = False
        fcombo9X = 0.298533
        fcombo9Y = 0.332253
        comboKeyScale9 = 1.150000
        ShowComboKey9 = False
        fcombo10X = 0.609803
        fcombo10Y = 0.581848
        comboKeyScale10 = 1.150000
        ShowComboKey10 = False
        fcombo11X = 0.701353
        fcombo11Y = 0.581848
        comboKeyScale11 = 1.150000
        ShowComboKey11 = False
        fcombo12X = 0.792903
        fcombo12Y = 0.581848
        comboKeyScale12 = 1.150000
        ShowComboKey12 = False
        fcombo13X = 0.609803
        fcombo13Y = 0.414911
        comboKeyScale13 = 1.150000
        ShowComboKey13 = False
        fcombo14X = 0.701353
        fcombo14Y = 0.414911
        comboKeyScale14 = 1.150000
        ShowComboKey14 = False
        fcombo15X = 0.390083
        fcombo15Y = 0.581848
        comboKeyScale15 = 1.150000
        ShowComboKey15 = False
        fcombo16X = 0.298533
        fcombo16Y = 0.581848
        comboKeyScale16 = 1.150000
        ShowComboKey16 = False
        fcombo17X = 0.206983
        fcombo17Y = 0.581848
        comboKeyScale17 = 1.150000
        ShowComboKey17 = False
        fcombo18X = 0.390083
        fcombo18Y = 0.414911
        comboKeyScale18 = 1.150000
        ShowComboKey18 = False
        fcombo19X = 0.298533
        fcombo19Y = 0.414911
        comboKeyScale19 = 1.150000
        ShowComboKey19 = False
        TiltBaseAngleY = 0.900000
        TiltInvertX = False
        TiltInvertY = False
        TiltAnalogDeadzoneRadius = 0.000000
        TiltInverseDeadzone = 0.000000
        TiltCircularDeadzone = True
        GamepadOnlyFocused = False
        TouchButtonHideSeconds = 20
        AutoCenterTouchAnalog = False
        StickyTouchDPad = False
        TouchSnapToGrid = False
        TouchSnapGridSize = 64
        RightAnalogStickX = 0.904356
        RightAnalogStickY = 0.850891
        RightAnalogStickScale = 1.150000
        ShowRightAnalogStick = False
        AnalogDeadzone = 0.150000
        AnalogInverseDeadzone = 0.000000
        AnalogSensitivity = 1.100000
        AnalogIsCircular = False
        AnalogAutoRotSpeed = 8.000000
        AnalogTriggerThreshold = 0.750000
        AllowMappingCombos = False
        StrictComboOrder = False
        LeftStickHeadScale = 1.000000
        RightStickHeadScale = 1.000000
        HideStickBackground = False
        UseMouse = False
        MapMouse = False
        ConfineMap = False
        MouseSensitivity = 0.100000
        MouseSmoothing = 0.900000
        MouseWheelUpDelayMs = 80
        SystemControls = True
        RapidFileInterval = 5
        AnalogGesture = False
        AnalogGestureSensibility = 1.000000
        [Network]
        EnableWlan = False
        EnableAdhocServer = False
        proAdhocServer = socom.cc
        PortOffset = 10000
        MinTimeout = 0
        ForcedFirstConnect = False
        EnableUPnP = False
        UPnPUseOriginalPort = False
        EnableNetworkChat = False
        ChatButtonPosition = 0
        ChatScreenPosition = 0
        EnableQuickChat = True
        QuickChat1 = Quick Chat 1
        QuickChat2 = Quick Chat 2
        QuickChat3 = Quick Chat 3
        QuickChat4 = Quick Chat 4
        QuickChat5 = Quick Chat 5
        [SystemParam]
        PSPModel = 0
        PSPFirmwareVersion = 150
        NickName = PPSSPP
        proAdhocServer = coldbird.net
        MacAddress = bf:74:78:30:ba:5e
        Language = 3
        TimeFormat = 1
        DateFormat = 1
        TimeZone = 0
        DayLightSavings = False
        ButtonPreference = 1
        LockParentalLevel = 0
        WlanAdhocChannel = 0
        WlanPowerSave = False
        EncryptSave = True
        GameLanguage = -1
        ParamTimeFormat = 0
        ParamDateFormat = 0
        BypassOSKWithKeyboard = False
        SavedataUpgradeVersion = True
        MemStickSize = 16
        [Debugger]
        DisasmWindowX = -1
        DisasmWindowY = -1
        DisasmWindowW = -1
        DisasmWindowH = -1
        GEWindowX = -1
        GEWindowY = -1
        GEWindowW = -1
        GEWindowH = -1
        ConsoleWindowX = -1
        ConsoleWindowY = -1
        FontWidth = 8
        FontHeight = 12
        DisplayStatusBar = True
        ShowBottomTabTitles = True
        ShowDeveloperMenu = False
        SkipDeadbeefFilling = False
        FuncHashMap = False
        GEWindowTabsBL = 0x00000000
        GEWindowTabsBR = 0x00000000
        GEWindowTabsTR = 0x00000000
        SkipFuncHashMap = 
        MemInfoDetailed = False
        [SpeedHacks]
        PrescaleUV = True
        DisableAlphaTest = True
        [Upgrade]
        UpgradeMessage = 
        UpgradeVersion = 
        DismissedVersion = 
        [Recent]
        MaxRecent = 30
        FileName0 = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp/God Of War Chains Of Olympus (Esp).iso
        FileName1 = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Ghost_Of_Sparta_Esp/God Of War Ghost Of Sparta (Esp).iso
        [Theme]
        ThemeName = Default
        [VR]
        VREnable = True
        VREnable6DoF = True
        VREnableStereo = False
        VREnableMotions = True
        VRForce72Hz = True
        VRManualForceVR = False
        VRPassthrough = False
        VRRescaleHUD = True
        VRCameraDistance = 0.000000
        VRCameraHeight = 0.000000
        VRCameraSide = 0.000000
        VRCameraPitch = 0
        VRCanvasDistance = 12.000000
        VRCanvas3DDistance = 3.000000
        VRHeadUpDisplayScale = 0.300000
        VRMotionLength = 0.500000
        VRHeadRotationScale = 5.000000
        VRHeadRotationEnabled = False
        VRHeadRotationSmoothing = False
        [Achievements]
        AchievementsEnable = True
        AchievementsChallengeMode = True
        AchievementsEncoreMode = False
        AchievementsUnofficial = False
        AchievementsLogBadMemReads = False
        bAchievementsSaveStateInChallengeMode = False
        AchievementsUserName = 
        AchievementsSoundEffects = True
        AchievementsUnlockAudioFile = 
        AchievementsLeaderboardSubmitAudioFile = 
        AchievementsLeaderboardTrackerPos = 3
        AchievementsLeaderboardStartedOrFailedPos = 3
        AchievementsLeaderboardSubmittedPos = 3
        AchievementsProgressPos = 3
        AchievementsChallengePos = 3
        AchievementsUnlockedPos = 4
        [Log]
        SYSTEMEnabled = True
        SYSTEMLevel = 2
        BOOTEnabled = True
        BOOTLevel = 2
        COMMONEnabled = True
        COMMONLevel = 2
        CPUEnabled = True
        CPULevel = 2
        FILESYSEnabled = True
        FILESYSLevel = 2
        G3DEnabled = True
        G3DLevel = 2
        HLEEnabled = True
        HLELevel = 2
        JITEnabled = True
        JITLevel = 2
        LOADEREnabled = True
        LOADERLevel = 2
        MEEnabled = True
        MELevel = 2
        MEMMAPEnabled = True
        MEMMAPLevel = 2
        SASMIXEnabled = True
        SASMIXLevel = 2
        SAVESTATEEnabled = True
        SAVESTATELevel = 2
        FRAMEBUFEnabled = True
        FRAMEBUFLevel = 2
        AUDIOEnabled = True
        AUDIOLevel = 2
        IOEnabled = True
        IOLevel = 2
        ACHIEVEMENTSEnabled = True
        ACHIEVEMENTSLevel = 2
        HTTPEnabled = True
        HTTPLevel = 2
        PRINTFEnabled = True
        PRINTFLevel = 2
        SCEAUDIOEnabled = True
        SCEAUDIOLevel = 2
        SCECTRLEnabled = True
        SCECTRLLevel = 2
        SCEDISPEnabled = True
        SCEDISPLevel = 2
        SCEFONTEnabled = True
        SCEFONTLevel = 2
        SCEGEEnabled = True
        SCEGELevel = 2
        SCEINTCEnabled = True
        SCEINTCLevel = 2
        SCEIOEnabled = True
        SCEIOLevel = 2
        SCEKERNELEnabled = True
        SCEKERNELLevel = 2
        SCEMODULEEnabled = True
        SCEMODULELevel = 2
        SCENETEnabled = True
        SCENETLevel = 2
        SCERTCEnabled = True
        SCERTCLevel = 2
        SCESASEnabled = True
        SCESASLevel = 2
        SCEUTILEnabled = True
        SCEUTILLevel = 2
        SCEMISCEnabled = True
        SCEMISCLevel = 2
        [PlayTime]
        UCES00842 = 7,1729279254704904448
        UCES01401 = 275,1729279246702391552"
    
    # Usar 'sed' para eliminar los espacios en blanco al inicio de cada línea
    echo "$configuracion_fps_gow_coo" | sed 's/^[ \t]*//' > "$archivo_cheat_fps_psp"
    
    # Usar 'sed' para eliminar los espacios en blanco al inicio de cada línea
    echo "$configuracion_ppsspp_ini" | sed 's/^[ \t]*//' > "$archivo_system_ini_psp"
    
    # Verificar si el archivo fue creado
    if [ -f "$archivo_cheat_fps_psp" ]; then
        echo -e "Configuración escrita en:\n$archivo_cheat_fps_psp"
    else
        echo -e "Error: No se pudo crear el archivo:\n$archivo_cheat_fps_psp"
    fi
    # Verificar si el archivo fue creado
    if [ -f "$archivo_system_ini_psp" ]; then
        echo -e "Configuración escrita en:\n$archivo_system_ini_psp"
    else
        echo -e "Error: No se pudo crear el archivo:\n$archivo_system_ini_psp"
    fi
}

fps_stable_cheat_psp_gow_gos() {
    # Ruta del archivo con la barra inicial en sdcard
    dir_cheat_psp="/sdcard/PSP/Cheats/"
    archivo_cheat_fps_psp="/sdcard/PSP/Cheats/UCES01401.ini"
    dir_system_psp="/sdcard/PSP/SYSTEM/"
    archivo_system_ini_psp="/sdcard/PSP/SYSTEM/ppsspp.ini"
    
    # Crear el directorio si no existe
    if [ ! -d "$dir_cheat_psp" ]; then
        mkdir -p "${dir_cheat_psp}"
    fi
    # Crear el directorio si no existe
    if [ ! -d "$dir_system_psp" ]; then
        mkdir -p "${dir_system_psp}"
    fi
    
    # Bloque de texto con la configuración del cheat, indentado para legibilidad
    configuracion_fps="_S UCES-01401
        _G GoW GoS [EUR-MULTI5-UMD]
        _C1 60 FPS [Fixed]
        _L 0xE00E003C 0x10003800
        _L 0xE00DE13C 0x000205DC//vblank
        _L 0x10003800 0x0000003C
        _L 0x20003804 0x10800003
        _L 0x20003808 0x00000000
        _L 0x2000380C 0x0E2FE13C
        _L 0x20003810 0x00000000
        _L 0x20003814 0x0E2FE13C
        _L 0x20003818 0x00000000
        _L 0x2000381C 0x8FBF0000
        _L 0x20003820 0x03E00008
        _L 0x20003824 0x27BD0010
        _L 0x2001B10C 0x0A200E01//Jump
        _L 0x2001B110 0x34040000//FPS
        _L 0x2001B114 0x00000000
        _C0 30 FPS [Fixed]
        _L 0xE00E001E 0x10003800
        _L 0xE00DE13C 0x000205DC//vblank
        _L 0x10003800 0x0000001E
        _L 0x20003804 0x10800003
        _L 0x20003808 0x00000000
        _L 0x2000380C 0x0E2FE13C
        _L 0x20003810 0x00000000
        _L 0x20003814 0x0E2FE13C
        _L 0x20003818 0x00000000
        _L 0x2000381C 0x8FBF0000
        _L 0x20003820 0x03E00008
        _L 0x20003824 0x27BD0010
        _L 0x2001B10C 0x0A200E01//Jump
        _L 0x2001B110 0x34040001//FPS
        _L 0x2001B114 0x00000000
        _C0 Unlimited FPS [Default]
        _L 0xE0040E01 0x1001B10C
        _L 0x2001B10C 0x8FBF0000
        _L 0x2001B110 0x03E00008
        _L 0x2001B114 0x27BD0010
        _L 0x10003800 0x00000000"
        
    # Bloque de texto con la configuración del ppsspp.ini, indentado para legibilidad
    configuracion_ppsspp_ini="[General]
        FirstRun = False
        RunCount = 42
        Enable Logging = True
        AutoRun = True
        Browse = False
        IgnoreBadMemAccess = True
        CurrentDirectory = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp
        ShowDebuggerOnLoad = False
        CheckForNewVersion = False
        Language = es_LA
        ForceLagSync = False
        NumWorkerThreads = 8
        EnableAutoLoad = False
        EnableCheats = True
        CwCheatRefreshRate = 77
        ScreenshotsAsPNG = False
        StateSlot = 2
        RewindFlipFrequency = 0
        GridView1 = True
        GridView2 = False
        GridView3 = False
        ReportingHost = default
        AutoSaveSymbolMap = False
        CacheFullIsoInRam = False
        ScreenRotation = 1
        PauseWhenMinimized = False
        DumpDecryptedEboots = False
        ForceLagSync2 = False
        DiscordPresence = True
        UISound = False
        AutoLoadSaveState = 0
        CwCheatScrollPosition = 0.000000
        GameListScrollPosition = 0.000000
        UseFFV1 = False
        DumpFrames = False
        DumpVideoOutput = False
        DumpAudio = False
        SaveLoadResetsAVdumping = False
        EnableStateUndo = False
        StateLoadUndoGame = NA
        StateUndoLastSaveGame = NA
        StateUndoLastSaveSlot = -5
        RewindSnapshotInterval = 0
        ShowOnScreenMessage = True
        ShowRegionOnGameIcon = False
        ShowIDOnGameIcon = False
        GameGridScale = 1.000000
        RightAnalogUp = 0
        RightAnalogDown = 0
        RightAnalogLeft = 0
        RightAnalogRight = 0
        RightAnalogPress = 0
        RightAnalogCustom = False
        RightAnalogDisableDiagonal = False
        SwipeUp = 0
        SwipeDown = 0
        SwipeLeft = 0
        SwipeRight = 0
        SwipeSensitivity = 1.000000
        SwipeSmoothing = 0.300000
        DoubleTapGesture = 0
        GestureControlEnabled = False
        RemoteISOPort = 0
        LastRemoteISOServer = 
        LastRemoteISOPort = 0
        RemoteISOManualConfig = False
        RemoteShareOnStartup = False
        RemoteISOSubdir = /
        RemoteDebuggerOnStartup = False
        RemoteTab = False
        RemoteISOSharedDir = 
        RemoteISOShareType = 0
        InternalScreenRotation = 1
        BackgroundAnimation = 1
        TransparentBackground = True
        UITint = 0.000000
        UISaturation = 1.000000
        ShowMenuBar = True
        MemStickInserted = True
        EnablePlugins = True
        IgnoreCompatSettings = 
        RunBehindPauseMenu = False
        [CPU]
        Jit = True
        SeparateCPUThread = False
        SeparateIOThread = True
        IOTimingMethod = 0
        FastMemoryAccess = True
        FuncReplacements = True
        CPUSpeed = 0
        SetRoundingMode = True
        ForceFlushToZero = True
        CPUCore = 1
        SeparateSASThread = True
        FunctionReplacements = True
        HideSlowWarnings = False
        HideStateWarnings = False
        PreloadFunctions = False
        JitDisableFlags = 0x00000000
        [Graphics]
        EnableCardboard = False
        CardboardScreenSize = 50
        CardboardXShift = 0
        CardboardYShift = 0
        ShowFPSCounter = 0
        GPUBackend = 0
        RenderingMode = 0
        SoftwareRendering = False
        HardwareTransform = True
        SoftwareSkinning = True
        TextureFiltering = 1
        BufferFiltering = 1
        InternalResolution = 2
        AndroidHwScale = 0
        FrameSkip = 0
        AutoFrameSkip = False
        FrameRate = 0
        FrameSkipUnthrottle = True
        ForceMaxEmulatedFPS = 60
        AnisotropyLevel = 0
        VertexCache = True
        TextureBackoffCache = True
        TextureSecondaryCache = True
        PartialStretch = False
        StretchToDisplay = False
        SmallDisplay = False
        ImmersiveMode = False
        TrueColor = True
        MipMap = True
        TexScalingLevel = 1
        TexScalingType = 0
        TexDeposterize = False
        VSyncInterval = False
        DisableStencilTest = False
        AlwaysDepthWrite = False
        DepthRangeHack = False
        BloomHack = 0
        TimerHack = False
        AlphaMaskHack = False
        SplineBezierQuality = 2
        PostShader = Off
        MemBlockTransferGPU = True
        DisableSlowFramebufEffects = True
        FragmentTestCache = True
        EnableCardboardVR = False
        iShowStatusFlags = 0
        GraphicsBackend = 3 (VULKAN)
        FailedGraphicsBackends = 
        DisabledGraphicsBackends = 
        VulkanDevice = 
        CameraDevice = 
        AndroidFramerateMode = 1
        UseGeometryShader = False
        SkipBufferEffects = False
        DisableRangeCulling = False
        SoftwareRenderer = False
        SoftwareRendererJit = True
        Smart2DTexFiltering = False
        HighQualityDepth = 1
        FrameSkipType = 0
        StereoRendering = False
        StereoToMonoShader = RedBlue
        FrameRate2 = -1
        AnalogFrameRate = 240
        UnthrottlingMode = SKIP_FLIP
        MultiSampleLevel = 0
        DisplayOffsetX = 0.500000
        DisplayOffsetY = 0.500000
        DisplayScale = 1.000000
        DisplayIntegerScale = False
        DisplayAspectRatio = 1.000000
        DisplayStretch = False
        DisplayCropTo16x9 = True
        SustainedPerformanceMode = False
        IgnoreScreenInsets = True
        ReplaceTextures = True
        SaveNewTextures = False
        IgnoreTextureFilenames = False
        TexHardwareScaling = False
        VSync = True
        HardwareTessellation = False
        TextureShader = Off
        ShaderChainRequires60FPS = False
        SkipGPUReadbackMode = 0
        LogFrameDrops = False
        InflightFrames = 3
        RenderDuplicateFrames = False
        MultiThreading = True
        GpuLogProfiler = False
        UberShaderVertex = True
        UberShaderFragment = True
        [Sound]
        Enable = True
        AudioBackend = 0
        AudioLatency = 1
        SoundSpeedHack = False
        AudioResampler = True
        ExtraAudioBuffering = False
        GlobalVolume = 10
        ReverbVolume = 10
        AltSpeedVolume = -1
        AchievementSoundVolume = 6
        AudioDevice = 
        AutoAudioDevice = True
        [Control]
        HapticFeedback = True
        ShowTouchCross = True
        ShowTouchCircle = True
        ShowTouchSquare = True
        ShowTouchTriangle = True
        ShowTouchStart = True
        ShowTouchSelect = True
        ShowTouchLTrigger = True
        ShowTouchRTrigger = True
        ShowAnalogStick = True
        ShowTouchDpad = True
        ShowTouchUnthrottle = True
        ShowTouchPause = False
        ShowTouchControls = True
        TiltBaseX = 0.000000
        TiltBaseY = 0.000000
        InvertTiltX = False
        InvertTiltY = True
        TiltSensitivityX = 100
        TiltSensitivityY = 100
        DeadzoneRadius = 0.200000
        TiltInputType = 0
        DisableDpadDiagonals = False
        TouchButtonStyle = 1
        TouchButtonOpacity = 65
        ActionButtonSpacing2 = 1.000000
        ActionButtonCenterX = 0.895379
        ActionButtonCenterY = 0.805511
        ActionButtonScale = 1.150000
        DPadX = 0.124673
        DPadY = 0.533225
        DPadScale = 1.150000
        DPadSpacing = 1.000000
        StartKeyX = 0.599826
        StartKeyY = 0.888169
        StartKeyScale = 1.150000
        SelectKeyX = 0.499564
        SelectKeyY = 0.888169
        SelectKeyScale = 1.150000
        UnthrottleKeyX = 0.399303
        UnthrottleKeyY = 0.888169
        UnthrottleKeyScale = 1.150000
        LKeyX = 0.069747
        LKeyY = 0.074554
        LKeyScale = 1.150000
        RKeyX = 0.939843
        RKeyY = 0.074554
        RKeyScale = 1.150000
        AnalogStickX = 0.124673
        AnalogStickY = 0.850891
        AnalogStickScale = 1.150000
        AnalogLimiterDeadzone = 0.600000
        Custom0Mapping = 0x0000000000000000
        Custom0Image = 0
        Custom0Shape = 0
        Custom0Toggle = False
        Custom0Repeat = False
        Custom1Mapping = 0x0000000000000000
        Custom1Image = 1
        Custom1Shape = 0
        Custom1Toggle = False
        Custom1Repeat = False
        Custom2Mapping = 0x0000000000000000
        Custom2Image = 2
        Custom2Shape = 0
        Custom2Toggle = False
        Custom2Repeat = False
        Custom3Mapping = 0x0000000000000000
        Custom3Image = 3
        Custom3Shape = 0
        Custom3Toggle = False
        Custom3Repeat = False
        Custom4Mapping = 0x0000000000000000
        Custom4Image = 4
        Custom4Shape = 0
        Custom4Toggle = False
        Custom4Repeat = False
        Custom5Mapping = 0x0000000000000000
        Custom5Image = 0
        Custom5Shape = 1
        Custom5Toggle = False
        Custom5Repeat = False
        Custom6Mapping = 0x0000000000000000
        Custom6Image = 1
        Custom6Shape = 1
        Custom6Toggle = False
        Custom6Repeat = False
        Custom7Mapping = 0x0000000000000000
        Custom7Image = 2
        Custom7Shape = 1
        Custom7Toggle = False
        Custom7Repeat = False
        Custom8Mapping = 0x0000000000000000
        Custom8Image = 3
        Custom8Shape = 1
        Custom8Toggle = False
        Custom8Repeat = False
        Custom9Mapping = 0x0000000000000000
        Custom9Image = 4
        Custom9Shape = 1
        Custom9Toggle = False
        Custom9Repeat = False
        Custom10Mapping = 0x0000000000000000
        Custom10Image = 0
        Custom10Shape = 2
        Custom10Toggle = False
        Custom10Repeat = False
        Custom11Mapping = 0x0000000000000000
        Custom11Image = 1
        Custom11Shape = 2
        Custom11Toggle = False
        Custom11Repeat = False
        Custom12Mapping = 0x0000000000000000
        Custom12Image = 2
        Custom12Shape = 2
        Custom12Toggle = False
        Custom12Repeat = False
        Custom13Mapping = 0x0000000000000000
        Custom13Image = 3
        Custom13Shape = 2
        Custom13Toggle = False
        Custom13Repeat = False
        Custom14Mapping = 0x0000000000000000
        Custom14Image = 4
        Custom14Shape = 2
        Custom14Toggle = False
        Custom14Repeat = False
        Custom15Mapping = 0x0000000000000000
        Custom15Image = 0
        Custom15Shape = 9
        Custom15Toggle = False
        Custom15Repeat = False
        Custom16Mapping = 0x0000000000000000
        Custom16Image = 1
        Custom16Shape = 9
        Custom16Toggle = False
        Custom16Repeat = False
        Custom17Mapping = 0x0000000000000000
        Custom17Image = 2
        Custom17Shape = 9
        Custom17Toggle = False
        Custom17Repeat = False
        Custom18Mapping = 0x0000000000000000
        Custom18Image = 3
        Custom18Shape = 9
        Custom18Toggle = False
        Custom18Repeat = False
        Custom19Mapping = 0x0000000000000000
        Custom19Image = 4
        Custom19Shape = 9
        Custom19Toggle = False
        Custom19Repeat = False
        fcombo0X = 0.609803
        fcombo0Y = 0.499190
        comboKeyScale0 = 1.150000
        ShowComboKey0 = False
        fcombo1X = 0.701353
        fcombo1Y = 0.499190
        comboKeyScale1 = 1.150000
        ShowComboKey1 = False
        fcombo2X = 0.792903
        fcombo2Y = 0.499190
        comboKeyScale2 = 1.150000
        ShowComboKey2 = False
        fcombo3X = 0.609803
        fcombo3Y = 0.332253
        comboKeyScale3 = 1.150000
        ShowComboKey3 = False
        fcombo4X = 0.701353
        fcombo4Y = 0.332253
        comboKeyScale4 = 1.150000
        ShowComboKey4 = False
        fcombo5X = 0.390083
        fcombo5Y = 0.499190
        comboKeyScale5 = 1.150000
        ShowComboKey5 = False
        fcombo6X = 0.298533
        fcombo6Y = 0.499190
        comboKeyScale6 = 1.150000
        ShowComboKey6 = False
        fcombo7X = 0.206983
        fcombo7Y = 0.499190
        comboKeyScale7 = 1.150000
        ShowComboKey7 = False
        fcombo8X = 0.390083
        fcombo8Y = 0.332253
        comboKeyScale8 = 1.150000
        ShowComboKey8 = False
        fcombo9X = 0.298533
        fcombo9Y = 0.332253
        comboKeyScale9 = 1.150000
        ShowComboKey9 = False
        fcombo10X = 0.609803
        fcombo10Y = 0.581848
        comboKeyScale10 = 1.150000
        ShowComboKey10 = False
        fcombo11X = 0.701353
        fcombo11Y = 0.581848
        comboKeyScale11 = 1.150000
        ShowComboKey11 = False
        fcombo12X = 0.792903
        fcombo12Y = 0.581848
        comboKeyScale12 = 1.150000
        ShowComboKey12 = False
        fcombo13X = 0.609803
        fcombo13Y = 0.414911
        comboKeyScale13 = 1.150000
        ShowComboKey13 = False
        fcombo14X = 0.701353
        fcombo14Y = 0.414911
        comboKeyScale14 = 1.150000
        ShowComboKey14 = False
        fcombo15X = 0.390083
        fcombo15Y = 0.581848
        comboKeyScale15 = 1.150000
        ShowComboKey15 = False
        fcombo16X = 0.298533
        fcombo16Y = 0.581848
        comboKeyScale16 = 1.150000
        ShowComboKey16 = False
        fcombo17X = 0.206983
        fcombo17Y = 0.581848
        comboKeyScale17 = 1.150000
        ShowComboKey17 = False
        fcombo18X = 0.390083
        fcombo18Y = 0.414911
        comboKeyScale18 = 1.150000
        ShowComboKey18 = False
        fcombo19X = 0.298533
        fcombo19Y = 0.414911
        comboKeyScale19 = 1.150000
        ShowComboKey19 = False
        TiltBaseAngleY = 0.900000
        TiltInvertX = False
        TiltInvertY = False
        TiltAnalogDeadzoneRadius = 0.000000
        TiltInverseDeadzone = 0.000000
        TiltCircularDeadzone = True
        GamepadOnlyFocused = False
        TouchButtonHideSeconds = 20
        AutoCenterTouchAnalog = False
        StickyTouchDPad = False
        TouchSnapToGrid = False
        TouchSnapGridSize = 64
        RightAnalogStickX = 0.904356
        RightAnalogStickY = 0.850891
        RightAnalogStickScale = 1.150000
        ShowRightAnalogStick = False
        AnalogDeadzone = 0.150000
        AnalogInverseDeadzone = 0.000000
        AnalogSensitivity = 1.100000
        AnalogIsCircular = False
        AnalogAutoRotSpeed = 8.000000
        AnalogTriggerThreshold = 0.750000
        AllowMappingCombos = False
        StrictComboOrder = False
        LeftStickHeadScale = 1.000000
        RightStickHeadScale = 1.000000
        HideStickBackground = False
        UseMouse = False
        MapMouse = False
        ConfineMap = False
        MouseSensitivity = 0.100000
        MouseSmoothing = 0.900000
        MouseWheelUpDelayMs = 80
        SystemControls = True
        RapidFileInterval = 5
        AnalogGesture = False
        AnalogGestureSensibility = 1.000000
        [Network]
        EnableWlan = False
        EnableAdhocServer = False
        proAdhocServer = socom.cc
        PortOffset = 10000
        MinTimeout = 0
        ForcedFirstConnect = False
        EnableUPnP = False
        UPnPUseOriginalPort = False
        EnableNetworkChat = False
        ChatButtonPosition = 0
        ChatScreenPosition = 0
        EnableQuickChat = True
        QuickChat1 = Quick Chat 1
        QuickChat2 = Quick Chat 2
        QuickChat3 = Quick Chat 3
        QuickChat4 = Quick Chat 4
        QuickChat5 = Quick Chat 5
        [SystemParam]
        PSPModel = 0
        PSPFirmwareVersion = 150
        NickName = PPSSPP
        proAdhocServer = coldbird.net
        MacAddress = bf:74:78:30:ba:5e
        Language = 3
        TimeFormat = 1
        DateFormat = 1
        TimeZone = 0
        DayLightSavings = False
        ButtonPreference = 1
        LockParentalLevel = 0
        WlanAdhocChannel = 0
        WlanPowerSave = False
        EncryptSave = True
        GameLanguage = -1
        ParamTimeFormat = 0
        ParamDateFormat = 0
        BypassOSKWithKeyboard = False
        SavedataUpgradeVersion = True
        MemStickSize = 16
        [Debugger]
        DisasmWindowX = -1
        DisasmWindowY = -1
        DisasmWindowW = -1
        DisasmWindowH = -1
        GEWindowX = -1
        GEWindowY = -1
        GEWindowW = -1
        GEWindowH = -1
        ConsoleWindowX = -1
        ConsoleWindowY = -1
        FontWidth = 8
        FontHeight = 12
        DisplayStatusBar = True
        ShowBottomTabTitles = True
        ShowDeveloperMenu = False
        SkipDeadbeefFilling = False
        FuncHashMap = False
        GEWindowTabsBL = 0x00000000
        GEWindowTabsBR = 0x00000000
        GEWindowTabsTR = 0x00000000
        SkipFuncHashMap = 
        MemInfoDetailed = False
        [SpeedHacks]
        PrescaleUV = True
        DisableAlphaTest = True
        [Upgrade]
        UpgradeMessage = 
        UpgradeVersion = 
        DismissedVersion = 
        [Recent]
        MaxRecent = 30
        FileName0 = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp/God Of War Chains Of Olympus (Esp).iso
        FileName1 = /storage/emulated/0/Download/Games/PSE/PPSSPP/God_Of_War_Ghost_Of_Sparta_Esp/God Of War Ghost Of Sparta (Esp).iso
        [Theme]
        ThemeName = Default
        [VR]
        VREnable = True
        VREnable6DoF = True
        VREnableStereo = False
        VREnableMotions = True
        VRForce72Hz = True
        VRManualForceVR = False
        VRPassthrough = False
        VRRescaleHUD = True
        VRCameraDistance = 0.000000
        VRCameraHeight = 0.000000
        VRCameraSide = 0.000000
        VRCameraPitch = 0
        VRCanvasDistance = 12.000000
        VRCanvas3DDistance = 3.000000
        VRHeadUpDisplayScale = 0.300000
        VRMotionLength = 0.500000
        VRHeadRotationScale = 5.000000
        VRHeadRotationEnabled = False
        VRHeadRotationSmoothing = False
        [Achievements]
        AchievementsEnable = True
        AchievementsChallengeMode = True
        AchievementsEncoreMode = False
        AchievementsUnofficial = False
        AchievementsLogBadMemReads = False
        bAchievementsSaveStateInChallengeMode = False
        AchievementsUserName = 
        AchievementsSoundEffects = True
        AchievementsUnlockAudioFile = 
        AchievementsLeaderboardSubmitAudioFile = 
        AchievementsLeaderboardTrackerPos = 3
        AchievementsLeaderboardStartedOrFailedPos = 3
        AchievementsLeaderboardSubmittedPos = 3
        AchievementsProgressPos = 3
        AchievementsChallengePos = 3
        AchievementsUnlockedPos = 4
        [Log]
        SYSTEMEnabled = True
        SYSTEMLevel = 2
        BOOTEnabled = True
        BOOTLevel = 2
        COMMONEnabled = True
        COMMONLevel = 2
        CPUEnabled = True
        CPULevel = 2
        FILESYSEnabled = True
        FILESYSLevel = 2
        G3DEnabled = True
        G3DLevel = 2
        HLEEnabled = True
        HLELevel = 2
        JITEnabled = True
        JITLevel = 2
        LOADEREnabled = True
        LOADERLevel = 2
        MEEnabled = True
        MELevel = 2
        MEMMAPEnabled = True
        MEMMAPLevel = 2
        SASMIXEnabled = True
        SASMIXLevel = 2
        SAVESTATEEnabled = True
        SAVESTATELevel = 2
        FRAMEBUFEnabled = True
        FRAMEBUFLevel = 2
        AUDIOEnabled = True
        AUDIOLevel = 2
        IOEnabled = True
        IOLevel = 2
        ACHIEVEMENTSEnabled = True
        ACHIEVEMENTSLevel = 2
        HTTPEnabled = True
        HTTPLevel = 2
        PRINTFEnabled = True
        PRINTFLevel = 2
        SCEAUDIOEnabled = True
        SCEAUDIOLevel = 2
        SCECTRLEnabled = True
        SCECTRLLevel = 2
        SCEDISPEnabled = True
        SCEDISPLevel = 2
        SCEFONTEnabled = True
        SCEFONTLevel = 2
        SCEGEEnabled = True
        SCEGELevel = 2
        SCEINTCEnabled = True
        SCEINTCLevel = 2
        SCEIOEnabled = True
        SCEIOLevel = 2
        SCEKERNELEnabled = True
        SCEKERNELLevel = 2
        SCEMODULEEnabled = True
        SCEMODULELevel = 2
        SCENETEnabled = True
        SCENETLevel = 2
        SCERTCEnabled = True
        SCERTCLevel = 2
        SCESASEnabled = True
        SCESASLevel = 2
        SCEUTILEnabled = True
        SCEUTILLevel = 2
        SCEMISCEnabled = True
        SCEMISCLevel = 2
        [PlayTime]
        UCES00842 = 7,1729279254704904448
        UCES01401 = 275,1729279246702391552"
    
    # Usar 'sed' para eliminar los espacios en blanco al inicio de cada línea
    echo "$configuracion_fps" | sed 's/^[ \t]*//' > "$archivo_cheat_fps_psp"
    
    # Usar 'sed' para eliminar los espacios en blanco al inicio de cada línea
    echo "$configuracion_ppsspp_ini" | sed 's/^[ \t]*//' > "$archivo_system_ini_psp"
    
    # Verificar si el archivo fue creado
    if [ -f "$archivo_cheat_fps_psp" ]; then
        echo -e "Configuración escrita en:\n$archivo_cheat_fps_psp"
    else
        echo -e "Error: No se pudo crear el archivo:\n$archivo_cheat_fps_psp"
    fi
    # Verificar si el archivo fue creado
    if [ -f "$archivo_system_ini_psp" ]; then
        echo -e "Configuración escrita en:\n$archivo_system_ini_psp"
    else
        echo -e "Error: No se pudo crear el archivo:\n$archivo_system_ini_psp"
    fi
}



verificar_archivo() {
    local archivo="$1"

    # Colores para la salida
    GREEN="\033[0;32m"
    RED="\033[0;31m"
    YELLOW="\033[1;33m"
    NC="\033[0m" # Sin color

    if [ ! -f "$archivo" ]; then
        echo -e "${YELLOW}El archivo $archivo no existe.${NC}"
        return
    fi

    # Obtener solo el nombre del archivo y luego la extensión
    nombre_archivo=$(basename "$archivo")
    extension="${nombre_archivo##*.}"

    case "$extension" in
        "zip")
            echo "Verificando archivo ZIP..."
            if unzip -t "$archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo ZIP $archivo está en buen estado.${NC}"
            else
                echo -e "${RED}El archivo ZIP $archivo está corrupto o incompleto.${NC}"
                return
            fi
            ;;
        "apk")
            echo "Verificando archivo APK..."
            if apksigner verify --verbose --print-certs "$archivo" | grep -i "Exception" >/dev/null 2>&1; then
                echo -e "${RED}Error: El archivo APK $archivo está corrupto o no es válido.${NC}"
                return
            else
                echo -e "${GREEN}El archivo APK $archivo está en buen estado.${NC}"
            fi
            ;;
        "mp4")
            echo "Verificando archivo MP4..."
            if mediainfo "$archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo MP4 $archivo está en buen estado.${NC}"
            else
                echo -e "${RED}El archivo MP4 $archivo tiene problemas o está corrupto.${NC}"
                return
            fi
            ;;
        *)
            echo -e "${YELLOW}Tipo de archivo no soportado para verificación: .$extension.${NC}"
            return
            ;;
    esac

    return 0
}


: '
https://drive.google.com/file/d/1CdJaDIcYc4-US4Jgq3yQODz5gUuGfEed/view?usp=drivesdk
# Del link original solo copia esto y lo pegas asi cómo ves el ejemplo en gdown:
1CdJaDIcYc4-US4Jgq3yQODz5gUuGfEed

# Descargar el archivo usando gdown de python
pip install gdown
gdown https://drive.google.com/uc?id=1CdJaDIcYc4-US4Jgq3yQODz5gUuGfEed

: '

iniciar_descarga_google_drive() {
    # ID del archivo de Google Drive
    local FILE_ID="$1"
    local archivo_zip="$2"
    local destino="$3"
    local funcion_actual="$4"
    local adb_conectado="$5"
    
    # Ruta y nombre del archivo donde deseas guardarlo
    RUTA_DESTINO="$destino/$archivo_zip"

    # Verificar si el directorio de destino existe
    if [ ! -d "$destino" ]; then
        echo -e "${YELLOW}El directorio $destino no existe. Creándolo...${NC}"
        mkdir -p "$destino"
        
        # Verificar si se creó correctamente
        if [ $? -ne 0 ]; then
            echo -e "${RED}Error al crear el directorio $destino. Saliendo...${NC}"
            exit 1
        fi
        echo -e "${YELLOW}Directorio creado con éxito.${NC}"
    fi

    # Descargar el archivo utilizando gdown
    echo -e "\n${YELLOW}Descargando archivo desde Google Drive...${NC}"
    gdown -O "$RUTA_DESTINO" "https://drive.google.com/uc?id=$FILE_ID"

    # Comprobar si la descarga fue exitosa
    if [ $? -eq 0 ]; then
        echo -e "${YELLOW}Descargado con éxito en:\n${GREEN}${destino}/${archivo_zip}${NC}"
        cd "$destino"
        unzip "${archivo_zip}"
        echo -e "${YELLOW}Extracción completada en:\n${GREEN}${destino}/${NC}"
        cd - > /dev/null
        $funcion_actual "$adb_conectado"
    else
        echo -e "${RED}Error al descargar el archivo. Verifica el enlace de Google Drive.${NC}"
        exit 1
    fi
}



iniciar_descarga() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    
    echo "Descargando $archivo_zip"
    # Descargar simulando un navegador real
    wget --header="User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" \
         --header="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" \
         --header="Accept-Language: en-US,en;q=0.5" \
         --header="Connection: keep-alive" \
         --max-redirect=20 \
         -O file "$url"
    # curl -O $url
    link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
    rm -rf file
    cd $destino
    wget --no-check-certificate ${link}
    echo -e "${YELLOW}Descargado con éxito en:\n${GREEN}${destino}/${archivo_zip}"
    cd - > /dev/null
}
# Función para descargar y descomprimir archivos
iniciar_descarga_y_descomprimir() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    
    # Descargar el archivo
    echo -e "\n${YELLOW}Descargando${NC}: ${archivo_zip}"
    # Descargar simulando un navegador real
    wget --header="User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" \
         --header="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" \
         --header="Accept-Language: en-US,en;q=0.5" \
         --header="Connection: keep-alive" \
         --max-redirect=20 \
         -O file "$url"
    # curl -O $url
    link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
    rm -rf file
    cd "${destino}"  
    wget --no-check-certificate ${link}
    unzip "${archivo_zip}"
    # rm -rf "${archivo_zip}"
    echo -e "${YELLOW}Descarga y extracción completadas en:\n${GREEN}${destino}/${NC}"
    cd - > /dev/null
}
# Función para descargar
descargar() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    local adb_conectado="$4"
    local nombre_pack="$5"
   
    local ruta_archivo="${destino}/${archivo_zip}"

    if [ ! -f "$ruta_archivo" ]; then
        iniciar_descarga "$url" "$archivo_zip" "$destino"
        return
    fi
        
    echo ""
    
    # Colores para la salida
    GREEN="\033[0;32m"
    RED="\033[0;31m"
    YELLOW="\033[1;33m"
    NC="\033[0m" # Sin color

    # Obtener solo el nombre del archivo y luego la extensión
    nombre_archivo=$(basename "$ruta_archivo")
    extension="${nombre_archivo##*.}"

    case "$extension" in
        "zip")
            echo "Verificando archivo ZIP..."
            if unzip -t "$archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo ZIP $ruta_archivo está en buen estado.${NC}"
            else
                echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${archivo_zip}${NC}"
                rm -f "$destino/$archivo_zip"
                iniciar_descarga "$url" "$archivo_zip" "$destino"
                return
            fi
            ;;
        "apk")
            echo "Verificando archivo APK..."
            APK_PATH="$ruta_archivo"
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$APK_PATH" 2>&1)
            # Verificar si contiene la palabra "Exception" o "Malformed"
            if echo "$result" | grep -qi "Exception"; then
                echo -e "${RED}El archivo APK es inválido o está corrupto.${NC}"
                rm -rf "${APK_PATH}"
                iniciar_descarga "$url" "$archivo_zip" "$destino"
            elif echo "$result" | grep -qi "Malformed"; then
                echo -e "${RED}El archivo APK está mal formado.${NC}"
                rm -rf "${APK_PATH}"
                iniciar_descarga "$url" "$archivo_zip" "$destino"
            else
                echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}"
                archivo_descargado='true'
            fi
            if [ "$archivo_descargado" == 'true' ]; then
                if adb -s "$adb_conectado" shell pm list packages | grep "$nombre_pack" >/dev/null; then
                    echo -e "${GREEN}Y está instalado!!!${NC}"
                else
                    if [ -n "$adb_conectado" ]; then
                        echo -e "${YELLOW} Instalando la app en su dispositivo!!!${NC}"
                        adb -s "$adb_conectado" push "$APK_PATH" /data/local/tmp/$nombre_archivo
                        adb -s "$adb_conectado" shell pm install /data/local/tmp/$nombre_archivo
                        adb -s "$adb_conectado" shell rm /data/local/tmp/$nombre_archivo
                        echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                    else
                        echo -e "${RED}No hay conexión ADB${NC}"         
                    fi
                fi
            fi
            ;;
        "mp4")
            echo "Verificando archivo MP4..."
            # Comprobar si el archivo puede ser decodificado correctamente con ffmpeg
            ffmpeg -v error -i "${ruta_archivo}" -f null - 2> error_log.txt

            # Verificar si hubo errores
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${ruta_archivo}${NC}"
                xdg-open "${ruta_archivo}"
            else
                echo "El archivo MP4 tiene errores:"
                # cat error_log.txt
                # Eliminar el log temporal
                # rm error_log.txt
                rm -rf "${ruta_archivo}"
                iniciar_descarga "$url" "$archivo_zip" "$destino"
            fi
            ;;
        *)
            echo -e "${YELLOW}Tipo de archivo no soportado para verificación: $ruta_archivo.${NC}"
            return
            ;;
    esac    
}

# Función para descargar y descomprimir archivos
descargar_apk_rom_y_descomprimir() {
    # "$1"   "$2"                  "$3"                    "$4"               "$5"        
    # "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$adb_conectado" 
    local url="$1"
    local archivo_zip="$2"
    local ruta_destino="$3"
    local arc_rom_apk="$4"
    local adb_conectado="$5"
    local funcion_actual="$6"
    local pack_app="$7"
    
    # Armar la ruta completa del archivo
    local ruta_archivo="${ruta_destino}/${archivo_zip}"
    
    echo ""   

    # Obtener solo el nombre del archivo y luego la extensión
    # capturar solo el archivo sin su ruta
    nombre_archivo=$(basename "$ruta_archivo")
    # capturar solo la extensión del archivo
    extension="${nombre_archivo##*.}"

    # Si existe el apk o rom.
    if [ -f "${arc_rom_apk}" ]; then
        # toma la extensión del archivo a analizar.
        nombre_archivo=$(basename "${arc_rom_apk}")
        # echo $nombre_archivo
        extension="${nombre_archivo##*.}"
        # nombre_archivo="AetherSX2_v1.5-3668(13930).apk"
        nombre_archivo_escapado=""
        for (( i=0; i<${#nombre_archivo}; i++ )); do
            char="${nombre_archivo:i:1}"
            case "$char" in
                '(' | ')' | '[' | ']')
                    nombre_archivo_escapado+="\\$char"
                    ;;
                *)
                    nombre_archivo_escapado+="$char"
                    ;;
            esac
        done

    # Si no existe el el zip principal, descargalo...
    elif [ ! -f "$ruta_archivo" ]; then
        iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$funcion_actual" "$adb_conectado"
        return
    fi
    
    
    app_instalada='false'
    # echo "aqui"
    # echo ${adb_conectado}
    if adb -s "$adb_conectado" shell pm list package | grep -qE "^package:${pack_app}$" > /dev/null; then
        app_instalada='true'
    fi
    # echo $app_instalada
    # echo "${pack_app}"
    # adb -s "${adb_conectado}" shell pm list package | grep -E "^package:${pack_app}$" | awk -F ':' '{print $2}'
    case "$extension" in
        "apk")
            echo -e "${YELLOW}Verificando archivo APK...${NC}"
            APK_PATH="$arc_rom_apk"
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$APK_PATH" 2>&1)
            tamanio_archivo=$(stat --format="%s" "${APK_PATH}")
            
            # Comparar si son iguales en tamaño.
            if [[ "${tamanio_archivo}" -eq 18891890 || "${tamanio_archivo}" -eq 19216165 ]]; then
                echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}" # > /dev/null
                apk_malo='false'
                if [[ "${app_instalada}" == "true" ]]; then
                    echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}"
                    $funcion_actual "$adb_conectado"
                    return
                elif [ -n "${adb_conectado}" ]; then
                    
                    echo -e "${YELLOW}Instalando la app en su dispositivo!!!${NC}"
                    adb -s "$adb_conectado" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                    adb -s "$adb_conectado" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                    adb -s "$adb_conectado" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                    echo -e "${GREEN}$nombre_archivo instalado correctamente${NC}"
                    return
                else
                    echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
                fi
            else
                # echo -e "${RED}El archivo APK no coincide en tamaño. Puede estar corrupto.${NC}"
                apk_malo='true'
            fi
            # Verificar otro archivo si contiene la palabra "Exception" o "Malformed"
            if echo "$result" | grep -qi "Exception"; then
                echo -e "${RED}El archivo APK es inválido o está corrupto.${NC}"
                rm -rf "${APK_PATH}"
                apk_malo='true'
            elif echo "$result" | grep -qi "Malformed"; then
                echo -e "${RED}El archivo APK está mal formado.${NC}"
                rm -rf "${APK_PATH}"
                apk_malo='true'
            else
                echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}"
                apk_malo='false'
                # APK_PATH="/sdcard/Download/Games/PSE/PPSSPP/PPSSPP_Gold_v1.17.0/InMG-PPSSPP GOLD APK ver.1.17.0.apk"
                # nombre_archivo="InMG-PPSSPP GOLD APK ver.1.17.0.apk"
                
                nombre_archivo_escapado=""
                for (( i=0; i<${#nombre_archivo}; i++ )); do
                    char="${nombre_archivo:i:1}"
                    case "$char" in
                        '(' | ')' | '[' | ']')
                            nombre_archivo_escapado+="\\$char"
                            ;;
                       ' ')
                           nombre_archivo_escapado=$(echo "${nombre_archivo}" | sed 's/ /\\ /g')
                           break
                           ;;
                        *)
                            nombre_archivo_escapado+="$char"
                            ;;
                    esac
                done
                if [[ "$app_instalada" == "true" ]]; then
                    echo -e "${GREEN}Y la aplicación ya está instalada en su dispositivo!!!${NC}" # > /dev/null
                    return
                elif [[ -n "$adb_conectado" ]] && [[ "$app_instalada" == "false" ]]; then
                    echo -e "${YELLOW}Instalando la app en su dispositivo!!!${NC}"
                    adb -s "$adb_conectado" push "$APK_PATH" "/data/local/tmp/$nombre_archivo" > /dev/null
                    adb -s "$adb_conectado" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                    adb -s "$adb_conectado" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                    echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
                else
                    echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
                fi
                return
            fi
            if [[ "$apk_malo" == 'true' ]] && [[ -f "$ruta_archivo" ]]; then
                echo "Verificando archivo ZIP apk..."
                if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                    echo "Descomprimiendo $ruta_archivo..."
                    unzip -o "$ruta_archivo" -d "$ruta_destino"
                    echo -e "${GREEN}Descompresión completada.${NC}"
                else
                    echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                    echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                    rm -f "$ruta_archivo"
                    iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$funcion_actual" "$adb_conectado"
                    return
                fi
            else
                iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$funcion_actual" "$adb_conectado"
                return
            fi
            ;;
        "zip")
            if [ -d "$ruta_destino" ]; then
                echo -e "\n${YELLOW}Verificando si existe el ZIP:\n${GREEN}$ruta_archivo${NC}"
                echo -e "el archivo zip existe.\nVerificando archivo ZIP $ruta_archivo..."
                if [[ -f "$ruta_archivo" ]] && unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                    echo -e "\n${YELLOW}Solo te falta el apk:\n${RED}$arc_rom_apk.${NC}"
                    # Verifica si existe el zip que contiene el apk
                    echo "Descomprimiendo $ruta_archivo..."
                    unzip -o "$ruta_archivo" -d "$ruta_destino"
                    echo -e "${GREEN}Descompresión completada.${NC}"
                    return
                fi
            else
                echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                rm -f "$ruta_archivo"
                iniciar_descarga_google_drive "$url" "$archivo_zip" "$ruta_destino" "$funcion_actual" "$adb_conectado"
                return
            fi
            ;;
        *)
            echo -e "${RED}Tipo de archivo no soportado para verificación:\n${CYAN}$ruta_archivo.${NC}"
            return
            ;;
    esac
    
}

# Función para descargar y descomprimir archivos
descargar_y_descomprimir() {
    local url="$1"
    local archivo_zip="$2"
    local destino="$3"
    local rom_apk="$4"
    local apk_url="$5"
    local ruta_destino_apk="$6"
    local ruta_obb="$7"
    local ruta_destino_obb="$8"
    local apk_zip="$9"
    local adb_conectado="$10"
    
    local ruta_archivo="${destino}/${archivo_zip}"
    
    # echo "${destino}/${archivo_zip}"

    echo ""   

    # Obtener solo el nombre del archivo y luego la extensión
    # capturar solo el archivo sin su ruta
    nombre_archivo=$(basename "$ruta_archivo")
    # capturar solo la extensión del archivo
    extension="${nombre_archivo##*.}"
    
    # Si existe el apk o rom.
    if [ -f "${rom_apk}" ]; then
        # echo "Nombre de rom_apk: $rom_apk"
        # toma la extensión del archivo a analizar.
        nombre_rom=$(basename "${rom_apk}")
        extension="${nombre_rom##*.}"
        # echo "$nombre_archivo"
        # echo "$extension"
    # Si no existe el el zip principal, descargalo...
    elif [ ! -f "$ruta_archivo" ]; then
        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
        return
    fi
    
    case "${extension}" in
        "apk")
            echo "Verificando archivo APK..."
            APK_PATH="$rom_apk"
            # Ejecutar apksigner y capturar errores
            result=$(apksigner verify --verbose --print-certs "$APK_PATH" 2>&1)
            
            # Verificar si contiene la palabra "Exception" o "Malformed"
            if echo "$result" | grep -qi "Exception"; then
                echo -e "${RED}El archivo APK es inválido o está corrupto.${NC}"
                rm -rf "${APK_PATH}"
                apk_malo='true'
            elif echo "$result" | grep -qi "Malformed"; then
                echo -e "${RED}El archivo APK está mal formado.${NC}"
                rm -rf "${APK_PATH}"
                apk_malo='true'
            else
                echo -e "${GREEN}El archivo ya está descargado en:\n${YELLOW}${APK_PATH}${NC}"
                apk_malo='false'
            fi
            if [[ "$apk_malo" == 'true' ]]; then
                echo "Verificando archivo ZIP apk..."
                if [[ -f "$ruta_destino_apk/$apk_zip" ]] && unzip -t "$ruta_destino_apk/$apk_zip" >/dev/null 2>&1; then
                    echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_destino_apk/$apk_zip${NC}"
                    echo "Descomprimiendo $ruta_destino_apk/$apk_zip..."
                    unzip -o "$ruta_destino_apk/$apk_zip" -d "$ruta_destino_apk"
                    echo -e "${GREEN}Descompresión completada.${NC}"
                else
                    echo -e "${RED}El archivo ZIP $ruta_destino_apk/$apk_zip está corrupto o incompleto.${NC}"
                    echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                    rm -f "$ruta_destino_apk/$apk_zip"
                    iniciar_descarga_y_descomprimir "$apk_url" "$apk_zip" "$ruta_destino_apk"
                    #return
                fi
            fi
            # Verificar que la variable no esté vacía y que el archivo exista
            if [ -n "$ruta_obb" ]; then
                echo "Verificando archivo ZIP obb..."
                # echo "Ruta del archivo obb: $ruta_obb"
                if [ -f "$ruta_obb" ]; then
                    if unzip -t "$ruta_obb" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP obb está en buen estado en:\n${YELLOW}$ruta_obb${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS]$ ]]; then
                            echo "Descomprimiendo $ruta_obb en $ruta_destino_obb..."
                            unzip -o "$ruta_obb" -d "$ruta_destino_obb"
                            echo -e "${GREEN}Descompresión completada.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_obb está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                else
                    echo -e "${RED}El archivo $ruta_obb no existe.${NC}"
                    echo -e "${RED} Descargando archivo ZIP $ruta_obb.${NC}"
                    iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                    return
                fi
            else
                echo -e "${RED}La variable ruta_obb está vacía.${NC}" >/dev/null 2>&1
            fi
            ;;
        "3ds")
            # Verificacion if para comparar números use según su necesidad: 
            # (-eq: igual a), (-ne: no igual a), (-lt: menor que), (-le: menor o igual a), (-ge: mayor o igual a)
            # Capturar el tamaño de un archivo en bytes.
            tamanio_archivo=$(stat --format="%s" "${rom_apk}")
            # Comparar si son iguales en tamaño.
            if [ "${tamanio_archivo}" -eq 536870912 ]; then
                echo -e "${GREEN}La rom ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                return
            fi
            iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
            ;;
        "chd")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 6598202475 ]]; then
                    echo -e "${GREEN}La iso ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "iso")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 1355710464 || "${tamanio_archivo}" -eq 1651015680 || "${tamanio_archivo}" -eq 8383463424 || "${tamanio_archivo}" -eq 4866244608 || "${tamanio_archivo}" -eq 2468872192 || "${tamanio_archivo}" -eq 809631744 ]]; then
                    echo -e "${GREEN}La iso ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "wbfs")
            if [ -f "${rom_apk}" ]; then
                tamanio_archivo=$(stat --format="%s" "${rom_apk}")
                # Comparar si son iguales en tamaño.
                if [[ "${tamanio_archivo}" -eq 369098752 || "${tamanio_archivo}" -eq 1651015680 || "${tamanio_archivo}" -eq 8383463424 || "${tamanio_archivo}" -eq 4866244608 ]]; then
                    echo -e "${GREEN}La Rom ya esta descargada en:\n${YELLOW}$rom_apk${NC}"
                    return
                else
                    # echo "tamaños no igual"
                    echo -e "Verificando archivo ZIP principal"
                    if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                        # Preguntar si desea descomprimir
                        read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                        if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                            echo "Descomprimiendo $ruta_archivo en $destino..."
                           unzip -o "$ruta_archivo" -d "$destino"
                            echo -e "${GREEN}Descompresión completada en:\n${YELLOW}$destino.${NC}"
                        else
                            echo -e "${YELLOW}Descompresión cancelada.${NC}"
                        fi
                    else
                        echo -e "${RED}El archivo ZIP $ruta_archivo está corrupto o incompleto.${NC}"
                        echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                        rm -f "$ruta_archivo"
                        iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                        return
                    fi
                fi
            fi
            ;;
        "zip")
            if [ -d "$ruta_destino_apk" ]; then
                echo -e "${YELLOW}Verificando si existe el obb:\n${YELLOW}$ruta_obb${NC}"
                if [ -f "$ruta_obb" ]; then
                    echo -e "el archivo obb existe.\nVerificando archivo ZIP obb..."
                    if unzip -t "$ruta_obb" >/dev/null 2>&1; then
                        echo -e "${GREEN}El archivo ZIP obb está en buen estado en:\n${YELLOW}$ruta_obb${NC}"
                        echo -e "\n${RED}Solo te falta el apk $rom_apk.${NC}"
                        # Verifica si existe el zip que contiene el apk
                        echo -e "${YELLOW}Verificar si existe el zip que contiene el apk${NC}"
                        if [[ -f "$ruta_destino_apk/$apk_zip" ]] && unzip -t "$ruta_destino_apk/$apk_zip" >/dev/null 2>&1; then
                            echo -e "${GREEN}El archivo ZIP apk está en buen estado en:\n${YELLOW}$ruta_destino_apk/$apk_zip${NC}"
                            echo "Descomprimiendo $ruta_destino_apk/$apk_zip..."
                            unzip -o "$ruta_destino_apk/$apk_zip" -d "$ruta_destino_apk"
                            echo -e "${GREEN}Descompresión completada.${NC}"
                            return
                        else
                            echo -e "${RED}El archivo ZIP $ruta_destino_apk/$apk_zip no existe o está incompleto.${NC}"
                            # echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}$ruta_destino_apk/$apk_zip${NC}"
                            rm -f "$ruta_destino_apk/$apk_zip"
                            iniciar_descarga_y_descomprimir "$apk_url" "$apk_zip" "$ruta_destino_apk"
                            return
                        fi
                    rm -rf ruta_destino_apk
                    fi
                fi
            fi          
            echo -e "Verificando archivo ZIP principal"
            if unzip -t "$ruta_archivo" >/dev/null 2>&1; then
                echo -e "${GREEN}El archivo ZIP está en buen estado en:\n${YELLOW}$ruta_archivo${NC}"
                # Preguntar si desea descomprimir
                read -p "¿Desea descomprimir el archivo ZIP? (s/n): " respuesta
                if [[ "$respuesta" =~ ^[sS](i|I)?$ ]]; then
                    echo "Descomprimiendo $ruta_archivo en $destino..."
                    unzip -o "$ruta_archivo" -d "$destino"
                    echo -e "${GREEN}Descompresión completada.${NC}"
                else
                    echo -e "${YELLOW}Descompresión cancelada.${NC}"
                fi
            else
                echo -e "${RED}El archivo ZIP $archivo está corrupto o incompleto.${NC}"
                echo -e "${YELLOW}Eliminando archivo corrupto:\n${CYAN}${ruta_archivo}${NC}"
                rm -f "$ruta_archivo"
                iniciar_descarga_y_descomprimir "$url" "$archivo_zip" "$destino"
                return
            fi
            ;;
        
        *)
            echo -e "${RED}Tipo de archivo no soportado para verificación:\n${CYAN}$ruta_archivo.${NC}"
            return
            ;;
    esac    
}

verif_adb_conect() {
    # Obtener la IP local
    # str=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
    # ip=$(echo "${str%%/*}")
    
    # ip=$(busybox ifconfig wlan0 | grep 'inet addr:' | awk -F: '{print $2}' | awk '{print $1}')
    ip=$(busybox ifconfig wlan0 2>/dev/null | grep 'inet ' | awk -F'[: ]+' '{print $4}')

    # Obtener los dispositivos conectados por ADB
    adb_output=$(adb devices -l)
    # connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}')
    connected_devices=$(echo "$adb_output" | grep "device " | awk '{print $1}' | grep -E "^(emulator-5554|${ip})$")

    # Mostrar la IP local
    echo -e "\nIP local: $ip"

    # Buscar si hay un dispositivo con la IP o el emulador
    ip_device=$(echo "$connected_devices" | grep -Ei "$ip:5555|emulator-5554" | head -n 1)

    # Verificar si se encontró algún dispositivo
    if [[ -n "$ip_device" ]]; then
        echo -e "${GREEN}Dispositivo conectado a adb${NC}: $ip_device"
        disponible_adb='false'
        # adb_conectado='true'
        adb_conectado="$ip_device"
        return
    else
        # echo "No se encontró ningún dispositivo con la IP $ip:5555 o el emulador emulator-5554."
        wlan0
    fi
}


# Submenú de configuraciones de Citra
submenu_citra() {
    while true; do
        verif_adb_conect
        local adb_conectado="$1"
        # if [ "$adb_conectado" == 'true' ]; then
        if [ -n "$adb_conectado" ]; then
            echo -en "\n${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado" > /dev/null
        fi
        echo -e "\n01. Instalar Citra Nintendo 3DS"
        echo -e "${CYAN}Juegos de Citra 3DS${NC}"
        echo "02. The Legend Of Zelda Ocarina Of Time 3DS"
        echo "03. Texturas 4K para Zelda"
        echo -e "${CYAN}Configuración de Citra${NC}"
        echo "04. Video tutorial ajustes Citra"
        echo "05. Configurar pantalla de Citra"
        echo "06. Estabilizar FPS de Citra"
        echo "07. Guía Citra"
        echo "08. Volver al menú principal"
        read -p "Seleccione una opción: " opcion_submenu

        case $opcion_submenu in
            1|01)
                # descargar "$1"   "$2"                  "$3"                           "$4"                      "$5"            
                # descargar "$url" "$archivo.zip" "$ruta_destino" "$adb_conectado" "$nombre_pack" 
                descargar "https://www.mediafire.com/file/uz33nhk99aqs4mo/Citra_MMJ_20231010.apk/file" "Citra_MMJ_20231010.apk" "/sdcard/Download/Games/N3DS" "$adb_conectado" "org.citra.emu"
                ;;
            2|02)
                descargar_y_descomprimir "https://www.mediafire.com/file/mn9xslsm1qsxtg5/The_Legend_Of_Zelda_Ocarina_Of_Time_3D_Europe_En,Fr,Ge,It,Es_3ds.zip/file" "The_Legend_Of_Zelda_Ocarina_Of_Time_3D_Europe_En,Fr,Ge,It,Es_3ds.zip" "/sdcard/Download/Games/N3DS/roms" '/sdcard/Download/Games/N3DS/roms/3DS0004 - The Legend Of Zelda Ocarina Of Time 3D (Europe)(En,Fr,Ge,It,Es).3ds'
                ;;
            3|03)
                descargar_y_descomprimir "https://www.mediafire.com/file/hepheo1rnc8s5p2/texturas_4K_1080.zip/file" "texturas_4K_1080.zip" "/sdcard/Download/Games/N3DS/texturas"
                if [ ! -d /sdcard/citra-emu/load/textures/0004000000033600 ]; then
                    # Crear la carpeta que ejecuta las texturas si no está!
                    mkdir -p /sdcard/citra-emu/load/textures                    
                fi
                # Si está la carpeta 0004000000033600 de las texturas, es por que se descomprimió el texturas_4K_1080.zip...
                if [ -d /sdcard/Download/Games/N3DS/texturas/0004000000033600 ]; then
                    echo -e "${YELLOW}Moviendo las texturas a:\n${CYAN}/sdcard/citra-emu/load/textures/${NC}"
                    # rsync -av --delete --progress /sdcard/Download/Games/N3DS/texturas/0004000000033600 /sdcard/citra-emu/load/textures/
                    rsync -avc --progress /sdcard/Download/Games/N3DS/texturas/0004000000033600 /sdcard/citra-emu/load/textures/
                    # mv /sdcard/Download/Games/N3DS/texturas/0004000000033600 /sdcard/citra-emu/load/textures/
                    echo -e "${GREEN}Texturas completas para cargar en citra${NC}"
                fi
                ;;
            4|04)
                descargar "https://www.mediafire.com/file/yw3y7jy55x0n6i4/config_citra.mp4/file" "config_citra.mp4" "/sdcard/Download/Games/N3DS"
                ;;
            5|05)
                configurar_pantalla_citra
                ;;
            6|06)
                fps_stable_cheat
                ;;
            7|07)
                if [ ! -f /sdcard/Download/Games/N3DS/guia.txt ]; then
                    descargar "https://www.mediafire.com/file/6bfo5zwwphalca6/guia.txt/file" "guia.txt" "/sdcard/Download/Games/N3DS"
                fi
                cat /sdcard/Download/Games/N3DS/guia.txt
                ;;
            8|08)
                echo "Volviendo al menú principal..."
                break
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
                ;;
        esac
    done
}

# Submenú de PSP
submenu_psp() {
    while true; do
        # verif_adb_conect
        local adb_conectado="$1"
        app_instalada='false'
        # if [ "$adb_conectado" == 'true' ]; then
        if [ -n "${adb_conectado}" ]; then
            echo -en "\n${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado" # > /dev/null
            # echo "aqui"
            # echo -e "${adb_conectado}"
            #if adb -s "${adb_conectado}" shell pm list package | grep -E "^package:$pack_app$" | awk -F ':' '{print $2}' > /dev/null; then
                #app_instalada='true'
            #fi
        fi
        echo -e "\n${CYAN}Play Station 2${NC}"
        echo -e "01. Instalar Emulador PS2 Aethersx2 v1.5-3668-13930"
        # link de video configuración máxima, recomendado descargar y ver!.
        # https://drive.google.com/file/d/1WZZIGTK1GimXiKTEz-uDIvW8lF6HSgQU/view?usp=drivesdk
        echo -e "${CYAN}Juegos de PS2${NC}"
        echo "02. God Of War - 1 (Español)"
        echo "03. God Of War - 2 (Español)"
        echo "04. Dragón Ball Z Budokai Tenkaichi - 4 (Esp Lat)"
        echo "05. Conflic Global Storm (Esp Lat)"        
        
        echo -e "${CYAN}Play Station Portátil${NC}"
        echo -e "06. Instalar Emulador PSP v1.18.1 (118010000)"
        echo -e "${CYAN}Juegos de PSP${NC}"
        echo "07. God Of War - Chains of Olympus (Español)"
        echo "08. Estabilizar FPS de PSP - Chains of Olympus"
        echo "09. God Of War - Ghost Of Sparta (Español)"
        echo "10. Estabilizar FPS de PSP - Ghost Of Sparta"
        echo "11. assassin's creed bloodlines (Esp Lat)"
        # echo -e "${CYAN}Configuración de PSP${NC}"
        echo "12. Volver al menú principal"
        read -p "Seleccione una opción: " opcion_submenu_psp

        case $opcion_submenu_psp in
            # Nota: Al agregar otro juego, debes tener en cuenta el peso de la iso en este caso
            
            # link de la configuración 
            # https://drive.google.com/file/d/1A7I_bxM85VmqIMWgEN1bjkmKdtZXwvkY/view?usp=drivesdk
            # https://drive.google.com/file/d/1SyltpI6MD1yk5L5ogKf4B_SCC3FODl06/view?usp=drivesdk
            # https://drive.google.com/file/d/1-nDudnJTw3_ebtPBwMD1JLhWipSvUxl7/view?usp=drivesdk
            
            # descargar_y_descomprimir "$1"   "$2"                  "$3"                    "$4"               "$5"            "$6"        
            # descargar_y_descomprimir "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$apk_zip" "$adb_conectado"
            1|01)
                
                # Link del emulador de PS2
                # https://drive.google.com/file/d/1uAXATsAwSLWY_JRVSyP-BAjxt8DWd5Ap/view?usp=drivesdk
                # https://drive.google.com/file/d/1-FTeFCv8X2TcW5HWuzkLdZKGapkyRE5b/view?usp=drivesdk
                # https://drive.google.com/file/d/17f_8NSGAXW_FuerK0dgdb3f9eKb25Ygn/view?usp=drivesdk
                descargar_apk_rom_y_descomprimir "17f_8NSGAXW_FuerK0dgdb3f9eKb25Ygn" "Emulador_PS2_Bios.zip" "/sdcard/Download/Games/PSE/Play_Station_2" "/sdcard/Download/Games/PSE/Play_Station_2/Emulador_PS2_Bios/AetherSX2_v1.5-3668(13930).apk" "$adb_conectado" "submenu_psp" "xyz.aethersx2.android"
                APK_PATH="/sdcard/Download/Games/PSE/Play_Station_2/Emulador_PS2_Bios/AetherSX2_v1.5-3668(13930).apk"
                nombre_archivo="AetherSX2_v1.5-3668(13930).apk"
                if adb -s "${adb_conectado}" shell pm list package | grep -E "^package:xyz.aethersx2.android$" | awk -F ':' '{print $2}' > /dev/null; then
                    app_instalada='true'
                fi
                nombre_archivo_escapado=""
                for (( i=0; i<${#nombre_archivo}; i++ )); do
                    char="${nombre_archivo:i:1}"
                    case "$char" in
                        '(' | ')' | '[' | ']')
                            nombre_archivo_escapado+="\\$char"
                            ;;
                        *)
                            nombre_archivo_escapado+="$char"
                            ;;
                    esac
                done
                if [ -n "${adb_conectado}" ] && [ "${app_instalada}" == "true" ]; then
                    echo -e "${YELLOW}La aplicación ya esta instalada en su dispositivo!!!${NC}" > /dev/null
                    return
                elif [ -n "${adb_conectado}" ] && [ "${app_instalada}" == "false" ]; then
                    echo -e "${YELLOW}Instalando la app en su dispositivo!!!${NC}"
                    adb -s "${adb_conectado}" push "$APK_PATH" "/data/local/tmp/$nombre_archivo"
                    adb -s "${adb_conectado}" shell pm install "/data/local/tmp/$nombre_archivo_escapado"
                    adb -s "${adb_conectado}" shell rm "/data/local/tmp/$nombre_archivo_escapado"
                    echo -e "${GREEN}${nombre_archivo} instalado correctamente${NC}"
                else
                    echo -e "${RED}No se detectó un dispositivo conectado a través de ADB.${NC}" > /dev/null
                fi
                ;;
            2|02)
                # Link de PS2: GOW 1
                descargar_y_descomprimir "https://www.mediafire.com/file/xncr3c1dwbgibft/God_Of_War_1_Esp.zip/file" "God_Of_War_1_Esp.zip" "/sdcard/Download/Games/PSE/Play_Station_2" "/sdcard/Download/Games/PSE/Play_Station_2/God Of War I (Europe, Australia) (En,Fr,De,Es,It,Ru)/God of War (Europe Australia) (EnFrDeEsIt).chd"
                ;;
            3|03)
                # Link de PS2: GOW 2
                descargar_y_descomprimir "https://www.mediafire.com/file/5obakmeu901t05d/God_of_War_2_Esp.zip/file" "God_Of_War_2_Esp.zip" "/sdcard/Download/Games/PSE/Play_Station_2" "/sdcard/Download/Games/PSE/Play_Station_2/God of War II (Europe, Australia) (En,Fr,De,Es,It,Ru)/God of War II (Europe, Australia) (En,Fr,De,Es,It,Ru).iso"
                ;;
            4|04)
                # Link de PS2: DBZBT 4
                descargar_y_descomprimir "https://www.mediafire.com/file/n5vsjcxwa5ug0sl/Dragon_Ball_Z_Budokai_Tenkaichi_4.zip/file" "Dragon_Ball_Z_Budokai_Tenkaichi_4.zip" "/sdcard/Download/Games/PSE/Play_Station_2" "/sdcard/Download/Games/PSE/Play_Station_2/Dragon Ball Z Budokai Tenkaichi 4  (Beta 13 Rev4.2 v0.13.4.2) [NTSC]/Dragon_Ball_Z_Budokai_Tenkaichi_4_Latino.iso"
                ;;
            5|05)
                # Link de PS2: CGS
                # Link: Conflict Global Storm
                # https://www.mediafire.com/file/3zdxzehhf8rn32v/Conflict_Global_Storm.zip/file
                descargar_y_descomprimir "https://www.mediafire.com/file/3zdxzehhf8rn32v/Conflict_Global_Storm.zip/file" "Conflict_Global_Storm.zip" "/sdcard/Download/Games/PSE/Play_Station_2" "/sdcard/Download/Games/PSE/Play_Station_2/Conflict Global Storm [PAL-NTSC] [Es,Fr,De,En,It]/Conflict GS.iso"
                ;;
            
            6|06)
                app_instalada='false'
                # https://drive.google.com/file/d/1-0F8MimioVARMZURs_vjqLWwAIHGQDq9/view?usp=drivesdk                                                                                                                 
                # descargar_apk_rom_y_descomprimir "$url"                                                                     "$archivo_zip"        "$ruta_destino"                                                                                         "$ruta_apk"                                                                                                                               "$adb_conectado"
                # descargar_apk_rom_y_descomprimir "1-0F8MimioVARMZURs_vjqLWwAIHGQDq9" "PSP_v1.0.1.0.zip" "/sdcard/Download/Games/God_Of_War_Ghost_Of_Sparta_Esp" "/sdcard/Download/Games/God_Of_War_Ghost_Of_Sparta_Esp/PSP_v1.0.1.0.apk" "$adb_conectado"
                # https://drive.google.com/file/d/1JTDoR6U0RWN0-LRsJHy56LjNG7sipKil/view?usp=drivesdk
                # descargar_apk_rom_y_descomprimir "1JTDoR6U0RWN0-LRsJHy56LjNG7sipKil" "PPSSPP_Gold_v1.17.1.zip" "/sdcard/Download/Games/God_Of_War" "/sdcard/Download/Games/God_Of_War/PPSSPP_Gold_v1.17.1.apk" "$adb_conectado"
                # https://drive.google.com/file/d/1WgWfFyPKAI3wzP3a-wVQmBYZw7la6VWp/view?usp=drivesdk
                # https://drive.google.com/file/d/18pgE0brpURZKdupnSJZrskLFU6wB1VBq/view?usp=drivesdk
                descargar_apk_rom_y_descomprimir "18pgE0brpURZKdupnSJZrskLFU6wB1VBq" "PPSSPP_Gold.zip" "/sdcard/Download/Games/PSE/PPSSPP" "/sdcard/Download/Games/PSE/PPSSPP/PPSSPP_Gold/PPSSPP_Gold_v1.18.1.apk" "$adb_conectado" "submenu_psp" "org.ppsspp.ppssppgold"
                mkdir -p /sdcard/PSP
                ;;
            7|07)
                descargar_y_descomprimir "https://www.mediafire.com/file/23vdt913xtzedus/God_Of_War_Chains_Of_Olympus_Esp.zip/file" "God_Of_War_Chains_Of_Olympus_Esp.zip" "/sdcard/Download/Games/PSE/PPSSPP" "/sdcard/Download/Games/PSE/PPSSPP/God_Of_War_Chains_Of_Olympus_Esp/God Of War Chains Of Olympus (Esp).iso"
                ;;
            8|08)
                fps_stable_cheat_psp_gow_coo
                ;;
            9|09)
                descargar_y_descomprimir "https://www.mediafire.com/file/49dfmc491t395qu/God_Of_War_Ghost_Of_Sparta_Esp.zip/file" "God_Of_War_Ghost_Of_Sparta_Esp.zip" "/sdcard/Download/Games/PSE/PPSSPP" "/sdcard/Download/Games/PSE/PPSSPP/God_Of_War_Ghost_Of_Sparta_Esp/God Of War Ghost Of Sparta (Esp).iso"
                ;;
            10)
                fps_stable_cheat_psp_gow_gos
                ;;
            11)
                descargar_y_descomprimir "https://www.mediafire.com/file/89p0t39zyrbl38w/assassin_s_creed_bloodlines.zip/file" "assassin_s_creed_bloodlines.zip" "/sdcard/Download/Games/PSE/PPSSPP" "/sdcard/Download/Games/PSE/PPSSPP/assassin's_creed_bloodlines/assassin's creed bloodlines.iso"
                ;;
            12)
                echo "Volviendo al menú principal..."
                menu_principal
                break
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
                ;;
        esac
        # app_instalada='false'
    done
}



# Submenú de wii
submenu_wii() {
    while true; do
        local adb_conectado="$1"
        # if [ "$adb_conectado" == 'true' ]; then
        if [ -n "$adb_conectado" ]; then
            echo -en "\n${GREEN}Dispositivo conectado a adb${NC}: $adb_conectado"
        fi
        echo -e "\n${CYAN}Nintendo Wii${NC}"
        echo -e "01. Instalar Emulador NWii"
        echo -e "${CYAN}Juegos de NWii${NC}"
        echo "02. New Super Mario Bros (Español)"
        echo "03. Volver al menú principal"
        read -p "Seleccione una opción: " opcion_submenu_nwii

        case $opcion_submenu_nwii in
            # Nota: Al agregar otro juego, debes tener en cuenta el peso de la iso en este caso
            # https://drive.google.com/file/d/1ZCnbDsQLvEd1ZLjNpQyKOJM4xzYj8iyi/view?usp=drivesdk
            # descargar_y_descomprimir "$1"   "$2"                  "$3"                    "$4"               "$5"            "$6"        
            # descargar_y_descomprimir "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$apk_zip" "$adb_conectado"
            1|01)
                # Link del emulador de NWii
                # https://drive.google.com/file/d/1_JH798sKDHKEeDyZJob2RmNe-IiaGRVB/view?usp=drivesdk
                # https://drive.google.com/file/d/16-wm_iVifjGksN678sntJpIvrRp-gm5D/view?usp=drivesdk
                # https://drive.google.com/file/d/17-YAysEHZ0C4Jz-dhYUZ0uFo06MMYEUg/view?usp=drivesdk
                # https://drive.google.com/file/d/17RdH0oDUd9mpaht38XnPQ82Q4j-4371P/view?usp=drivesdk
                # https://drive.google.com/file/d/17iuNhZezwzEW7PIaLYpeOzQMdXvxSj-w/view?usp=drivesdk
                # https://drive.google.com/file/d/19hi1FPqSyeUUwr7iP6p9lGOEkkaGOyzk/view?usp=drivesdk
                # https://drive.google.com/file/d/1A20nzlJN8WmyX7xfmFLhE5gAp5_Hht2m/view?usp=drivesdk
                # https://drive.google.com/file/d/1AoUEmcmvmJJUJ_CLpLMF4IbbPbug79ZF/view?usp=drivesdk
                # https://drive.google.com/file/d/1B1K6vQuR2M21-UrCUdf9xPuU-Aqc-2kg/view?usp=drivesdk
                descargar_apk_rom_y_descomprimir "1B1K6vQuR2M21-UrCUdf9xPuU-Aqc-2kg" "Emulador_wii.zip" "/sdcard/Download/Games/NWII/Nintendo_Wii" "/sdcard/Download/Games/NWII/Nintendo_Wii/Emulador_wii/Dolphin-MMJR.v3.0-20814.apk" "$adb_conectado" "submenu_wii" "org.dolphinemu.mmjr3"
                ;;
            2|02)
                # Link de NWII: New Súper Mario Bros
                descargar_y_descomprimir "https://www.mediafire.com/file/sd1v292g5lt1c1m/New_Super_Mario_Bros_Wii.zip/file" "New_Super_Mario_Bros_Wii.zip" "/sdcard/Download/Games/NWII/Nintendo_Wii" "/sdcard/Download/Games/NWII/Nintendo_Wii/New Super Mario Bros Wii [SMNE01].wbfs"
                ;;
            3|03)
                echo "Volviendo al menú principal..."
                break
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
                ;;
        esac
    done
}

menu_principal() {
    while true; do
        # wlan0
        verif_adb_conect
        if [ "$disponible_adb" == 'true' ]; then
            echo -e "\n${YELLOW}La dirección IP de wlan0 es${NC}: $ip0"
            echo -e "${GREEN}Disponible para conectar adb${NC}"
            echo -e "\n${CYAN}Menú Principal${NC}"
            echo -e "00. ${GREEN}Conectar adb${NC}"
        fi
        if [ "$disponible_adb" == 'false' ]; then
            # echo -e "${YELLOW}No estás conectado a un ${NC}(${RED}adaptador${RED}) ${YELLOW}WI-FI${NC}:\n${YELLOW}ip: ${NC}$ip1"
            echo -e "\n${CYAN}Menú Principal${NC}"
            # echo -e "00. ${GREEN}Conectar adb${NC}"
        fi
        echo "01. Modern Combat 1 - Sand Storm"
        echo "02. Modern Combat 2 - Black Pegasus"
        echo "03. Modern Combat 3 - Fallen Nation"
        echo "04. Modern Combat 4 - Zero Hour"
        echo "05. Call Of Duty - Strike Team"
        echo "06. Shadow Gun - DeadZone"
        echo "07. PSP Gold - Play Station"
        echo "08. Citra 3DS - Emulador y juegos"
        echo "09. Más Emuladores y Juegos N64"
        echo "10. Nintendo WII - Emulador y juegos"
        echo "11. Salir"
        read -p "Ingrese el número de su elección: " eleccion
    
        case $eleccion in
            # descargar_y_descomprimir "$1"   "$2"                  "$3"                    "$4"              "$5"            "$6"                            "$7"               "$8"                             "$9"            "$10"
            # descargar_y_descomprimir "$url" "$archivo_zip" "$ruta_destino" "$ruta_apk" "$url_apk" "$ruta_destino_apk" "$ruta_obb" "$ruta_destino_obb" "$apk_zip" "$adb_conectado" 
        0|00)
                if [ "$disponible_adb" == 'true' ]; then
                    solicitar_emparejamiento
                fi
                ;;
            1|01)
                descargar_y_descomprimir "https://www.mediafire.com/file/8jttvxm57wu2sf6/Modern_Combat_1_Sand_Storm.zip/file" "Modern_Combat_1_Sand_Storm.zip" "/sdcard/Download/Games/Modern_Combat" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_1_Sand_Storm/mcS-hvga-androidianbuzz.blogspot.in.apk" "https://www.mediafire.com/file/xscrx3w6ll6dxmq/mc1.zip/file" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_1_Sand_Storm" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_1_Sand_Storm/sandstorm.zip" "/sdcard/Android/obb" "mc1.zip" "$adb_conectado" 
                ;;
            2|02)
                descargar_y_descomprimir "https://www.mediafire.com/file/1dmdmqdn68xu0de/Modern_Combat_2_Black_Pegasus.zip/file" "Modern_Combat_2_Black_Pegasus.zip" "/sdcard/Download/Games/Modern_Combat" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_2_Black_Pegasus/(1920x1080)Modern Combat 2 Black Pegasus HD v1.0.2_androidgamegratisan.blogs.apk" "https://www.mediafire.com/file/vfgc249hhbruarg/mc2.zip/file" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_2_Black_Pegasus" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_2_Black_Pegasus/Modern Combat 2 Black Pegasus HD v1.0.2_androidgamegratisan.blogspot.com.zip" "/sdcard/Android/obb" "mc2.zip" "$adb_conectado" 
                ;;
            3|03)
                descargar_y_descomprimir "https://www.mediafire.com/file/3y1tjfvxwz05xqw/Modern_Combat_3_Fallen_Nation.zip/file" "Modern_Combat_3_Fallen_Nation.zip" "/sdcard/Download/Games/Modern_Combat" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_3_Fallen_Nation/Modern-Combat-3-Fallen-Nation-v1-1-7g-offline.apk" "https://www.mediafire.com/file/5wfqxd9b4df19ef/mc3.zip/file" "/sdcard/Download/Modern_Combat/Games/Modern_Combat_3_Fallen_Nation" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_3_Fallen_Nation/411-Modern-Combat-3-Fallen-Nation-v1-1-6b-cache1.zip" "/sdcard/Android/obb" "mc3.zip" "$adb_conectado" 
                ;;
            4|04)
                descargar_y_descomprimir "https://www.mediafire.com/file/75vpclhv3m97xzk/Modern_Combat_4_Zero_Hour.zip/file" "Modern_Combat_4_Zero_Hour.zip" "/sdcard/Download/Games/Modern_Combat" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_4_Zero_Hour/Modern-Combat-4-Zero-Hour-v1-2-2e-Low.apk" "https://www.mediafire.com/file/5gpfugpegtd8buc/mc4.zip/file" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_4_Zero_Hour" "/sdcard/Download/Games/Modern_Combat/Modern_Combat_4_Zero_Hour/Modern_Combat_4_obb.zip" "/sdcard/Android/obb" "mc4.zip" "$adb_conectado" 
                ;;
            5|05)
                descargar_y_descomprimir "https://www.mediafire.com/file/1rj9feqv2thjn3i/Call_Of_Duty_Strike_Team.zip/file" "Call_Of_Duty_Strike_Team.zip" "/sdcard/Download/Games" "/sdcard/Download/Games/Call_Of_Duty_Strike_Team/Call-of-Duty-Strike-Team-v1-0-40.apk" "https://www.mediafire.com/file/op3qqadw5uaynkg/CODST.zip/file" "/sdcard/Download/Games/Call_Of_Duty_Strike_Team" "/sdcard/Download/Games/Call_Of_Duty_Strike_Team/08847-Call-of-Duty-Strike-Team-v1-0-40-cache1.zip" "/sdcard/Android/obb" "CODST.zip" "$adb_conectado" 
                ;;
            6|06)
                descargar_y_descomprimir "https://www.mediafire.com/file/hfg7bmtapsy5pmd/Shadow_Gun.zip/file" "Shadow_Gun.zip" "/sdcard/Download/Games" "/sdcard/Download/Games/Shadow gun/Archivo206.apk" "https://www.mediafire.com/file/0gnthl0ixkc249l/sgun.zip/file" "/sdcard/Download/Games/Shadow gun" "/sdcard/Download/Games/Shadow gun/com.madfingergames.shadowgun.zip" "/sdcard/Android/obb" "sgun.zip" "$adb_conectado" 
                ;;
            7|07)
                submenu_psp "$adb_conectado" 
                ;;
            8|08)
                submenu_citra "$adb_conectado" 
                ;;
            09|09)
                descargar_y_descomprimir "https://www.mediafire.com/file/f2d5hwytl50gig8/com.supern64.n64.emulator.zip/file" "com.supern64.n64.emulator.zip" "/sdcard/Download/Games/N64"
                descargar_y_descomprimir "https://www.mediafire.com/file/g537ztp48uegp0z/N64oid_2.6.3thidroidvlog.zip/file" "N64oid_2.6.3thidroidvlog.zip" "/sdcard/Download/Games/N64"
                descargar_y_descomprimir "https://www.mediafire.com/file/l3flqz9jlefwzom/N64oid_v2.4.3.zip/file" "N64oid_v2.4.3.zip" "/sdcard/Download/Games/N64"
                descargar_y_descomprimir "https://www.mediafire.com/file/d7j9qtp7clihwbn/paulscode.android.mupen64plus.free.zip/file" "paulscode.android.mupen64plus.free.zip" "/sdcard/Download/Games/N64"
                descargar_y_descomprimir "https://www.mediafire.com/file/993n408u6h7o6jg/Diddy_Kong_Racing_E_M3_64.zip/file" "Diddy_Kong_Racing_E_M3_64.zip" "/sdcard/Download/Games/N64/ROMS"
                descargar_y_descomprimir "https://www.mediafire.com/file/5yh0wt8mypkb1my/GoldenEye_007_64.zip/file" "GoldenEye_007_64.zip" "/sdcard/Download/Games/N64/ROMS"
                descargar_y_descomprimir "https://www.mediafire.com/file/c862tk3euq01cty/Mario_Kart_64.zip/file" "Mario_Kart_64.zip" "/sdcard/Download/Games/N64/ROMS"
                descargar_y_descomprimir "https://www.mediafire.com/file/si0zj8vugd53o89/Perfect_Dark_E_M5.zip/file" "Perfect_Dark_E_M5.zip" "/sdcard/Download/Games/N64/ROMS"
                ;;
            10)
                submenu_wii "$adb_conectado" 
                ;;
            11)
                echo "Saliendo..."
                cd ~/Busca-Palabras
                bash Menu-Busca-Palabras.sh
                exit 0
                ;;
            *)
                echo -e "${RED}Opción no válida. Intente de nuevo.${NC}"
                ;;
        esac
    done
}

menu_principal

: '
esta es una línea que esta en el archivo file qué se descargo de mediafire con curl, y contiene la url
href="https://download1501.mediafire.com/i96gg0tc36kgbAsqrfzEPx-iNZxOHGUGkr0ilcGw8qizugZ77F8VxYU-lFkeEVeXcUBAFYs1bCGeqtlx84MFRCTw7jthha7fPQwKyEuCvfBOZ9Wm7ZIcvQUT0xorojQZAeGKhlgdQBPODUZNyul2wg6C5lycepfTSYrPk0VRyHeJcvwg/pn6jn3bt120mdaz/Texturas_De_Zelda_Ocarina_Of_Time.zip"           id="downloadButton"

Luego con:
grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2

1. grep 'href.*download.*media.*' file
Realiza una búsqueda en el archivo file de todas las líneas que contienen las palabras 'href', 'download' y 'media' en ese orden. Devuelve las líneas que cumplen con esta condición.

2. head -1
Devuelve solo la primera línea que coincide con la condición.

3. cut -d '"' -f 2: 
Divide la línea en campos utilizando el carácter `"` como delimitador y selecciona el segundo campo. En este caso, el segundo campo es la URL de descarga.

https://download1501.mediafire.com/i96gg0tc36kgbAsqrfzEPx-iNZxOHGUGkr0ilcGw8qizugZ77F8VxYU-lFkeEVeXcUBAFYs1bCGeqtlx84MFRCTw7jthha7fPQwKyEuCvfBOZ9Wm7ZIcvQUT0xorojQZAeGKhlgdQBPODUZNyul2wg6C5lycepfTSYrPk0VRyHeJcvwg/pn6jn3bt120mdaz/Texturas_De_Zelda_Ocarina_Of_Time.zip
: '

# archivo para pruebas
# https://www.mediafire.com/file/3nv38n7cej4djvz/Dynamo_Labs_v0.1_adb.zip/file


: '
# Código verifica imagen 
# # Instalar ImageMagick
# pkg install imagemagick

# Archivo de imagen pasado como argumento
archivo_imagen="$1"

# Función para verificar si una imagen png, jpg, jpeg. estan en buen estado o si estan corruptas o mala
verificar_imagen() {
    echo "Verificando: $archivo_imagen"
    
    # Usar el comando identify para verificar la imagen
    salida=$(identify "$archivo_imagen" 2>&1)
    
    # Comprobar si el comando fue exitoso
    if [[ $? -eq 0 ]]; then
        echo "La imagen está en buen estado."
        echo "Detalles: $salida"
    else
        echo "Error al verificar la imagen: $salida"
        echo "La imagen está corrupta o no es un formato válido."
    fi
}

# Uso del script
verificar_imagen
: '


# Configurar AetherSX2 
# https://www.mediafire.com/file/ksm8w2om1118fdu/AetherSX_Config.mp4/file