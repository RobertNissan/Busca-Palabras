while true
do
clear
echo -e ""
echo -e "      ${verde}Para que funcionen los idiomas
      primero debes tener instalado
         (Vocalizer TTS v3.1.1)\n"

echo -e "              ${blanco}Pack De Idiomas"
echo -e "${verde}+------------------------------------------+
#Espanol De Colombia  |Espanol De Espana   #
#[${blanco}1${verde}] ${blanco}Voz de Carlos    ${verde}|[${blanco}4${verde}] ${blanco}Voz de Jorge    ${verde}#
#[${blanco}2${verde}] ${blanco}Voz de Soledad   ${verde}|[${blanco}5] ${blanco}Voz de Monica   ${verde}#
#[${blanco}3${verde}] ${blanco}Voz de Ximena    ${verde}|[${blanco}6${verde}] ${blanco}Voz de Marisol  ${verde}#
#------------------------------------------#
#${verde}Espanol De Mexico    |Espanol De Argentina#
#[${blanco}7${verde}] ${blanco}Voz de Angelica  ${verde}|[${blanco}10${verde}] ${blanco}Voz de Diego   ${verde}#
#[${blanco}8${verde}] ${blanco}Voz de Juan      ${verde}|[${blanco}11${verde}] ${blanco}Voz de Isabela ${verde}#
#[${blanco}9${verde}] ${blanco}Voz de Paulina   ${verde}|                    #
#------------------------------------------#
#Espanol De Chile     |${blanco}     Aplicacion     ${verde}#
#[${blanco}12${verde}] ${blanco}Voz de Francisca${verde}|[${blanco}13${verde}]${blanco} Vocalizer TTS  ${verde}#
#------------------------------------------#
#      [${blanco}14${verde}] ${blanco}Volver al menu ttsreader       ${verde}#
+------------------------------------------+"

#codigo verificar si existen voces instaladas
if [ -d /sdcard/VocalizerTTS ]; then 
con=$(ls /sdcard/VocalizerTTS/data | wc -l)
if [[ $con =~ ^[0-9]+$ ]] && (($con >= 1 && $con <= 12)); then
echo -e ""
echo -en "${verde}Actualmente tiene $con idiomas instalados!${blanco}"
cd /sdcard/VocalizerTTS/data
r=$(echo -e "$rojo")
b=$(echo -e "$blanco")
#------------------
#sl=$(ls)
#echo -e $sl
#------------------
for i in $(seq 1 ${con}); do
sl=$(ls)
ak=$(echo -e $sl | cut -d' ' -f${i})
# Variable busco solo dos digitos
echo ${r}
stri="$(echo -e "0$i $ak" | grep -E "\<[0-9]{2}\>")"
#echo $stri
nu="$(echo -e "0$i" | grep -E "\<[0-9]{2}\>")"
#echo $nu
# Variable busco solo tres digitos y borra el primer digito
str="$(echo -e "0$i $ak" | grep -E "\<^[0-9]{3}\>" | sed 's/^0//' )"
#echo -e "$str\n"
num="$(echo -e "0$i" | grep -E "\<^[0-9]{3}\>" | sed 's/^0//' )"
#echo $num
if [[ "$ak" == "esspanishmonica" ]]; then mo=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Monica");eses=$(echo -en "Espanol De Espana");echo -en "$mo";elif [[ "$ak" == "spanishcolombiasoledad" ]]; then so=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Soledad");escol=$(echo -en "Espanol De Colombia");echo -en "$so";elif [[ "$ak" == "spanishcolombiaximena" ]]; then xi=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Ximena");escol=$(echo -en "Espanol De Colombia");echo -en "$xi";elif [[ "$ak" == "mexicanspanishangelica" ]]; then an=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Angelica");esme=$(echo -en "Espanol De Mexico");echo -en "$an";elif [[ "$ak" == "mexicanspanishjuan" ]]; then ju=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Juan");esme=$(echo -en "Espanol De Mexico");echo -en "$ju";elif [[ "$ak" == "mexicanspanishpaulina" ]]; then pa=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Paulina");esme=$(echo -en "Espanol De Mexico");echo -en "$pa";elif [[ "$ak" == "spanishchilefrancisca" ]]; then fr=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Francisca");esch=$(echo -en "Espanol De Chile");echo -en "$fr";elif [[ "$ak" == "spanishjorge" ]]; then jo=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Jorge");eses=$(echo -en "Espanol De Espana");echo -en "$jo";elif [[ "$ak" == "spanishcolombiacarlos" ]]; then ca=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Carlos");escol=$(echo -en "Espanol De Colombia");echo -en "$ca";elif [[ "$ak" == "spanishmarisol" ]]; then ma=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Marisol");eses=$(echo -en "Espanol De Espana");echo -en "$ma";elif [[ "$ak" == "spanishargentinadiego" ]]; then di=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Diego");esar=$(echo -en "Espanol De Argentina");echo -en "$di";elif [[ "$ak" == "spanishargentinaisabela" ]]; then is=$(echo -en "${verde}[${rojo}Instalada${verde}] ${b}Voz de Isabela");esar=$(echo -en "Espanol De Argentina");echo -en "$is";fi;
done
cd
fi
fi
#fin del codigo verificar existencia de voz

echo -e "\n"
mkdir -p /sdcard/VocalizerTTS/data
read -p "Selecciona el idioma que deseas instalar! " id
case $id in

1|01)
#voces vocalizer
wget https://www.dropbox.com/s/k50kylf132mebdp/spanishcolombiacarlos.zip?dl=0;mv spanishcolombiacarlos.zip?dl=0 spanishcolombiacarlos.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishcolombiacarlos.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Carlos extraido";sleep 2;clear;rm -rf spanishcolombiacarlos.zip;bash Busca-Palabras/opc/voz.sh
;;

2|02)
wget https://www.dropbox.com/s/fttexzwhzce5p87/spanishcolombiasoledad.zip?dl=0;mv spanishcolombiasoledad.zip?dl=0 spanishcolombiasoledad.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishcolombiasoledad.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Soledad extraido";sleep 2;clear;rm -rf spanishcolombiasoledad.zip;bash Busca-Palabras/opc/voz.sh
;;

3|03)
wget https://www.dropbox.com/s/zzvcm33tvtfeuqx/spanishcolombiaximena.zip?dl=0;mv spanishcolombiaximena.zip?dl=0 spanishcolombiaximena.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishcolombiaximena.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Ximena extraido";sleep 2;clear;rm -rf spanishcolombiaximena.zip;bash Busca-Palabras/opc/voz.sh
;;

4|04)
wget https://www.dropbox.com/s/xm3t0rfnemhevj8/spanishjorge.zip?dl=0;mv spanishjorge.zip?dl=0 spanishjorge.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishjorge.zip -d /sdcard/VocalizerTTS/data;sleep 2;echo -e "";echo "Idioma de Jorge extraido";sleep 2;clear;rm -rf spanishjorge.zip;bash Busca-Palabras/opc/voz.sh
;;

5|05)
wget https://www.dropbox.com/s/1uufo3lgrhfpm87/esspanishmonica.zip?dl=0;mv esspanishmonica.zip?dl=0 esspanishmonica.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o esspanishmonica.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Monica extraido";sleep 2;clear;rm -rf esspanishmonica.zip;bash Busca-Palabras/opc/voz.sh
;;

6|06)
wget https://www.dropbox.com/s/ebqr1bmjby0n3pl/spanishmarisol.zip?dl=0;mv spanishmarisol.zip?dl=0 spanishmarisol.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishmarisol.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Marisol extraido";sleep 2;clear;rm -rf spanishmarisol.zip;bash Busca-Palabras/opc/voz.sh
;;

7|07)
wget https://www.dropbox.com/s/2nykunsjshp28vp/mexicanspanishangelica.zip?dl=0;mv mexicanspanishangelica.zip?dl=0 mexicanspanishangelica.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o mexicanspanishangelica.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Angelica extraido";sleep 2;clear;rm -rf mexicanspanishangelica.zip;bash Busca-Palabras/opc/voz.sh
;;

8|08)
wget https://www.dropbox.com/s/jq7hc8p5q674dm9/mexicanspanishjuan.zip?dl=0;mv mexicanspanishjuan.zip?dl=0 mexicanspanishjuan.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o mexicanspanishjuan.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Juan extraido";sleep 2;clear;rm -rf mexicanspanishjuan.zip;bash Busca-Palabras/opc/voz.sh
;;

9|09)
wget https://www.dropbox.com/s/5hrsrl347ixkfwj/mexicanspanishpaulina.zip?dl=0;mv mexicanspanishpaulina.zip?dl=0 mexicanspanishpaulina.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o mexicanspanishpaulina.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Paulina extraido";sleep 2;clear;rm -rf mexicanspanishpaulina.zip;bash Busca-Palabras/opc/voz.sh
;;

10)
wget https://www.dropbox.com/s/36cqj4satod05hd/spanishargentinadiego.zip?dl=0;mv spanishargentinadiego.zip?dl=0 spanishargentinadiego.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishargentinadiego.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Diego extraido";sleep 2;clear;rm -rf spanishargentinadiego.zip;bash Busca-Palabras/opc/voz.sh
;;

11)
wget https://www.dropbox.com/s/3lu3boxsjbyf3c3/spanishargentinaisabela.zip?dl=0;mv spanishargentinaisabela.zip?dl=0 spanishargentinaisabela.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishargentinaisabela.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Isabela extraido";sleep 2;clear;rm -rf spanishargentinaisabela.zip;bash Busca-Palabras/opc/voz.sh
;;

12)
wget https://www.dropbox.com/s/zbpa9t8ofgshgk2/spanishchilefrancisca.zip?dl=0;mv spanishchilefrancisca.zip?dl=0 spanishchilefrancisca.zip;clear;echo -e "Extrayendo achivos a VocalizerTTS/data\n";sleep 2;unzip -o spanishchilefrancisca.zip -d /sdcard/VocalizerTTS/data;echo -e "";echo "Idioma de Francisca extraido";sleep 2;clear;rm -rf spanishchilefrancisca.zip;bash Busca-Palabras/opc/voz.sh
;;

13)
echo -e ""
if [ -e ${HOME}/Vocalizer_TTS_Pro3.1.11-1.apk ]; then
echo "Vocalizer_TTS_Pro3.1.11-1"
echo "Ya esta descargado"
sleep 2
xdg-open Vocalizer_TTS_Pro3.1.11-1.apk
bash Busca-Palabras/opc/voz.sh
clear
else
echo -e ""
echo "Descargando Vocalizer_TTS_Pro3.1.11-1"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/6r3sys5xi9sc03p/Vocalizer_TTS_Pro3.1.11-1.apk?dl=0;mv Vocalizer_TTS_Pro3.1.11-1.apk?dl=0 Vocalizer_TTS_Pro3.1.11-1.apk;xdg-open Vocalizer_TTS_Pro3.1.11-1.apk;echo -e ""
bash Busca-Palabras/opc/voz.sh
clear
fi
;;

14)
bash Busca-Palabras/opc/ttsreader.sh
;;

*) echo "opcion invalida";sleep 1;clear
;;

esac
done
exit