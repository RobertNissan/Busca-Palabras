#!/bin/bash
sn=0
sn=1
source ${PWD}/Colors.sh
cd ${HOME}/
# Bucle while 
clear
while [[ "$sn" == "0" || "$sn" == "1" ]]; do
clear
echo -e ""
echo -e "   Copia de seguridad WhatsApp Aero"
echo -en "${verde}+---------------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar WhatsApp Aero v9.29   ${verde}#
#---------------------------------------#
# "[${blanco}02${verde}] | ${blanco}Respaldar la copia de aero"     ${verde}#
#---------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Restaurar copia de aero"        ${verde}#
#---------------------------------------#
# "[${blanco}04${verde}] | ${blanco}Repositorios zip y tsu"         ${verde}#
#---------------------------------------#
# "[${blanco}05${verde}] | ${blanco}Volver al menu app premium"     ${verde}#
+---------------------------------------+
|
+->>> "${blanco}
read -r "sn"
clear
echo -e ""
case $sn in

		1|01)
echo -e ""
if [ -e ${HOME}/WA_AERO_Modern_Hazar.apk ]; then
echo "WhatsApp AERO Modern Hazar"
echo "Ya esta descargado"
sleep 2
xdg-open WA_AERO_Modern_Hazar.apk
clear
else
echo -e ""
echo "Descargando WhatsApp AERO Modern Hazar"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/p6kvxez88nk6ipx/WA_AERO_Modern_Hazar.apk?dl=0;mv WA_AERO_Modern_Hazar.apk?dl=0 WA_AERO_Modern_Hazar.apk;xdg-open WA_AERO_Modern_Hazar.apk;
echo -e ""
clear
fi
;;

       2|02)
clear
if [ -d /sdcard/WhatsApp/aeroYedek ]; then
echo "Iniciando"
sleep 1
else
echo -e "Aun no has creado la copia!"
echo "entra a WhatsApp Aero, luego click en los
3 puntos (...) en la parte superior derecha
click en:
1)Privilegios Aero
2)Universal
3)Copia de seguridad y restauracion
4)Copia de seguridad de WhatsApp
Listo"
exit
fi
#root="$(echo "/mnt/media_rw/")"
misd=$(sudo ls /mnt/media_rw/)
root=$(echo "/mnt/media_rw/")
var=$(su -c ls /storage/"$misd"/backups/ | grep WhatsApp.zip)
#echo "$var"
vari=$(echo "WhatsApp.zip")
#echo "$vari"
#echo -e "/storage/$misd"
if [ -d /storage/$misd ]; then
if [ -e /storage/$misd/backups/WhatsApp.zip ]; then
#sn=0
#while [ "$sn" == "0" ]; do
clear
echo "Copia en la memoria externa"
echo "Existe una copia ya!!!"
read -p "Desea sobrescribir S/N? > " sn
if [[ "$sn" == "s" || "$sn" == "S" ]]; then
echo Borrando antigua copia
sudo rm -r /mnt/media_rw/$misd/backups/WhatsApp.zip >/dev/null 2>&1

echo Comprimiendo nueva copia
echo -e ""
cd /sdcard/WhatsApp/
zip -r9 WhatsApp.zip *

echo -e ""
echo "Moviendo Copia de seguridad!"
echo -e "Destino: /storage/"$misd"/backups/"
echo "Espere por favor"
mkdir -p /storage/$misd/backups/
cd /sdcard/WhatsApp/
sudo mv WhatsApp.zip /storage/$misd/backups/
clear
if [ -e /storage/"$misd"/backups/WhatsApp.zip ]; then
echo -e ""
echo "Copia realizada"
echo "en /storage/"$misd"/backups/"
ver=$(sudo ls /storage/"$misd"/backups/ | grep WhatsApp.zip)
echo "Nombre: $ver"
#peso=$(sudo ls -n /storage/"$misd"/backups/ | grep WhatsApp.zip | cut -d' ' -f6)
peso=$(du -h /storage/"$misd"/backups/WhatsApp.zip)
size="$(echo "$peso" | grep -o ^[0-9].[A-Z])"
echo -e "Peso: ${size}"
###############################
##while [[ ! "$peso" =~ ^[0-9]+$ ]]; do
##misd=$(sudo ls /mnt/media_rw/)
##ver=$(sudo ls /storage/"$misd"/backups/ | grep WhatsApp.zip)
##peso=$(sudo fincore /storage/"$misd"/backups/"$ver" | sed -n '$p' | cut -d' ' -f8)
##echo $peso
##misd=$(sudo ls /mnt/media_rw/)
##ls -n /storage/"$misd"/backups/ | grep WhatsApp.zip | cut -d' ' -f6
    #read $peso
##done
###############################
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
else
echo copia abortada
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
fi



#ho que hace este codigo aqui??? 
if [[ "$sn" != "s" || "$sn" != "S" ]]; then
echo "Opcion invalida S1"
sleep 2
sn=1
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 0
fi

if [[ "$sn" == "n" || "$sn" == "N" ]]; then
echo "Ok, preservando la antigua copia"
sleep 3
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 0
fi
fi
#done
 
else
if [ -d "$root$misd" ]; then
echo Comprimiendo nueva copia
echo -e ""
cd /sdcard/WhatsApp/
zip -r9 WhatsApp.zip *

echo -e ""
echo "Moviendo Copia de seguridad!"
echo -e "Destino: /storage/"$misd"/backups"
echo "Espere por favor"
mkdir -p /storage/$misd/backups/
cd /sdcard/WhatsApp/
sudo mv WhatsApp.zip /storage/$misd/backups/
clear
if [ -e /storage/"$misd"/backups/WhatsApp.zip ]; then
echo -e ""
echo "Copia realizada"
echo "en /storage/"$misd"/backups/"
ver=$(sudo ls /storage/"$misd"/backups/ | grep WhatsApp.zip)
echo "Nombre: $ver"
#peso=$(sudo ls -n /storage/"$misd"/backups/ | grep WhatsApp.zip | cut -d' ' -f6)
peso=$(du -h /storage/"$misd"/backups/WhatsApp.zip)
size="$(echo "$peso" | grep -o ^[0-9].[A-Z])"
echo -e "Peso: ${size}"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
fi


if [ -d "$root$misd" ]; then
echo copia abortada
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
fi

if [[ "$sn" == "n" || "$sn" == "N" ]]; then
echo "Ok, preservando la antigua copia"
sleep 3
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 0
fi
fi
fi
fi
#fin1

if [ -d "$root$misd" ]; then
if [[ "$sn" == "n" || "$sn" == "N" ]]; then
echo "Ok, preservando la antigua copia"
sleep 3
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 0
fi

if [[ "$sn" != "n" || "$sn" != "N" ]]; then
#Opcion invalida N1
echo "Opcion invalida"
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
clear
exit 0
fi
fi


if [ -e /sdcard/backups/WhatsApp.zip ]; then
#sn="1"
#while [ "$sn" == "1" ]; do
clear
echo "Nota: Usted no posee memoria externa, y
si usted va realizar un formateo entonces
guarde esta copia en un lugar seguro"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
clear
echo "Copia en la memoria interna"
echo "Existe una copia ya!!!"
read -p "Desea sobrescribir S/N? > " sn
if [[ "$sn" == "s" || "$sn" == "S" ]]; then
echo "Borrando antigua copia"
rm -r /sdcard/backups/WhatsApp.zip >/dev/null 2>&1
echo Comprimiendo nueva copia
sleep 1
cd /sdcard/WhatsApp/
echo -e ""
zip -r9 WhatsApp.zip *

echo -e ""
echo "Moviendo Copia de seguridad!"
echo -e "Destino: /sdcard/backups"
echo "Espere por favor"
mkdir -p /sdcard/backups/
cd /sdcard/WhatsApp/
mv WhatsApp.zip /sdcard/backups/
clear
if [ -e /sdcard/backups/WhatsApp.zip ]; then
echo -e ""
echo "Copia realizada en /sdcard/backups"
echo "Nombre: WhatsApp.zip"
sleep 2
#peso=$(ls -n /sdcard/backups/ | grep WhatsApp.zip | cut -d' ' -f5)
peso=$(du -h /sdcard/backups/WhatsApp.zip)
size="$(echo "$peso" | grep -o ^[0-9].[A-Z])"
#echo -e "Peso: ${peso}kb"
echo -e "Peso: ${size}"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
else
echo copia abortada
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
fi
fi

if [[ "$sn" == "n" || "$sn" == "N" ]]; then
echo "Ok, preservando la antigua copia"
sleep 3
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 0
fi

if [[ "$sn" != "s" || "$sn" != "S" ]]; then
echo "Opcion invalida"
sleep 2
sn=1
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 1
fi

if [[ "$sn" != "n" || "$sn" != "N" ]]; then
echo "Opcion invalida"
sleep 2
sn=1
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
exit 1
fi

else
clear
echo "Nota: Usted no posee memoria externa, y
si usted va realizar un formateo entonces
guarde esta copia en un lugar seguro"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
echo "Borrando antigua copia"
rm -r /sdcard/backups/WhatsApp.zip >/dev/null 2>&1
echo Comprimiendo nueva copia
sleep 1
cd /sdcard/WhatsApp/
echo -e ""
zip -r9 WhatsApp.zip *

echo -e ""
echo "Moviendo Copia de seguridad!"
echo -e "Destino: /sdcard/backups"
echo "Espere por favor"
mkdir -p /sdcard/backups/
cd /sdcard/WhatsApp/
mv WhatsApp.zip /sdcard/backups/
clear
if [ -e /sdcard/backups/WhatsApp.zip ]; then
echo -e ""
echo "Copia realizada en /sdcard/backups"
echo "Nombre: WhatsApp.zip"
sleep 2
#peso=$(ls -n /sdcard/backups/ | grep WhatsApp.zip | cut -d' ' -f5)
peso=$(du -h /sdcard/backups/WhatsApp.zip)
size="$(echo "$peso" | grep -o ^[0-9].[A-Z])"
#echo -e "Peso: ${peso}kb"
echo -e "Peso: ${size}"
echo -e ""
read -n 1 -p "Presione cualquier tecla para continuar!"
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
exit
else
echo copia abortada
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
exit
fi
fi
#done
;;

      3|03)
clear
misd=$(sudo ls /mnt/media_rw/)
echo "Restaurar Copia de seguridad WhatsApp"
echo -e ""
echo "Verificando existencia de la copia"
sleep 1
if [ -e /storage/$misd/backups/WhatsApp.zip ]; then
mkdir -p /sdcard/WhatsApp
rm -r /sdcard/WhatsApp/*
sudo unzip /storage/$misd/backups/WhatsApp.zip -d /sdcard/WhatsApp/
echo -e ""
echo "Copia restaurada"
echo -e ""
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh

elif [ -e /sdcard/backups/WhatsApp.zip ]; then
clear
echo "Restaurar Copia de seguridad WhatsApp"
echo -e ""
echo "Verificando existencia de la copia"
echo -e ""
sleep 1
mkdir -p /sdcard/WhatsApp
rm -r /sdcard/WhatsApp/*
unzip /sdcard/backups/WhatsApp.zip -d /sdcard/WhatsApp/
echo -e ""
echo "Copia restaurada"
echo -e ""
sleep 2
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh

elif [ -d /storage/$misd/backups/ ]; then
echo -e "La copia de seguridad no existe en
/storage/"$misd"/backups/WhatsApp.zip"
echo -e ""
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh

elif [ -d /sdcard/backups/ ]; then
echo "La copia de seguridad no existe en
/sdcard/backups/WhatsApp.zip"
echo -e ""
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
fi

;;

       4|04)
if [ -f $PREFIX/bin/zip ]; then
echo "Repositorio zip"
echo "Ya existe"
sleep 2
else
echo "Instalando Repositorios:"
echo -e ""
echo "Instalando zip"
echo -e ""
sleep 1
pkg install zip
fi

if [ -x ${PREFIX}/bin/tsu ]
then
echo "Repositorio tsu"
echo "Ya existe"
sleep 2
else 
echo "Instalando tsu"
echo -e ""
sleep 1
apt install tsu -y
fi
source ${HOME}/Busca-Palabras/opc/whatsapp-backup.sh
echo -e ""
;;

      5|05) cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
exit
;;

*) echo -e "   Copia de seguridad WhatsApp Aero"
echo -en "${verde}+---------------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar WhatsApp Aero v8.95   ${verde}#
#---------------------------------------#
# "[${blanco}02${verde}] | ${blanco}Respaldar la copia de aero"     ${verde}#
#---------------------------------------#
# "[${blanco}03${verde}] | ${blanco}Restaurar copia de aero"        ${verde}#
#---------------------------------------#
# "[${blanco}04${verde}] | ${blanco}Repositorios zip y tsu"         ${verde}#
#---------------------------------------#
# "[${blanco}05${verde}] | ${blanco}Volver al menu app premium"     ${verde}#
+---------------------------------------+
|
+->>> "${blanco};echo -en "opcion invalida";sleep 1;clear;sn=1
;;

esac
done
