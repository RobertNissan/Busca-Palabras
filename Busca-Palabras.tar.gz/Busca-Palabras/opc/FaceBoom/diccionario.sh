if [ -x $PREFIX/bin/megatools ]; then 
echo "Existe" >/dev/ null 2>&1
else
pkg install megatools -y
fi


#descaga diccionario
cd ~/Busca-Palabras/opc/hack_pass_zip/
megadl --print-names 'https://mega.nz/file/aNoCDbaa#mxqrnsHmZl8poRpY1B1n85Sq7HqeLWVXK9RIEv6-1uA'