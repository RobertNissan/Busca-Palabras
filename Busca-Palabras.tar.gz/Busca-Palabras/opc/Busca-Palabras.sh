#!/bin/bash
#apt update
#apt upgrade
#apt install tsu
#pkg install fish -y
# fish
#codigo busca correo: "[0-Z._]+@[0-Z]+\.[a-Z]+"
#codigo busca la hora: [0-9]{2}:[0-9]{2}:[0-9]{2}
# [0-9]{2} esta expresion le dice al motor de busqueda que encuentre dos digitos contiguos.
#Un caracter que no sea ninguno de los incluidos: [^A-Z]
#busca todos los parrafos que comiencen con un numero: ^[0-9]
#Mostrara en pantalla todas las lineas que/comiencen con las vocales en minusculas  ^[aeiou] (Puedes cambiar a mayusculas o ambas 
#Busca todas las lineas que terminen en algun numero dado en el intervalo de 0 a 3  [0-3]$
#Este codigo te busca una palabra en un archivo y te la reemplaza por la segunda grep -rl 'bultico' /sdcard/backups/apps/ | xargs sed -i 's/bultico/palabra2/g'
# \?  Este signo nos permitira especificar que parte de la busqueda es opcional: jali\?o\?s (busca jalis o jalos)
# Este codigo hace tabulacion de espacios echo -e "\t Hello World!"

# Listar solo los archivos donde este el nombre jalis codigo: grep jalis fami.txt -i -l

# jes[[:lower:]]s 

#Las veces que aparece la palabra jalis en cada archivo
#find -type f | grep -rcEIHrins jalos /sdcard/backups/
#find /sdcard/ -type f -exec grep -l "jalos" {} \;

# Busque las palabras de 16 letras en el documento  \<[0-Z]{16}\>

#Cambiar de Mayuscula a Minusculas
#w="$(echo $exacta | sed 's/[a-z]/\U&/g')"
#w="$(echo $exacta | tr [:upper:] [:lower:])"

#termux-open https://www.facebook.com/speed.robert
#clean cache
#du -had1

#Cambiar el  numero en for in "num" y asi cambia de color "nota: no funciona como super usuario este codigo, error tput
#B=`tput bold` #BOLD
#D=`tput dim` #DIM
#U=`tput sgr 0 1` #UNDERLINE
#U2=`tput smul` #UNDERLINE2
#NU=`tput rmul` #NO UNDERLINE H=`tput smso` #HIGHLIGHT
#X=`tput sgr0` #RESET COLOR
#C='tput setaf ' #COLOR
#for i in 2; do c=`$C$i`;
#color=$(echo $c${B}${U}$NU$D${U2}$NU$c${H})
#uselo asi echo $color"Palabra-a-colorear"$X

# mas rapido que grep
# Primero instala: 
# pkg update
# pkg install silversearcher-ag
# ag -S "Jakekovac3" --skip "/sdcard/Android/data" /sdcard/ 2>/dev/null



#Codigo para centrar texto "nota: no funciona como super usuario este codigo, error tput
print_center(){
    local x
    local y
    text="$*"
    x=$(( ($(tput cols) - ${#text}) / 2))
    echo -ne "\E[6n";read -sdR y; y=$(echo -ne "${y#*[}" | cut -d';' -f1)
    echo -ne "\033[${y};${x}f$*"
}

# main()

# Color del texto que imprimira 
echo -ne "\\033[2J\033[10;1f\e[94m"

#fin Codigo para centrar texto
#print_center 'Aqui texto a centrar'

choice=1
source ${PWD}/Colors.sh
rojo='\e[1m\e[31m'
#azul="\e[34m\e[0m"
verde='\e[1m\e[32m'
verde2='\033[32m'
white="\e[1;37m\e[0m"
azulluz="\e[1;34m\e[0m"
azulcielo='\e[1m\e[36m'
#mezcla color
mzv=$(echo -e ${white}${verde2})
mza=$(echo -e ${azulcielo}${blanco})
rosa="\033[38;5;207m"
#rojo='\033[30.1m'
#amarillo='\033[33m'
#azul='\033[34m'
#morado='\033[35m'
#blanco='\033[37m'
#cyan='\033[0.1;36m'
#magenta='\033[0.1;35m'

# El uso del colo azul luz los estoy usando asi con la palabra dentro "\e[1;34m"palabra"\e[0m"
# cuando se usa con un: echo -e "--palabra--"
# debes anadir las comillas al principio y al final de este codigo color
# Quedaria asi!!! 
# echo -e "--\e[1;34m"palabra"\e[0m--"

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "$fichero EXISTE" >/dev/null 2>&1
	
sudo rm -r /data/data/com.termux/files/home/091184.sh >/dev/null 2>&1


else

clear

fi

clear

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "$fichero EXISTE" >/dev/null 2>&1
	

rm -r /data/data/com.termux/files/home/091184.sh >/dev/null 2>&1

fi

clear
echo "${mzv}"
# Mensaje a la salida estandard
clear
echo -e ""
#print_center 'Robert Nissan'
#echo ''
echo -e " \t    Autor: Robert Nissan"
echo -e "\t +------------------------+"
echo -en "$white"
echo -e '\t #-----BUSCA_PALABRAS-----#'
echo -en "$verde2"
echo -e "\t +------------------------+"

echo -en "${verde2}+---------------------------------------+
#"$white" Para encontrar varias palabras        ${verde2}#
#"$white" puedes hacer asi!!!                   ${verde2}#
#"$azulcielo""$rojo" palabra1"$azulcielo"|"$rojo"palabra2"$azulcielo"|"$rojo"palabra3 "$azulcielo"etc.       ${mzv}#
#"$white" puedes seguir insertando mas palabras "$verde2"#
#"$white" siempre y cuando agregues esto: "$azulcielo"|     ${mzv}#
#"$white" despues de cada palabra!!!            "$verde2"#
+---------------------------------------+
+------------------------+
#---${blanco}"ESCRIBA LA PALABRA"${verde2}---#
+------------------------+
+->>> "${mza}
read -r bus
clear
echo -e ""
int="$(echo -e "\e[4;4m>>\e[0m")"
#metiendo los colores en otra variable para que funcionen en este "for" #Nota: la opcion -n es la clave para eso!
r=$(echo -ne "$rojo")
b=$(echo -ne "$white")
a=$(echo -ne "$azulcielo")
sub="\e[4;1mW\e[0m"
srn=$(echo -en "$sub")
ent="\e[4;1mE N T E R\e[0m"
enter=$(echo -en "$ent")
for x in "$a"1")""$b"E s c r i b a" "l a" "l e t r a" ${r}"$srn""$b" "p a r a" "p a l a b r a" "e x a c t a; do
echo -n $x
sleep .00
done
echo -e "  "
echo -e ""
for a in "$a"2")""$b"$color O p c i o n - r e c o m e n d a d a$X; do
echo -n $a
sleep .00
done
echo -e " "
for z in P r e s i o n a" "$r""$enter""$b" "p a r a" "r e l l e n a r" "l o s" "c a r a c t e r e s; do
echo -n $z
sleep .00
done
echo -e " "
for x in f a l t a n t e s" "d e" "l a" "p a l a b r a . . . ; do
echo -n $x
sleep .00
done
echo -e " "
echo -e "$rojo$bus$azulcielo+"$white"caracteres" 
echo -e "$azulcielo"

echo -e "              +-------------+           |
+----------<<<# ["$white"W"$verde2"] | "$rojo"ENTER "$verde2"#<<<--------+
|             +-------------+
|"
read -rp "+->>> " "exacta"
echo -e "$white"

w="$(echo "$exacta" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula

if [[ $w == w || $w == W ]]; then
exa=$(echo -e "Espere mientras buscamos la palabra exacta:")
pal=$(echo -e "$rojo""$bus")

else
w="$(echo "$exacta" | tr [:upper:] [:lower:])"
if [[ $w != w || $w != W ]]; then
w=""
car="$(echo -e "Espere mientras buscamos la palabra:")"
pal="$(echo -e "$rojo$bus$azulcielo+"$white"caracteres")"
fi
fi

echo "________________________________________________"
echo -e ""
echo -e "${mzv}Escribe cuantas lineas quieres que aparezcan"
echo -e "antes y despues de la palabra que se encuentren en el texto:"
echo -e ""
echo -e "$white"
echo -e "Elija un numero:"
echo -e "$azulcielo"[0]$b"Recomendado" 
echo -e "$azulcielo"[1]$b"O mayor opcional"
echo -e ""

read -p ""$int" " nl
# si nl es igual a digitos entonces prosigue sino entonces mantente en repeticion while
while [[ ! "$nl" =~ ^[0-9]+$ ]]; do
    echo
    echo "Ingrese solo numeros enteros:"
    echo -e "Elija un numero:"
echo -e "$azulcielo"[0]$b"Recomendado" 
echo -e "$azulcielo"[1]$b"O mayor opcional"
echo -e ""
    read -p ""$int" " nl
done

echo -n "Selecciona la ruta que desees!!!"
echo -e  ""
echo -e  ""
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""
# Bucle while 
while [ $choice = "1" ]; do

read -p "$int " choice
clear
if [[ $choice == r || $choice == R ]]; then
echo -e "" 
echo "Elegiste la raiz del dispositivo"
echo -e "$exa""$car"
echo -e "$pal"

echo -e "\e[1;37m\e[0m"
echo -e  ""
# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo
echo -e "$azulcielo"\Busqueda Recursiva De Ficheros""
echo -e "$white"
echo -e "time find -type f | xargs grep -EIHrins"$w" '"$bus"' --color --context=$nl /data/misc/wifi/" >> /data/data/com.termux/files/home/091184.sh
#la palabra debe estar protegida por token 
#       ' "$bus" '      los token deben estar pegados, asi de esta forma se creara el archivo reconociendo los simbolos \|

#grep -- 'foo*'\''bar' *.txt

if [ -e "$fichero" ];
then


sudo bash /data/data/com.termux/files/home/091184.sh
sudo rm -r ~/091184.sh
fi

if [ -e "$fichero" ] ; then
bash /data/data/com.termux/files/home/091184.sh
rm -r ~/091184.sh
fi
echo -e ""
options=("Si" "No")
pre=$(echo -e "${mzv}+-----------+
# $white[01] | Si ${mzv}#
#-----------#
# $white[02] | No ${mzv}#
#-----------+---------------------+
# $white"Desea abrir algun archivo donde" ${mzv}#
# $white"se encuentre su palabra SI/NO?"  ${mzv}#
+---------------------------------+
+->>> ${mza}")
echo -e ""
PS3=$pre
select opt in "${options[@]}"
do
echo -e ""
case $opt in
    "Si")
		echo "Yes" >/dev/null 2>&1
		
#borra los espacios del texto.
#echo "Hello my name is Robert" | sed  s/\ //g
#file="hola corazon"
#for file in *; do mv "$file" `echo $file | tr ' ' '_'`;  done

#agrega un asterisco al final de cada palabra
#echo "hola que tal" | sed -e "s/[ \t\n\r\v]/* /g"

#agrega una barra invertida al final de cada palabra que le prosiga un espacio.
#echo "grep opciones.txt" | sed 's_ _\\&_g'
#echo "grep opciones.txt" | sed 's_\s_\\&_g'
echo -e ""
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
while [ -z "$arch" ]; do
echo
    echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

sudo find /data/misc/wifi/ -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
sudo nano ~/Busca-Palabras/cache/"$arch"
else

echo -e ""
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi

echo -e ""
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula
#rm -r ~/840911.sh
if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then
echo -e ""
	echo "$arch
guardado en la sdcard" 
   echo -e ""
	sudo rm -r /sdcard/"$arch" >/dev/null 2>&1
	sudo cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
	
	sudo rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1

else
sudo cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
echo -e ""
echo "$arch 
guardado en la sdcard"
echo -e ""
sudo rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
fi
if [[ $yn != y || $yn != Y ]]; then
sudo rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
		;;
    [nN][oO]|[nN])
		echo "No" >/dev/null 2>&1
		echo Saliendo del script
		sleep .5
		echo -e ""
		exit
       		;;
    *)  echo "Opcion Invalida... $REPLY";sleep .5;echo -e "";;
    
esac
done
else

if [[ $choice == i || $choice == I ]]; then
echo -e ""
echo "Elegiste la interna sdcard"
echo -e "$exa""$car"
echo -e "$pal"
echo -e "\e[1;37m\e[0m"

# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo
#bash /sdcard/091184.sh;su;bash /sdcard/091184.sh;
#sudo bash /sdcard/091184.sh
#sudo rm -r /sdcard/091184.sh
#exit
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
UserDir="$(echo /sdcard/)"
eval cd "$UserDir"
time ag -S -i "$bus" --skip "/sdcard/Android/data" "$PWD"/ 2>/dev/null
echo -e ""
options=("Si" "No")
pre=$(echo -e "${mzv}+-----------+
# $white[01] | Si ${mzv}#
#-----------#
# $white[02] | No ${mzv}#
#-----------+---------------------+
# $white"Desea abrir algun archivo donde" ${mzv}#
# $white"se encuentre su palabra SI/NO?"  ${mzv}#
+---------------------------------+
+->>> ${mza}")
echo -e ""
PS3=$pre
select opt in "${options[@]}"
do
echo -e ""
case $opt in
    "Si")
		echo "Yes" >/dev/null 2>&1
		
#borra los espacios del texto.
#echo "Hello my name is Robert" | sed  s/\ //g
#file="hola corazon"
#for file in *; do mv "$file" `echo $file | tr ' ' '_'`;  done

#agrega un asterisco al final de cada palabra
#echo "hola que tal" | sed -e "s/[ \t\n\r\v]/* /g"

#agrega una barra invertida al final de cada palabra que le prosiga un espacio.
#echo "grep opciones.txt" | sed 's_ _\\&_g'
#echo "grep opciones.txt" | sed 's_\s_\\&_g'
echo -e ""
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
while [ -z "$arch" ]; do
echo
    echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

find /sdcard/ -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
nano ~/Busca-Palabras/cache/"$arch"
else
echo -e ""
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi
echo -e ""
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula

if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then
rm -r /sdcard/"$arch" >/dev/null 2>&1
cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
	echo -e ""
echo "$arch 
guardado en la sdcard" 
	echo -e ""
	
	
	rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1

else
cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
echo -e ""
echo "$arch 
guardado en la sdcard" 
echo -e ""
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
fi
if [[ $yn != y || $yn != Y ]]; then
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
		;;
    [nN][oO]|[nN])
		echo "No" >/dev/null 2>&1
		echo Saliendo del script
		sleep .5
		echo -e ""
		exit
       		;;
    *)  echo "Opcion Invalida... $REPLY";sleep .5;echo -e "";;
    
esac
done
else
if [[ $choice == e || $choice == E ]]; then

# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo en los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo

if [ -f /storage/sdext/.micro ]; then
#echo "Existe"
ext=sdext
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
#ext=16EB-3564
#ext=$(su -c ls /mnt/media_rw/)
echo -e ""
echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r ext
#touch /storage/$ext/ext 
clear
while [ -z "$ext" ]; do
clear
echo -e ""
    echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r ext
done
fi

UserDir="$(echo /storage/"$ext"/)"
eval cd "$UserDir" #> ext.txt #/dev/null 2>&1
#eval cd "$UserDir" /dev/null 2>&1
#x="$(echo $PWD > ~/ext.txt)"
x="$(echo $PWD)"
#echo $x > ext.txt
#echo "$PWD" > ~/ext.txt

#xex=$(sed -n "1p" ~/ext.txt)
tez=/storage/$ext
#rm -rf ~/ext.txt /dev/null 2>&1
#echo $tez
#echo $PWD
#read



if [ "$x" == "$tez" ]; then
UserDir="$(echo /storage/$ext/)"
eval cd "$UserDir"
touch /storage/$ext/.$ext
#No modificar las lineas 534 y 536 de este script!
A=$(sed -n "534p" ~/Busca-Palabras/opc/Busca-Palabras.sh)
B=$(echo "$A" | cut -d' ' -f4)
sed -i "s%$B%/storage/$ext/.$ext%g" ~/Busca-Palabras/opc/Busca-Palabras.sh
#grep -rl "$b" ~/Busca-Palabras/opc/Busca-Palabras.sh | xargs sed -i 's/"$b"/"if [ -f /storage/$ext/$ext ]; then"/g'
#No modificar las lineas 534 y 536 de este script!
C=$(sed -n "536p" ~/Busca-Palabras/opc/Busca-Palabras.sh)
sed -i "s%$C%ext=$ext%g" ~/Busca-Palabras/opc/Busca-Palabras.sh
#grep -rl "$c" ~/Busca-Palabras/opc/Busca-Palabras.sh | xargs sed -i 's/"$c"/"ext=sdext"/g'
else
clear
echo -e ""
echo "Busque bien el nombre de su SDCARD EXTERNA"
#rm -rf ~/ext.txt /dev/null 2>&1
read
exit
fi
echo -e ""
clear
echo -e ""Elegiste la externa sdcard-"\e[1;34m"$ext"\e[0m"
echo -en "$white"
echo -e "$exa""$car"
echo -e "$pal"
echo -e "\e[1;37m\e[0m"
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
time ag -S -i "$bus" --skip "/sdcard/Android/data" "$PWD"/ 2>/dev/null
echo -e ""
options=("Si" "No")
pre=$(echo -e "${mzv}+-----------+
# $white[01] | Si ${mzv}#
#-----------#
# $white[02] | No ${mzv}#
#-----------+---------------------+
# $white"Desea abrir algun archivo donde" ${mzv}#
# $white"se encuentre su palabra SI/NO?"  ${mzv}#
+---------------------------------+
+->>> ${mza}")
echo -e ""
PS3=$pre
select opt in "${options[@]}"
do
echo -e ""
case $opt in
    "Si")
		echo "Yes" >/dev/null 2>&1
		
#borra los espacios del texto.
#echo "Hello my name is Robert" | sed  s/\ //g
#file="hola corazon"
#for file in *; do mv "$file" `echo $file | tr ' ' '_'`;  done

#agrega un asterisco al final de cada palabra
#echo "hola que tal" | sed -e "s/[ \t\n\r\v]/* /g"

#agrega una barra invertida al final de cada palabra que le prosiga un espacio.
#echo "grep opciones.txt" | sed 's_ _\\&_g'
#echo "grep opciones.txt" | sed 's_\s_\\&_g'
echo -e ""
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
while [ -z "$arch" ]; do
echo
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

sudo find /mnt/media_rw/$misd/ -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
sudo nano ~/Busca-Palabras/cache/"$arch"
else
echo -e ""
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi
echo -e ""
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula

if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then
    rm -r /sdcard/"$arch" >/dev/null 2>&1
	cd ${HOME}/Busca-Palabras/cache/
    sudo cp -r "$arch" /sdcard/ >/dev/null 2>&1
	echo -e ""
    echo "$arch 
guardado en la sdcard"
echo -e ""
	rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1

else
   cd ${HOME}/Busca-Palabras/cache/
   sudo cp -r "$arch" /sdcard/ >/dev/null 2>&1
   echo -e ""
   echo "$arch 
guardado en la sdcard"
   echo -e ""
   rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
fi
if [[ $yn != y || $yn != Y ]]; then
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
		;;
    [nN][oO]|[nN])
		echo "No" >/dev/null 2>&1
		echo Saliendo del script
		sleep .5
		echo -e ""
		exit
       		;;
    *)  echo "Opcion Invalida... $REPLY";sleep .5;echo -e "";;
  
esac
done
else
clear
echo -n "Selecciona la ruta que desees!!!"
echo -e ""
echo "Usa las letras "
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""

choice=1

fi
fi
fi
done;
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit