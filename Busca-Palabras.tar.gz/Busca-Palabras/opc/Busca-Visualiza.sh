#!/bin/bash
#apt update
#apt upgrade
#apt install tsu
#pkg install fish -y
# fish

choice=1
source ${PWD}/Colors.sh
rojo='\e[1m\e[31m'
azul="\e[34m\e[0m"
verde='\e[1m\e[32m'
verde2='\033[32m'
white="\e[1;37m\e[0m"
azulluz="\e[1;34m\e[0m"
azulcielo='\e[1m\e[36m'
#mezcla color
mzv=$(echo -e ${white}${verde2})
mza=$(echo -e ${azulcielo}${blanco})
rosa="\033[38;5;207m"
#rojo='\033[30.1m'
#amarillo='\033[33m'
#azul='\033[34m'
#morado='\033[35m'
#blanco='\033[37m'
#cyan='\033[0.1;36m'
#magenta='\033[0.1;35m'

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE" >/dev/null 2>&1
	
sudo rm -r /data/data/com.termux/files/home/091184.sh >/dev/null 2>&1


else

clear >/dev/null 2>&1

fi

clear >/dev/null 2>&1

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE" >/dev/null 2>&1
	

rm -r /data/data/com.termux/files/home/091184.sh >/dev/null 2>&1

fi

rm -r /data/data/com.termux/files/home/Install-Busca-Palabras.sh >/dev/null 2>&1

clear
echo "${mzv}"
# Mensaje a la salida estandard
clear
echo -e ""
#print_center 'Robert Nissan'
#echo ''
echo -e " \t    Autor: Robert Nissan"
echo -e "\t +------------------------+"
echo -en "$white"
echo -e '\t #-----BUSCA_FICHEROS-----#'
echo -en "$verde2"
echo -e "\t +------------------------+"




echo -n "Selecciona la ruta que desees!!!"
echo -e  ""
echo -e  ""
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""
# Bucle while 
while [ $choice = "1" ]; do

read -p "$int " choice
clear
if [[ $choice == r || $choice == R ]]; then
echo -e "" 
echo "Elegiste la raiz del dispositivo"

echo -e ""
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
echo -e ""
#Verifica si no has escrito nada! 
while [ -z "$arch" ]; do
echo
    echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

sudo find /data/misc/wifi/ -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
sudo nano ~/Busca-Palabras/cache/"$arch"
else
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi
echo -e ""
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula
#rm -r ~/840911.sh
if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then

	echo "$arc EXISTE" >/dev/null 2>&1
	sudo rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1
	sudo cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
	echo -e ""
	echo "$arch
guardado en la sdcard" 
	sudo rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1

else
sudo cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/ >/dev/null 2>&1
echo -e ""
	echo "$arch
guardado en la sdcard" 
sudo rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1
fi
fi

if [[ $yn == n || $yn == N ]]; then
sudo rm -r ~/Busca-Palabras/cache/* >/dev/null 2>&1
fi

		
else

if [[ $choice == i || $choice == I ]]; then
echo -e ""
echo -e "$white"
echo -e ""Elegiste la interna "\e[1;34m"sdcard"\e[0m"

echo -e "\e[1;37m\e[0m"



UserDir="$(echo /sdcard/)"
eval cd "$UserDir"

echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
#Verifica si no has escrito nada! 
while [ -z "$arch" ]; do
echo
    echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
echo -e ""
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

find -path ./Android -prune -o -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
nano ~/Busca-Palabras/cache/"$arch"
else
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula

if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then

	echo "$arc EXISTE" >/dev/null 2>&1
	rm -r /sdcard/"$arch"
	cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/
	echo -e ""
	echo "$arch
guardado en la sdcard" 
	rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1

else
cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/
echo -e ""
	echo "$arch
guardado en la sdcard" 
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
fi

if [[ $yn == n || $yn == N ]]; then
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
		

else
if [[ $choice == e || $choice == E ]]; then


echo -e "\e[1;37m\e[0m"

#clear
#cd /mnt/media_rw/;su;cd /mnt/media_rw/;
#misd=$(ls /mnt/media_rw/)
misd=$(su -c ls /mnt/media_rw/) >/dev/null
echo -e ""
clear
echo -e ""Elegiste la externa sdcard-"\e[1;34m"$misd"\e[0m"
echo -en "$white"
echo -e ""
echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
#Verifica si no has escrito nada! 
while [ -z "$arch" ]; do
echo
    echo -en "${mzv}+--------------------------------+
# $white"inserta el nombre del archivo:" ${mzv}#
+--------------------------------+
+->>> "${mza}
read -r arch
done
echo -e ""
echo -e "\e[1;37m\e[0m"
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
cam="$(echo "$arch" | sed 's_\s_\\&_g')"

find /mnt/media_rw/$misd/ -type f -iname "$cam" -exec cp -r '{}' ~/Busca-Palabras/cache/ \; && archi="$arch";if [ -e ~/Busca-Palabras/cache/"$archi" ]; then
sudo nano ~/Busca-Palabras/cache/"$arch"
else
echo -e "No existe el fichero $rojo"$arch""
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit
fi
echo -en "${mzv}+---------------------------------+
# $white"Deseas guardar el archivo en la" ${mzv}#
# $white"memoria interna [Y/N]?"          ${mzv}#
+---------------------------------+
+->>> "${mza}
read -r yn

yn="$(echo "$yn" | tr [:upper:] [:lower:])"
# si los caracteres insertados son mayusculas, me los transformas a minuscula

if [[ $yn == y || $yn == Y ]]; then

arc="/sdcard/$arch"
if [ -e "$arc" ]; then

	echo "$arc EXISTE" >/dev/null 2>&1
	rm -r /sdcard/"$arch"
	cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/
	echo -e ""
	echo "$arch
guardado en la sdcard" 
	rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1

else
cp -r ~/Busca-Palabras/cache/"$arch" /sdcard/
echo -e ""
	echo "$arch
guardado en la sdcard" 
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
fi

if [[ $yn == n || $yn == N ]]; then
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
fi
		
else
clear
echo -n "Selecciona la ruta que desees!!!"
echo -e ""
echo "Usa las letras "
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""

choice=1

fi
fi
fi
done;
rm -r ~/Busca-Palabras/cache/"$arch" >/dev/null 2>&1
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
