#!/bin/bash
while true
do
clear
chmod +x ~/Busca-Palabras/opc/hack.sh
echo -e -n "${verde}
+-------------------------------+
# [${blanco}01${verde}] | ${blanco}CLIFTY PHISHING        ${verde}#
#-------------------------------#
# ["$blanco"02"$verde"] | "$blanco"SEEKER  RASTREADOR     ${verde}#
#-------------------------------#
# [${blanco}03${verde}] | ${blanco}RECOVERY PASSWORD ZIP  ${verde}#
+-------------------------------+
|
+->>> "${blanco}

read -r text
cd ${HOME}
echo -e ""
case $text in

1|01)
clift=a
while [ "$clift" = "a" ]; do
clear
echo -e ""
# Mostrar menú
echo -e "            Hack + Phishing"
echo -e "${verde}+--------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar clifty${verde}#
#--------------------------------#
# [${blanco}02${verde}] | ${blanco}Ejecutar clifty${verde}#
#--------------------------------#
# [${blanco}03${verde}] | ${blanco}Eliminar clifty${verde}#
#--------------------------------#
# [${blanco}04${verde}] | ${blanco}Volver al menu anterior${verde}#
+--------------------------------+
|
+->>> ${blanco}"
read -r clift
echo -e ""

if [ "$clift" == "1" ]; then
echo -e ""
echo "CLIFTY" >/dev/null 2>&1
if [ -e ${HOME}/Busca-Palabras/opc/Clifty/clifty.sh ]; then
echo "CLIFTY"
echo "Ya esta descargado"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e ""
echo "Descargando clifty phishing pro"
echo -e ""
#TERMUX
cd
#ligero
if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
mkdir -p ~/Busca-Palabras/opc/
cd ~/Busca-Palabras/opc/ 
megadl --print-names 'https://mega.nz/file/OVhUGRiA#prS6s_ErKMHSCbujhSm0ODdMNpNgwajpgzvHwW1RVNk'
unzip Clifty_Phishing.zip
rm -rf Clifty_Phishing.zip
cd Clifty
chmod +x clifty.sh
#bash hack.sh
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
read -n 1 -p "Presione cualquier tecla volver al menu!!!"
./spawn
exit
fi
fi

if [ "$clift" == "2" ]; then
if [ -x ~/Busca-Palabras/opc/Clifty ]; then 
cd ${HOME}/Busca-Palabras/opc/Clifty/
bash clifty.sh
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e "CLIFTY NO ESTA INSTALADO"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$clift" == "3" ]; then
if [ ! -x ~/Busca-Palabras/opc/Clifty ]; then 
cd ${HOME}/Busca-Palabras/opc/
echo -e "CLIFTY NO EXISTE!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
cd ${HOME}/Busca-Palabras/opc/
rm -rf Clifty
echo -e "CLIFTY ELIMINADO!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$clift" == "4" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash hack.sh
exit
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
clift=a
done
exit
;; 

2|02)
seek=a
while [ "$seek" = "a" ]; do
clear
echo -e ""
# Mostrar menú
echo -e "            Hack + Phishing"
echo -e "${verde}+--------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar seeker${verde}#
#--------------------------------#
# [${blanco}02${verde}] | ${blanco}Ejecutar seeker${verde}#
#--------------------------------#
# [${blanco}03${verde}] | ${blanco}Eliminar seeker${verde}#
#--------------------------------#
# [${blanco}04${verde}] | ${blanco}Volver al menu anterior${verde}#
+--------------------------------+
|
+->>> ${blanco}"
read -r seek
echo -e ""

if [ "$seek" == "1" ]; then
echo -e ""
echo "SEEKER" >/dev/null 2>&1
if [ -e ${HOME}/Busca-Palabras/opc/seeker/seeker.py ]; then
echo "SEEKER"
echo "Ya esta descargado"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e ""
echo "Descargando seeker rastreador"
echo -e ""
#TERMUX
cd
if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
cd ~/Busca-Palabras/opc/
megadl --print-names 'https://mega.nz/file/DcREABzb#OUmMtD6vSLqmrb2LXju6xF5b3u2Gjsl6pD9nucGGFf8'
unzip seeker.zip
rm seeker.zip
cd seeker/
chmod +x install.sh seeker.py
./install.sh
#bash hack.sh
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
read -n 1 -p "Presione cualquier tecla volver al menu!!!"
./spawn
exit
fi
fi

if [ "$seek" == "2" ]; then
if [ -x ~/Busca-Palabras/opc/seeker ]; then 
cd ${HOME}/Busca-Palabras/opc/seeker/
clear
python3 seeker.py
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e "SEEKER NO ESTA INSTALADO"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$seek" == "3" ]; then
if [ ! -x ~/Busca-Palabras/opc/seeker ]; then 
cd ${HOME}/Busca-Palabras/opc/
echo -e "SEEKER NO EXISTE!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
cd ${HOME}/Busca-Palabras/opc/
rm -rf seeker
echo -e "SEEKER ELIMINADO!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "2\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$seek" == "4" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash hack.sh
exit
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
seek=a
done
exit
;;

3|03)
hzip=a
while [ "$hzip" = "a" ]; do
clear
echo -e ""
# Mostrar menú
echo -e "            Hack + Password"
echo -e "${verde}+--------------------------------+
# [${blanco}01${verde}] | ${blanco}Instalar hziper${verde}#
#--------------------------------#
# [${blanco}02${verde}] | ${blanco}Ejecutar hziper${verde}#
#--------------------------------#
# [${blanco}03${verde}] | ${blanco}Eliminar hziper${verde}#
#--------------------------------#
# [${blanco}04${verde}] | ${blanco}Volver al menu anterior${verde}#
+--------------------------------+
|
+->>> ${blanco}"
read -r hzip
echo -e ""


if [ "$hzip" == "1" ]; then
echo -e ""
echo "HZIPER" >/dev/null 2>&1
if [ -e ${HOME}/Busca-Palabras/opc/hziper/hziper.py ]; then
echo "HZIPER"
echo "Ya esta descargado"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e ""
echo "Descargando hziper pass"
echo -e ""
#TERMUX
cd
if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
cd ~/Busca-Palabras/opc/
megadl --print-names 'https://mega.nz/file/aVIAUapI#MJPxPiy2ZezxDLNi3SOzaI41J4b-yUNHkqnWDzV4ewo'
unzip hziper.zip
rm hziper.zip
unzip hziper/rockyou.zip -d hziper/ >/dev/null 2>&1
rm hziper/rockyou.zip
cd hziper/
chmod +x hziper.py
#bash hack.sh
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
read -n 1 -p "Presione cualquier tecla volver al menu!!!"
./spawn
exit
fi
fi

if [ "$hzip" == "2" ]; then
if [ -x ~/Busca-Palabras/opc/hziper ]; then 
cd ${HOME}/Busca-Palabras/opc/hziper/
clear
python hziper.py
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
echo -e "HZIPER NO ESTA INSTALADO"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$hzip" == "3" ]; then
if [ ! -x ~/Busca-Palabras/opc/hziper ]; then 
cd ${HOME}/Busca-Palabras/opc/
echo -e "HZIPER NO EXISTE!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
else
cd ${HOME}/Busca-Palabras/opc/
rm -rf hziper
echo -e "HZIPER ELIMINADO!"
sleep 2
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send " 3\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
./spawn
exit
fi
fi

if [ "$hzip" == "4" ]; then
cd ${HOME}/Busca-Palabras/opc/
bash hack.sh
exit
fi
echo -e ""
echo -e "Opcion invalida"
sleep 2
hzip=a
done
exit
;;

4|04)
cd ${HOME}/Busca-Palabras/
bash Menu-Busca-Palabras.sh
exit
;;

*) echo "opcion invalida";sleep 1;clear
;;
esac
done
cd ${HOME}/Busca-Palabras/opc/
echo '#!/usr/bin/expect -f' > spawn
echo 'spawn ./hack.sh' >> spawn
echo 'send "1\r"' >> spawn
echo 'interact' >> spawn
chmod +x spawn
exit


