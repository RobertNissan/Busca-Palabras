esd=a
while [ "$esd" == "a" ]; do
clear
echo -e ""
echo "elija la ruta donde escanear"
echo "[1] termux /home/"
echo "[2] Interna /sdcard/"
echo "[3] Externa /sdcard/"
echo "[4] Menu anterior"
read -p "> " esd
case $esd in

1|01)
disco="/data/data/com.termux/files/home"
eval cd $disco
echo -e ""
clear
echo -e ""Elegiste termux-home "\e[1;34m"$disco"\e[0m"
bash ~/Busca-Palabras/opc/scpscan.sh
;;
2|02)
disco="/sdcard"
eval cd $disco
echo -e ""
clear
echo -e ""Elegiste la memoria-interna "\e[1;34m"$disco"\e[0m"
bash ~/Busca-Palabras/opc/scpscan.sh
;;
3|03)
if [ -f /storage/sdext/.micro ]; then
disco=sdext
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
echo -e ""
echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r disco
clear
while [ -z "$disco" ]; do
clear
echo -e ""
    echo -en "${mzv}+----------------------------------+
# $white"inserta el nombre de tu tarjeta:" ${mzv}#
+----------------------------------+
+->>> "${mza}
read -r disco
done
fi

UserDir="$(echo /storage/"$disco"/)"
eval cd "$UserDir"
x="$(echo $PWD)"
tez=/storage/$disco

if [ "$x" == "$tez" ]; then
UserDir="$(echo /storage/$disco/)"
eval cd "$UserDir"
touch /storage/$disco/.$disco
#-------------------------------------------------------------------------
#A=$(sed -n "30p" ~/Busca-Palabras/opc/memory.sh)
A=$(grep -EIris "/storage/sdext/.micro" ~/Busca-Palabras/opc/memory.sh | head -n 1) 

B=$(echo "$A" | cut -d' ' -f4)
sed -i "s%$B%/storage/$disco/.$disco%g" ~/Busca-Palabras/opc/memory.sh

#-------------------------------------------------------------------------

#-------------------------------------------------------------------------
#C=$(sed -n "31p" ~/Busca-Palabras/opc/memory.sh)
C=$(grep -EIris "disco=sdext" ~/Busca-Palabras/opc/memory.sh | head -n 1) 

D=$(echo "$C" | cut -d' ' -f4)
sed -i "s%$D%disco=$disco%g" ~/Busca-Palabras/opc/memory.sh
#---------------------------------------------------------------------
echo -e ""
clear
echo -e ""Elegiste la memoria-externa "\e[1;34m"$disco"\e[0m"
bash ~/Busca-Palabras/opc/scpscan.sh
else
clear
echo -e ""
echo "Busque bien el nombre de su SDCARD EXTERNA"
read
esd=a
fi
;;
4|04)
bash ~/Busca-Palabras/opc/lista-server.sh
exit
;;
*) echo "opcion invalida";sleep 1;clear;esd=a
;;
esac
done
exit