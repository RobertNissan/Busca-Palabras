#!/bin/bash
# include this boilerplate
function jumpto
{
       label=$1
       cmd=$(sed -n "/$label:/{:a;n;p;ba};" $0 | grep -v ':$')
       eval "$cmd"
       exit
}


dialog --msgbox "---- JUEGO DE CARTAS LA 21 ----" 5 31

#dialog --title "Mesa de cartas" --msgbox "A         B          C" 10 30

#INTRO
#COLORES
rojo='\e[1m\e[31m'
verde='\e[1m\e[32m'
blanco='\e[1m\e[38m'
amarillo='\e[1m\e[33m'
azulcielo='\e[1m\e[36m'

clear

nombre=$(dialog --title 'Su nombre' --stdout --inputbox "?Cual es su nombre?" 0 0)
if [ -n $nombre ];
clear

echo -e ""
echo -e ""

sleep 0.1

echo -en "       GRACIAS POR UTILIZAR MI SCRIPT"
sleep 0.1
echo -e -n "${verde}
+---------------------------------------+
# ${blanco}        JUEGO_DE_CARTAS_LA_21         ${verde}#
#---------------------------------------#
# ${blanco}       CREADOR: ROBERT - NISSAN       ${verde}#
#---------------------------------------#
# ${blanco}        SUSCRIBETE A MI CANAL         ${verde}#
+---------------------------------------+\n"

sleep 0.1
echo -e $rojo"      AYUDA A CRECER EL CANAL AMIGO"
x=0
free > adv
random=$(cat adv | grep -EIiso "${x}1|${x}2|${x}3|${x}4|${x}5|${x}6|${x}7|${x}8|${x}9|10|11|12|13|14|15|16|17|18|19|20|21" | sed -n '3 p' | tail -n 1)
#echo $random
rm -rf adv

echo -e "$azulcielo"
read -s -n 1 -p "Presiona cualquier tecla para empezar..."


 then
	dialog --title "Hola "$nombre --msgbox "Mi nombre es Robert Nissan.
Y he creado este juego para tu entretenimiento" 0 0
fi

#echo -e -n $azulcielo"Cual es tu nombre amig@?:\e[1m\e[36m "
#read "NOMBRE"
#echo -e ""
#echo -e ""
#sleep 0.1



echo -e $azulcielo"Hola $NOMBRE, Mi nombre es $rojo Robert Nissan.$azulcielo
Y he creado este juego para tu entretenimiento"
echo -e ""
#read -s -n 1 -p "Presiona cualquier tecla para empezar..."
clear

##############################
#ejemplo 1
#l1
#guardar haciendo con el echo -e para activar \n (saltos de lineas) tambien se puede hacer simple como el l2
##echo -e "A=\nB=\nC=\nD=\nE=\nF=\nG=\nH=\nI=\nJ=\nK=\nL=\nM=\nN=\nO=\nP=\nQ=\nR=\nS=\nT=\nU=" > l1

#l2
#guardando con comillas simples para no activar las barras invertidas
##echo '01\\n
##02\\n
##03\\n
##04\\n
##05\\n
##06\\n
##07\\n
##08\\n
##09\\n
##10\\n
##11\\n
##12\\n
##13\\n
##14\\n
##15\\n
##16\\n
##17\\n
##18\\n
##19\\n
##20\\n
##21\\n' > l2

#juntar las columnas
##paste l1 l2 > juntos
#en variable muestra en pantalla con cat 
##j="$(cat juntos)"
#en variable muestra los que hizo cat y ajusta los espacios
##y="$(echo "$j" | xargs echo -n)"
#eliminar espacios de la variable $y
##x="$(echo "$y" | sed 's/\ //g')"
#guardar archivo haciendo saltos de lineas
##echo -e "$x" > juntos
#nano juntos

##############################
#ejemplo 2
#l1
#guardar haciendo con el echo -e para activar \n (saltos de lineas) tambien se puede hacer simple como el l2
##salto=$(echo "A= B= C= D= E= F= G= H= I= J= K= L= M= N= O= P= Q= R= S= T= U= " | sed 's_\s_\\n&_g' | sed -r 's/\s+//g') && echo -e "$salto" > l1

#l2
#guardando con comillas simples para no activar las barras invertidas
##echo '01
##02
##03
##04
##05
##06
##07
##08
##09
##10
##11
##12
##13
##14
##15
##16
##17
##18
##19
##20
##21' > l2
#juntar las columnas
##paste l1 l2 > juntos

##sed -r 's/\s+//g' juntos > output
##nano output
##############################

#guia 
#A=01 =332

#B=02 =113

#C=03 =213

#D=04 =313

#E=05 =123

#F=06 =223

#G=07 =323

#H=08 =212

#I=09 = 312

#J=10 =122

#K=22 =222

#L=12 =322

#M=13 =132

#N=14 =232

#O=15 =121

#P=16 =221

#Q=17 =321

#R=18 =131

#S=19 =231

#T=20 =331

#U=21 =112

#21-U-112    08-H-212     09-I-312

#02-B-113    03-C-213     04-D-313

#15-O-121    16-P-221     17-Q-321

#10-J-122    22-K-222     12-L-322

#05-E-123    06-F-223     07-G-323

#18-R-131    19-S-231     20-T-331

#13-M-132    14-N-232     01-A-332



#error

#111         211          311

#133         233          333




if [ "$random" == "01" ]; then
A=01
B=02
C=03
D=04
E=05
F=06
G=07
H=08
I=09
J=10
K=11
L=12
M=13
N=14
O=15
P=16
Q=17
R=18
S=19
T=20
U=21
fi

if [ "$random" == "02" ]; then
A=21
B=01
C=02
D=03
E=04
F=05
G=06
H=07
I=08
J=09
K=10
L=11
M=12
N=13
O=14
P=15
Q=16
R=17
S=18
T=19
U=20
fi

if [ "$random" == "03" ]; then
A=20
B=21
C=01
D=02
E=03
F=04
G=05
H=06
I=07
J=08
K=09
L=10
M=11
N=12
O=13
P=14
Q=15
R=16
S=17
T=18
U=19
fi

if [ "$random" == "04" ]; then
A=19
B=20
C=21
D=01
E=02
F=03
G=04
H=05
I=06
J=07
K=08
L=09
M=10
N=11
O=12
P=13
Q=14
R=15
S=16
T=17
U=18
fi

if [ "$random" == "05" ]; then
A=18
B=19
C=20
D=21
E=01
F=02
G=03
H=04
I=05
J=06
K=07
L=08
M=09
N=10
O=11
P=12
Q=13
R=14
S=15
T=16
U=17
fi

if [ "$random" == "06" ]; then
A=17
B=18
C=19
D=20
E=21
F=01
G=02
H=03
I=04
J=05
K=06
L=07
M=08
N=09
O=10
P=11
Q=12
R=13
S=14
T=15
U=16
fi

if [ "$random" == "07" ]; then
A=16
B=17
C=18
D=19
E=20
F=21
G=01
H=02
I=03
J=04
K=05
L=06
M=07
N=08
O=09
P=10
Q=11
R=12
S=13
T=14
U=15
fi

if [ "$random" == "08" ]; then
A=15
B=16
C=17
D=18
E=19
F=20
G=21
H=01
I=02
J=03
K=04
L=05
M=06
N=07
O=08
P=09
Q=10
R=11
S=12
T=13
U=14
fi

if [ "$random" == "09" ]; then
A=14
B=15
C=16
D=17
E=18
F=19
G=20
H=21
I=01
J=02
K=03
L=04
M=05
N=06
O=07
P=08
Q=09
R=10
S=11
T=12
U=13
fi

if [ "$random" == "10" ]; then
A=13
B=14
C=15
D=16
E=17
F=18
G=19
H=20
I=21
J=01
K=02
L=03
M=04
N=05
O=06
P=07
Q=08
R=09
S=10
T=11
U=12
fi

if [ "$random" == "11" ]; then
A=12
B=13
C=14
D=15
E=16
F=17
G=18
H=19
I=20
J=21
K=01
L=02
M=03
N=04
O=05
P=06
Q=07
R=08
S=09
T=10
U=11
fi

if [ "$random" == "12" ]; then
A=11
B=12
C=13
D=14
E=15
F=16
G=17
H=18
I=19
J=20
K=21
L=01
M=02
N=03
O=04
P=05
Q=06
R=07
S=08
T=09
U=10
fi

if [ "$random" == "13" ]; then
A=10
B=11
C=12
D=13
E=14
F=15
G=16
H=17
I=18
J=19
K=20
L=21
M=01
N=02
O=03
P=04
Q=05
R=06
S=07
T=08
U=09
fi

if [ "$random" == "14" ]; then
A=09
B=10
C=11
D=12
E=13
F=14
G=15
H=16
I=17
J=18
K=19
L=20
M=21
N=01
O=02
P=03
Q=04
R=05
S=06
T=07
U=08
fi

if [ "$random" == "15" ]; then
A=08
B=09
C=10
D=11
E=12
F=13
G=14
H=15
I=16
J=17
K=18
L=19
M=20
N=21
O=01
P=02
Q=03
R=04
S=05
T=06
U=07
fi

if [ "$random" == "16" ]; then
A=07
B=08
C=09
D=10
E=11
F=12
G=13
H=14
I=15
J=16
K=17
L=18
M=19
N=20
O=21
P=01
Q=02
R=03
S=04
T=05
U=06
fi

if [ "$random" == "17" ]; then
A=06
B=07
C=08
D=09
E=10
F=11
G=12
H=13
I=14
J=15
K=16
L=17
M=18
N=19
O=20
P=21
Q=01
R=02
S=03
T=04
U=05
fi

if [ "$random" == "18" ]; then
A=05
B=06
C=07
D=08
E=09
F=10
G=11
H=12
I=13
J=14
K=15
L=16
M=17
N=18
O=19
P=20
Q=21
R=01
S=02
T=03
U=04
fi

if [ "$random" == "19" ]; then
A=04
B=05
C=06
D=07
E=08
F=09
G=10
H=11
I=12
J=13
K=14
L=15
M=16
N=17
O=18
P=19
Q=20
R=21
S=01
T=02
U=03
fi

if [ "$random" == "20" ]; then
A=03
B=04
C=05
D=06
E=07
F=08
G=09
H=10
I=11
J=12
K=13
L=14
M=15
N=16
O=17
P=18
Q=19
R=20
S=21
T=01
U=02
fi

if [ "$random" == "21" ]; then
A=02
B=03
C=04
D=05
E=06
F=07
G=08
H=09
I=10
J=11
K=12
L=13
M=14
N=15
O=16
P=17
Q=18
R=19
S=20
T=21
U=01
fi


dialog --msgbox "EL  SIGUIENTE  CUADRO TE MOSTRARA VARIOS BLOQUE DONDE ESTARAN LOS NUMEROS A ELEGIR" 0 0
clear 

echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|       Elige una carta mentalmente      |"
echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"
echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $A              $H              $O   |"
echo -e "$azulcielo|   $B              $I              $P   |"
echo -e "$azulcielo|   $C              $J              $Q   |"
echo -e "$azulcielo|   $D              $K              $R   |"
echo -e "$azulcielo|   $E              $L              $S   |"
echo -e "$azulcielo|   $F              $M              $T   |"
echo -e "$azulcielo|   $G              $N              $U   |"
echo -e "$azulcielo|                                        |"

echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."

dialog --msgbox "EL  SIGUIENTE  CUADRO TE MOSTRARA VARIOS BLOQUE DONDE ESTARA   EL NUMERO QUE ELEGISTE" 0 0



clear

#echo Mano I UB
echo -e ""
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"
echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $O              $P              $Q   |"
echo -e "$azulcielo|   $R              $S              $T   |"
echo -e "$azulcielo|   $U              $H              $I   |"
echo -e "$azulcielo|   $J              $K              $L   |"
echo -e "$azulcielo|   $M              $N              $A   |"
echo -e "$azulcielo|   $B              $C              $D   |"
echo -e "$azulcielo|   $E              $F              $G   |"
echo -e "$azulcielo|                                        |"

echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."

#read -p "cual es tu nombre: " es

man=$(dialog --title "Sesion I" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")



#if [ "$es" == "1" ]
#then

#start=${1:-"start"}
clear
jumpto UB"$man"


UB1:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $P              $S              $H   |"
echo -e "$azulcielo|   $K              $N              $C   |"
echo -e "$azulcielo|   $F              $O              $R   |"
echo -e "$azulcielo|   $U              $J              $M   |"
echo -e "$azulcielo|   $B              $E              $Q   |"
echo -e "$azulcielo|   $T              $I              $L   |"
echo -e "$azulcielo|   $A              $D              $G   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto UB"$man$man2"


#HC212
UB2:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $Q              $T              $I   |"
echo -e "$azulcielo|   $L              $A              $D   |"
echo -e "$azulcielo|   $G              $P              $S   |"
echo -e "$azulcielo|   $H              $K              $N   |"
echo -e "$azulcielo|   $C              $F              $O   |"
echo -e "$azulcielo|   $R              $U              $J   |"
echo -e "$azulcielo|   $M              $B              $E   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto HC"$man$man2"





#DI
#LGQ
#TA
UB3:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $P              $S              $H   |"
echo -e "$azulcielo|   $K              $N              $C   |"
echo -e "$azulcielo|   $F              $Q              $T   |"
echo -e "$azulcielo|   $I              $L              $A   |"
echo -e "$azulcielo|   $D              $G              $O   |"
echo -e "$azulcielo|   $R              $U              $J   |"
echo -e "$azulcielo|   $M              $B              $E   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto DI"$man$man2"



DI31:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $S              $N              $Q   |"
echo -e "$azulcielo|   $L              $G              $U   |"
echo -e "$azulcielo|   $B              $P              $K   |"
echo -e "$azulcielo|   $F              $I              $D   |"
echo -e "$azulcielo|   $R              $M              $H   |"
echo -e "$azulcielo|   $C              $T              $A   |"
echo -e "$azulcielo|   $O              $J              $E   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto DI"$man$man2$man3"




#LGQ322
DI32:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $P              $K              $F   |"
echo -e "$azulcielo|   $I              $D              $R   |"
echo -e "$azulcielo|   $M              $S              $N   |"
echo -e "$azulcielo|   $Q              $L              $G   |"
echo -e "$azulcielo|   $U              $B              $H   |"
echo -e "$azulcielo|   $C              $T              $A   |"
echo -e "$azulcielo|   $O              $J              $E   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto LGQ"$man$man2$man3"



#TA331
DI33:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $S              $N              $Q   |"
echo -e "$azulcielo|   $L              $G              $U   |"
echo -e "$azulcielo|   $B              $H              $C   |"
echo -e "$azulcielo|   $T              $A              $O   |"
echo -e "$azulcielo|   $J              $E              $P   |"
echo -e "$azulcielo|   $K              $F              $I   |"
echo -e "$azulcielo|   $D              $R              $M   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto TA"$man$man2$man3"




















#NS232
HC23:
echo -e ""
#echo Mano III NS
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $T              $A              $P   |"
echo -e "$azulcielo|   $K              $F              $U   |"
echo -e "$azulcielo|   $B              $I              $D   |"
echo -e "$azulcielo|   $S              $N              $O   |"
echo -e "$azulcielo|   $J              $E              $Q   |"
echo -e "$azulcielo|   $L              $G              $H   |"
echo -e "$azulcielo|   $C              $R              $M   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto NS"$man$man2$man3"





















#FKP
#F223
HC22:
echo -e ""
#echo Mano III FKP
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $I              $D              $S   |"
echo -e "$azulcielo|   $N              $O              $J   |"
echo -e "$azulcielo|   $E              $T              $A   |"
echo -e "$azulcielo|   $P              $K              $F   |"
echo -e "$azulcielo|   $U              $B              $Q   |"
echo -e "$azulcielo|   $L              $G              $H   |"
echo -e "$azulcielo|   $C              $R              $M   |"
echo -e "$azulcielo|                                        |"


echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto FKP"$man$man2$man3"












HC21:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $T              $A              $P   |"
echo -e "$azulcielo|   $K              $F              $U   |"
echo -e "$azulcielo|   $B              $Q              $L   |"
echo -e "$azulcielo|   $G              $H              $C   |"
echo -e "$azulcielo|   $R              $M              $I   |"
echo -e "$azulcielo|   $D              $S              $N   |"
echo -e "$azulcielo|   $O              $J              $E   |"
echo -e "$azulcielo|                                        |"

echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear

jumpto HC"$man$man2$man3"
 
 
 
    
    
    
    
    
    
    
    
    

#JOE122
UB12:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $H              $C              $R   |"
echo -e "$azulcielo|   $M              $Q              $L   |"
echo -e "$azulcielo|   $G              $S              $N   |"
echo -e "$azulcielo|   $O              $J              $E   |"
echo -e "$azulcielo|   $I              $D              $P   |"
echo -e "$azulcielo|   $K              $F              $U   |"
echo -e "$azulcielo|   $B              $T              $A   |"
echo -e "$azulcielo|                                        |"

echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear
jumpto JOE"$man$man2$man3"

#paki3
UB13:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $S              $N              $O   |"
echo -e "$azulcielo|   $J              $E              $I   |"
echo -e "$azulcielo|   $D              $H              $C   |"
echo -e "$azulcielo|   $R              $M              $Q   |"
echo -e "$azulcielo|   $L              $G              $P   |"
echo -e "$azulcielo|   $K              $F              $U   |"
echo -e "$azulcielo|   $B              $T              $A   |"
echo -e "$azulcielo|                                        |"

echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

clear


jumpto RM"$man$man2$man3"





#3mano 
#paki1
UB11:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e ""
sleep 0.1

echo -e "$azulcielo|      En que bloque esta tu carta       |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo| BLOQUE          BLOQUE          BLOQUE |"
echo -e "$azulcielo|   I               II              III  |"

echo -e "$azulcielo|                                        |"
echo -e "$azulcielo|   $S              $N              $O   |"
echo -e "$azulcielo|   $J              $E              $I   |"
echo -e "$azulcielo|   $D              $P              $K   |"
echo -e "$azulcielo|   $F              $U              $B   |"
echo -e "$azulcielo|   $T              $A              $H   |"
echo -e "$azulcielo|   $C              $R              $M   |"
echo -e "$azulcielo|   $Q              $L              $G   |"
echo -e "$azulcielo|                                        |"

echo -e ""
echo -e ""
read -s -n 1 -p "Presiona cualquier tecla para continuar..."


man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")

jumpto UB"$man$man2$man3"


clear
#Sesion Magia1

#---------------------------------------#

UB112:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $U" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

UB113:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $B" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit


#|--------------------------------------#









#tercera mano
#paki3


clear


#Sesion Magia RM

#---------------------------------------#

RM131:

echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $R" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

RM132:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $M" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit
#---------------------------------------#










#---------------------------------------#

JOE122:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $J" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

JOE121:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $O" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

JOE123:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $E" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

#---------------------------------------#






HC212:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $H" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

HC213:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $C" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit




#---------------------------------------#




FKP223:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $F" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

FKP222:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $K" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

FKP221:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $P" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit







#---------------------------------------#

NS232:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $N" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

NS231:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $S" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit




#---------------------------------------#




DI313:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $D" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

DI312:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $I" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit


#---------------------------------------#






LGQ322:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $L" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

LGQ323:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $G" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

LGQ321:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $Q" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit







#---------------------------------------#






TA331:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $T" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit

TA332:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $A" 0 0
#read -s -n 1 -p "Presiona cualquier tecla para continuar..."
exit


#---------------------------------------#


