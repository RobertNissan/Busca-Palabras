#!/bin/bash

/usr/bin/scp me@website.com:file somewhere 2>/dev/null &
pid=$! # Process Id of the previous running command

s='-\|/'
i=0
while kill -0 $pid; do 
i=$(( (i+1) %4 ))
printf "\r${s:$i:1}"
sleep 0.1
done 
