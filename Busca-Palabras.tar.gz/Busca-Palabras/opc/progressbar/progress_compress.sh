#!/bin/bash

rm -rf .compress.txt
cd Busca-Palabras
varX=$(find . -type d -iname "*" -print | cut -c 3- | wc -l)
varY=$(find . -type f -iname "*" -print | cut -c 3- | wc -l)
let suma=$varX+$varY

cd
tar -zcvf Busca-Palabras.tar.gz Busca-Palabras >/dev/null 2>&1 > .compress.txt &

count=0
total="$suma"
start=`date +%s`
while [[ "$count" -le "$total" ]]; do
  #sleep 0.1 # this is work
  count=$(wc -l .compress.txt | awk '{print $1}')
  cur=`date +%s`
  count=$(( $count + 1 -1 ))
  pd=$(( $count * 73 / $total ))
  runtime=$(( $cur-$start ))
  estremain=$(( ($runtime * $total / $count)-$runtime ))
  printf "\r%d.%d%% complete ($count of $total) - est %d:%0.2d remaining\e[K" $(( $count*100/$total )) $(( ($count*1000/$total)%10)) $(( $estremain/60 )) $(( $estremain%60 ))
  if [[ "$count" =~ "$total" ]]; then
  rm -rf .compress.txt
  break
  fi
done
kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1
printf "\ndone\n"
