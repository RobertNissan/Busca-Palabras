# Colores Bash
#
#export rosa="\033[38;5;207m"
#export rojo='\033[31m'
#export verde='\033[32m'
#export amarillo='\033[33m'
#export azul='\033[34m'
#export morado='\033[35m'
#export blanco='\033[37m'
#export cyan='\033[1;36m'
#export magenta='\033[1;35m'

export Off='\033[0m'
export rosa="\033[38;5;207m"
export rojo='\033[1;91m'
export verde='\033[1;92m'
export amarillo='\033[1;93m'
export azul='\033[1;94m'
export morado='\033[1;95m'
export blanco='\033[1;97m'
export cyan='\033[1;96m'
export magenta='\033[1;35m'


NC='\033[0m'

#echo Regular Colors
export Black='\033[0;30m'
export Red='\033[0;31m'
export Green='\033[0;32m'
export Yellow='\033[0;33m'
export Blue='\033[0;34m'
export Purple='\033[0;35m'
export Cyan='\033[0;36m'
export White='\033[0;37m'

#echo Bold
export BBlack='\033[1;30m'
export BRed='\033[1;31m'
export BGreen='\033[1;32m'
export BYellow='\033[1;33m'
export BBlue='\033[1;34m'
export BPurple='\033[1;35m'
export BCyan='\033[1;36m'
export BWhite='\033[1;37m'

#echo Underline
export UBlack='\033[4;30m'
export URed='\033[4;31m'
export UGreen='\033[4;32m'
export UYellow='\033[4;33m'
export UBlue='\033[4;34m'
export UPurple='\033[4;35m'
export UCyan='\033[4;36m'
export UWhite='\033[4;37m'

#echo Background
export OBlack='\033[40m'
export ORed='\033[41m'
export OGreen='\033[42m'
export OYellow='\033[43m'
export OBlue='\033[44m'
export OPurple='\033[45m'
export OCyan='\033[46m'
export OWhite='\033[47m'

#echo High Intensity
export IBlack='\033[0;90m'
export IRed='\033[0;91m'
export IGreen='\033[0;92m'
export IYellow='\033[0;93m'
export IBlue='\033[0;94m'
export IPurple='\033[0;95m'
export ICyan='\033[0;96m'
export IWhite='\033[0;97m'

#echo Bold High Intensity
export BIBlack='\033[1;90m'
export BIRed='\033[1;91m'
export BIGreen='\033[1;92m'
export BIYellow='\033[1;93m'
export BIBlue='\033[1;94m'
export BIPurple='\033[1;95m'
export BICyan='\033[1;96m'
export BIWhite='\033[1;97m'

#echo High Intensity backgrounds
export HBlack='\033[0;100m'
export HRed='\033[0;101m'
export HGreen='\033[0;102m'
export HYellow='\033[0;103m'
export HBlue='\033[0;104m'
export HPurple='\033[0;105m'
export HCyan='\033[0;106m'
export HWhite='\033[0;107m'
