import os
import difflib

directorio = '/data/data/com.termux/files/home/downloads/python'
frase2 = input("Ingresa la primera linea de busqueda: ")
corte = 80  # Porcentaje minimo de similitud para considerar la comparacion como valida

# Recorrer los archivos del directorio y sus subdirectorios
for dirpath, dirnames, filenames in os.walk(directorio):
    for archivo in filenames:
        ruta_archivo = os.path.join(dirpath, archivo)
        # Leer la primera linea del archivo y separarla en preguntas
        with open(ruta_archivo, 'r', encoding="ISO-8859-1") as f:  # Especificando el formato del archivo
            primera_linea = f.readline().strip()
            preguntas = primera_linea.split('? ')

        # Buscar las semejanzas con la frase2 en cada pregunta
        similitud_max = 0
        for pregunta in preguntas:
            # Agregar el signo de interrogacion al final de cada pregunta
            pregunta = pregunta.strip() + '?'

            # Comparar la pregunta con la frase2
            s = difflib.SequenceMatcher(None, frase2, pregunta)
            porcentaje_pregunta = s.ratio() * 100
            similitud_max = max(similitud_max, porcentaje_pregunta)

        # Si hay similitud, mostrar el nombre del archivo y el contenido restante
        if similitud_max >= corte:
            with open(ruta_archivo, 'r', encoding="ISO-8859-1") as f:  # Especificando el formato del archivo
                # Descartar la primera linea
                next(f)
                print(ruta_archivo)
                # Mostrar el contenido restante del archivo

                # Leer todas las lineas y eliminar la primera linea del archivo
                lineas = f.readlines()[1:]
                #print(ruta_archivo)
                # Imprimir las lineas con su indentacion y saltos de linea
                for linea in lineas:
                    print(linea, end='')
                print()
                '''for linea in f:
                    print(linea.strip())
                print()'''
            # Si se encontro un archivo que contiene la linea de similitud, salir del bucle
            break
        else:
            continue
        break
