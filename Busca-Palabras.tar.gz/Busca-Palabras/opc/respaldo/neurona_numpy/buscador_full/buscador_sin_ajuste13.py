import os
import difflib
import textwrap
from unidecode import unidecode

#directorio = '/sdcard/Download/diccionario/'
directorio = '/sdcard/Alarms/termux-comandos'

frase2 = input("Ingresa la primera linea de busqueda: ")
corte = 80  # Porcentaje minimo de similitud para considerar la comparacion como valida

# Calcular el tamano de la pantalla
terminal_size = os.get_terminal_size().columns

# Convertir la frase2 a minusculas y quitarle las tildes
frase2 = unidecode(frase2.lower().strip())

# Recorrer los archivos del directorio y sus subdirectorios
for dirpath, dirnames, filenames in os.walk(directorio):
    for archivo in filenames:
        ruta_archivo = os.path.join(dirpath, archivo)
        # Leer la primera linea del archivo
        with open(ruta_archivo, 'r', encoding="ISO-8859-1") as f:  # Especificando el formato del archivo
            primera_linea = f.readline().strip()
            # Separar cada pregunta de la linea
            preguntas = primera_linea.split('? ')

        # Buscar las semejanzas de la frase2 en cada pregunta del archivo
        similitud_max = 0
        for pregunta in preguntas:
            # Agregar el signo de interrogacion al final de cada pregunta
            pregunta = pregunta.strip() + '?'
            # Convertir la pregunta a minusculas y quitarle las tildes
            pregunta = unidecode(pregunta.lower().strip())

            # Comparar las pregunta de la linea del archivo con la frase2 del input
            s = difflib.SequenceMatcher(None, frase2, pregunta)
            porcentaje_pregunta = s.ratio() * 100
            similitud_max = max(similitud_max, porcentaje_pregunta)

        # Si hay similitud, mostrar el nombre del archivo y el contenido restante
        if similitud_max >= corte:
            with open(ruta_archivo, 'r', encoding="utf-8") as f:  # Especificando el formato del archivo
                # Leer todas las lineas y eliminar la primera linea del archivo
                lineas = f.readlines()[1:]
                print(f'{ruta_archivo}\n')
                # Imprimir las lineas con su indentacion y saltos de linea
                for linea in lineas:
                    for linea in linea.split("\n"):
                        if linea.split():
                            # Considerar los saltos de linea y su indentacion
                            linea = linea.replace('\\n', '\n').replace(' ', ' ')
                            print(linea)
      
                print()
                print("ruta del archivo:")
                print(f'{ruta_archivo}\n')
            # Si se encontro un archivo que contiene la linea de similitud, salir del bucle
            break
    else:
        continue
    break