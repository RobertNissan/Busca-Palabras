import os
import textwrap
from unidecode import unidecode
from difflib import SequenceMatcher


# Especifica el directorio principal a buscar
directorio_principal = '/storage/emulated/0/Download/diccionario/dics'

# Pide al usuario que ingrese la palabra de busqueda y conviertela a ASCII utilizando la biblioteca unidecode
entrada = input('Ingrese la palabra de busqueda: ')
#entrada = unidecode(entrada.lower())

# Obtener el tamano de la terminal para la impresion
terminal_size = os.get_terminal_size().columns

# Convierte la entrada en una lista de palabras
palabras_entrada = entrada.split()


#print(f"palabras_entrada {palabras_entrada}")
#input()

# Recorre todos los archivos dentro de directorio_principal y sus subdirectorios
for ruta, directorios, archivos in os.walk(directorio_principal):
    for archivo in archivos:
        ruta_completa = os.path.join(ruta, archivo)
        
        # Abre el archivo en modo lectura
        with open(ruta_completa, 'r', encoding='utf-8-sig') as f:
            try:
                # Lee la primera linea del archivo y elimina los espacios en blanco
                primera_linea = f.readline().strip()
            except UnicodeDecodeError:
                # Si se produce un error de decodificacion, intenta leer el archivo con la codificacion ISO-8859-1
                with open(ruta_completa, 'r', encoding='ISO-8859-1') as f:
                    primera_linea = f.readline().strip()
        
        
        #print(f"primera_linea {primera_linea}")
        #input()
        
        
        
        # Lista de preguntas que contienen todas las palabras clave de la entrada
        preguntas_coincidentes = []
        for pregunta in primera_linea.split('\n'):
            coincidencias = 0
            #print(f"pregunta1 {pregunta}")
            #input()
            for palabra in palabras_entrada:
                if palabra in pregunta:
                    coincidencias += 1
            if coincidencias == len(palabras_entrada):
                preguntas_coincidentes.append(pregunta)
        #print(f"coincidentes {preguntas_coincidentes}")
        #input()
        # Procesa todas las preguntas coincidentes (si hay alguna)
        if preguntas_coincidentes:
            similitudes = {}
            for pregunta in preguntas_coincidentes:
                #print(f"pregunta2 {pregunta}")
                #input()

                similitud = SequenceMatcher(None, entrada, pregunta).ratio()
                #print(f"similitud {similitud}")
                #input()
                similitudes[pregunta] = similitud
        
        
        
            #print(f"pre_ingresada {entrada}, similitudes3 {similitudes}")
            #input()

            pregunta_mas_parecida = max(similitudes, key=similitudes.get)
            print(f"pre_mas_parecida {pregunta_mas_parecida}")
            #print(f"pre_encontrada {primera_linea}")
            #input()
        
            # Si la primera linea contiene la palabra clave especificada (insensible a mayusculas y minusculas y sin diacriticos)
            if unidecode(pregunta_mas_parecida.lower()) == unidecode(primera_linea.lower()):
                print(f'La primera linea del archivo {ruta_completa} contiene la palabra clave "{pregunta_mas_parecida}"')
            
                # Imprime el contenido del archivo despues de la linea que contiene la palabra clave sin procesamiento adicional
                with open(ruta_completa, 'r', encoding='utf-8-sig') as f:
                    try:
                        # Lee todas las lineas del archivo
                        lineas = f.readlines()
                    except UnicodeDecodeError:
                        # Si se produce un error de decodificacion, intenta leer el archivo con la codificacion ISO-8859-1
                        with open(ruta_completa, 'r', encoding='ISO-8859-1') as f:
                            lineas = f.readlines()
                
                    # Busca la linea que contiene la palabra clave (insensible a mayusculas y minusculas y sin diacriticos)
                    for i, linea in enumerate(lineas):
                        #print(f"linea encontrada {linea}")
                        #input()
                        if unidecode(pregunta_mas_parecida.lower()) in unidecode(linea.lower()):
                            # Si encuentra la linea, imprime todas las lineas a partir de la siguiente linea sin procesamiento adicional
                            lineas_desde = lineas[i+1:]
                            contenido_desde = ''.join(lineas_desde)
                        
                            print(f'Contenido despues de la linea que contiene la palabra clave "{pregunta_mas_parecida}":')
                            #print(contenido_desde)
                            #print("segunda fase")
                            for linea in contenido_desde.split("\n"):
                                #print(linea)
                                #input()
                                if linea.split('\n'):
                                    for l in linea.split('\n'):
                                        linea_ajustada = textwrap.wrap(l, terminal_size)
                                        linea_ajustada = "\n".join(linea_ajustada)
                                        print(linea_ajustada)
                                       #input()
                            break