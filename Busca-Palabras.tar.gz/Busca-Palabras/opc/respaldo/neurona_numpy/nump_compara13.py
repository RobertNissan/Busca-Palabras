import os
from difflib import SequenceMatcher

# Obtener el tamano de la terminal para la impresion
terminal_size = os.get_terminal_size().columns

# Lee las preguntas y respuestas desde el archivo "preguntas.txt"
preguntas_archivo = open("preguntas.txt", "r", encoding="utf8")
preguntas = []
for pregunta in preguntas_archivo:
    preguntas.append(pregunta.strip().split("#"))
preguntas_archivo.close()

# Obtiene la entrada del usuario 
entrada = input("Haz una pregunta o ingresa alguna frase para comparar: ")

# Convierte la entrada en una lista de palabras
palabras_entrada = entrada.split()

# Lista de preguntas que contienen todas las palabras clave de la entrada
preguntas_coincidentes = []
for pregunta in preguntas:
    coincidencias = 0
    for palabra in palabras_entrada:
        if palabra in pregunta[0]:
            coincidencias += 1
    if coincidencias == len(palabras_entrada):
        preguntas_coincidentes.append(pregunta)

# Procesa todas las preguntas coincidentes (si hay alguna)
if preguntas_coincidentes:
    similitudes = {}
    for pregunta in preguntas_coincidentes:
        similitud = SequenceMatcher(None, entrada, pregunta[0]).ratio()
        similitudes[pregunta[0]] = similitud

    pregunta_mas_parecida = max(similitudes, key=similitudes.get)
    #print(f"La respuesta a \"{pregunta_mas_parecida}\" es: {preguntas[preguntas.index([pregunta_mas_parecida, similitudes[pregunta_mas_parecida]])][1]}")
    print(f"La respuesta a \"{pregunta_mas_parecida}\" es:\n{list(filter(lambda x: x[0] == pregunta_mas_parecida, preguntas))[0][1]}")
else:
    print("No tengo una respuesta para esa entrada.")
