import math

def vectorizar(frase):
    palabras = frase.split()
    vector = {}
    for palabra in palabras:
        if palabra in vector:
            vector[palabra] += 1
        else:
            vector[palabra] = 1
    return vector

def similitud_coseno(frase1, frase2):
    vector1 = vectorizar(frase1)
    vector2 = vectorizar(frase2)
    interseccion = set(vector1.keys()) & set(vector2.keys())
    numerador = sum([vector1[palabra] * vector2[palabra] for palabra in interseccion])
    sum1 = sum([vector1[palabra] ** 2 for palabra in vector1.keys()])
    sum2 = sum([vector2[palabra] ** 2 for palabra in vector2.keys()])
    denominador = math.sqrt(sum1) * math.sqrt(sum2)
    if not denominador:
        return 0
    else:
        return float(numerador) / denominador


pregunta_usuario = "como hago una pizza"
preguntas = ["como preparar una pizza", "como hacer pizza casera", "receta de pizza italiana"]

mayor_similitud = 0
pregunta_similar = ""

for pregunta in preguntas:
    similitud = similitud_coseno(pregunta_usuario, pregunta)
    print(f"{pregunta_usuario} vs {pregunta}: {similitud}")
    if similitud > mayor_similitud:
        mayor_similitud = similitud
        pregunta_similar = pregunta

if mayor_similitud >= 0.8:
    print(f"?Quisiste decir '{pregunta_similar}'?")
else:
    print("No se encontro una pregunta similar")
