import os
import textwrap
from difflib import SequenceMatcher

# Lee las preguntas y respuestas desde el archivo "preguntas.txt"
preguntas_archivo = open("preguntas.txt", "r", encoding="utf8")
preguntas = []
for pregunta in preguntas_archivo:
    preguntas.append(pregunta.strip().split("#"))
preguntas_archivo.close()

# Obtiene la entrada del usuario 
entrada = input("Haz una pregunta: ")
print()

# Obtener el tamano de la terminal para la impresion
terminal_size = os.get_terminal_size().columns

# Convierte la entrada en una lista de palabras
palabras_entrada = entrada.split()

# Lista de preguntas que contienen todas las palabras clave de la entrada
preguntas_coincidentes = []
for pregunta in preguntas:
    coincidencias = 0
    for palabra in palabras_entrada:
        if palabra in pregunta[0]:
            coincidencias += 1
    if coincidencias == len(palabras_entrada):
        preguntas_coincidentes.append(pregunta)

# Procesa todas las preguntas coincidentes (si hay alguna)
if preguntas_coincidentes:
    similitudes = {}
    for pregunta in preguntas_coincidentes:
        similitud = SequenceMatcher(None, entrada, pregunta[0]).ratio()
        similitudes[pregunta[0]] = similitud

    pregunta_mas_parecida = max(similitudes, key=similitudes.get)
    respuesta = list(filter(lambda x: x[0] == pregunta_mas_parecida, preguntas))[0][1]

    if respuesta == 'ip':
        os.system("ifconfig | grep 'inet [0-9]' | awk '{print $2}'")
        print()
        exit()

    for linea in respuesta.split("\n"):
        if linea.strip():
            linea = linea.replace("\\n", "\n").replace(" ", " ")
            for l in linea.split('\n'):  
                lineas_ajustadas = textwrap.wrap(l, terminal_size)
                lineas_ajustadas = "\n".join(lineas_ajustadas)
                print(lineas_ajustadas)
            print()
            exit()

            for linea_ajustada in lineas_ajustadas:
                if linea_ajustada.strip():
                    print(linea_ajustada)
    print()
    exit()
    print(respuesta)
    input()

    for linea in respuesta.split("\n"):
        linea_ajustada = textwrap.fill(linea, terminal_size)
        print(linea_ajustada)
    print("fin 1")
    input()

    for lg in respuesta.split('\n'):
        for i in lg.split('\n'):
            for linea_ajustada in i.split('\n'):
                linea_ajustada = textwrap.wrap(linea_ajustada, terminal_size).replace('\\n', '\n')
                print(linea_ajustada)
                input()
else:
    print("No tengo una respuesta para esa entrada.")
