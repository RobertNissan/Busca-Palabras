import os
from difflib import SequenceMatcher

# Obtener el tamano de la terminal para la impresion
terminal_size = os.get_terminal_size().columns

# Diccionario con algunas preguntas y respuestas
respuestas = {
    'como estas': 'bien grazie',
    'cual es tu comida favorita': 'no como',
    'en que ciudad vives': 'aqui',
    'cual es tu color favorito': 'no color',
    'de donde eres': 'no vivo',
    'que lenguajes de programacion conoces': 'python',
    'cual es el sentido de la vida': 'no se',
    'como preparar una pizza': 'sabrosa',
    'como capturar solo el archivo sin su ruta en bash': 'solo archivo bash',
    'como capturar solo la ruta sin el archivo en bash': 'solo ruta bash',
    'como capturar solo archivo sin su ruta en python': 'solo archivo python',
    'como capturar solo ruta sin el archivo en python': 'solo ruta python',
    'que es bash': 'Bash es una shell de Unix compatible que se utiliza en una variedad de sistemas operativos, como Linux, macOS y Windows.'}


# Obtiene la entrada del usuario 
entrada = input("Haz una pregunta o ingresa alguna frase para comparar: ")

# Convierte la entrada en una lista de palabras
palabras_entrada = entrada.split()

# Lista de preguntas que contienen todas las palabras clave de la entrada
preguntas_coincidentes = []
for pregunta in respuestas.keys():
    coincidencias = 0
    for palabra in palabras_entrada:
        if palabra in pregunta:
            coincidencias += 1
    if coincidencias == len(palabras_entrada):
        preguntas_coincidentes.append(pregunta)

# Procesa todas las preguntas coincidentes (si hay alguna)
if preguntas_coincidentes:
    similitudes = {}
    for pregunta in preguntas_coincidentes:
        similitud = SequenceMatcher(None, entrada, pregunta).ratio()
        similitudes[pregunta] = similitud

    pregunta_mas_parecida = max(similitudes, key=similitudes.get)
    print(f"La respuesta a \"{pregunta_mas_parecida}\" es: {respuestas[pregunta_mas_parecida]}")
else:
    print("No tengo una respuesta para esa entrada.")
