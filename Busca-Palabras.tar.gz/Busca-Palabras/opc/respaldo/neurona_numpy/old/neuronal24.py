import os
import math
import textwrap
import numpy as np

terminal_size = os.get_terminal_size().columns

# Definicion de la red neuronal
def neural_network(input_data, weights):
    hidden_layer = sigmoid(np.dot(input_data, weights[0]))
    output = sigmoid(np.dot(hidden_layer, weights[1]))
    return output

# Funcion de activacion sigmoid
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Funcion que devuelve la respuesta a una pregunta
def responder_pregunta(pregunta, preguntas_respuestas):
    for pr in preguntas_respuestas:
        if pr[0].lower() == pregunta.lower():
            # Datos de entrada para la pregunta
            X_pregunta = np.array([[1, 0, 0]])
            # Realizar prediccion para la pregunta
            prediccion = neural_network(X_pregunta, [W1, W2])[0][0]
            # Si la prediccion indica que la respuesta es "si", devuelve la respuesta
            if prediccion >= 0.5:
                return pr[1]
    return "Lo siento, no comprendo la pregunta."

# Abrir y leer el archivo de texto
file_path = os.path.join(os.getcwd(), "preguntas.txt")
with open(file_path, "r") as file:
    content = file.read()

# Parsear el contenido del archivo para crear el array de preguntas y respuestas
preguntas_respuestas = []
lines = content.split("\n")
for line in lines:
    if line != "":
        pregunta, respuesta = line.split("#")
        preguntas_respuestas.append([pregunta, respuesta])

# Datos de entrada (solo se necesitan los datos de entrada para entrenamiento)
X = np.array([[0, 0, 1], [0, 1, 1], [1, 0, 1], [1, 1, 1]])

# Etiquetas de salida (solo se necesitan las etiquetas de salida para entrenamiento)
y = np.array([[0, 1, 1, 0]]).T

# Pesos entrenados (ya estan entrenados en este ejemplo)
W1 = np.array([[-0.16595599, 0.44064899, -0.99977125, -0.39533485],
               [-0.70648822, -0.81532281, -0.62747958, -0.30887855],
               [-0.20646505, 0.07763347, -0.16161097, 0.370439  ]])

W2 = np.array([[-0.5910955 ],
               [ 0.75623487],
               [-0.94522481],
               [ 0.34093502]])

while True:
    # Obtener la pregunta del usuario
    pregunta = input("Haz una pregunta: ")
    terminal_size = os.get_terminal_size().columns

    def vectorizar(frase):
        palabras = frase.split()
        vector = {}
        for palabra in palabras:
            if palabra in vector:
                vector[palabra] += 1
            else:
                vector[palabra] = 1
        return vector

    def similitud_coseno(frase1, frase2):
        vector1 = vectorizar(frase1)
        vector2 = vectorizar(frase2)
        interseccion = set(vector1.keys()) & set(vector2.keys())
        numerador = sum([vector1[palabra] * vector2[palabra] for palabra in interseccion])
        sum1 = sum([vector1[palabra] ** 2 for palabra in vector1.keys()])
        sum2 = sum([vector2[palabra] ** 2 for palabra in vector2.keys()])
        denominador = math.sqrt(sum1) * math.sqrt(sum2)
        if not denominador:
            return 0
        else:
            return float(numerador) / denominador


    #preguntas = ["quien eres", "como preparar una pizza", "como hacer pizza casera", "receta de pizza italiana"]
    '''nombre_archivo = 'preguntas2.txt'
    lin = []
    with open(nombre_archivo, "r") as archivo:
        lineas = archivo.readlines()
        for linea in lineas[1:]:
            linea = linea.strip()
            lin.append(linea.strip())
    preguntas = lin'''

    with open('preguntas.txt', 'r') as f:
        notas = []
        for linea in f:
            partes = linea.strip().split('#')
            notas.append(partes[0])
        print(notas)
        preguntas = notas
        input()

    '''with open('preguntas.txt', 'r') as f:
        for linea in f:
            partes = linea.strip().split('#')
            print(partes[0])'''



    mayor_similitud = 0
    pregunta_similar = ""

    for pregunta1 in preguntas:
        similitud = similitud_coseno(pregunta, pregunta1)
        #print(f"{pregunta} vs {pregunta}: {similitud}")
        if similitud > mayor_similitud:
            mayor_similitud = similitud
            pregunta_similar = pregunta1

    if mayor_similitud > 0:
        print(f"?Quisiste decir '{pregunta_similar}'?")
        pregunta = pregunta_similar
    else:
        print("No se encontro una pregunta similar")

    # Salir si el usuario lo indica
    if pregunta.lower() == "adios":
        print("Adios!")
        break

    # Obtener y imprimir la respuesta de la red neuronal
    respuesta = responder_pregunta(pregunta, preguntas_respuestas)

    #linea = respuesta.replace("\\n ", "\n").replace(" ", " ")

    # dividimos la cadena en lineas individuales con la funcion split()
    lineas_individuales = respuesta.splitlines()

    # Ajustar cada linea al ancho deseado
    '''lineas_ajustadas = []
    for linea in lineas_individuales:
        linea_ajustada = textwrap.wrap(linea, terminal_size)
        lineas_ajustadas.extend(linea_ajustada)'''


    lineas_ajustadas = "".join(lineas_individuales)


    '''lineas_ajustadas = []
    for lg in lineas_individuales:
        lg = lg.replace("\\n", "\n").replace(" ", " ")
        for linea in lg.split('\n'):
            if linea.strip():
                linea_ajustada = textwrap.wrap(linea, terminal_size)
                linea.extend(linea_ajustada)
                print(linea.strip())
                input()'''



    for lg in lineas_individuales:
            lg = lg.replace("\\n", "\n").replace(" ", " ")
            for linea in lg.split('\n'):
                if linea.strip():
                    lineas_ajustadas = textwrap.wrap(linea, terminal_size)
                    for linea_ajustada in lineas_ajustadas:
                        print(linea_ajustada)


    print('\n')
    #input()



    #print(lineas_ajustadas)
    #input()
    # recorremos todas las lineas ajustadas con un bucle for
    '''array = []
    long = 0
    lineas_ajustadas = []
    for lg in lineas_individuales:
        lg = lg.replace("\\n", "\n").replace(" ", " ")
        lg = lg
        linea_ajustada = textwrap.wrap(lg, terminal_size)
        lineas_ajustadas.extend(linea_ajustada)

        for li in lineas_ajustadas:
            long = len(li)
            for longitud in range(1, 150):
                medida = long + longitud
                if medida == terminal_size:
                    #print(long)
                    array.append(li)
                    #print(array)
                    os.system("sleep .05")
                    #input()
    array = "\n".join(array)
    print(array)
    print('\n')'''






    # Convertimos la lista en un string y reemplazamos los saltos de linea con "\n"
    '''resultado = "\n".join(array)

    resultado = resultado.replace("\\n", "\n").replace(" ", " ")

    # Imprimimos el resultado
    print(resultado)
    print('\n')'''

    '''for lg in linea.split():
        #lg = lg.replace("\\n ", "\n").replace(" ", " ")
        print(lg)
        input()
    linea = textwrap.wrap(linea, terminal_size)
    print(linea)'''


    # Imprimir cada linea
    '''for linea in respuesta:
        linea = linea.replace("\\n ", "\n").replace(" ", " ")
        print(linea)'''
        #print(respuesta)


'''with open("archivo.txt", "r") as archivo:
    linea = archivo.readline().strip()
    #linea = linea.replace("\\n", "\n")
    linea = linea.replace("\\n ", "\n").replace(" ", " ")
    print(linea)'''
