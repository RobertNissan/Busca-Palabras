import numpy as np
import difflib

archivo = 'archivo_p.txt'
frase1 = input('Ingrese una frase: ')

corte = 53
# Cargar la frase2 desde el archivo
with open(archivo, 'r') as f:
    frase2 = f.read().replace('\n', '')

# Separar la frase2 en preguntas
preguntas = frase2.split('? ')

# Comparar cada pregunta con la frase1
porcentaje_max = 0
for pregunta in preguntas:
    # Agregar el signo de interrogacion al final de cada pregunta
    pregunta = pregunta.strip() + '?'

    # Comparar la pregunta con la frase1
    s = difflib.SequenceMatcher(None, frase1, pregunta)
    match = s.find_longest_match(0, len(frase1), 0, len(pregunta))

    # Calcular el porcentaje de similitud y actualizar el porcentaje maximo
    porcentaje_pregunta = s.ratio() * 100
    porcentaje_max = max(porcentaje_max, porcentaje_pregunta)

    # Mostrar el resultado de la comparacion para cada pregunta
    print(f'Pregunta: {pregunta}')
    print(f'Porcentaje de similitud: {porcentaje_pregunta:.2f}%')
    if porcentaje_pregunta >= corte:
        print('Frases iguales')
    else:
        print('Frases diferentes')


# Mostrar el resultado de la comparacion entre la frase1 y la frase2 total
porcentaje_total = difflib.SequenceMatcher(None, frase1, frase2).ratio() * 100
print(f'Porcentaje de similitud total: {porcentaje_total:.2f}%')
if porcentaje_max >= corte:
    print('Frases iguales')
else:
    print('Frases diferentes')
