import numpy as np
import difflib

#frase1 = 'como quiero capturar obtener tomar solo la ruta sin el su archivo en bash'
#frase2 = 'solo la ruta sin su archivo'
#frase2 = 'capturar solo el archivo sin ruta'

frase1 = '?como hacer una pizza?'
frase2 = '?como hacer una pizza? ?como se prepara una pizza? ?quiero hacer una pizza?'
#frase2 = '?como preparar una pizza?'

# Convertir las frases en arrays numpy de cadenas
arr1 = np.array([frase1])
arr2 = np.array([frase2])

# Obtener la secuencia mas larga comun de caracteres
s = difflib.SequenceMatcher(None, frase1, frase2)
match = s.find_longest_match(0, len(frase1), 0, len(frase2))

# Crear una mascara numpy en base a la secuencia mas larga comun
mask = np.zeros(len(frase1), dtype=bool)
mask[match.a: match.a+match.size] = True

# Calcular el porcentaje de similitud entre las dos frases y establecer un umbral de corte
corte = 53  # Porcentaje minimo de similitud para considerar la comparacion como valida
porcentaje = difflib.SequenceMatcher(None, frase1, frase2).ratio() * 100

# Mostrar el porcentaje de similitud y si las frases son iguales o diferentes
print(f'Porcentaje de similitud: {porcentaje:.2f}%')
if porcentaje >= corte:
    print('Frases iguales')
else:
    print('Frases diferentes')
