def organizar_letras(letras):
    # Convertir la entrada en una lista de letras
    letras = list(letras)
    
    # Obtener todas las permutaciones posibles de las letras
    permutaciones = []
    for i in range(len(letras)):
        if i == 0:
            permutaciones.append([letras[i]])
        else:
            nuevas_permutaciones = []
            for j in range(len(permutaciones)):
                for k in range(len(permutaciones[j])+1):
                    nuevas_permutaciones.append(permutaciones[j][:k] + [letras[i]] + permutaciones[j][k:])
            permutaciones = nuevas_permutaciones
    
    # Convertir cada permutacion en una palabra
    palabras = [''.join(p) for p in permutaciones]
    
    # Eliminar palabras duplicadas y ordenar la lista de palabras
    palabras = sorted(list(set(palabras)))
    
    # Crear un diccionario con las palabras a buscar
    diccionario = {'hola': True, 'mundo': True, 'python': True}
    
    # Buscar cada palabra en el diccionario e imprimir si existe
    for palabra in palabras:
        if diccionario.get(palabra):
            print(palabra)
# Ejemplo de uso
letras = input("Ingresa las letras: ")
palabras = organizar_letras(letras)
if palabras == None:
    pass
else:
    print(palabras)
