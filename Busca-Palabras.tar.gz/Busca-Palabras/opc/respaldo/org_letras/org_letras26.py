from unidecode import unidecode

def buscar_palabras(letras):
    if len(letras) == 1:
        return letras
    else:
        resultado = []
        for i in range(len(letras)):
            letra = letras[i]
            restantes = letras[:i] + letras[i+1:]
            for palabra in buscar_palabras(restantes):
                resultado.append(letra + palabra)
        return resultado

letras = input("Ingrese las letras: ")
posibles_palabras = buscar_palabras(letras)

with open('diccionario.txt', 'r', encoding='utf-8') as f:
    for linea in f:
        palabra = linea.rstrip()
        if palabra.lower() in posibles_palabras or unidecode(palabra.lower()) in posibles_palabras:
            print(palabra)
