import itertools
import numpy as np
import unicodedata

def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD', input_str)
    return u"".join([c for c in nfkd_form if not unicodedata.combining(c)])

palabra = input("Ingrese la palabra a buscar: ")

with open('diccionario.txt', 'r', encoding='utf-8') as f:
    palabras = set(linea.rstrip() for linea in f)
    palabras = set(remove_accents(p).lower() for p in palabras)

arreglo_palabras = np.array(list(palabras))
permutaciones = itertools.permutations(palabra)

palabras_impresas = set()
for permutacion in permutaciones:
    palabra_permutada = ''.join(permutacion)
    indices = np.where(arreglo_palabras == palabra_permutada)[0]
    for i in indices:
        if arreglo_palabras[i] not in palabras_impresas:
            print(arreglo_palabras[i])
            palabras_impresas.add(arreglo_palabras[i])
