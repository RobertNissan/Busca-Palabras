import threading
from unidecode import unidecode

def buscar_palabras(letras):
    if len(letras) == 1:
        return letras
    else:
        resultado = []
        for i in range(len(letras)):
            letra = letras[i]
            restantes = letras[:i] + letras[i+1:]
            for palabra in buscar_palabras(restantes):
                resultado.append(letra + palabra)
        return resultado

def buscar_en_diccionario(posibles_palabras):
    with open('diccionario.txt', 'r', encoding='utf-8') as f:
        for linea in f:
            palabra = linea.rstrip()
            if palabra.lower() in posibles_palabras or unidecode(palabra.lower()) in posibles_palabras:
                print(palabra)

letras = input("Ingrese las letras: ")
posibles_palabras = buscar_palabras(letras)

hilos = []
for i in range(1): # numero de hilos
    inicio = i * len(posibles_palabras) // 4
    fin = (i + 1) * len(posibles_palabras) // 4
    hilo = threading.Thread(target=buscar_en_diccionario, args=(posibles_palabras[inicio:fin],))
    hilos.append(hilo)
    hilo.start()
    
for hilo in hilos:
    hilo.join()
