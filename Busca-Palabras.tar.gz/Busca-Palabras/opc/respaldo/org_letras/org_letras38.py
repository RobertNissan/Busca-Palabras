import itertools
import concurrent.futures

# leer el archivo de diccionario y almacenar las palabras en un conjunto
with open('diccionario.txt') as f:
    diccionario = {line.strip() for line in f}

# funcion que busca las permutaciones de una palabra en el diccionario
def buscar_permutaciones(palabra):
    palabras_encontradas = []
    for perm in itertools.permutations(palabra):
        if ''.join(perm) in diccionario:
            palabras_encontradas.append(''.join(perm))
    return palabras_encontradas

# obtener la palabra a buscar del usuario
palabra_a_buscar = input('Ingrese la palabra a buscar: ')
long = len(palabra_a_buscar)

# dividir la palabra en subconjuntos mas pequenos para procesar en hilos
subconjuntos = [palabra_a_buscar[i:i+long] for i in range(0, len(palabra_a_buscar), long)]

# ejecutar la busqueda en paralelo en los subconjuntos
with concurrent.futures.ThreadPoolExecutor() as executor:
    resultados = list(executor.map(buscar_permutaciones, subconjuntos))

# imprimir los resultados
palabras_encontradas = set(sum(resultados, []))
#print('Palabras encontradas:', palabras_encontradas)

print('Palabras encontradas:')
for palabra in palabras_encontradas:
    print(palabra)
