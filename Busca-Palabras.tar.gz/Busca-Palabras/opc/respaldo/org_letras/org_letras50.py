import itertools
import mmap

def buscar_palabra(palabra_a_buscar, palabras_encontradas):
    with open("diccionario.txt", "rb", 0) as file, \
        mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as s:
        for line in iter(s.readline, b""):
            if len(line.strip()) == len(palabra_a_buscar) and set(line.strip()) == set(palabra_a_buscar):
                palabra = line.decode().strip()
                if palabra not in palabras_encontradas:
                    for mutada in itertools.permutations(palabra_a_buscar):
                        #print(''.join(chr(i) for i in mutada))
                        muta = (''.join(chr(i) for i in mutada))
                        print(f"{muta} - Encontrada {palabra}")
                        input()
                        palabras_encontradas.add(palabra)

busqueda = input("Ingrese la palabra > ")
palabra_a_buscar = busqueda.encode('utf-8')
palabras_encontradas = set()
buscar_palabra(palabra_a_buscar, palabras_encontradas)
