import difflib
import unicodedata

def organizar_letras(letras):
    # Convertir la entrada en una lista de letras
    letras = list(letras)
    # Obtener todas las permutaciones posibles de las letras
    permutaciones = []
    for i in range(len(letras)):
        if i == 0:
            permutaciones.append([letras[i]])
        else:
            nuevas_permutaciones = []
            for j in range(len(permutaciones)):
                for k in range(len(permutaciones[j])+1):
                    nuevas_permutaciones.append(permutaciones[j][:k] + [letras[i]] + permutaciones[j][k:])
            permutaciones = nuevas_permutaciones
    # Convertir cada permutacion en una palabra y buscarla en el diccionario                                    palabras = [''.join(p) for p in permutaciones]
    palabras = [''.join(p) for p in permutaciones]
    with open('diccionario.txt', 'r', encoding='utf-8') as f:
        lineas = f.readlines()
        diccionario = {}
        for linea in lineas:
            linea = linea.strip()
            palabra, definicion = linea.strip().split(':')
            diccionario[palabra] = definicion
    palabras = set(palabras)
    palabras_encontradas = set()
    for palabra in palabras:
        palabra_normalizada = unicodedata.normalize('NFKD', palabra).encode('ASCII', 'ignore').decode('utf-8')
        if diccionario.get(palabra_normalizada) and palabra not in palabras_encontradas:
            print(palabra)
            palabras_encontradas.add(palabra)
        else:
            buscar_palabras_similares(palabra_normalizada, diccionario.keys(), palabras_encontradas)

def buscar_palabras_similares(palabra, lista, palabras_encontradas):
    # Buscar la palabra mas similar en la lista
    palabra_similar = difflib.get_close_matches(palabra, lista, n=1)

    # Imprimir la palabra similar encontrada si no se ha impreso antes
    if palabra_similar and palabra_similar[0] not in palabras_encontradas:
        print(palabra_similar[0])
        palabras_encontradas.add(palabra_similar[0])

# Ejemplo de uso
letras = input("Ingresa las letras: ")
organizar_letras(set(letras))
