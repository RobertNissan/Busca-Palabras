import mmap
import itertools

palabra_a_buscar = input("Ingrese la palabra >").encode('utf-8')
permutations = set()
with open("diccionario.txt", "rb", 0) as file, \
    mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as s:
    for line in iter(s.readline, b""):
        if len(line.strip()) == len(palabra_a_buscar) and set(line.strip()) == set(palabra_a_buscar):
            print(line.decode().strip())
