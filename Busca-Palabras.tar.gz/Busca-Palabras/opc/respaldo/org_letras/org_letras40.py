import itertools
import concurrent.futures
from unidecode import unidecode
from multiprocessing import Pool

# leer el archivo de diccionario y almacenar las palabras en un diccionario
with open('diccionario.txt') as f:
    dictionary = {unidecode(line.rstrip()): line.rstrip() for line in f}

# funcion que busca las permutaciones de una palabra en el diccionario
def buscar_permutaciones(palabra):
    palabras_encontradas = []
    #for perm in itertools.islice(permutations(palabra, 30000)):
    for perm in itertools.islice(itertools.permutations(palabra), 5000):
        normalized_per = unidecode(''.join(perm))
        normalized_perm = unidecode(''.join(perm))
        if normalized_perm in dictionary and normalized_per in dictionary:
            palabras_encontradas.append(dictionary[normalized_perm])
    return palabras_encontradas

# obtener la palabra a buscar del usuario
palabra_a_buscar = input('Ingrese la palabra a buscar: ')
long = len(palabra_a_buscar)
if long == 0:
    print("Nada ingresado")
    exit()
# dividir la palabra en subconjuntos mas pequenos para procesar en hilos
subconjuntos = [palabra_a_buscar[i:i+long] for i in range(0, len(palabra_a_buscar), long)]

# ejecutar la busqueda en paralelo en los subconjuntos
with Pool() as p:
    resultados = p.map(buscar_permutaciones, subconjuntos)

# imprimir los resultados
palabras_encontradas = set(sum(resultados, []))
print('Palabras encontradas:')
for palabra in palabras_encontradas:
    print(palabra)
