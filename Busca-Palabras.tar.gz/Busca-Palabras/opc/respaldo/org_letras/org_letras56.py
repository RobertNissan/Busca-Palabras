import os
import unicodedata

try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode


with open('diccionario.txt') as f:
    palabras = f.readlines()

def normalize_text(text):
    # Convertir la cadena a minusculas
    text = text.lower()
    # Remover los acentos
    text = unidecode(text)
    return text

palabra = input('Ingrese una palabra: ')
#Normalizar la cadena ingresada
palabra = normalize_text(palabra)

palabra_ordenada = ''.join(sorted(palabra.lower()))
longitud_palabra = len(palabra)

for p in palabras:
    p = p.strip()
    p_sin_tildes = unicodedata.normalize('NFKD', p).encode('ASCII', 'ignore').decode('utf-8')
    if len(p_sin_tildes) != longitud_palabra:
        continue
    p_ordenada = ''.join(sorted(p_sin_tildes.lower()))

    if p_ordenada == palabra_ordenada:
        print(p)
