import os

# especificar la ubicacion de los archivos a combinar
dir_path = "/storage/emulated/0/Download/diccionario/limpios_puntos/"

# abrir un archivo nuevo en modo de escritura
with open("merged_file.txt", "w") as outfile:

    # iterar sobre cada archivo en la carpeta
    for filename in os.listdir(dir_path):
        if filename.endswith(".txt"):
            # abrir el archivo en modo de lectura
            with open(os.path.join(dir_path, filename), "r") as infile:
                # escribir el contenido en el archivo nuevo
                outfile.write(infile.read())
            
# cerrar todos los archivos
outfile.close()