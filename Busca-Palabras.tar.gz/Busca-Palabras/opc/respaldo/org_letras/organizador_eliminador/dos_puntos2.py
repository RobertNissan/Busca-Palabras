import os

# nombre del directorio donde estan los archivos
directorio = "/storage/emulated/0/Download/diccionario/dics/"

# recorremos todos los archivos del directorio
for archivo in os.listdir(directorio):
    # comprobamos que sea un archivo de texto
    if archivo.endswith(".txt"):
        ruta_absoluta = os.path.join(directorio, archivo)
        # abrimos el archivo en modo lectura
        with open(ruta_absoluta, "r") as archivo_lectura:
            # leemos todas las lineas del archivo
            lineas = archivo_lectura.readlines()
        # abrimos el archivo en modo escritura
        with open(ruta_absoluta, "w") as archivo_escritura:
            # recorremos todas las lineas del archivo
            for linea in lineas:
                # eliminamos los espacios en blanco
                linea = linea.strip()
                # agregamos dos puntos al final de cada palabra
                palabras = linea.split()
                linea_nueva = " ".join([p + ":" for p in palabras])
                archivo_escritura.write(linea_nueva + "\n")