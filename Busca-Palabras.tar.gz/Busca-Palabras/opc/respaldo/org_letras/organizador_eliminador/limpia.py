import os

directorio = "/storage/emulated/0/Download/diccionario/dics/" # reemplazar por la ruta del directorio que quieras leer

for archivo in os.listdir(directorio):
    if archivo.endswith(".txt"): # solo lee archivos de texto
        ruta_archivo = os.path.join(directorio, archivo)
        lineas_limpas = []
        with open(ruta_archivo, "r") as f:
            for linea in f:
                partes = linea.split(":")
                texto_limpio = partes[0].strip() # elimina los espacios en blanco alrededor del texto
                lineas_limpas.append(texto_limpio)
        with open(ruta_archivo, "w") as f:
            for linea in lineas_limpas:
                f.write(linea + "\n")