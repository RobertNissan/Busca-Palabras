import os

# Ruta del directorio con los archivos
dir_path= '/storage/emulated/0/Download/diccionario/dics/'

# Loop para recorrer cada archivo dentro del directorio

# Recorrer todos los archivos en el directorio
for filename in os.listdir(dir_path):
    # Comprobar que el elemento es un archivo y no un directorio
    if os.path.isfile(os.path.join(dir_path, filename)):
        # Abrir el archivo en modo lectura y escritura
        with open(os.path.join(dir_path, filename), 'r+') as file:
            # Leer todo el contenido del archivo
            content = file.read()
            # Reemplazar todas las palabra
s con un salto de linea al final
            new_content = content.replace("palabra
", "palabra
\n")
            # Escribir el nuevo contenido en el archivo
            file.seek(0)
            file.write(new_content)
            file.truncate()
