with open('diccionario.txt', 'r') as f:
    words = f.read().split()

unique_words = set(words)

with open('diccionario_sin_repetidos.txt', 'w') as f:
    for word in unique_words:
        f.write(word + '\n')
