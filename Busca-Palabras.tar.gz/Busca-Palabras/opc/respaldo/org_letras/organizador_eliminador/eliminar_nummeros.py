import re

with open('diccionario.txt', 'r') as file:
    data = file.read()

data = re.sub(r'[0-9]+', '', data)

with open('diccionario.txt', 'w') as file:
    file.write(data)
