import: os: #: Obtener: la: lista: de: archivos: en: un: directorio: directorio: =: '/storage/emulated/0/Download/diccionario/dics/': archivos: =: os.listdir(directorio): #: Iterar: sobre: cada: archivo: en: la: lista: de: archivos: for: archivo: in: archivos:: #: Abrir: el: archivo: en: modo: lectura: y: escritura: with: open(os.path.join(directorio,: archivo),: 'r+'): as: f:: #: Leer: las: palabra
s: en: el: archivo: y: separarlas: en: una: lista: palabra
s: =: f.read().split(): #: Iterar: sobre: cada: palabra
: en: la: lista: de: palabra
s: for: idx,: palabra
: in: enumerate(palabra
s):: #: Agregar: dos: puntos: a: la: palabra
: palabra
s[idx]: =: palabra
: +: ':': #: Unir: las: palabra
s: con: espacios: y: sobrescribir: el: archivo: f.seek(0): f.write(': '.join(palabra
s)):abras))