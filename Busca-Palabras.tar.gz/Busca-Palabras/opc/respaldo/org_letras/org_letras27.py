from unidecode import unidecode

def buscar_palabras(letras):
    if len(letras) == 1:
        return letras
    else:
        resultado = []
        for i in range(len(letras)):
            letra = letras[i]
            restantes = letras[:i] + letras[i+1:]
            for palabra in buscar_palabras(restantes):
                resultado.append(letra + palabra)
        return resultado

letras = input("Ingrese las letras: ")
posibles_palabras = buscar_palabras(letras)

with open('diccionario.txt', 'r', encoding='utf-8') as f:
    palabras = set(linea.rstrip().lower() for linea in f)
    for palabra in posibles_palabras:
        if palabra.lower() in palabras or unidecode(palabra.lower()) in palabras:
            print(palabra)
