import os
import threading
import platform
import subprocess
import signal
import sys

if platform.system() == 'Windows':
    local = subprocess.getoutput("""for /f "tokens=2 delims=[]" %a in ('ping -n 1 -4 "%computername%"') do @echo %a""")
else:
    local = subprocess.getoutput("x=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}');echo ${x%%/*}")
    iscan = subprocess.getoutput("x=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}');mi=$(echo ${x%%/*});md=$(echo ${mi%.*});echo ${md}.")
print("Conectados a mi red")
print(f"Mi dispositivo: {local}")

def search(ip_adress):

  comando = "ping -c 1 "+ip_adress
  response = os.popen(comando).read()
  if "1 received" in response:
   print("Encontrado en: ",ip_adress)
   #print (comando)


def interrupcion(signal, contexto):
   print("ierre de procesos CTRL+C")
   exit
signal.signal(signal.SIGINT, interrupcion)

for ip in range(2,254):
   current_ip = (iscan)+str(ip)
   if not current_ip == (local):
    #print("Analizando la ip: ",current_ip)
    #search(current_ip)

    run = threading.Thread(target=search, args=(current_ip,))
    run.start()
