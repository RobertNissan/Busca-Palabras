#!/bin/bash

declare -A ARCHIVO_ZIP=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation.zip"]=854825995)
declare -A ZIP_APK=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/mc3.zip"]=24567712)
declare -A ARCHIVO_PATH=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/Modern-Combat-3-Fallen-Nation-v1-1-7g-offline.apk"]=24761380)
declare -A ARCHIVOS_OBB=(["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM3HM/main.1120.com.gameloft.android.ANMP.GloftM3HM.obb"]=1342717349 ["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM3HM/patch.11428.com.gameloft.android.ANMP.GloftM3HM.obb"]=81507652)
declare -A ARCHIVO_ZIP_OBB=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/411-Modern-Combat-3-Fallen-Nation-v1-1-6b-cache1.zip"]=833473207)

declare -A archivos
# Función para combinar arrays asociativos
combinar_arrays() {
    local -n array_fuente=$1
    for clave in "${!array_fuente[@]}"; do
        archivos["$clave"]="${array_fuente[$clave]}"
    done
}

# Combinar todos los arrays en el array 'archivos'
combinar_arrays ARCHIVO_ZIP;combinar_arrays ZIP_APK;combinar_arrays ARCHIVO_PATH;combinar_arrays ARCHIVOS_OBB;combinar_arrays ARCHIVO_ZIP_OBB

# Inicializar la variable para la suma total de los tamaños
suma_total=0

# Función para convertir bytes a un formato legible
convertir_tamano() {
    local size=$1
    if (( size >= 1073741824 )); then
        printf "%.2f GB" "$(bc -l <<< "$size/1073741824")"
    elif (( size >= 1048576 )); then
        printf "%.2f MB" "$(bc -l <<< "$size/1048576")"
    elif (( size >= 1024 )); then
        printf "%.2f KB" "$(bc -l <<< "$size/1024")"
    else
        printf "%d bytes" "$size"
    fi
}

convertir_a_bytes() {
    local size_str=$1
    local size=$(echo "$size_str" | grep -oE '[0-9]+(\.[0-9]+)?')  # Extraer número con decimales
    local unit=$(echo "$size_str" | grep -oE '[KMGTP]')  # Extraer unidad (K, M, G, T)
    local bytes=0

    case "$unit" in
        K) bytes=$(echo "$size * 1024" | bc) ;;
        M) bytes=$(echo "$size * 1048576" | bc) ;;
        G) bytes=$(echo "$size * 1073741824" | bc) ;;
        T) bytes=$(echo "$size * 1099511627776" | bc) ;;
        *) bytes=$size ;; # Si no tiene unidad, ya está en bytes
    esac

    # Convertir el resultado a entero sin decimales
    printf "%.0f\n" "$bytes"
}

# Recorrer los archivos y mostrar sus tamaños en un formato legible
for archivo in "${!archivos[@]}"; do
    size=${archivos["$archivo"]}
    suma_total=$((suma_total + size))
    tamano_legible=$(convertir_tamano "$size")
    echo "$archivo => $tamano_legible"
done

# Mostrar el tamaño total en un formato legible
tamano_total_legible=$(convertir_tamano "$suma_total")
echo "Tamaño total: $tamano_total_legible"

# Obtener el espacio libre en el sistema de archivos donde se encuentra RUTA_DESTINO
espacio_libre=$(df -h | grep -E /storage/emulated | xargs | awk '{print $4}')
# espacio_libre='22.16G'
echo "espacio_libre: $espacio_libre"

# Convertir el espacio libre a bytes
espacio_libre_bytes=$(convertir_a_bytes "$espacio_libre")
# echo "espacio_libre_bytes: $espacio_libre_bytes"
disponible_futuro=$(( espacio_libre_bytes - suma_total ))
disponible_futuro_legible=$(convertir_tamano "$disponible_futuro")
# Comparar el tamaño total de los archivos con el espacio libre
if (( disponible_futuro < 0 )); then
    echo "No hay suficiente espacio para descargar los archivos."
else
    echo -e "Hay suficiente espacio disponible para los archivos.\nEl futuro de tu espacio será: $disponible_futuro_legible"
fi
