#!/bin/bash
# ======================================================
# Funciones de conversión de tamaños
# ======================================================

# Convierte una cantidad en bytes a un formato legible (KB, MB, GB)
convertir_tamano() {
    local size=$1
    if (( size >= 1073741824 )); then
        printf "%.2f GB" "$(bc -l <<< "$size/1073741824")"
    elif (( size >= 1048576 )); then
        printf "%.2f MB" "$(bc -l <<< "$size/1048576")"
    elif (( size >= 1024 )); then
        printf "%.2f KB" "$(bc -l <<< "$size/1024")"
    else
        printf "%d bytes" "$size"
    fi
}

# Convierte una cadena con sufijo (por ejemplo, 22.16G) a bytes
convertir_a_bytes() {
    local size_str=$1
    # Extrae la parte numérica (incluyendo decimales)
    local size
    size=$(echo "$size_str" | grep -oE '[0-9]+(\.[0-9]+)?')
    # Extrae la unidad (K, M, G, T)
    local unit
    unit=$(echo "$size_str" | grep -oE '[KMGTP]')
    local bytes=0
    case "$unit" in
        K) bytes=$(echo "$size * 1024" | bc) ;;
        M) bytes=$(echo "$size * 1048576" | bc) ;;
        G) bytes=$(echo "$size * 1073741824" | bc) ;;
        T) bytes=$(echo "$size * 1099511627776" | bc) ;;
        *) bytes=$size ;;
    esac
    # Redondea sin decimales y retorna el valor
    printf "%.0f\n" "$bytes"
}

# ======================================================
# Funciones para sumar tamaños (en bytes)
# ======================================================

# Suma los valores de un array indexado (elementos en bytes)
sumar_bytes_array() {
    local arr=("$@")
    local suma=0
    for valor in "${arr[@]}"; do
        suma=$(( suma + valor ))
    done
    echo "$suma"
}

# Suma los valores de un array asociativo (elementos en bytes)
sumar_bytes_array_asociativo() {
    local -n arr=$1
    local suma=0
    for clave in "${!arr[@]}"; do
        suma=$(( suma + arr[$clave] ))
    done
    echo "$suma"
}

# ======================================================
# Función para combinar arrays asociativos
# ======================================================
# Combina múltiples arrays asociativos (sus nombres se pasan como argumentos)
# en un array asociativo de resultado (el primer argumento, pasado por referencia)
combinar_arrays() {
    local -n resultado=$1
    shift
    for arr_name in "$@"; do
        local -n arr_fuente="$arr_name"
        for clave in "${!arr_fuente[@]}"; do
            resultado["$clave"]="${arr_fuente[$clave]}"
        done
    done
}

verificar_almacenamiento() {
    local espacio_libre=$(df -h | grep -E '/storage/emulated' | xargs | awk '{print $4}')
    echo "Espacio libre: $espacio_libre"
    local espacio_libre_bytes=$(convertir_a_bytes "$espacio_libre")
    local disponible_futuro=$(( espacio_libre_bytes - ${1} ))
    local disponible_futuro_legible=$(convertir_tamano "$disponible_futuro")
    if (( disponible_futuro < 0 )); then
        echo "No hay suficiente espacio para descargar los archivos."
    else
        echo "Hay suficiente espacio disponible."
        echo "El futuro de tu espacio será: $disponible_futuro_legible"
    fi
}
# ======================================================
# Main - Script 1: Uso de array indexado
# ======================================================
echo "----- Script 1: Array indexado -----"
# Definir los tamaños esperados en bytes
TAMANIO_ESPERADO=8383463424
TAMANIO_ZIP_ESPERADO=6852344212

# Almacenar los valores en un array indexado
archivos_index=("$TAMANIO_ESPERADO" "$TAMANIO_ZIP_ESPERADO")
suma_total=$(sumar_bytes_array "${archivos_index[@]}")
tamano_total_legible=$(convertir_tamano "$suma_total")
echo "Tamaño total: $tamano_total_legible"

verificar_almacenamiento "${suma_total}"

# ======================================================
# Main - Script 2: Uso de arrays asociativos
# ======================================================
echo -e "\n----- Script 2: Arrays asociativos -----"
# Es importante que las variables RUTA_DESTINO y RUTA_DESTINO_OBB estén definidas.
# Por ejemplo:
# RUTA_DESTINO="/sdcard/Download/Games/Modern_Combat"
# RUTA_DESTINO_OBB="/sdcard/Android/obb"

declare -A ARCHIVO_ZIP=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation.zip"]=854825995)
declare -A ZIP_APK=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/mc3.zip"]=24567712)
declare -A ARCHIVO_PATH=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/Modern-Combat-3-Fallen-Nation-v1-1-7g-offline.apk"]=24761380)
declare -A ARCHIVOS_OBB=(["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM3HM/main.1120.com.gameloft.android.ANMP.GloftM3HM.obb"]=1342717349 ["$RUTA_DESTINO_OBB/com.gameloft.android.ANMP.GloftM3HM/patch.11428.com.gameloft.android.ANMP.GloftM3HM.obb"]=81507652)
declare -A ARCHIVO_ZIP_OBB=(["$RUTA_DESTINO/Modern_Combat_3_Fallen_Nation/411-Modern-Combat-3-Fallen-Nation-v1-1-6b-cache1.zip"]=833473207)

# Crear array asociativo combinado
declare -A archivos_asoc
combinar_arrays archivos_asoc ARCHIVO_ZIP ZIP_APK ARCHIVO_PATH ARCHIVOS_OBB ARCHIVO_ZIP_OBB

suma_total=$(sumar_bytes_array_asociativo archivos_asoc)
tamano_total_legible=$(convertir_tamano "$suma_total")
echo "Tamaño total: $tamano_total_legible"

verificar_almacenamiento "${suma_total}"