#Este es un script de Bash que busca archivos vacios en el directorio /sdcard/Alarms/Busca-Palabras. Si encuentra algun archivo vacio, busca un archivo de respaldo en el directorio /sdcard/backups/Busca-Palabras/ y lo copia en el archivo vacio. Si no encuentra un archivo de respaldo para el archivo vacio, muestra un mensaje que indica que no se encontro un archivo de respaldo para el archivo vacio.

#Aqui esta una explicacion linea por linea del script:

contador=0 #inicializa la variable contador a 0.

dir="/sdcard/Alarms/Busca-Palabras" #establece la variable dir como el directorio /sdcard/Alarms/Busca-Palabras.

while true; do # inicia un bucle infinito.

if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then # verifica si hay algun archivo vacio en el directorio /sdcard/Alarms/Busca-Palabras.

find "$dir" -type f -empty | while read file; do # busca archivos vacios en el directorio $dir y los procesa uno por uno.

if [ $contador -eq 0 ]; then # verifica si la variable contador es igual a 0.

echo "Arreglando archivos vacios." # muestra un mensaje que indica que se estan arreglando los archivos vacios.

echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco" # muestra el nombre del archivo vacio en rojo.

backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}" # establece la variable backup_file como la ruta del archivo de respaldo correspondiente al archivo vacio.

if [ -f "$backup_file" ]; then # verifica si existe un archivo de respaldo para el archivo vacio.

cp "$backup_file" "$file" # copia el archivo de respaldo en el archivo vacio.

else # si no existe un archivo de respaldo para el archivo vacio, muestra un mensaje que indica que no se encontro un archivo de respaldo para el archivo vacio.

contador=$((contador+1)) # incrementa la variable contador en 1.

done # finaliza el bucle while.

else # si no hay ningun archivo vacio en el directorio /sdcard/Alarms/Busca-Palabras, finaliza el bucle infinito.






#traduccion a python
import os
import shutil

dir = "/sdcard/Alarms/Busca-Palabras"
dir2 = "/sdcard/backups/"

for root, dirs, files in os.walk(dir):
    for file in files:
        full_path = os.path.join(root, file)
        if os.path.getsize(full_path) == 0:
            backup_file = os.path.join(dir2, root.replace('/sdcard/Alarms/', ''), file)
            print(f"Vacio {full_path}")
            print(backup_file)
            #input()
            shutil.copy(backup_file, full_path)
