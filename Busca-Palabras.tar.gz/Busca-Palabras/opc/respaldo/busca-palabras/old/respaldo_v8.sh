#!/data/data/com.termux/files/usr/bin/bash
# 0️⃣ 1️⃣ 2️⃣ 3️⃣ 4️⃣ 5️⃣ 6️⃣ 7️⃣ 8️⃣ 9️⃣

export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export blanco='\033[37m'

# Función para manejar señales de interrupción (Ctrl+C, Ctrl+Z, etc.)
trap_handler() {
  #echo Hey, received signal : SIGINT 
  kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
  kill ${kill} >/dev/null 2>&1
  cd /sdcard/Alarms/
  rm -rf .compress.txt Busca-Palabras.tar.gz .not_int.txt >/dev/null 2>&1
  echo -e ""
  echo processo detinido...
  #echo "I will do some task here and exit"
  exit 1
}
# Asignar el manejador a las señales SIGINT (Ctrl+C) y SIGTSTP (Ctrl+Z)
trap 'trap_handler' SIGINT SIGTSTP

if [ `pidof proot` ]; then
    echo -e "Por favor no comprima el zip en distro termux-chroot\nDetenga el script de Busca-Palabras que ejecuta el servicio!!!"
    # pkill -f Menu-Busca-Palabras.sh
    usuario_termux=$(whoami)
    #killall -u $usuario_termux
    exit
fi

if [ -f $PREFIX/bin/pv ]; then
    echo "Existe" >/dev/null 2>&1
else
    echo "Instalando pv"
    pkg install pv >/dev/null 2>&1
fi
if [ -f $PREFIX/bin/zip ]; then
    echo "Ya existe" >/dev/null 2>&1
else
    echo -e "$verde[$blanco*$verde] ${blanco}Instalando Repositorios zip:"
    echo -e "" 
    echo -e "$verde[$blanco+$verde] ${blanco}Instalando zip"
    pkg install zip >/dev/null 2>&1
fi

vav_dos_com_rec() {

contador=0
dir="/sdcard/Alarms/Busca-Palabras"
while true; do
    if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
        find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
            echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        # echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        # exit
        break
    fi
    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}

vav_dos_com() {
mkdir -p /sdcard/Alarms/ >/dev/null 2>&1
contador=0
dir="/sdcard/Alarms/Busca-Palabras"
while true; do
    if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
        find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
            echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        # echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        # exit
        break
    fi

    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}



convert() {
    echo -e "$verde[$blanco*$verde] ${blanco}Convirtiendo archivos necesarios a dos2unix!$blanco"
    array=("/sdcard/Alarms/Busca-Palabras/opc/scp.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/voz.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/hack.sh"
            /sdcard/Alarms/Busca-Palabras/opc/config/*
           "/sdcard/Alarms/Busca-Palabras/opc/memory.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/scpscan.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/config-ta.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/team-droid.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/lista-server.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/multi_tunel_ver_url_global.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Actualizar-Busca-Palabras.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/deshabiltar_habiltar_apps_adb_v3.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/solution_groups_ubuntu/capturar_error.sh")

    #ns=($(for i in "${array[@]}"; do echo "${#i}:$i"; done | sort -n | cut -d':' -f2-))
    #echo "${ns[@]}"
    #read

    ns=($(for i in "${array[@]}"; do 
    nam=($(basename ${i}))
    name=$(echo -e  "${nam}")
    num=$(echo -n "${name}" | wc -c)
    echo -e "${num}:$name"
    done | sort -n -k2 | cut -d' ' -f1- && echo ""))

    size=${#ns[@]}
    ns=($(printf '%s\n' "${ns[@]}" | awk '{print length, $0}' | sort -n | cut -d " " -f2- && echo ""))
    count=0
    total=${#ns[@]}

    #for ((i=0; i<$size; i++)); do
    for i in "${ns[@]}"; do
        sleep .05
        ((count++))
        progress=$((count * 100 / total))
        #echo -e "${i}"
        name=$(echo "${i##*:}")
        dos2unix ${array} >/dev/null 2>&1
        #echo -e ""
        echo -ne "\r[${progress}%] ${name}"
    done #| sort -n | cut -d' ' -f1-
}



pack_proyect() {

    cd
    convert
    echo -e ""
    echo -e "$verde[$blanco+$verde] ${blanco}Archivos convertidos!\n"

    cd /sdcard/Alarms/
    rm -r Busca-Palabras.tar.gz >/dev/null 2>&1
    rm -rf .compress.txt >/dev/null 2>&1
    cd Busca-Palabras

    varX=$(find . -type d -iname "*" -print | cut -c 3- | wc -l)
    varY=$(find . -type f -iname "*" -print | cut -c 3- | wc -l)
    let suma=$varX+$varY

    cd ..

    tar -zcvf Busca-Palabras.tar.gz Busca-Palabras >/dev/null 2>&1 > .compress.txt &

    # $$ is a special variable that returns process ID of current  
    # process/script 
    echo -e "$verde[$blanco*$verde] ${blanco}Comprimiendo proyecto | process ID $$"

    sleep .5
    count=0
    total="$suma"
    start=`date +%s`
    while [[ "$count" -le "$total" ]]; do
        #sleep 0.1 # this is work
        count=$(wc -l .compress.txt | awk '{print $1}')
        cur=`date +%s`
        count=$(( $count + 1 -1 ))
        pd=$(( $count * 73 / $total ))
        runtime=$(( $cur-$start ))
        estremain=$(( ($runtime * $total / $count)-$runtime ))
        printf "\r%d.%d%% complete ($count of $total) - est %d:%0.2d remaining\e[K" $(( $count*100/$total )) $(( ($count*1000/$total)%10)) $(( $estremain/60 )) $(( $estremain%60 ))
        if [[ "$count" =~ "$total" ]]; then
            rm -rf .compress.txt
            kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
            kill ${kill} >/dev/null 2>&1
            break
        fi
    done

    if [ -e /sdcard/Alarms/Busca-Palabras.tar.gz ]; then 
        echo -e ""
        echo -e "$verde[$blanco+$verde] ${blanco}Compresion completada!\n"
        mkdir -p ~/backup-busca-Palabras
        cp -r /sdcard/Alarms/Busca-Palabras.tar.gz ~/backup-busca-Palabras
    else
        echo -e "Hubo un error en la compresion!"
        echo "Vuelva a intentar!"
        exit
    fi
}

peso() {
    peso=$(ls | grep /sdcard/Alarms/Busca-Palabras.tar.gz | du -h /sdcard/Alarms/Busca-Palabras.tar.gz | xargs echo -n | awk '{print $1}')
    peso1=$(ls | grep /sdcard/Alarms/Busca-Palabras.tar.gz | du -h /sdcard/Alarms/Busca-Palabras.tar.gz | xargs echo -n)    
    while [[ "$peso" =~ "" ]]; do
        peso=$(ls | grep /sdcard/Alarms/Busca-Palabras.tar.gz | du -h /sdcard/Alarms/Busca-Palabras.tar.gz | xargs echo -n | awk '{print $1}')
    done
    echo -e "$peso1\n"
}
vav_dos_com_rec
pack_proyect
vav_dos_com
peso

# Github Manager
[[ -d ".git" ]] && rm -rf ".git"

#  Instalamos `gh` en Termux si no está instalado
if ! command -v gh &>/dev/null; then
    pkg update -y && pkg install gh -y
fi

pregunta_github() {
    while true; do
        echo -e "\n"
        echo -e "1️⃣ Registrarme a Github."
        echo -e "2️⃣ Crear token de GitHub?"
        echo -e "3️⃣ Ingresar desde termux (gh auth login)"
        echo -e "4️⃣ Proseguir a ingresar token (Recomendado)"
        echo -e "5️⃣ Salir"
        read -rp "👉 Elige una opción (1/2/3/4/5): " opcion

        case "$opcion" in
            1|01)
                sleep 1.5
                echo -e "Abriendo GitHub para para registrarse."
                termux-open-url "https://github.com/login"
                ;;
            2|02)
                echo -e "🔗 Abrir GitHub para para crear un token de:\nfichas clásicas con permisos para repo y workflow. O todos..."
                echo -n "Presiona cualquier tecla para continuar...";read -n 1
                # Crea un nuevo token fichas clásicas con permisos para repo y workflow. O todos.
                termux-open-url "https://github.com/settings/tokens"
                echo -n "✅ Una vez creado y copiado el token, presiona cualquier tecla para continuar...";read -n 1
                ;;
            3|03)
                gh auth login
                ;;
            4|04)
                break
                ;;
            5|05)
                echo "👋 Saliendo..."
                exit 1
                ;;
            *)
                echo "⚠️ Opción inválida. Intenta nuevamente."
                ;;
        esac
    done
}

# Archivo de configuración de GitHub CLI
CONFIG_FILE="$HOME/.config/gh/hosts.yml"
SSH_KEY_PATH="$HOME/.ssh/id_rsa.pub"
KNOWN_HOSTS="$HOME/.ssh/known_hosts"
ssh_token() {

    # Verificar autenticación via gh auth login
    echo "🔍 Verificando autenticación en GitHub..."
    if gh auth status &>/dev/null; then
        echo "✅ Ya estás autenticado en GitHub."
        return 1
    fi

    echo "⚠️ No estás autenticado. Iniciando sesión automática..."

    # Verificar si ya hay un token válido
    if [[ -f "$CONFIG_FILE" ]] && grep -q "oauth_token" "$CONFIG_FILE"; then
        TOKEN=$(grep "oauth_token" "$CONFIG_FILE" | awk '{print $2}')
        if curl -s -H "Authorization: token $TOKEN" https://api.github.com/user | grep -q "login"; then
            echo "✅ Token válido encontrado, autenticando..."
            return 0
        else
            echo "❌ Token inválido o expirado. Eliminando credenciales..."
            rm -f "$CONFIG_FILE" >/dev/null
            pregunta_github
        fi
    fi
    
    pregunta_github
    # Pedir token si no hay uno válido
    echo "🔑 Ingresa tu token de GitHub (PAT):"
    read -sp "Token: " TOKEN
    echo

    # Asegurar que la clave SSH existe
    if [[ ! -f "$SSH_KEY_PATH" ]]; then
        echo "⚠️ No se encontró una clave SSH. Creando una nueva..."
        # ssh-keygen -t rsa -b 4096 -f "$HOME/.ssh/id_rsa" -N ""
        ssh-keygen -t rsa -b 4096 -f "$HOME/.ssh/id_rsa" -N "" -q
    fi

    # Agregar la clave SSH a GitHub automáticamente
    echo "✅ Subiendo clave SSH a GitHub..."
    SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
    curl -s -H "Authorization: token $TOKEN" \
         -X POST -d "{\"title\":\"$(hostname) SSH Key\",\"key\":\"$SSH_KEY_CONTENT\"}" \
         https://api.github.com/user/keys &> /dev/null

    # Guardar configuración en ~/.config/gh/hosts.yml
    mkdir -p "$(dirname "$CONFIG_FILE")"
    cat > "$CONFIG_FILE" <<EOF
github.com:
    user: $(whoami)
    oauth_token: $TOKEN
    git_protocol: ssh
EOF

    echo "✅ Configuración guardada, autenticando..."

    # Agregar la clave SSH de GitHub a la lista de hosts conocidos automáticamente
    echo "🔑 Agregando GitHub a los hosts conocidos..."
    ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null

    # Verificar conexión clave SSH con GitHub
    echo "🔗 Verificando conexión SSH con GitHub..."
    ssh -o StrictHostKeyChecking=no -T git@github.com &> /dev/null

    # Verificar si la autenticación fue exitosa
    if gh auth status &>/dev/null; then
        echo "✅ Autenticación SSH completada con éxito."
        return 0
    else
        echo "❌ Fallo en la autenticación. Intenta manualmente con 'gh auth login'."
        exit 1
    fi
}

ssh_token

ssh -T git@github.com &>/dev/null
if [ $? -ne 1 ]; then
    # Asegurar que la clave SSH existe
    if [[ -f "$SSH_KEY_PATH" ]]; then

        # Agregar la clave SSH a GitHub automáticamente
        echo "✅ Subiendo clave SSH a GitHub..."
        SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
        curl -s -H "Authorization: token $TOKEN" \
             -X POST -d "{\"title\":\"$(hostname) SSH Key\",\"key\":\"$SSH_KEY_CONTENT\"}" \
             https://api.github.com/user/keys &> /dev/null

        # Guardar configuración en ~/.config/gh/hosts.yml
        mkdir -p "$(dirname "$CONFIG_FILE")"
        cat > "$CONFIG_FILE" <<EOF
github.com:
    user: $(whoami)
    oauth_token: $TOKEN
    git_protocol: ssh
EOF

        echo "✅ Configuración guardada, autenticando..."

        # Agregar la clave SSH de GitHub a la lista de hosts conocidos automáticamente
        echo "🔑 Agregando GitHub a los hosts conocidos..."
        ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null

        # Verificar conexión clave SSH con GitHub
        echo "🔗 Verificando conexión SSH con GitHub..."
        ssh -o StrictHostKeyChecking=no -T git@github.com &> /dev/null
        pregunta_github
    fi
fi

# 2️⃣ Obtener nombre de usuario de GitHub
usuario_autenticado=$(ssh -T git@github.com 2>&1 | sed -n 's/Hi \([^ ]*\)!.*/\1/p')
usuario_autenticado1=$(gh api user 2>/dev/null | jq -r .login)
if [[ -n "$usuario_autenticado" ]];then
    usuario_github="$usuario_autenticado"
elif [[ -n "$usuario_autenticado1" ]];then 
    usuario_github="$usuario_autenticado1"
fi

: '
# 3️⃣ Bucle hasta que el usuario ingrese un nombre de repositorio o decida salir
# Función para validar respuestas
validar_respuesta() {
    local resp=$(echo "$1" | tr '[:upper:]' '[:lower:]')
    [[ "$resp" =~ ^(y|yes|s|si)$ ]] && return 0 || return 1
}
# Función para crear un nuevo repositorio
crear_repositorio() {
    echo "📂 Creando repositorio '$repo_name' en GitHub..."
    gh repo create "$repo_name" --public &>/dev/null
    echo "✅ Repositorio '$repo_name' creado correctamente."
}
: '
repo_name='Busca-Palabras'
# Bucle hasta que el usuario ingrese un nombre de repositorio válido
while [[ -z "$repo_name" ]]; do
    echo -e "\n📂 Ingresa el nombre del repositorio (obligatorio) o presiona 'q' para salir:"
    read -r repo_name

    if [[ "$repo_name" == "q" || "$repo_name" == "Q" ]]; then
        echo "🚪 Saliendo..."
        exit 0
    elif [[ -z "$repo_name" ]]; then
        continue
    fi

    : '
    echo -e "\n🚀Verificando repositorio '$repo_name'..."
    if gh repo view "$repo_name" &>/dev/null; then
        echo "⚠️ El repositorio '$repo_name' ya existe en GitHub."
        echo -e "¿Deseas actualizar la fuente de archivos? (si/no)"
        read -r respuesta
        if validar_respuesta "$respuesta"; then
            echo "✅ Actualizando archivos en '$repo_name'..."
            break
        else
            repo_name=""
            continue
        fi
    else
        echo -e "¿Deseas crear '$repo_name' como nuevo repositorio? (si/no)"
        read -r respuesta
        if validar_respuesta "$respuesta"; then
            crear_repositorio
            break
        else
            repo_name=""
            continue
        fi
    fi
    : '
done

# 4️⃣ Función para subir archivos al repositorio
subir_github() {
    cd ~/backup-busca-Palabras
   # 1️⃣ Detectar archivo comprimido automáticamente
    archivo_comprimido=$(ls | grep -E '\.(zip|tar\.gz|tar\.xz|tar\.bz2|7z|rar)$' | head -n 1)
    [[ -z "$archivo_comprimido" ]] && archivo_comprimido=$(ls | grep -E '\.(html|cpp|pdf|txt|py|sh)$' | head -n 1)
    # Asegurar que el README.md tenga un título
    if [ ! -f "README.md" ]; then
        # printf "# %s\n" "JalisFamily\nProyecto Busca-Palabras" > README.md
        printf '# %s\n%s\n' "JalisFamily" "Proyecto Busca-Palabras" > README.md
    fi
    git init &>/dev/null
    git add . &>/dev/null
    git reset -- sube_github_v1.sh  # Quita el archivo que no quieres subir del commit
    git config --global user.name "${usuario_github}" &>/dev/null
    # git config --global user.email "robertj.mezaurueta@gmail.com"
    # Verificar si el repositorio remoto ya está configurado
    if git remote | grep -q "origin" 2>/dev/null; then
        git remote set-url origin git@github.com:${usuario_github}/${repo_name}.git &>/dev/null
    else
        git remote add origin git@github.com:${usuario_github}/${repo_name}.git &>/dev/null
    fi
    git commit -m "first commit" &>/dev/null  
    git branch -M main &>/dev/null
    git push --force origin main
}

echo "⬆️ Subiendo archivos al repositorio..."
subir_github

echo -e "✅ Repositorio completo en:\ngit clone https://github.com/${usuario_github}/${repo_name}"
if [[ -n "$archivo_comprimido" ]]; then
    # echo -e "✅ Archivo específico en:\nwget https://raw.githubusercontent.com/${usuario_github}/${repo_name}/main/${archivo_comprimido}"
    echo -e "✅ Archivo específico en:\nwget -O ${archivo_comprimido} https://raw.githubusercontent.com/${usuario_github}/${repo_name}/main/${archivo_comprimido}"
fi


: '
# Si deseas que gh almacene las credenciales en lugar de usar la variable de entorno, debes eliminar el token de la sesión actual antes de ejecutar gh auth login nuevamente:
bash
unset GH_TOKEN GITHUB_TOKEN
export GH_TOKEN=
export GITHUB_TOKEN=
rm -rf ~/.config/gh/hosts.yml >/dev/null
rm -rf ~/.ssh/* >/dev/null
gh auth logout >/dev/null
sed -i '/export GH_TOKEN/d' ~/.bashrc ~/.profile ~/.bash_profile >/dev/null
source ~/.bashrc  # Recarga la configuración >/dev/null

# Verifica que ya no existan 
env | grep GH_TOKEN
env | grep GITHUB_TOKEN

gh auth login
# Esto te permitirá iniciar sesión manualmente y almacenar las credenciales en el sistema, en lugar de depender de la variable de entorno.

# Desde la línea de comandos (GitHub CLI) puedes eliminar un repositorio específico 
# Si tienes instalada la GitHub CLI (gh), usa el siguiente comando:
gh repo delete RobertNissan/unzip-7z --confirm


# copiar algo de un texto 
cat ~/.ssh/id_rsa.pub | termux-clipboard-set

: '
