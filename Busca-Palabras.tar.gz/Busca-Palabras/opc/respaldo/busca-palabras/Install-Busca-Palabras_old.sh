#!/bin/bash

# Fecha inicio 01/Sep/2021
# actualizado 26/Jun/2024
# Por: @robert_nissan

# COLORES
rojo='\e[1m\e[31m'
verde='\e[1m\e[32m'
white="\e[1;37m\e[0m"
amarillo='\e[1m\e[33m'
azulcielo='\e[1m\e[36m'
COLOR_RESET="\033[0m"
echo -e ""$verde"=-=-=-=(PERMISOS DE ALMACENAMIENTO)=-=-=-="
# Verificar si los permisos de almacenamiento ya han sido concedidos
# Ruta de prueba
prueba_ruta="/sdcard/.prueba_permiso_termux.txt"
# Verificar el estado del almacenamiento
verificar_almacenamiento() {
    if [ -d "/sdcard/" ]; then
        # Intentar crear un archivo para verificar los permisos
        echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
        if [ -f "$prueba_ruta" ]; then
            echo -e "${verde}Los permisos de almacenamiento ya han sido concedidos.${COLOR_RESET}"
            rm "$prueba_ruta"  # Eliminar el archivo de prueba
            return 0
        else
            echo -e "${rojo}El directorio existe, pero los permisos de escritura no están disponibles.${COLOR_RESET}"
        fi
    fi

    # Si llegamos aquí, es porque no se tienen los permisos
    echo -e "${amarillo}Concediendo permisos de almacenamiento...${COLOR_RESET}"
    termux-setup-storage
    sleep 5  # Esperar un momento para permitir que se concedan los permisos

    # Verificar de nuevo los permisos
    if [ -d "/sdcard/" ]; then
        echo "Prueba de permisos" > "$prueba_ruta" 2>/dev/null
        if [ -f "$prueba_ruta" ]; then
            echo -e "${verde}Permisos de almacenamiento concedidos correctamente.${COLOR_RESET}"
            rm "$prueba_ruta"  # Eliminar el archivo de prueba
            return 0
        else
            echo -e "${rojo}No se pudieron conceder los permisos de almacenamiento. Asegúrate de aceptar la solicitud de permisos.${COLOR_RESET}"
            return 1
        fi
    else
        echo -e "${rojo}El directorio de almacenamiento no está disponible. Asegúrate de aceptar la solicitud de permisos.${COLOR_RESET}"
        return 1
    fi
}

# Ejecutar la función
verificar_almacenamiento
echo -e ""$amarillo"<>=<>=<>=INSTALANDO DEPENDENCIAS=<>=<>=<>${COLOR_RESET}";sleep 2;

z=""
impreso="No hay conexión a Internet"

con_act() {
    impreso="Conexión a Internet activa"
}

rec_int() {
    while ! curl -m 5 -s --head http://www.google.com | grep "200 OK" > /dev/null; do
        if [ "$impreso" != "No hay conexión a Internet" ]; then
            con_act
            break
        fi
    done
    impreso="Conexión a Internet activa"
}

verif_inter() {
    while true; do
        if [ "$impreso" == "Conexión a Internet activa" ]; then
            break
        elif curl -m 5 -s --head http://www.google.com | grep "200 OK" > /dev/null; then
            break
        else
            echo "No hay conexión a Internet"
            echo "No se pudo instalar $pkg"
            impreso="No hay conexión a Internet"
            rec_int
        fi
    done
}

pkgs=("jq" "bc" "pv" "adb" "tsu" "fish" "proot" "rsync" "python" "expect" "crunch" "iproute2" "busybox" "termux-api" "proot-distro" "libqrencode" "silversearcher-ag")
count=0
for pkg in "${pkgs[@]}"; do
    count=$((count + 1))
    # printf "%d - " "$count"
    printf "%02d - " "$count"
    
    case "$pkg" in
    "jq")
        if [ -x "$PREFIX/bin/jq" ]; then
            echo -e "${verde}jq instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando jq${COLOR_RESET}"
            verif_inter
            pkg install jq -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/jq" ]; then
                echo -e "  >  ${verde}jq instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "bc")
        if [ -x "$PREFIX/bin/bc" ]; then
            echo -e "${verde}bc instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando bc${COLOR_RESET}"
            verif_inter
            pkg install bc -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/bc" ]; then
                echo -e "  >  ${verde}bc instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "pv")
        if [ -x "$PREFIX/bin/pv" ]; then
            echo -e "${verde}pv instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando pv${COLOR_RESET}"
            verif_inter
            pkg install pv >/dev/null 2>&1
            if [ -x "$PREFIX/bin/pv" ]; then
                echo -e "  >  ${verde}pv instalado${COLOR_RESET}"
            fi
        fi
        ;;
     "adb")
        if [ -x "$PREFIX/bin/adb" ]; then
            echo -e "${verde}adb instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando adb${COLOR_RESET}"
            verif_inter
            pkg install android-tools -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/adb" ]; then
                echo -e "  >  ${verde}adb-tools instalado${COLOR_RESET}"
            fi
        fi
        ;;   
    "tsu")
        if [ -x "$PREFIX/bin/tsu" ]; then
            echo -e "${verde}tsu instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando tsu${COLOR_RESET}"
            verif_inter
            apt install tsu -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/tsu" ]; then
                echo -e "  >  ${verde}tsu instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "fish")
        if [ -x "$PREFIX/bin/fish" ]; then
            echo -e "${verde}fish instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando fish${COLOR_RESET}"
            verif_inter
            apt install fish -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/fish" ]; then
                echo -e "  >  ${verde}fish instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "proot")
        if [ -x "$PREFIX/bin/proot" ]; then
            echo -e "${verde}proot instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando proot${COLOR_RESET}"
            verif_inter
            apt install proot -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/proot" ]; then
                echo -e "  >  ${verde}proot instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "rsync")
        if [ -x "$PREFIX/bin/rsync" ]; then
            echo -e "${verde}rsync instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando rsync${COLOR_RESET}"
            verif_inter
            apt install rsync -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/rsync" ]; then
                echo -e "  >  ${verde}rsync instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "python")
        if [ -x "$PREFIX/bin/python" ]; then
            echo -e "${verde}python instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando python${COLOR_RESET}"
            verif_inter
            apt install python -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/python" ]; then
                echo -e "  >  ${verde}python instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "expect")
        if [ -x "$PREFIX/bin/expect" ]; then
            echo -e "${verde}expect instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando expect${COLOR_RESET}"
            verif_inter
            apt-get -y install expect >/dev/null 2>&1
            if [ -x "$PREFIX/bin/expect" ]; then
                echo -e "  >  ${verde}expect instalado${COLOR_RESET}"
            fi
        fi
        ;;       
    "crunch")
        if [ -x "$PREFIX/bin/crunch" ]; then
            echo -e "${verde}crunch instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando crunch${COLOR_RESET}"
            verif_inter
            pkg install crunch >/dev/null 2>&1
            if [ -x "$PREFIX/bin/crunch" ]; then
                echo -e "  >  ${verde}crunch instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "iproute2")
        if [ -x "$PREFIX/share/doc/iproute2" ]; then
            echo -e "${verde}iproute2 instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando iproute2${COLOR_RESET}"
            verif_inter
            pkg install iproute2 >/dev/null 2>&1
            if [ -x "$PREFIX/share/doc/iproute2" ]; then
                echo -e "  >  ${verde}iproute2 instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "busybox")
        if [ -x "$PREFIX/bin/busybox" ]; then
            echo -e "${verde}busybox instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando busybox${COLOR_RESET}"
            verif_inter
            pkg install busybox >/dev/null 2>&1
            if [ -x "$PREFIX/bin/busybox" ]; then
                echo -e "  >  ${verde}busybox instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "termux-api")
        if dpkg -l | grep -q termux-api; then
            echo -e "${verde}termux-api instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando termux-api${COLOR_RESET}"
            verif_inter
            pkg install termux-api >/dev/null 2>&1
            if dpkg -l | grep -q termux-api; then
                echo -e "  >  ${verde}termux-api instalado${COLOR_RESET}"
            fi
        fi
        ;;
    "proot-distro")
        if pkg list-installed 2>/dev/null | grep -q "proot-distro"; then
            echo -e "${verde}proot-distro instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando proot-distro${COLOR_RESET}"
            verif_inter
            pkg install proot-distro -y >/dev/null 2>&1
            if [ $? -eq 0 ]; then
                echo -e "  >  ${verde}proot-distro instalado${COLOR_RESET}"
            else
                echo -e "\e[31mError durante la instalación de proot-distro.\e[0m"
            fi
        fi
        ;;
    "libqrencode")
        if [ -x "$PREFIX/share/doc/libqrencode" ]; then
            echo -e "${verde}libqrencode instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando libqrencode${COLOR_RESET}"
            verif_inter
            pkg install libqrencode -y >/dev/null 2>&1
            if [ -x "$PREFIX/share/doc/libqrencode" ]; then
                echo -e "  >  ${verde}libqrencode instalado${COLOR_RESET}"
            fi
        fi
        ;;     
    "silversearcher-ag")
        if [ -x "$PREFIX/share/doc/silversearcher-ag" ]; then
            echo -e "${verde}silversearcher-ag instalado${COLOR_RESET}"
        else
            echo -e "${amarillo}Instalando silversearcher-ag${COLOR_RESET}"
            verif_inter
            pkg install silversearcher-ag >/dev/null 2>&1
            if [ -x "$PREFIX/share/doc/silversearcher-ag" ]; then
                echo -e "  >  ${verde}silversearcher-ag instalado${COLOR_RESET}"
            fi
        fi
        ;; 
    *)
        echo "Paquete desconocido: $pkg"
        ;;
    esac
 
done

if [ "$count" -eq "${#pkgs[@]}" ]; then
    echo "Todos los paquetes instalados"
fi

# Descomprimir con tar
# tar -xvzf archivo-comprimido.tar.gz

archivo='Busca-Palabras.tar.gz'
mkdir -p /sdcard/backups
if [ ! -f "$archivo" ]; then
    echo -e "";echo -e ""$white"   ••(DESCARGANDO SCRIPT BUSCA-PALABRAS)••    ";sleep 1.5;wget https://www.dropbox.com/s/dat7yzgquuhe3og/Busca-Palabras.tar.gz?dl=0;mv Busca-Palabras.tar.gz?dl=0 Busca-Palabras.tar.gz;tar -xvzf Busca-Palabras.tar.gz;rm -r Busca-Palabras.tar.gz;cp -r Busca-Palabras /sdcard/backups;cd Busca-Palabras;chmod +x Menu-Busca-Palabras.sh;dos2unix Menu-Busca-Palabras.sh;chmod +x spawn;bash Menu-Busca-Palabras.sh;cd ${HOME}/Busca-Palabras/;fish
else
    tar -xvzf Busca-Palabras.tar.gz;rm -r Busca-Palabras.tar.gz;cp -r Busca-Palabras /sdcard/backups;cd Busca-Palabras;chmod +x Menu-Busca-Palabras.sh;dos2unix Menu-Busca-Palabras.sh;chmod +x spawn;bash Menu-Busca-Palabras.sh;cd ${HOME}/Busca-Palabras/;fish
fi 