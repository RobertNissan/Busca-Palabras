# ?repositorios? ?repositorios que uso?
#!/bin/bash

# Fecha inicio 01/09/2021
# actualizado 01/10/2023
# Por: @robert_nissan

# COLORES
rojo='\e[1m\e[31m'
verde='\e[1m\e[32m'
white="\e[1;37m\e[0m"
amarillo='\e[1m\e[33m'
azulcielo='\e[1m\e[36m'
echo -e ""
echo -e ""$amarillo"<>=<>=<>=INSTALANDO REPOSITORIOS=<>=<>=<>"
sleep 1

z=""
impreso="No hay conexion a Internet"

con_act() {
    impreso="Conexion a Internet activa"
}

rec_int() {
    while ! curl -m 5 -s --head http://www.google.com | grep "200 OK" > /dev/null; do
        if [ "$impreso" != "No hay conexion a Internet" ]; then
            con_act
            break
        fi
    done
    impreso="Conexion a Internet activa"
}

verif_inter() {
    while true; do
        if [ "$impreso" == "Conexion a Internet activa" ]; then
            break
        elif curl -m 5 -s --head http://www.google.com | grep "200 OK" > /dev/null; then
            break
        else
            echo "No hay conexion a Internet"
            echo "No se pudo instalar $pkg"
            impreso="No hay conexion a Internet"
            rec_int
        fi
    done
}

pkgs=("jq" "pv" "adb" "tsu" "php" "fish" "nmap" "proot" "rsync" "expect" "iproute2")
count=0
for pkg in "${pkgs[@]}"; do
    count=$((count + 1))
    # printf "%d - " "$count"
    printf "%03d - %s" "$count"
    
    case "$pkg" in
    "jq")
        if [ -x "$PREFIX/bin/jq" ]; then
            echo "jq instalado"
        else
            echo "Instalando jq"
            verif_inter
            pkg install jq -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/jq" ]; then
                echo -e "  > jq instalado"
            fi
        fi
        ;;
    "pv")
        if [ -x "$PREFIX/bin/pv" ]; then
            echo "pv instalado"
        else
            echo "Instalando pv"
            verif_inter
            pkg install pv >/dev/null 2>&1
            if [ -x "$PREFIX/bin/pv" ]; then
                echo -e "  > pv instalado"
            fi
        fi
        ;;
     "adb")
        if [ -x "$PREFIX/bin/adb" ]; then
            echo "adb instalado"
        else
            echo "Instalando adb"
            verif_inter
            pkg install android-tools -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/adb" ]; then
                echo -e "  > adb-tools instalado"
            fi
        fi
        ;;   
    "tsu")
        if [ -x "$PREFIX/bin/tsu" ]; then
            echo "tsu instalado"
        else
            echo "Instalando tsu"
            verif_inter
            apt install tsu -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/tsu" ]; then
                echo -e "  > tsu instalado"
            fi
        fi
        ;;
    "php")
        if [ -x "$PREFIX/bin/php" ]; then
            echo "php instalado"
        else
            echo "Instalando php"
            verif_inter
            pkg install php -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/php" ]; then
                echo -e "  > php instalado"
            fi
        fi
        ;;
    "fish")
        if [ -x "$PREFIX/bin/fish" ]; then
            echo "fish instalado"
        else
            echo "Instalando fish"
            verif_inter
            apt install fish -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/fish" ]; then
                echo -e "  > fish instalado"
            fi
        fi
        ;;
    "nmap")
        if [ -x "$PREFIX/bin/nmap" ]; then
            echo "nmap instalado"
        else
            echo "Instalando nmap"
            verif_inter
            pkg install nmap -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/nmap" ]; then
                echo -e "  > nmap instalado"
            fi
        fi
        ;;
    "proot")
        if [ -x "$PREFIX/bin/proot" ]; then
            echo "proot instalado"
        else
            echo "Instalando proot"
            verif_inter
            apt install proot -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/proot" ]; then
                echo -e "  > proot instalado"
            fi
        fi
        ;;
    "rsync")
        if [ -x "$PREFIX/bin/rsync" ]; then
            echo "rsync instalado"
        else
            echo "Instalando rsync"
            verif_inter
            apt install rsync -y >/dev/null 2>&1
            if [ -x "$PREFIX/bin/rsync" ]; then
                echo -e "  > rsync instalado"
            fi
        fi
        ;;
    "expect")
        if [ -x "$PREFIX/bin/expect" ]; then
            echo "expect instalado"
        else
            echo "Instalando expect"
            verif_inter
            apt-get -y install expect >/dev/null 2>&1
            if [ -x "$PREFIX/bin/expect" ]; then
                echo -e "  > expect instalado"
            fi
        fi
        ;;
    "iproute2")
        if [ -x "$PREFIX/share/doc/iproute2" ]; then
            echo "iproute2 instalado"
        else
            echo "Instalando iproute2"
            verif_inter
            pkg install iproute2 >/dev/null 2>&1
            if [ -x "$PREFIX/bin/iproute2" ]; then
                echo -e "  > iproute2 instalado"
            fi
        fi
        ;; 
    *)
        echo "Paquete desconocido: $pkg"
        ;;
    esac
 
done

if [ "$count" -eq "${#pkgs[@]}" ]; then
    echo "Todos los paquetes instalados"
fi

# Descomprimir con tar
# tar -xvzf archivo-comprimido.tar.gz
# Este script necesita dos2unix
