#!/data/data/com.termux/files/usr/bin/bash
# 0️⃣ 1️⃣ 2️⃣ 3️⃣ 4️⃣ 5️⃣ 6️⃣ 7️⃣ 8️⃣ 9️⃣

export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export blanco='\033[37m'

# Verificar y eliminar el archivo de bloqueo si existe
LOCKFILE="/data/data/com.termux/files/home/.respaldo.lock"
if [ -f "$LOCKFILE" ]; then
    echo -e "${amarillo}⚠️ Se detectó un archivo de bloqueo de un proceso anterior. Eliminando...${blanco}"
    rm -f "$LOCKFILE"
fi
# Función para manejar señales de interrupción (Ctrl+C, Ctrl+Z, etc.)
trap_handler() {
  # Eliminar archivo de bloqueo
  rm -f $LOCKFILE
 
  #echo Hey, received signal : SIGINT 
  kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
  kill ${kill} >/dev/null 2>&1
  cd /sdcard/Alarms/
  rm -rf .compress.txt Busca-Palabras.tar.gz .not_int.txt >/dev/null 2>&1
  echo -e ""
  echo processo detinido...
  #echo "I will do some task here and exit"
  exit 1
}
# Asignar el manejador a las señales SIGINT (Ctrl+C) y SIGTSTP (Ctrl+Z)
trap 'trap_handler' SIGINT SIGTSTP
# trap "rm -f $LOCKFILE; exit" INT TERM EXIT

if [[ ! -d /sdcard/Alarms/Busca-Palabras ]]; then
    echo -e "No tienes el proyecto para editar.\nProcedemos a descargar"
    tamanio=$(wget --spider --server-response "https://raw.githubusercontent.com/RobertNissan/Busca-Palabras/main/Busca-Palabras.tar.gz" 2>&1 | 
    awk '/Length:/ {print $2}' | head -n 1 | 
    awk '{
        size = $1;
        if (size >= 1073741824) printf "%.2fGB\n", size / 1073741824;
        else if (size >= 1048576) printf "%.2fMB\n", size / 1048576;
        else if (size >= 1024) printf "%.2fKB\n", size / 1024;
        else printf "%dB\n", size;
    }')
    tar_extrator_progress() {
        total=$(tar -tzf Busca-Palabras.tar.gz | wc -l)
        count=0
        tar -xvzf Busca-Palabras.tar.gz | while read -r line; do
            count=$((count + 1))
            percent=$((count * 100 / total))
            echo -ne "Progreso: $percent% [$count/$total] archivos extraídos...\r"
        done
        echo -e "\nExtracción completada."
        # echo "Actualización completa!!!."
        sleep 2
    }
    archivo='Busca-Palabras.tar.gz'
    mkdir -p /sdcard/Alarms
    cd /sdcard/Alarms
    if [ ! -f "$archivo" ]; then
        echo "Tamaño del archivo: ${tamanio}"
        wget --no-check-certificate --quiet --show-progress -O "${archivo}" "https://raw.githubusercontent.com/RobertNissan/Busca-Palabras/main/${archivo}"
        tar_extrator_progress
        rm -r "${archivo}"
    else
        tar_extrator_progress
       rm -r "${archivo}"
   fi
   echo -e "Proyecto a editar descargado.\nAhora ya puedes editar y hacer backup!!!."
   exit
fi

# Ajustar prioridad si proot está activo
if pidof proot >/dev/null 2>&1; then
    echo -e "${amarillo}⚠️ Proot detectado. Ajustando prioridad del proceso...${blanco}"
    renice -n 19 -p $$ >/dev/null 2>&1
    ionice -c 3 -p $$ >/dev/null 2>&1
fi


LOCKFILE="/data/data/com.termux/files/home/.respaldo.lock"

# Verificar si ya hay otro proceso ejecutando el script
if [ -f "$LOCKFILE" ]; then
    echo -e "${rojo}❌ Ya hay un proceso de respaldo en ejecución${blanco}"
    exit 1
fi

# Crear lockfile
echo $$ > "$LOCKFILE"
trap "rm -f $LOCKFILE; exit" INT TERM EXIT

if pidof proot >/dev/null 2>&1; then
    echo -e "${amarillo}⚠️ Sesión proot detectada. Ajustando prioridad del proceso...${blanco}"
    renice -n 19 -p $$ >/dev/null 2>&1
    ionice -c 3 -p $$ >/dev/null 2>&1
fi

#######FUNCIONES_PAQUETES#######
source ~/Busca-Palabras/config/pack_repo
paquetes_termux zip pv
#######FIN_FUNCIONES_PAQUETES#######

# =================== Internet check ===================
#!/usr/bin/env bash
# verificar_internet.sh
# Versión: robusta - chequea ping, DNS y HTTP con reintentos y detecciones

PING_TIMEOUT_DEFAULT=2      # segundos por intento
ATTEMPTS_DEFAULT=2          # intentos completos (cada intento prueba ping+http)
SLEEP_BETWEEN=1             # segundos entre intentos

# Targets y URLs de comprobación (varios para resiliencia)
PING_TARGETS=( "1.1.1.1" "8.8.8.8" "google.com" )
HTTP_URLS=( "https://cloudflare.com/generate_204" \
            "http://clients3.google.com/generate_204" \
            "http://example.com/" )

# Helper: ejecutar con timeout si existe 'timeout'
_run_with_timeout() {
    local t="$1"; shift
    if command -v timeout >/dev/null 2>&1; then
        timeout "$t" "$@"
    else
        "$@"
    fi
}

# Main function
verificar_internet() {
    local timeout="${1:-$PING_TIMEOUT_DEFAULT}"
    local attempts="${2:-$ATTEMPTS_DEFAULT}"
    local i j host url rc

    # Detectar herramientas
    local has_curl=false has_wget=false has_getent=false
    command -v curl >/dev/null 2>&1 && has_curl=true
    command -v wget >/dev/null 2>&1 && has_wget=true
    command -v getent >/dev/null 2>&1 && has_getent=true

    for ((i=1; i<=attempts; i++)); do
        # 1) Chequeo rápido por ping a varios targets (útil si ICMP permitido)
        for host in "${PING_TARGETS[@]}"; do
            # limitamos el tiempo total usando timeout (si está disponible)
            if _run_with_timeout "$timeout" ping -c 1 -W "$timeout" "$host" >/dev/null 2>&1; then
                echo 'true'
                return 0
            fi
        done

        # 2) Resolución DNS (al menos confirmar que un nombre resuelve)
        if [ "$has_getent" = true ]; then
            if getent hosts example.com >/dev/null 2>&1; then
                echo 'true'
                return 0
            fi
        else
            # alternativa simple con nslookup/host/dig si getent no está
            if command -v nslookup >/dev/null 2>&1; then
                if nslookup example.com >/dev/null 2>&1; then
                    echo 'true'
                    return 0
                fi
            elif command -v host >/dev/null 2>&1; then
                if host example.com >/dev/null 2>&1; then
                    echo 'true'
                    return 0
                fi
            fi
        fi

        # 3) Petición HTTP(S) — esto detecta si hay portal cautivo o proxys que responden.
        if [ "$has_curl" = true ]; then
            for url in "${HTTP_URLS[@]}"; do
                # -s silent, -S show errors, -I head, -m max-time, -w http_code
                http_code=$(curl -s -S -I --max-time "$timeout" -o /dev/null -w "%{http_code}" "$url" 2>/dev/null || echo "")
                # generar_204 devuelve 204 cuando no hay interceptación; 200 también OK
                if [ "$http_code" = "204" ] || [ "$http_code" = "200" ]; then
                    echo 'true'
                    return 0
                fi
            done
        elif [ "$has_wget" = true ]; then
            for url in "${HTTP_URLS[@]}"; do
                # --spider no descarga; -T timeout
                if wget --spider -q --timeout="$timeout" "$url" >/dev/null 2>&1; then
                    echo 'true'
                    return 0
                fi
            done
        fi

        # Si llegamos hasta aquí, intento fallido -> esperar y reintentar (si quedan intentos)
        if [ "$i" -lt "$attempts" ]; then
            sleep "$SLEEP_BETWEEN"
        fi
    done

    # Si todos los intentos fallaron
    echo 'false'
    return 1
}

# Uso rápido:
# echo "verificar_internet: $(verificar_internet)"
# O en condicional:
# if verificar_internet; then echo "OK"; else echo "NO"; fi

vav_dos_com_rec() {

    contador=0
    dir="/sdcard/Alarms/Busca-Palabras"
    while true; do
        if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
            find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
                echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        # echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        # exit
        break
    fi
    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}

vav_dos_com() {
mkdir -p /sdcard/Alarms/ >/dev/null 2>&1
contador=0
dir="/sdcard/Alarms/Busca-Palabras"
while true; do
    if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
        find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
            echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        # echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        # exit
        break
    fi

    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}



convert() {
    echo -e "$verde[$blanco*$verde] ${blanco}Convirtiendo archivos necesarios a dos2unix!$blanco"

    array=("/sdcard/Alarms/Busca-Palabras/opc/scp.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/voz.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/hack.sh"
           "/sdcard/Alarms/Busca-Palabras/config/"*
           "/sdcard/Alarms/Busca-Palabras/opc/config/"*
           "/sdcard/Alarms/Busca-Palabras/opc/memory.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/scpscan.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/config-ta.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/lista-server.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/team-droid.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/multi_tunel_ver_url_global.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Actualizar-Busca-Palabras.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/deshabiltar_habiltar_apps_adb_v3.sh"
           "/sdcard/Alarms/Busca-Palabras/opc/solution_groups_ubuntu/capturar_error.sh")

    ns=()
    archivos_filtrados=()

    # Filtrar solo archivos regulares
    for i in "${array[@]}"; do
        if [ -f "$i" ]; then
            archivos_filtrados+=("$i")
            nam=$(basename "$i")
            num=$(echo -n "$nam" | wc -c)
            ns+=("${num}:${nam}")
        fi
    done

    # Ordenar `ns`
    IFS=$'\n' ns=($(printf "%s\n" "${ns[@]}" | sort -n -k2))
    total=${#archivos_filtrados[@]}
    count=0

    for archivo in "${archivos_filtrados[@]}"; do
        sleep .01
        ((count++))
        progress=$((count * 100 / total))
        nombre=$(basename "$archivo")

        # Verifica si el archivo tiene caracteres de retorno de carro antes de convertir
        if [[ -f "$archivo" ]] && grep -Iq $'\r' "$archivo"; then
            dos2unix "$archivo" >/dev/null 2>&1
        else
            echo -e "\nNo es necesario: $archivo" >/dev/null
        fi

        echo -ne "\r\033[K[${progress}%] ${nombre}"
    done
    echo -ne "\r\033[K[${progress}%] Completado"
}


pack_proyect() {
    
    cd
    convert
    echo -e ""
    echo -e "$verde[$blanco+$verde] ${blanco}Archivos convertidos!\n"

    cd /sdcard/Alarms/
    rm -r Busca-Palabras.tar.gz >/dev/null 2>&1
    rm -rf .compress.txt >/dev/null 2>&1
    cd Busca-Palabras

    varX=$(find . -type d -iname "*" -print | cut -c 3- | wc -l)
    varY=$(find . -type f -iname "*" -print | cut -c 3- | wc -l)
    let suma=$varX+$varY

    cd ..

    # Ajustar prioridad de tar si proot está activo
    if pidof proot >/dev/null 2>&1; then
        nice -n 19 ionice -c 3 tar -zcvf Busca-Palabras.tar.gz Busca-Palabras > .compress.txt 2>&1 &
    else
        tar -zcvf Busca-Palabras.tar.gz Busca-Palabras >/dev/null 2>&1 > .compress.txt &
    fi

    # $$ is a special variable that returns process ID of current  
    # process/script 
    echo -e "$verde[$blanco*$verde] ${blanco}Comprimiendo proyecto | process ID $$"

    peso() {
        local archivo="/sdcard/Alarms/Busca-Palabras.tar.gz"

        # Esperar hasta que el archivo exista
        while [[ ! -f "$archivo" ]]; do
            sleep 1
        done

        # Obtener tamaño en formato legible (humano)
        peso_humano=$(du -h "$archivo" | awk '{print $1}')

        # Obtener tamaño con formato automático
        peso1=$(du -sb "$archivo" | awk '{
            size = $1;
            if (size >= 1073741824) printf "%.2fGB\n", size / 1073741824;
            else if (size >= 1048576) printf "%.2fMB\n", size / 1048576;
            else if (size >= 1024) printf "%.2fKB\n", size / 1024;
            else printf "%dB\n", size;
        }')

        echo -e "$peso1\n"
    }
    

    sleep .5
    count=0
    total="$suma"
    start=`date +%s`
    while [[ "$count" -le "$total" ]]; do
        #sleep 0.1 # this is work
        count=$(wc -l .compress.txt | awk '{print $1}')
        cur=`date +%s`
        count=$(( $count + 1 -1 ))
        pd=$(( $count * 73 / $total ))
        runtime=$(( $cur-$start ))
        estremain=$(( ($runtime * $total / $count)-$runtime ))
        printf "\r%d.%d%% complete ($count of $total) - est %d:%0.2d remaining\e[K" $(( $count*100/$total )) $(( ($count*1000/$total)%10)) $(( $estremain/60 )) $(( $estremain%60 ))
        if [[ "$count" =~ "$total" ]]; then
            rm -rf .compress.txt
            kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
            kill ${kill} >/dev/null 2>&1
            break
        fi
    done

    sleep 1
    if [[ -e /sdcard/Alarms/Busca-Palabras.tar.gz ]]; then 
        echo -e ""
        echo -e "$verde[$blanco+$verde] ${blanco}Compresion completada! $(peso)\n/sdcard/Alarms/Busca-Palabras.tar.gz\n"
        mkdir -p ~/backup-busca-Palabras
        [[ -f ~/backup-busca-Palabras ]] && rm -rf ~/backup-busca-Palabras
        sleep 0.5
        cp -r /sdcard/Alarms/Busca-Palabras.tar.gz ~/backup-busca-Palabras
        # echo "Copiado"
    else
        echo -e "Hubo un error en la compresion!"
        echo "Vuelva a intentar!"
        exit
    fi
}


vav_dos_com_rec
pack_proyect
vav_dos_com

# Github Manager
#  Instalamos `gh` en Termux si no está instalado
if ! command -v gh &>/dev/null; then
    pkg update -y && pkg install gh -y
fi

pregunta_github() {
    while true; do
        echo -e "\n"
        echo -e "1️⃣ Registrarme a Github."
        echo -e "2️⃣ Crear token de GitHub?"
        echo -e "3️⃣ Ingresar desde termux (gh auth login)"
        echo -e "4️⃣ Proseguir a ingresar token (Recomendado)"
        echo -e "5️⃣ Salir"
        read -rp "👉 Elige una opción (1/2/3/4/5): " opcion

        case "$opcion" in
            1|01)
                sleep 1.5
                echo -e "Abriendo GitHub para para registrarse."
                termux-open-url "https://github.com/login"
                ;;
            2|02)
                echo -e "🔗 Abrir GitHub para para crear un token de:\nfichas clásicas con permisos para repo y workflow. O todos..."
                echo -n "Presiona cualquier tecla para continuar...";read -n 1
                # Crea un nuevo token fichas clásicas con permisos para repo y workflow. O todos.
                termux-open-url "https://github.com/settings/tokens"
                echo -n "✅ Una vez creado y copiado el token, presiona cualquier tecla para continuar...";read -n 1
                ;;
            3|03)
                gh auth login
                ;;
            4|04)
                break
                ;;
            5|05)
                echo "👋 Saliendo..."
                exit 1
                ;;
            *)
                echo "⚠️ Opción inválida. Intenta nuevamente."
                ;;
        esac
    done
}

# Archivo de configuración de GitHub CLI
CONFIG_FILE="$HOME/.config/gh/hosts.yml"
SSH_KEY_PATH="$HOME/.ssh/id_rsa.pub"
KNOWN_HOSTS="$HOME/.ssh/known_hosts"
ssh_token() {
    echo "🔍 Verificando autenticación en GitHub..."
    # if $(verificar_internet) == 'true'; then
    if [ "$(verificar_internet)" = "true" ]; then
        # Verificar si ya hay un token válido en el archivo de configuración
        if [[ -f "$CONFIG_FILE" ]] && grep -q "oauth_token" "$CONFIG_FILE"; then
            TOKEN=$(grep "oauth_token" "$CONFIG_FILE" | awk '{print $2}')
            if curl -s -H "Authorization: token $TOKEN" https://api.github.com/user | grep -q "login"; then
                echo "✅ Token válido encontrado."
                return 0
            else
                echo "❌ Token inválido o expirado. Eliminando credenciales..."
                rm -f "$CONFIG_FILE" >/dev/null 2>&1
            fi
        fi
        
        # Si gh auth status falla o no hay token válido, mostrar menú
        if ! gh auth status &>/dev/null; then
            echo "⚠️ No estás autenticado. Iniciando sesión..."
            pregunta_github
        else
            echo "✅ Ya estás autenticado en GitHub."
            return 0
        fi
    else
        echo -e 'No hay conexión a internet\n'
        exit
    fi
    # Pedir token si no hay uno válido
    echo "🔑 Ingresa tu token de GitHub (PAT):"
    read -sp "Token: " TOKEN
    echo

    # Validar el token antes de continuar
    if ! curl -s -H "Authorization: token $TOKEN" https://api.github.com/user | grep -q "login"; then
        echo "❌ Token inválido. Intenta nuevamente."
        pregunta_github
        return 1
    fi

    # Asegurar que la clave SSH existe
    if [[ ! -f "$SSH_KEY_PATH" ]]; then
        echo "⚠️ No se encontró una clave SSH. Creando una nueva..."
        # ssh-keygen -t rsa -b 4096 -f "$HOME/.ssh/id_rsa" -N ""
        ssh-keygen -t rsa -b 4096 -f "$HOME/.ssh/id_rsa" -N "" -q
    fi

    # Agregar la clave SSH a GitHub automáticamente
    echo "✅ Subiendo clave SSH a GitHub..."
    SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
    curl -s -H "Authorization: token $TOKEN" \
         -X POST -d "{\"title\":\"$(hostname) SSH Key\",\"key\":\"$SSH_KEY_CONTENT\"}" \
         https://api.github.com/user/keys &> /dev/null

    # Guardar configuración en ~/.config/gh/hosts.yml
    mkdir -p "$(dirname "$CONFIG_FILE")"
    cat > "$CONFIG_FILE" <<EOF
github.com:
    user: $(whoami)
    oauth_token: $TOKEN
    git_protocol: ssh
EOF

    echo "✅ Configuración guardada, autenticando..."

    # Agregar la clave SSH de GitHub a la lista de hosts conocidos automáticamente
    echo "🔑 Agregando GitHub a los hosts conocidos..."
    ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null

    # Verificar conexión clave SSH con GitHub
    echo "🔗 Verificando conexión SSH con GitHub..."
    ssh -o StrictHostKeyChecking=no -T git@github.com &> /dev/null

    # Verificar si la autenticación fue exitosa
    if gh auth status &>/dev/null; then
        echo "✅ Autenticación SSH completada con éxito."
        return 0
    else
        echo "❌ Fallo en la autenticación. Intenta manualmente con 'gh auth login'."
        exit 1
    fi
}

ssh_token

ssh -T git@github.com &>/dev/null
if [ $? -ne 1 ]; then
    # Asegurar que la clave SSH existe
    if [[ -f "$SSH_KEY_PATH" ]]; then

        # Agregar la clave SSH a GitHub automáticamente
        echo "✅ Subiendo clave SSH a GitHub..."
        SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
        curl -s -H "Authorization: token $TOKEN" \
             -X POST -d "{\"title\":\"$(hostname) SSH Key\",\"key\":\"$SSH_KEY_CONTENT\"}" \
             https://api.github.com/user/keys &> /dev/null

        # Guardar configuración en ~/.config/gh/hosts.yml
        mkdir -p "$(dirname "$CONFIG_FILE")"
        cat > "$CONFIG_FILE" <<EOF
github.com:
    user: $(whoami)
    oauth_token: $TOKEN
    git_protocol: ssh
EOF

        echo "✅ Configuración guardada, autenticando..."

        # Agregar la clave SSH de GitHub a la lista de hosts conocidos automáticamente
        echo "🔑 Agregando GitHub a los hosts conocidos..."
        ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null

        # Verificar conexión clave SSH con GitHub
        echo "🔗 Verificando conexión SSH con GitHub..."
        ssh -o StrictHostKeyChecking=no -T git@github.com &> /dev/null
        pregunta_github
    fi
fi

# 2️⃣ Obtener nombre de usuario de GitHub
usuario_autenticado=$(ssh -T git@github.com 2>&1 | sed -n 's/Hi \([^ ]*\)!.*/\1/p')
usuario_autenticado1=$(gh api user 2>/dev/null | jq -r .login)
if [[ -n "$usuario_autenticado" ]];then
    usuario_github="$usuario_autenticado"
elif [[ -n "$usuario_autenticado1" ]];then 
    usuario_github="$usuario_autenticado1"
fi

repo_name='Busca-Palabras'

# echo -e "\n🚀Verificando repositorio '$repo_name'..."
if gh repo view "$repo_name" &>/dev/null; then
    gh repo delete "${usuario_github}/${repo_name}" --confirm &>/dev/null
    sleep 1
    gh repo create "$repo_name" --public &>/dev/null
else
    gh repo create "$repo_name" --public &>/dev/null
    sleep 1
fi


# 4️⃣ Función para subir archivos al repositorio
subir_github() {
    # Asegurar que el directorio tmp de Termux exista antes de crear el temporal
    mkdir -p "$PREFIX/tmp"
    # Crear directorio temporal
    TMPDIR=$(mktemp -d -t backup-XXXX)
    cp ~/backup-busca-Palabras/*.tar.gz "$TMPDIR"
    [[ -f ~/backup-busca-Palabras/README.md ]] && cp ~/backup-busca-Palabras/README.md "$TMPDIR"
    cd "$TMPDIR" || exit 1

    # Crear README.md si no existe
    if [ ! -f "README.md" ]; then
        printf '# %s\n%s\n' "JalisFamily" "Proyecto Busca-Palabras" > README.md
    fi

    git config --global advice.defaultBranchName false
    git init -b main
    git config user.email "robertj.mezaurueta@gmail.com"
    git config user.name "${usuario_github}"

    git add -A
    if ! git diff --cached --quiet; then
        git commit -m "Actualizar proyecto"
    else
        echo "❌ Nada que commitear"
    fi

    if ! git remote | grep -q "origin"; then
        git remote add origin git@github.com:${usuario_github}/${repo_name}.git
    fi

    git push --force origin main

    # Volver al home y borrar temporal
    cd ~
    rm -rf "$TMPDIR"
}

if [ "$(verificar_internet)" = "true" ]; then
    echo "⬆️  Subiendo archivos al repositorio..."
    subir_github
else
    echo 'No hay conexión a internet' 
    exit
fi
echo -e "✅ Repositorio completo en:\ngit clone https://github.com/${usuario_github}/${repo_name}"
if [[ -n "$archivo_comprimido" ]]; then
    # echo -e "✅ Archivo específico en:\nwget https://raw.githubusercontent.com/${usuario_github}/${repo_name}/main/${archivo_comprimido}"
    echo -e "✅ Archivo específico en:\nwget -O ${archivo_comprimido} https://raw.githubusercontent.com/${usuario_github}/${repo_name}/main/${archivo_comprimido}"
fi
rm -rf ~/backup-busca-Palabras >/dev/null


: '
# Si deseas que gh almacene las credenciales en lugar de usar la variable de entorno, debes eliminar el token de la sesión actual antes de ejecutar gh auth login nuevamente:
bash
unset GH_TOKEN GITHUB_TOKEN
export GH_TOKEN=
export GITHUB_TOKEN=
rm -rf ~/.config/gh/hosts.yml >/dev/null
rm -rf ~/.ssh/* >/dev/null
gh auth logout >/dev/null
sed -i '/export GH_TOKEN/d' ~/.bashrc ~/.profile ~/.bash_profile >/dev/null
source ~/.bashrc  # Recarga la configuración >/dev/null

# Verifica que ya no existan 
env | grep GH_TOKEN
env | grep GITHUB_TOKEN

gh auth login
# Esto te permitirá iniciar sesión manualmente y almacenar las credenciales en el sistema, en lugar de depender de la variable de entorno.

# Desde la línea de comandos (GitHub CLI) puedes eliminar un repositorio específico 
# Si tienes instalada la GitHub CLI (gh), usa el siguiente comando:
gh repo delete RobertNissan/unzip-7z --confirm


# copiar algo de un texto 
cat ~/.ssh/id_rsa.pub | termux-clipboard-set

: '
