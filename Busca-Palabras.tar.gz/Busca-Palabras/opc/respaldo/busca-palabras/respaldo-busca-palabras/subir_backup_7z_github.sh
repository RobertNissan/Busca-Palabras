#!/data/data/com.termux/files/usr/bin/bash

export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export blanco='\033[37m'

# Verificar paquetes necesarios
if ! command -v 7z &>/dev/null; then
    echo -e "${amarillo}Instalando 7zip...${blanco}"
    pkg install p7zip -y
fi

if ! command -v gh &>/dev/null; then
    echo -e "${amarillo}Instalando GitHub CLI...${blanco}"
    pkg install gh -y
fi

# Verificar internet
# =================== Internet check ===================
PING_TARGET="1.1.1.1"
PING_TIMEOUT=1

verificar_internet() {
    # Método 1: Ping a Cloudflare
    if ping -c 1 -W 2 1.1.1.1 >/dev/null 2>&1; then
        echo "true"
        return 0
    fi
    
    # Método 2: Ping a Google DNS
    if ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
        echo "true"
        return 0
    fi
    
    # Método 3: Curl a GitHub
    if curl -s --connect-timeout 3 --max-time 5 https://github.com >/dev/null 2>&1; then
        echo "true"
        return 0
    fi
    
    # Método 4: Wget a Google
    if wget -q --spider --timeout=3 --tries=1 https://www.google.com 2>/dev/null; then
        echo "true"
        return 0
    fi
    
    echo "false"
    return 1
}

# Solicitar datos al usuario
echo -e "${verde}=== Backup con 7z a GitHub ===${blanco}\n"
read -p "📁 Ruta completa de carpeta/archivo a comprimir: " ruta_origen
read -p "📦 Nombre del proyecto (sin espacios): " proyecto

# Validar que existe la ruta
if [[ ! -e "$ruta_origen" ]]; then
    echo -e "${rojo}❌ Error: La ruta no existe${blanco}"
    exit 1
fi

# Crear directorio temporal
TMPDIR=$(mktemp -d -t backup-XXXX)
archivo_7z="${proyecto}.7z"

# Comprimir con 7z
echo -e "\n${verde}[*]${blanco} Comprimiendo con 7z..."
cd "$(dirname "$ruta_origen")"
7z a -t7z -mx=9 "$TMPDIR/$archivo_7z" "$(basename "$ruta_origen")" | pv -l >/dev/null

if [[ ! -f "$TMPDIR/$archivo_7z" ]]; then
    echo -e "${rojo}❌ Error en la compresión${blanco}"
    exit 1
fi

peso=$(du -h "$TMPDIR/$archivo_7z" | awk '{print $1}')
echo -e "${verde}[+]${blanco} Compresión completada: ${peso}\n"

# Configuración GitHub
CONFIG_FILE="$HOME/.config/gh/hosts.yml"
SSH_KEY_PATH="$HOME/.ssh/id_rsa.pub"
KNOWN_HOSTS="$HOME/.ssh/known_hosts"

pregunta_github() {
    while true; do
        echo -e "\n1️⃣ Registrarme en GitHub"
        echo -e "2️⃣ Crear token de GitHub (necesita permisos: repo, delete_repo)"
        echo -e "3️⃣ Ingresar desde termux (gh auth login)"
        echo -e "4️⃣ Ingresar token manualmente"
        echo -e "5️⃣ Salir"
        read -rp "👉 Opción (1-5): " opcion

        case "$opcion" in
            1) termux-open-url "https://github.com/login" ;;
            2) 
               echo -e "${amarillo}IMPORTANTE: El token debe tener estos permisos:${blanco}"
               echo -e "  ✓ repo (acceso completo)"
               echo -e "  ✓ delete_repo (para recrear repos)"
               sleep 2
               termux-open-url "https://github.com/settings/tokens/new?scopes=repo,delete_repo&description=Termux+Backup"
               read -n 1 -p "✅ Presiona cualquier tecla después de copiar el token..." 
               ;;
            3) gh auth login ;;
            4) break ;;
            5) exit 1 ;;
            *) echo "⚠️ Opción inválida" ;;
        esac
    done
}

# Autenticación SSH
ssh_token() {
    if [[ "$(verificar_internet)" != "true" ]]; then
        echo -e "${rojo}No hay conexión a internet${blanco}"
        exit 1
    fi

    if gh auth status &>/dev/null; then
        echo "✅ Ya estás autenticado en GitHub"
        return 0
    fi

    echo "⚠️ No estás autenticado. Iniciando sesión..."

    if [[ -f "$CONFIG_FILE" ]] && grep -q "oauth_token" "$CONFIG_FILE"; then
        TOKEN=$(grep "oauth_token" "$CONFIG_FILE" | awk '{print $2}')
        if curl -s -H "Authorization: token $TOKEN" https://api.github.com/user | grep -q "login"; then
            return 0
        else
            rm -f "$CONFIG_FILE"
            pregunta_github
        fi
    fi

    pregunta_github
    read -sp "🔑 Token de GitHub: " TOKEN
    echo

    if [[ ! -f "$SSH_KEY_PATH" ]]; then
        ssh-keygen -t rsa -b 4096 -f "$HOME/.ssh/id_rsa" -N "" -q
    fi

    SSH_KEY_CONTENT=$(cat "$SSH_KEY_PATH")
    curl -s -H "Authorization: token $TOKEN" \
         -X POST -d "{\"title\":\"$(hostname) SSH Key\",\"key\":\"$SSH_KEY_CONTENT\"}" \
         https://api.github.com/user/keys &>/dev/null

    mkdir -p "$(dirname "$CONFIG_FILE")"
    cat > "$CONFIG_FILE" <<EOF
github.com:
    user: $(whoami)
    oauth_token: $TOKEN
    git_protocol: ssh
EOF

    ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null
    ssh -o StrictHostKeyChecking=no -T git@github.com &>/dev/null

    if gh auth status &>/dev/null; then
        echo "✅ Autenticación exitosa"
        return 0
    else
        echo "❌ Fallo en la autenticación"
        exit 1
    fi
}

ssh_token

# Obtener usuario
usuario_github=$(ssh -T git@github.com 2>&1 | sed -n 's/Hi \([^ ]*\)!.*/\1/p')
[[ -z "$usuario_github" ]] && usuario_github=$(gh api user 2>/dev/null | jq -r .login)

# Crear/recrear repositorio
echo -e "\n🚀 Verificando repositorio '$proyecto'..."
if gh repo view "${usuario_github}/${proyecto}" &>/dev/null; then
    echo "Eliminando repositorio existente..."
    gh repo delete "${usuario_github}/${proyecto}" --yes 2>/dev/null
    sleep 2
fi
echo "Creando repositorio..."
gh repo create "$proyecto" --public 2>/dev/null
sleep 3

# Verificar creación
if ! gh repo view "${usuario_github}/${proyecto}" &>/dev/null; then
    echo -e "${amarillo}⚠️ No se pudo crear con gh, intentando con git directo...${blanco}"
fi

# Subir a GitHub
subir_github() {
    cd "$TMPDIR" || exit 1

    printf '# %s\n%s\n' "$proyecto" "Backup comprimido con 7z" > README.md

    # Obtener token
    TOKEN=$(grep "oauth_token" "$CONFIG_FILE" | awk '{print $2}')
    
    git config --global advice.defaultBranchName false
    git init -b main
    git config user.email "backup@termux.local"
    git config user.name "${usuario_github}"

    git add -A
    git commit -m "Backup: $proyecto"

    # Usar HTTPS con token en lugar de SSH
    git remote add origin https://${TOKEN}@github.com/${usuario_github}/${proyecto}.git
    
    echo "Subiendo archivos..."
    # Intentar push, si falla crear repo con API y reintentar
    if ! git push -u origin main 2>/dev/null; then
        echo "Creando repositorio con API..."
        
        # Crear repo y capturar respuesta
        respuesta=$(curl -s -H "Authorization: token $TOKEN" \
             -X POST -d "{\"name\":\"${proyecto}\",\"private\":false}" \
             https://api.github.com/user/repos)
        
        # Verificar si hubo error
        if echo "$respuesta" | grep -q "\"message\""; then
            error_msg=$(echo "$respuesta" | grep -o '"message":"[^"]*"' | cut -d'"' -f4)
            
            # Si el repo ya existe, continuar
            if echo "$respuesta" | grep -q "already exists"; then
                echo "El repositorio ya existe, continuando..."
            elif echo "$respuesta" | grep -q "not accessible"; then
                echo -e "${rojo}❌ Token sin permisos para crear repositorios${blanco}"
                echo -e "${amarillo}Opciones:${blanco}"
                echo -e "1️⃣ Crear nuevo token con permisos 'repo' y 'delete_repo'"
                echo -e "2️⃣ Usar un repositorio existente"
                read -rp "👉 Opción (1/2): " opt
                
                if [[ "$opt" == "1" ]]; then
                    echo -e "\n${amarillo}Abriendo GitHub para crear token...${blanco}"
                    termux-open-url "https://github.com/settings/tokens/new?scopes=repo,delete_repo&description=Termux+Backup"
                    read -n 1 -p "Presiona cualquier tecla después de crear el token..."
                    echo -e "\n${amarillo}Ejecuta: gh auth logout && gh auth login${blanco}"
                    exit 1
                else
                    read -p "Nombre del repositorio existente: " proyecto
                    # Verificar que existe
                    check=$(curl -s -H "Authorization: token $TOKEN" \
                           "https://api.github.com/repos/${usuario_github}/${proyecto}")
                    if ! echo "$check" | grep -q "\"full_name\":"; then
                        echo -e "${rojo}❌ El repositorio no existe${blanco}"
                        exit 1
                    fi
                    repo_existe=true
                fi
            else
                echo -e "${rojo}Error API: $error_msg${blanco}"
                echo "Respuesta completa: $respuesta"
                exit 1
            fi
        else
            repo_existe=true
        fi
        
        # Esperar a que GitHub cree el repo (solo si se creó nuevo)
        if [[ "$repo_existe" != "true" ]]; then
            echo "Esperando a que GitHub procese el repositorio..."
            for i in {1..15}; do
                sleep 2
                check=$(curl -s -H "Authorization: token $TOKEN" \
                       "https://api.github.com/repos/${usuario_github}/${proyecto}")
                
                if echo "$check" | grep -q "\"full_name\":"; then
                    echo -e "\n${verde}Repositorio confirmado${blanco}"
                    repo_existe=true
                    break
                fi
                echo -n "."
            done
            echo ""
            
            if [[ "$repo_existe" != "true" ]]; then
                echo -e "${rojo}El repositorio no se creó correctamente${blanco}"
                exit 1
            fi
        fi
        
        sleep 3
        
        if git push -u origin main 2>&1; then
            echo -e "${verde}✅ Subida exitosa${blanco}"
        else
            echo -e "${rojo}❌ Error al subir archivos${blanco}"
            exit 1
        fi
    else
        echo -e "${verde}✅ Subida exitosa${blanco}"
    fi

    cd ~
    rm -rf "$TMPDIR"
}

echo "⬆️  Subiendo a GitHub..."
subir_github

echo -e "${verde}✅ Completado!${blanco}"
echo -e "📦 Repositorio: https://github.com/${usuario_github}/${proyecto}"
echo -e "⬇️  Descargar: wget https://raw.githubusercontent.com/${usuario_github}/${proyecto}/main/${archivo_7z}"
