#!/bin/bash

clear
# Función para convertir el archivo a formato Unix (LF)
convert_to_unix() {
    local file="$1"
    echo "Convirtiendo '$file' a formato Unix (LF)..."
    sed -i 's/\r$//' "$file"
}

# Directorio a recorrer
DIRECTORIO="/sdcard"

# Verificar si el directorio existe
if [ ! -d "$DIRECTORIO" ]; then
    echo "El directorio '$DIRECTORIO' no existe."
    exit 1
fi

# Contadores
total_archivos=0
archivos_convertidos=0
# Función recursiva para recorrer directorios
recorrer_directorio() {
    local dir="$1"
    for archivo in "$dir"/*; do
        if [ -d "$archivo" ]; then
            # Si es un directorio, llamar a la función recursivamente
            recorrer_directorio "$archivo"
        elif [ -f "$archivo" ]; then
            total_archivos=$((total_archivos + 1))  # Contar archivos revisados
            # Si es un archivo .sh, verificar formato CRLF
            if [[ "$archivo" == *.sh ]]; then
                if grep -q $'\r' "$archivo"; then
                    printf "\r\033[K%s"
                    echo -e "Procesando: $archivo)"
                    convert_to_unix "$archivo"
                    archivos_convertidos=$((archivos_convertidos + 1))  # Contar archivos convertidos
                    read
                else
                    status="No se detectó formato CRLF en $archivo"
                fi
            else
                status="No es un archivo .sh: $archivo"
            fi

            # Calcular ancho de terminal y líneas necesarias para limpiar
            terminal_width=$(tput cols)
            status_length=${#status}
            lines=$(( (status_length + terminal_width - 1) / terminal_width )) # Redondear hacia arriba

            # Limpia las líneas previas antes de imprimir
            for ((i = 0; i < lines; i++)); do
                printf "\r\033[K\033[F" # Limpia la línea actual y mueve hacia arriba
            done

            # Imprimir el nuevo estado
            echo -ne "$status\r"
        fi
    done
}

# Iniciar la búsqueda desde el directorio principal
recorrer_directorio "$DIRECTORIO"

# Mensaje de finalización
echo -e "\nProceso completado."
