#!/bin/bash

# Función para convertir el archivo a formato Unix (LF)
convert_to_unix() {
    local file="$1"
    echo "Convirtiendo '$file' a formato Unix (LF)..."
    sed -i 's/\r$//' "$file"
}
# Directorio a recorrer
DIRECTORIO="/sdcard"
# Verificar si el directorio existe
if [ ! -d "$DIRECTORIO" ]; then
    echo "El directorio '$DIRECTORIO' no existe."
    exit 1
fi

wrapper_find() {
  array=(
    "/sdcard/Alarms/Busca-Palabras/opc/scp.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/voz.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/hack.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/config/*"
    "/sdcard/Alarms/Busca-Palabras/opc/memory.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/scpscan.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/config-ta.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/team-droid.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/lista-server.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/multi_tunel_ver_url_global.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/deshabiltar_habiltar_apps_adb_v3.sh"
    "/sdcard/Alarms/Busca-Palabras/opc/solution_groups_ubuntu/capturar_error.sh"
  )

  count=0
  total=${#array[@]}
  terminal_width=$(tput cols) # Obtiene el ancho de la terminal

  for file in "${array[@]}"; do
    if [[ -f "$file" ]]; then
      dos2unix "$file" >/dev/null 2>&1
      name=$(basename "$file")
      status="Procesando: ${name}"
    else
      status="No encontrado: $(basename "$file")"
    fi

    ((count++))
    progress=$((count * 100 / total))

    # Limpia la línea antes de imprimir
    printf "\r\033[K[%3d%%] %s" "$progress" "$status"
    sleep 0.05
  done

  # Añade un salto de línea al final
  echo -e "\nProceso completado."
}

wrapper_find
