array1=(1 2 3 4)
array2=(a b c d)
size=${#array1[@]}

for ((i=0; i<$size; i++))
do
  echo "${array1[i]} ${array2[i]}"
done
