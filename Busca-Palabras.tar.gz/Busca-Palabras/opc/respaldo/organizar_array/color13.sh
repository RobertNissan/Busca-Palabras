array=("manzana" "banana" "naranja" "kiwi")
sorted=($(for i in "${array[@]}"; do echo "${#i}:$i"; done | sort -n -r | cut -d':' -f2-))
#echo "${sorted[@]}"

for i in "${sorted[@]}"; do
nam=($(basename ${i}))
    echo -e  "${nam}"
    echo -n "${nam}" | wc -c
done
