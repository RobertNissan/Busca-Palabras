array=("/sdcard/Alarms/Busca-Palabras/opc/scp.sh"
"/sdcard/Alarms/Busca-Palabras/opc/voz.sh"
"/sdcard/Alarms/Busca-Palabras/opc/hack.sh"
"/sdcard/Alarms/Busca-Palabras/opc/active.sh"
/sdcard/Alarms/Busca-Palabras/opc/config/*
"/sdcard/Alarms/Busca-Palabras/opc/memory.sh"
"/sdcard/Alarms/Busca-Palabras/opc/scpscan.sh"
"/sdcard/Alarms/Busca-Palabras/opc/config-ta.sh"
"/sdcard/Alarms/Busca-Palabras/opc/soundwire.sh"
"/sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh"
"/sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh"
"/sdcard/Alarms/Busca-Palabras/opc/team-droid.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh"
"/sdcard/Alarms/Busca-Palabras/opc/lista-server.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh"
"/sdcard/Alarms/Busca-Palabras/opc/multi_tunel_ver_url_global.sh")

#ns=($(for i in "${array[@]}"; do echo "${#i}:$i"; done | sort -n | cut -d':' -f2-))
#echo "${ns[@]}"
#read

ns=($(for i in "${array[@]}"; do 
nam=($(basename ${i}))
name=$(echo -e  "${nam}")
num=$(echo -n "${name}" | wc -c)
echo -e "${num}:$name"
done | sort -n -k2 | cut -d' ' -f1- && echo ""))

size=${#ns[@]}
ns=($(printf '%s\n' "${ns[@]}" | awk '{print length, $0}' | sort -n | cut -d " " -f2- && echo ""))
count=0
total=${#ns[@]}

#for ((i=0; i<$size; i++)); do
for i in "${ns[@]}"; do
#>/dev/null 2>&1
    sleep .05
    ((count++))
    progress=$((count * 100 / total))
    #echo -e "${i}"
    name=$(echo "${i##*:}")
    dos2unix ${array} >/dev/null 2>&1
    #echo -e ""
    echo -ne "\r[${progress}%] ${name}"
done #| sort -n | cut -d' ' -f1-
