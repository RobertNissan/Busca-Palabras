#!/bin/bash
# include this boilerplate
function jumpto
{
       label=$1
       cmd=$(sed -n "/$label:/{:a;n;p;ba};" $0 | grep -v ':$')
       eval "$cmd"
       exit
}

          #correcto
A=01 # 01-A-332
B=02 # #02-B-113    
C=03 # 03-C-213
D=04 # 04-D-313
E=05 # 05-E-123
F=06 # 06-F-223
G=07 # 07-G-323
H=08 # 08-H-212
I=09 # 09-I-312
J=10 # 10-J-122
K=11 # 11-K-222
L=12 # 12-L-322
M=13 # 13-M-132    
N=14 # 14-N-232
O=15 # 15-O-121    
P=16 # 16-P-221
Q=17 # 17-Q-321
R=18 # 18-R-131
S=19 # 19-S-231
T=20 # 20-T-331
U=21 # 21-U-112

#error trampa
#111         211          311
#133         233          333

man=$(dialog --title "Sesion I" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto UB"$man"

################opcion 1###############

UB1:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e "Estamos en UB1"
sleep 0.1
read
man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto UB"$man$man2"


UB11:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en UB11"
sleep 0.1
read 
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto UB"$man$man2$man3"

UB12:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en UB12"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto JOE"$man$man2$man3"

UB13:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en UB13"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto RM"$man$man2$man3"

#----------------------Definicion magia---------------------------#
UB111:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Trampa"
sleep 0.1
exit

UB112:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $U" 0 0
exit

UB113:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $B" 0 0
exit
#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
JOE121:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $O" 0 0
exit

JOE122:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $J" 0 0
exit

JOE123:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $E" 0 0
exit
#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
RM131:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $R" 0 0
exit

RM132:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $M" 0 0
exit

RM133:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Trampa"
sleep 0.1
exit
#--------------------Definicion fin magia-------------------------#


################opcion 2###############

UB2:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e "Estamos en UB2"
sleep 0.1
read
man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto HC"$man$man2"

HC21:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en HC21"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto HC"$man$man2$man3"

HC22:
echo -e ""
#echo Mano III FKP
echo -e ""
echo -e "Estamos en HC22"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto FKP"$man$man2$man3"


HC23:
echo -e ""
#echo Mano III NS
echo -e ""
echo -e "Estamos en HC23"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto NS"$man$man2$man3"

#----------------------Definicion magia---------------------------#
HC211:
echo -e ""
#echo Mano III C3
echo -e ""
echo -e "Trampa"
sleep 0.1
exit

HC212:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $H" 0 0
exit

HC213:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $C" 0 0
exit
#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
FKP221:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $P" 0 0
exit

FKP222:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $K" 0 0
exit

FKP223:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $F" 0 0
exit
#--------------------Definicion fin magia-------------------------#


#----------------------Definicion magia---------------------------#
NS231:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $S" 0 0
exit

NS232:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $N" 0 0
exit

FKP233:
echo -e ""
#echo Mano III C3
echo -e ""
echo -e "Trampa"
sleep 0.1
exit
#--------------------Definicion fin magia-------------------------#



################opcion 3###############

UB3:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e "Estamos en UB3"
sleep 0.1
read
man2=$(dialog --title "Sesion II" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto DI"$man$man2"

DI31:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en DI31"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto DI"$man$man2$man3"

DI32:
echo -e ""
#echo Mano II UB
echo -e ""
echo -e "Estamos en DI32"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto LGQ"$man$man2$man3"

DI33:
echo -e ""
#echo Mano III UB
echo -e ""
echo -e "Estamos en DI33"
sleep 0.1
read
man3=$(dialog --title "Sesion III" --stdout --menu "Hola $name En Que Bloque Cayo Tu Carta?" 0 0 0 \1 "Primer Bloque" \2 "Segundo Bloque" \3 "Tercer Bloque")
jumpto TA"$man$man2$man3"

#----------------------Definicion magia---------------------------#
DI311:
echo -e ""
#echo Mano III C3
echo -e ""
echo -e "Trampa"
sleep 0.1
exit

DI312:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $I" 0 0
exit

DI313:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $D" 0 0
exit

#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
DI311:
echo -e ""
#echo Mano III C3
echo -e ""
echo -e "Trampa"
sleep 0.1
exit

DI312:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $I" 0 0
exit

DI313:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $D" 0 0
exit
#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
LGQ321:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $Q" 0 0
exit

LGQ322:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $L" 0 0
exit

LGQ323:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $G" 0 0
exit

#--------------------Definicion fin magia-------------------------#

#----------------------Definicion magia---------------------------#
TA331:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $T" 0 0
exit

TA332:
echo -e ""
#echo Mano III C3
dialog --title 'Magia' --msgbox "$name Su Numero Es El $A" 0 0
exit

TA333:
echo -e ""
#echo Mano III C3
echo -e ""
echo -e "Trampa"
sleep 0.1
exit

#--------------------Definicion fin magia-------------------------#

