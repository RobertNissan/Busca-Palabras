import subprocess

zip_path = "comprimido.zip"  # Ruta del archivo ZIP comprimido
password = "_contrasena"  # Contrasena del archivo ZIP

# Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'
command = f"7za x -p{password} {zip_path}"
subprocess.run(command, shell=True)
