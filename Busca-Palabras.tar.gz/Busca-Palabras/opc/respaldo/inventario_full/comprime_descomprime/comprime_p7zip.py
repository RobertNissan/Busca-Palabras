import zipfile

zip_filename = "comprimido.zip"  # Nombre del archivo ZIP comprimido
archivo_a_comprimir = "descomprime_p7zip.py"  # Ruta del archivo a comprimir
password = "tu_contrasena"  # Contrasena para el archivo ZIP

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_LZMA) as zip_file:
    zip_file.setpassword(password.encode('utf-8'))
    zip_file.write(archivo_a_comprimir)

print("Archivo comprimido con contrasena.")