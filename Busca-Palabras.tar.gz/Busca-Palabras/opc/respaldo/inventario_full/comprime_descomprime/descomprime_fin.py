import subprocess

zip_path = "comprimido.zip"  # Ruta del archivo ZIP comprimido
correct_password = False  # Variable para verificar si la contrasena es correcta

while not correct_password:
    password = input("Ingresa la contrasena para descomprimir el archivo ZIP: ")
    
    try:
        # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'
        command = f"7za x -p{password} -y {zip_path} > /dev/null 2>&1"
        subprocess.run(command, shell=True, check=True)
        print("Archivo ZIP descomprimido con exito.")
        correct_password = True
    except subprocess.CalledProcessError as e:
        if "Wrong password" in str(e):
            print("Contrasena incorrecta. Por favor, intenta de nuevo.")
        else:
            print("Error al descomprimir el archivo ZIP:", str(e))