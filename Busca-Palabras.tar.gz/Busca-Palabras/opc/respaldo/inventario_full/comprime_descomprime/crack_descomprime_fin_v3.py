# este codigo funciona super rapido, el unico error es que aveces no encuentra la contrasena aun pasando por ella
import os
import sys
import threading
import subprocess

password_list = "rocky.txt"
zip_path = "Zydra.zip"  # Ruta del archivo ZIP comprimido
password = []
password_found = False  # Variable compartida para indicar si se encontro la contrasena correcta
lock = threading.Lock()  # Bloqueo para sincronizar los hilos

def descomprimir(zip_path, password):
    global password_found
    global passwd

    #with lock:
    if password_found:
        with lock:
            return False
    try:
        print(f"Probando contrasena: {password}")      
        print(f"Iniciando hilo de ejecucion para descomprimir {zip_path}")
        command = f"7za x -p{password.strip()} -y {zip_path} > /dev/null 2>&1"
        #os.system("sleep .00005")
        subprocess.run(command, shell=True, check=True)
        
        password_found = True
        print("!Contrasena correcta encontrada!", password)
        
        
        if password_found:
            
            with lock:
                password_found = True
                return False
                #print("!Contrasena correcta encontrada!", password)
                passwd = password
        
        
    
    except subprocess.CalledProcessError as e:
        if password_found:
            with lock:
                password_found = True
                #print("!Contrasena correcta encontrada!", password)
                passwd = password
        return False
        #print(f"001 - Excepcion en hilo de ejecucion para descomprimir {zip_path}: {str(e)}")

# Codigo para leer la lista de contrasenas desde un archivo
with open(password_list, 'r') as f:
    passwords = f.read().splitlines()

# Iniciar un hilo de ejecucion para cada contrasena en la lista
threads1 = []
threads2 = []

half = len(passwords) // 2 

# Crear hilos para el primer grupo de contrasenas
for pw in passwords[:half]:
    if password_found:
    	with lock:
            break

    t = threading.Thread(target=descomprimir, args=(zip_path, pw))
    threads1.append(t)
    t.start()

# Crear hilos para el segundo grupo de contrasenas
for pw in passwords[half:]:
    if password_found:
        with lock:
            break

    t = threading.Thread(target=descomprimir, args=(zip_path, pw))
    threads2.append(t)
    t.start()
    

# Esperar a que todos los hilos terminen o se encuentre la contrasena
for t1 in threads1:
    t1.join()
    

for t2 in threads2:
    t2.join()


if not password_found:
    print("No se encontro ninguna contrasena valida.")
print("\nLa contrasena es:", passwd)