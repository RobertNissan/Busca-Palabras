import pyminizip
import subprocess

archivo_a_comprimir = "descomprime_p7zip.py"  # Ruta del archivo a comprimir
zip_filename = "comprimido.zip"  # Nombre del archivo ZIP comprimido
password = "tu_contrasena"  # Contrasena para el archivo ZIP

# Comprimir el archivo utilizando pyminizip
pyminizip.compress(archivo_a_comprimir, "", zip_filename, password, 0)

print("Archivo comprimido con contrasena.")