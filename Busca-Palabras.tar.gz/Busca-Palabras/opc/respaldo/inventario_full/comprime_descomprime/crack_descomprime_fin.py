import subprocess

zip_path = "Zydra.zip"  # Ruta del archivo ZIP comprimido
correct_password = False  # Variable para verificar si la contrasena es correcta


def crack_password(password_list):
    count = 1
    with open(password_list, 'r') as file:
        for line in file:
            for word in line.split():
                word = (word.strip())
                try:
                    # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'  
                    print(f"Probar {word}")             
                    command = f"7za x -p{word} -y {zip_path} > /dev/null 2>&1"
                    subprocess.run(command, shell=True, check=True)
                    print("Archivo ZIP descomprimido con exito.")
                    return True
                except subprocess.CalledProcessError as e:                	
                    if "Wrong password" in str(e):
                        continue
                        #print("Contrasena incorrecta. Por favor, intenta de nuevo.")
                    else:
                        number = count
                        print (f'[%s] [-] Contrasena {word} %s' % (number, "fallo\n"))
                        count += 1
                        continue
    return False

password_list = "rocky.txt"
if crack_password(password_list) == False:
    print("No hay contrasenas que coincidan!!!")