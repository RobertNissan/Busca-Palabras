import os
import sys
import time
import zipfile
import platform
import subprocess
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from colorama import Fore, init

try:
    init()
except ImportError:
    os.system("pip3 install colorama")

system = platform.uname()[0]
End = '\033[0m'

banner = Fore.GREEN + """
# ... (tu banner aqui)
""" + End

os.system("clear")
print(banner)

opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)

# Ensure 7za is installed
os.system('if [ -f $PREFIX/bin/7za ]; then echo "Ya existe" >/dev/null 2>&1; else echo "Instalando Repositorio:"; echo -e "Instalando p7zip\n"; pkg install p7zip -y >/dev/null 2>&1; fi')

rocky = "PnYFiAhD"
password_list = input("\nIngrese lista de contrasenas: ")

try:
    with open(password_list, 'rb') as file:
        cnt = len(file.read().splitlines())
    print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print("Diccionario no encontrado!")
    sys.exit()

time.sleep(0.35)
zip_path = input("\nIngrese archivo zip: ")

try:
    with zipfile.ZipFile(zip_path, 'r') as zip_file:
        zip_file.printdir()  # Display information about the ZIP file
    print("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print("Archivo zip no encontrado!")
    sys.exit()

# Use a lock for thread-safe global variable access
listo = False
listo_lock = Lock()

def crack_password(word, zip_path):
    global listo
    if not listo:
        try:
            print(f"Probar {word}")
            command = f"7za x -p{word} -y {zip_path} > /dev/null 2>&1"
            subprocess.run(command, shell=True, check=True)
            with listo_lock:
                listo = True
                print("Archivo ZIP descomprimido con exito.")
                sys.exit()
        except subprocess.CalledProcessError:
            print(f'[-] Contrasena {word} fallo')

def crack_password_parallel(password_list, zip_path):
    with open(password_list, 'r', encoding='utf-8') as file:
        passwords = [word.strip() for word in file.read().splitlines()]
    
    for word in passwords:
        crack_password(word, zip_path)

crack_password_parallel(password_list, zip_path)
