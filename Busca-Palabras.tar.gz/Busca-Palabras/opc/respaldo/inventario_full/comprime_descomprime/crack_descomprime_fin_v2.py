import os
import subprocess

os.system('if [ -f $PREFIX/bin/7za ]; then echo "Ya existe" >/dev/null 2>&1; else echo "Instalando Repositorio:"; echo -e "Instalando p7zip\n"; pkg install p7zip -y >/dev/null 2>&1; fi')
  
zip_path = "Zydra.zip"  # Ruta del archivo ZIP comprimido

def crack_password(password_list):
    count = 1
    with open(password_list, 'r', encoding='utf-8') as file:
        for line in file:
            for word in line.split():
                word = str(word.strip())
                try:
                    # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'  
                    print(f"Probar {word}")             
                    command = f"7za x -p{word} -y {zip_path} > /dev/null 2>&1"
                    subprocess.run(command, shell=True, check=True)
                    print("Archivo ZIP descomprimido con exito.")
                    return True
                except subprocess.CalledProcessError as e:
                    number = count
                    print('[%s] [-] Contrasena %s fallo\n' % (number, word))
                    count += 1
                    continue
    return False

password_list = "rocky.txt"
if crack_password(password_list) == False:
    print("No hay contrasenas que coincidan!!!")