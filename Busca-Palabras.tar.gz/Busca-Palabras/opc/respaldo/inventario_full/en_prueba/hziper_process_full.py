from pathlib import Path
import zipfile
import sys
import time
import platform
from colorama import Fore, init
import os
from multiprocessing import Process

try:
    init()
except ImportError:
    os.system("pip3 install colorama")

system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++  ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End

os.system("clear")
print(banner)

opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z TO EXIT
""" + End
print(opt)

nombre_archivo_txt = 'rocky.txt'

word = input("\nEnter Pass List (zip file): ")

try:
    with zipfile.ZipFile(word, 'r') as zipf:
        pass_list = zipf.read(nombre_archivo_txt).decode().splitlines()
        cnt = str(len(pass_list))
        print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print("Ingrese un archivo dentro de esta carpeta!")
    sys.exit()

time.sleep(0.35)
zip_file = input("\nEnter zip file to crack: ")

try:
    file = open(zip_file, 'rb')
    print ("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print ("Ingrese un archivo dentro este folder!")
    print()
    exit()

def crack_password(password_list, obj):
    idx = 0
    count = 1
    passw = password_list
    for word in passw:
        idx += 1
        try:
            obj.extractall(pwd=word.encode())
            print("Contrasena encontrada en la linea", idx)
            print("La contrasena es", word)
            return True
        except:
            print(f'Linea {count}/{cnt}: Contrasena {word} fallo\n')
            count += 1
            continue
    return False

# Crear tres procesos para ejecutar la funcion crack_password en paralelo
processes = []
for i in range(3):
    p = Process(target=crack_password, args=(pass_list, zipfile.ZipFile(zip_file)))
    processes.append(p)
    p.start()

# Esperar a que todos los procesos terminen
for p in processes:
    p.join()

print("Terminado.")
