# ?como comprimir una carpeta con python? ?comprimir una carpeta con python? ?como comprimir una carpeta python? ?comprimir una carpeta python?

import os
import sys
import shutil
import zipfile
import tempfile
from tqdm import tqdm

proyecto_zip = "inventario_full_v1.43.zip"

def compress_folder(folder_path, output_filename):
    # Nombre del archivo de salida
    if not output_filename.endswith('.zip'):
        output_filename += '.zip'
    
    # Crear directorio temporal
    tempdir = tempfile.mkdtemp()

    try:
        # Copiar la carpeta "inventario_full" al directorio temporal
        temp_folder_path = os.path.join(tempdir, "inventario_full")
        shutil.copytree(folder_path, temp_folder_path)
        
        # Configurar la barra de progreso
        total_files = sum([len(files) for _, _, files in os.walk(temp_folder_path)])
        progress_bar = tqdm(total=total_files, desc="Comprimiendo", unit="archivos", dynamic_ncols=True)

        # Comprimir el directorio temporal en un archivo zip
        with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(temp_folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_folder_path)
                    zipf.write(file_path, arcname=os.path.join("inventario_full", arcname))
                    # Actualizar la barra de progreso
                    progress_bar.update(1)
        # Cerrar la barra de progreso
        progress_bar.close()
    finally:
        # Eliminar el directorio temporal
        shutil.rmtree(tempdir)

# Folder a comprimir
folder_path = "/sdcard/Download/inventario_full"
output_filename = f"/sdcard/Download/{proyecto_zip}"

print("Comprimiendo el proyecto inventario_full...")
print("Por favor espere...")
compress_folder(folder_path, output_filename)
print("Proyecto comprimido.")
