import os
import sys
import glob
import time
import zipfile
import platform
import subprocess 
from pathlib import Path
from multiprocessing import Pool
from colorama import Fore, init

try:
    init()
except ImportError:
    os.system("pip3 install colorama")

system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Program on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++  ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End

os.system("clear")
print(banner)

opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)

os.system('if [ -f $PREFIX/bin/7za ]; then echo "Ya existe" >/dev/null 2>&1; else echo "Instalando Repositorio:"; echo -e "Instalando p7zip\n"; pkg install p7zip -y >/dev/null 2>&1; fi')

rocky = "PnYFiAhD"
password_list = input("\nIngrese lista de contrasenas: ")

try:
    cnt = len(list(open(password_list, "rb")))
    print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print("Diccionario no encontrado!")
    print()
    sys.exit()

time.sleep(0.35)
zip_path = input("\nIngrese archivo zip: ")

try:
    file = open(zip_path, 'rb')
    print("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print("Archivo zip no encontrado!")
    print()
    exit()

def try_password(password):
    try:
        # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'  
        print(f"Probar {password}")             
        command = f"7za x -p{password} -y {zip_path} > /dev/null 2>&1"
        subprocess.run(command, shell=True, check=True)
        print("Archivo ZIP descomprimido con exito.")
        return True
    except subprocess.CalledProcessError:
        print(f'[-] Contrasena {password} fallo')
        return False

def crack_password(password_list):
    with open(password_list, 'r', encoding='utf-8') as file:
        passwords = [word.strip() for line in file for word in line.split()]
        
    with Pool() as pool:
        results = pool.map(try_password, passwords)
    
    if any(results):
        return True
    else:
        return False

if crack_password(password_list) == False:
    print("No hay contrasenas que coincidan!!!")
