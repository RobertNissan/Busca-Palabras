import os
import sys
import time
import zipfile
import platform
import subprocess
from colorama import Fore, init

try:
    from colorama import Fore,init
    init()
except ImportError:
    os.system("pip3 install colorama")
system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++ ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End
os.system("clear")
print(banner)
opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)

os.system('if [ -f $PREFIX/bin/7za ]; then echo "Ya existe" >/dev/null 2>&1; else echo "Instalando Repositorio:"; echo -e "Instalando p7zip\n"; pkg install p7zip -y >/dev/null 2>&1; fi')
  
rocky = "PnYFiAhD"
#print(f'https://mega.nz/file/{rocky}#QksksWjXiZm-d2blXxeTHTjUD8ENgfllZRL9hplkRBc')
password_list = input("\nIngrese lista de contrasenas: ")
try:
    cnt = len(list(open(password_list, "rb")))
    print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print ("Diccionario no encontrado!")
    print()
    sys.exit()
 
time.sleep(0.35)
#zip_path = "inventario_tk.zip"  # Ruta del archivo ZIP comprimido
zip_path = input("\nIngrese archivo zip: ")
try:
    file = open(zip_path, 'rb')
    print ("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print ("Archivo zip no encontrado!")
    print()
    exit()


# Contador global
count = 0

def crack_password(password_list):
    global count
    with open(password_list, 'r', encoding='utf-8') as file:
        for line in file:
            for word in line.split():
                word = str(word.strip())
                try:
                    # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'
                    command = f"7za x -p{word} -y {zip_path} > /dev/null 2>&1"
                    subprocess.run(command, shell=True, check=True)
                    print(f"Archivo ZIP descomprimido con exito. Contrasena: {word}")
                    sys.exit()
                except subprocess.CalledProcessError as e:
                    count += 1
                    print(f'[{count}] [-] Contrasena {word} fallo')
                    continue

# Llamada a la funcion
crack_password(password_list)

# Mensaje final
print("No hay contrasenas que coincidan!!!")
