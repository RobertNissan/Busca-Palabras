import os
import sys
import time
import zipfile
import platform
from tqdm import tqdm
from colorama import Fore, init

# Configurar el tamano del bufer de salida de sys.stdout
buffer_size = 90000000  # Ajusta este valor segun tus necesidades
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', buffer_size)

try:
    init()
except ImportError:
    os.system("pip3 install colorama")

system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++  ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End

os.system("clear")
print(banner)

opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z TO EXIT
""" + End
print(opt)

nombre_archivo_txt = 'rocky.txt'

word = input("\nIngrese el archivo de contrasenas (zip file): ")

archivo_diccionario_contrasenas = os.path.normpath(word.strip("\"'"))

try:
    with zipfile.ZipFile(word, 'r') as zipf:
        pass_list = zipf.read(nombre_archivo_txt).decode().splitlines()
        cnt = str(len(pass_list))
        print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print("Ingrese un archivo dentro de esta carpeta!")
    sys.exit()

time.sleep(0.35)
zip_file = input("\nIngrese archivo zip  a crack: ")

try:
    file = open(zip_file, 'rb')
    print("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print("Ingrese un archivo dentro este folder!")
    print()
    exit()

# Iniciar el proceso de comprobacion de contrasenas
print("")
sys.stdout.flush()
# Bandera para indicar si se encontro la contrasena
contrasena_encontrada = False
# Crear un objeto tqdm para el bucle
progress_bar = tqdm(total=int(cnt), desc="bar", position=1, initial=1)

# ZipFile object initialised
try:
    obj = zipfile.ZipFile(zip_file)
except zipfile.BadZipFile:
    progress_bar.close()
    print("El archivo a hackear no es un zip")
    sys.exit()

# Almacenar la longitud de la contrasena anterior
prev_password_length = 0
# Almacenar la ultima salida escrita
last_output = ''

for idx, word in enumerate(pass_list, start=1):
    try:
        obj.extractall(pwd=word.encode())
        contrasena_encontrada = True
        print("")
        print("\r\033[K[\033[93m+\033[0m] \033[92mContrasena encontrada:\033[0m \033[93m{}\033[0m".format(word.strip()))
        sys.stdout.flush()
        progress_bar.close()  # Detener y limpiar tqdm
        break
    except:
        if len(word) <= 30 or len(word) <= prev_password_length:
            new_output = "[+] Contrasena fallida: {}".format(word.strip())
        else:
            last_output = "[+] Contrasena fallida: {}".format(word[:27].strip())  # Mostrar solo los primeros 27 caracteres
        
        # Limpiar solo si la nueva salida es diferente a la ultima salida
        if len(new_output) < len(last_output):
            sys.stdout.write("\r\033[K" + new_output)
            sys.stdout.flush()
            last_output = new_output
        else:
            sys.stdout.write("\r" + last_output)
            sys.stdout.flush()
            last_output = new_output
        
        prev_password_length = len(word)  # Actualizar la longitud de la contrasena anterior
        progress_bar.update(1)

# Cerrar el objeto tqdm si no se encontro la contrasena
if not contrasena_encontrada:
    progress_bar.close()
    print("\n!Contrasena no encontrada en el diccionario!", nombre_archivo_txt)
print("")
