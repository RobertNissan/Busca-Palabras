import io
import os
import sys
import time
import zipfile
import signal
import mmap
from colorama import Fore, init

try:
    init()
except ImportError:
    os.system("pip3 install colorama")

End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
██╗  ██╗ █████╗  ██████╗██╗  ██╗    ███████╗██╗██████╗ 
██║  ██║██╔══██╗██╔════╝██║ ██╔╝    ╚══███╔╝██║██╔══██╗
███████║███████║██║     █████╔╝█████╗ ███╔╝ ██║██████╔╝
██╔══██║██╔══██║██║     ██╔═██╗╚════╝███╔╝  ██║██╔═══╝ 
██║  ██║██║  ██║╚██████╗██║  ██╗    ███████╗██║██║     
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚══════╝╚═╝╚═╝     
""" + End

os.system("clear")
print(banner)

opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z TO EXIT
""" + End
print(opt)

# Bandera para indicar si se encontró la contraseña
contrasena_encontrada = False

# Variable para controlar si el bucle debe detenerse después de probar una contraseña
detener_bucle = False
pass_list = []
# Solicitar al usuario que ingrese la ruta al archivo de diccionario de contraseñas
try:
    word = input("Ingrese la ruta del diccionario de contraseñas:\n>> ")
    word = os.path.normpath(word.strip("\"'"))
    # Obtener el nombre del archivo sin extensión y agregar .txt
    nombre_archivo_sin_extension, _ = os.path.splitext(word)
    nombre_archivo = nombre_archivo_sin_extension + ".txt"
    nombre_archivo_txt = os.path.basename(nombre_archivo)
    with zipfile.ZipFile(word, 'r') as zipf:
        with zipf.open(nombre_archivo_txt, 'r') as file:
            content = file.read()
            content_bytes = io.BytesIO(content).read()
            with mmap.mmap(-1, len(content_bytes), access=mmap.ACCESS_READ) as file_mmap:
                pass_list = content_bytes.decode('utf-8').splitlines()
                print(f'Se cargaron {len(pass_list)} contraseñas en el archivo {nombre_archivo_txt}')
    zip_file = input("\nIngrese el zip a hackear:\n>> ")
  
except KeyboardInterrupt:
    print("Detenido por el usuario!\n")
    sys.exit()
except FileNotFoundError:
    print("¡Ingrese un archivo dentro de esta carpeta!\n")
    sys.exit()
except IsADirectoryError:
    print("Debe ingresar los datos!\n")
    sys.exit()    

time.sleep(0.35)
# Definir una función para manejar la señal SIGTSTP (Ctrl+Z)
def handler(signum, frame):
    global detener_bucle
    detener_bucle = True
    print("\n\n[!] Señal de salida (Ctrl+Z) detectada...")
    sys.exit()
# Asignar la función del controlador a la señal SIGTSTP
signal.signal(signal.SIGTSTP, handler)

# Definir una función para manejar la señal SIGINT (Ctrl+C)
def handler_sigint(signum, frame):
    global detener_bucle
    detener_bucle = True
    print("\n\n[!] Señal de salida (Ctrl+C) detectada...")
    sys.exit()
# Asignar la función del controlador a la señal SIGINT
signal.signal(signal.SIGINT, handler_sigint)

try:
    file = open(zip_file, 'rb')
    obj = zipfile.ZipFile(file)
    print("Archivos cargados")
    time.sleep(0.51)
    idx = 0
    passw = pass_list
    
    # Realizar la búsqueda de contraseñas hasta que se encuentre una o se detenga el bucle
    for word in passw:
        idx += 1
        if detener_bucle:
            print("Deteniendo el bucle...")
            break
        try:
            print(f'Linea {idx}/{len(passw)} - Probando: {word}')
            obj.extractall(pwd=word.encode())
            print("\033[92mLa contrasena es: \033[0m\033[93m{}\033[0m\n".format(word.strip()))
            contrasena_encontrada = True
            break  # Detener el bucle después de encontrar la contraseña
        except:
            continue

    if not contrasena_encontrada:
        print("¡Contraseña no encontrada!\n")
except Exception as e:
    print ("Ingrese un archivo dentro este folder!\n")
finally:
    # Cerrar el archivo ZIP si está abierto
    if 'obj' in locals():
        obj.close()
    if 'file' in locals():
        file.close()
