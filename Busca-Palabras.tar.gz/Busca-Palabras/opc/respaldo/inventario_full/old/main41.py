# ejecutar el inventario

import sqlite3
import os
try:
 import readchar
except ModuleNotFoundError:
 os.system("pip3 install readchar >/dev/null 2>&1")
 import readchar


conexion=sqlite3.connect("inventory.db")
conexion.execute("""CREATE TABLE IF NOT EXISTS clientes (clientId integer primary key, clientName text, price_out integer)""");
conexion.execute("""CREATE TABLE IF NOT EXISTS operation (clientId integer primary key autoincrement, price_out integer, operation_type integer)""");          
conexion.close()

# Colores
verde = '\x1b[1;32m'
blanco = '\x1b[1;37m'

# Funcion para mostrar el menu
# esta funcion se muestra todo el tiempo
def menu():
	i = 0
	while i!=12:
		print("\n\n-----* INVENTORY PY *-------")
		print("-----    MENU    -------")
		print("1. Ver inventario")
		print("2. Agregar a Inventario")
		print("3. Disminuir Inventario")
		#print("4. Ver Productos")
		print("4. Agregar Cliente")
		print("5. Agregar Producto a Cliente")
		print("6. Eliminar Cliente")
		print("7. Eliminar Producto a Cliente")
		print("8. Ver Un Cliente ")
		print("9. Ver abonos de cliente")
		print("10. Buscar Producto o fechas de abonos")
		print("11. Salir")
		i = input("\nOpcion > ")
		print()

		try:
			int(i)
			it_is = True
		except ValueError:
			it_is = False

		while (it_is) == False:
			print("LA OPCION DEBE SER UN NUMERO!!!")
			i = input("Opcion > ")
			print()
			try:
				int(i)
				it_is = True
			except ValueError:
				it_is = False

		i = int(i)
		#print("Opcion seleccionada:  ", i)
		#print("------------------------------")
		if i == 1:
			ver_inventario()
		elif i==2:
			agregar_inventario()
		elif i==3:
			disminuir_inventario()
		#elif i==4:
			#ver_productos()
		elif i==4:
			agregar_cliente()
		elif i==5:
			agregar_producto2()
		elif i==6:
			eliminar_cliente()
		elif i==7:
			eliminar_producto_client()
		elif i==8:
			ver_cliente()
		elif i==9:
			ver_cliente_abono()
		elif i==10:
			buscar()
		elif i==11:
			print("-- [ Powered by RobertNissan ] --")
			exit()


# opcion 8 funcion para ver productos

def ver_cliente():

	print("\n\n---- VER CLIENTE -----")
	clientId = input("Id del Cliente > ")
	#clientId = str(clientId)
	# using type()
	# Check if variable is string integer
	#res = isinstance(clientId, int)
	#if clientId.isalpha() or len(clientId) == 0 or type(clientId) is int:
	if clientId.isdigit() == True:
		#print("ID DEBE SER NUMEROS!!!")
		#input()
		
		
		
		width = os.get_terminal_size().columns
		m = width - 2
		n = int(m)
		print(f"mi pantalla {m}")
		n1 = (0.05 * m)
		n2 = (0.4 * m)
		n3 = (0.35 * m)
		n4 = (0.2 * m)
		mi2 = int(n1)
		md2 = int(n2)
		md3 = int(n3)
		mdi2 = int(n4) - 1
		for ent in range(10, 201, 10):
			if ent == (m):
				md2 = md2 + .5
				#mi2 = mi2 + 1
				#mdi2 = mdi + 1
		for tne in [39, 48, 69, 74, 76, 86, 99, 112, 159]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				#print(md2)
				md2 = md2 + 1
				break
		for tne in [140]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				#print(md2)
				md2 = md2 - 1
				break
		for tne in [35, 39]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				#print(md2)
				md2 = md2 - 2
				mi2 = mi2 + 2
				break
		for tne in [45, 48, 70, 95, 110, 130, 140, 180, 175]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				print(mdi2)
				mdi2 = mdi2 - 1
				break
		for tne in [86]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				print(mdi2)
				mdi2 = mdi2 - 2
				break
		for tne in [83, 76, 143, 206]:
			#print(f"primera tne {tne}")
			#input()
			if tne == m:
				print(mdi2)
				mdi2 = mdi2 - 1
				break
	

		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		try:
			name = con.execute("select clientName from clientes where clientId = {}".format(clientId))
			for namec in name:
				clientName = (namec[0])
				#print(namec)
				#input()
			try:
				rows = cursor.execute("select * from "+clientName+"")
				#print("+--+---------------+------------------+-------+")
				#print("|ID|CLIENTE        |ARTICULO          |PRECIO |")
				#print("+--+---------------+------------------+-------+")
				print('+'+'-'*m+'+')
				print('|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:<{mdi2}}|'.format('ID','CLIENTE','PRODUCTO','PRECIO', mi2=mi2,md2=md2,md3=md3,mdi2=mdi2))
				print('+'+'-'*m+'+')

				for r in rows:
					#print(r[0],"|",r[1],"|",r[2],"|",r[3])
					id = (r[0])
					#id = (f"[{id}]")
					no = (r[1])
					no = no.replace('"', '')
					ar = (r[2])
					ar = ar.replace('"', '')
					de = (r[3])
					cadena = '|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:>{mdi2}}|'.format(id,no,ar,de, mi2=mi2,md2=md2,md3=md3,mdi2=mdi2)
					print(cadena)
					#print("+--+---------------+------------------+-------+")
					print('+'+'-'*m+'+')

						#print(r)
				con.commit()
				#print("------------------------\n\n")
				menu() # Regresar al menu principal
				#except sqlite3.OperationalError:
			except sqlite3.OperationalError:
					print(f"No existe cliente con ese Id ")
					input()
					menu()

		except UnboundLocalError:
					print(f"No existe cliente con ese Id")
					input()
					menu()
	else:
		#print("nada")
		print("ID DEBE SER NUEROS!!!")


# opcion5 funcion para agregar un cliente a la base de datos
def agregar_cliente():
	print ("\n\n----- AGREGAR CLIENTE ----")
	clientName = input("Nombre del Cliente > ")
	while len(clientName) >= 21 or len(clientName) == 0:
	  if len(clientName) == 0:
	        clientName += clientName
	        print("Ingrese un Nombre!")
	        clientName = input("Nombre del Cliente > ")
	  elif len(clientName) == 0 or clientName >= readchar.key.CR:
	        clientName += clientName
	        print("Solo ingrese de 1 a 20 caracteres")
	        clientName = input("Nombre del Cliente > ")
	name = (clientName)
	clientName = str('"'+clientName+'"')

	try:
		con = sqlite3.connect("inventory.db")
		cursor1 = con.cursor()
		cursor1 = con.execute("SELECT count(*) FROM "+name+";")
		for ve in cursor1:
			tabla = (ve[0])
			#print(tabla)
			if tabla != 0:
				print("Ya existe un cliente con ese Nombre")
				input()
				menu()
	except sqlite3.OperationalError:
		#print("NOMBRE APROBADO")
		os.system("ok >/dev/null 2>&1")



	clientId = input("Agregar Id > ")
	while(not clientId.isdigit()) or len(clientId) >= 3 or len(clientId) == 0 or clientId == '0':
		if len(clientId) == 0:
			clientId += clientId
			print("Ingrese un Id!")
			clientId = input("Agregar Id > ")
		elif len(clientId) == 0 or clientId >= readchar.key.CR:
			clientId += clientId
			print("Solo ingrese de 1 a 2 digitos")
			clientId = input("Agregar Id > ")
	ID = int(clientId)
	clientId = str(clientId)

	try:
		con = sqlite3.connect("inventory.db")
		cursor4 = con.cursor()
		cursor4 = con.execute('select clientId from clientes where clientId=?', [ID])
		for id in cursor4:
			id = (id[0])
			#print(id)
			if id >= 1:
				print("Ya existe un cliente con ese id")
				input()
				menu()
	except UnboundLocalError:
		print("ID APROBADO")






	productName = input("Nombre del Producto > ")
	while len(productName) >= 17 or len(productName) == 0:
	  if len(productName) == 0:
	        productName += productName
	        print("Ingrese un Nombre!")
	        productName = input("Nombre del Producto > ")
	  elif len(productName) == 0 or productName >= readchar.key.CR:
	        productName += productName
	        print("Solo ingrese de 1 a 16 caracteres")
	        productName = input("Nombre del Producto > ")
	productName = str('"'+productName+'"')

	#price_in = input("Precio de Compra > ")
	#price_in  = float(price_in)
	price_out = input("Precio de Venta > ")
	while(not price_out.isdigit()) or len(price_out) >= 8 or len(price_out) == 0:
	  if len(price_out) == 0:
	        price_out += price_out
	        print("Ingrese un Precio!")
	        price_out = input("Precio de Venta > ")
	  elif len(price_out) == 0 or price_out >= readchar.key.CR:
	        price_out += price_out
	        print("Solo ingrese de 1 a 7 digitos")
	        price_out = input("Precio de Venta > ")
	quantity  = float(price_out)
	price_out = float(price_out)

	con = sqlite3.connect("inventory.db")
	con.execute("CREATE TABLE IF NOT EXISTS "+clientName+" (clientId integer primary key, clientName text, productName text, price_out integer)");
	
	con.execute("CREATE TABLE IF NOT EXISTS clientes (clientId integer primary key, clientName text, price_out integer)");

	valores = (clientId, clientName, quantity)
	con.execute("insert or replace into clientes (clientId, clientName, price_out) values (?,?,?)", valores)

	valores1 = (clientName, productName, price_out)
	con.execute("insert into "+clientName+" (clientId, clientName, productName, price_out) values (NULL,?,?,?)", valores1)

	valores2 = (clientId, quantity, 1)
	con.execute("insert or replace into operation (clientId, price_out, operation_type) values (?,?,?)", valores2)
	con.commit()
	print("[+] Agregado exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# opcion6 funcion para agregar un producto a cliente en la base de datos
def agregar_producto2():
	print ("\n\n----- AGREGAR PRODUCTO A CLIENTE ----")
	#clientName = input("Nombre del Cliente > ")
	clientId = input("Id del Cliente > ")
	try:
		int(clientId)
		it_is = True
	except ValueError:
		it_is = False

	while (it_is) == False:
		print("ID DEBE SER NUMEROS!!!")
		clientId = input("Id Del Cliente > ")
		print()
		try:
			int(clientId)
			it_is = True
		except ValueError:
			it_is = False
	clientId = str(clientId)
	ID = (clientId)
	con = sqlite3.connect("inventory.db")
	cursor = con.execute("select count(*) from clientes where clientId=?", [ID])
	for bi in cursor:
		vt = (bi[0])
		#print(f"existe {vt}")
		if vt == 0:
			print("No existe cliente con ese id!")
			menu()
			
		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		#Verificar la existencia de un cliente
		name2 = cursor.execute("select clientName from clientes where clientId=?", [clientId])
		for name in name2:
			name = (name[0])
			print(f"Agregar producto a {name}")

	productName = input("Nombre del Producto > ")
	while len(productName) >= 17 or len(productName) == 0:
	  if len(productName) == 0:
	        productName += productName
	        print("Ingrese un Nombre!")
	        productName = input("Nombre del Producto > ")
	  elif len(productName) == 0 or productName >= readchar.key.CR:
	        productName += productName
	        print("Solo ingrese de 1 a 16 caracteres")
	        productName = input("Nombre del Producto > ")
	productName = str(productName)

	#price_out = input("Precio de Venta > ")
	#quantity  = float(price_out)
	#price_out = float(price_out)
	
	price_out = input("Precio de Venta > ")
	while(not price_out.isdigit()) or len(price_out) >= 8 or len(price_out) == 0:
	  if len(price_out) == 0:
	        price_out += price_out
	        print("Ingrese un Precio!")
	        price_out = input("Precio de Venta > ")
	  elif len(price_out) == 0 or price_out >= readchar.key.CR:
	        price_out += price_out
	        print("Solo ingrese de 1 a 7 digitos")
	        price_out = input("Precio de Venta > ")
	quantity  = float(price_out)
	price_out = float(price_out)
	
	
	
	
	con = sqlite3.connect("inventory.db")
	
	cursor = con.execute("select clientName from clientes where clientId = {}".format(clientId))
	for i in cursor:
		name = (i[0])
		print (f"Se agregara producto a {name}", end='')
		input()
		clientName = (i[0])
	
	
	valores1 = (clientName, productName, price_out)
	con.execute("insert into "+clientName+" (clientId, clientName, productName, price_out) values (NULL,?,?,?)", valores1)
	
	cursor2 = con.cursor()
	entradas = 0
	salidas = 0
	inventario = 0
	entradas_rows = cursor2.execute("select sum(price_out) from operation where clientId = {}".format(clientId))
	for er in entradas_rows:
		if er[0]!=None:
			entradas = (er[0])
	inventario = entradas + quantity 
	valores = (clientId, (inventario), 1)
	con.execute("insert or replace into operation (clientId, price_out, operation_type) values (?,?,?)", valores)
	
	valores2 = (clientId, clientName, (inventario))
	con.execute("insert or replace into clientes (clientId, clientName, price_out) values (?,?,?)", valores2)

	con.commit()
	print("[+] Agregado exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal


# opcion2 funcion para agregar cantidades al inventario de un producto
def agregar_inventario():
	print ("\n\n----- AGREGAR INVENTARIO ----")
	clientId = input("Id del Cliente > ")
	if clientId.isdigit() == True:
		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		#Verificar la existencia de un id
		name2 = cursor.execute("select clientId from clientes where clientId=?", [clientId])
		for name in name2:
			if (name[0]) != 0:
				#Verificar la existencia de un Cliente
				name0 = cursor.execute("select clientName from clientes where clientId=?", [clientId])
				for name in name0:
					name = (name[0])
					print(f"Se incrementara la deuda de {name}", end='')
					input()
		
				quantity = input("Cantidad a Sumar > ")
				clientId = (clientId).__str__()
				quantity  = int(quantity)
				con = sqlite3.connect("inventory.db")
				cursor2 = con.cursor()
				entradas = 0
				salidas = 0
				inventario = 0
				entradas_rows = cursor2.execute("select price_out from operation where clientId = {}".format(clientId))
				for er in entradas_rows:
					if er[0]!=None:
						entradas = (er[0])
				inventario = entradas + quantity 
				valores = (clientId, (inventario), 1)
				price_out = str(inventario)
				con.execute("update clientes set price_out = "+price_out+" where clientId=?", (clientId,))
				con.execute("insert or replace into operation (clientId, price_out, operation_type) values (?,?,?)", valores)
				con.commit()
				print("[-] Agregado exitosamente!")
				print("------------------------\n\n")
				menu() # Regresar al menu Principal
	else:
		print("ID DEBE SER NUMEROS!!!")
		menu()
	print("Cliente no existe")
	menu()
	

# opcion1 funcion para ver el inventario
def ver_inventariobk():
	
	width = os.get_terminal_size().columns
	m = width - 2
	n = int(m)
	print(f"mi pantalla {m}")
	n1 = (0.1 * m)
	n2 = (0.6 * m)
	n3 = (0.3 * m)
	mi2 = int(n1)
	md2 = int(n2)
	mdi2 = int(n3) - 1
	for ent in range(10, 201, 10):
		if ent == (m):
			md2 = md2 + .5
			#mi2 = mi2 + 1
			#mdi2 = mdi + 1
	for tne in [39, 48, 69, 76, 86, 99, 112]:
		#print(f"primera tne {tne}")
		#input()
		if tne == m:
			#print(md2)
			md2 = md2 + 1
			break
	for tne in [140]:
		#print(f"primera tne {tne}")
		#input()
		if tne == m:
			#print(md2)
			md2 = md2 - 1
			break
	for tne in [39]:
		#print(f"primera tne {tne}")
		#input()
		if tne == m:
			#print(md2)
			md2 = md2 - 1
			break
	print("\n\n---- VER INVENTARIO -----")
	print("[1] Nombre del Cliente > ")
	print("[2] Ver todos los clientes")
	CN = input(" > ")
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	rows = cursor.execute("select * from "+CN+"")
	print("ID  |  CLIENTES |  DEUDA ")
	#fila=cursor.fetchone()
	fila=cursor.fetchall()
	print(fila)
	con.commit()
	print("------------------------\n\n")
	menu() # Regresar al menu principal
	
	

# opcion1 funcion para ver el inventario
def ver_inventario():
	
	# Obtener el ancho maximo de la tabla a partir del ancho del terminal
	table_width = os.get_terminal_size().columns

	texto = "----- VER INVENTARIO -----"
	texto2 = "Ver todos los clientes"

	# Para la primera cadena de texto
	espacios = (table_width - len(texto)) // 2
	centrado = (" " * espacios) + texto + (" " * espacios)
	print(centrado)

	# Para la segunda cadena de texto
	espacios = (table_width - len(texto2)) // 2
	centrado2 = (" " * espacios) + texto2 + (" " * espacios)
	print(centrado2)
	
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()

	print(f"mi pantalla {table_width}")
	n1 = int(0.07 * table_width)
	n2 = int(0.88 * table_width)
	n3 = int(0.15 * table_width)

	ID = 'ID'
	NOMBRE = 'CLIENTES'
	DEUDA = 'DEUDA'
	
	row_str = f"| {ID.ljust(n1)} | {NOMBRE.ljust(n2)} | {DEUDA.rjust(n3)} |"
	long = len(row_str)

	print("longitud:", long)
	for longitud in range(1, 399):
		medida = long - longitud
		#print(f"medida {medida}")
		if medida == table_width:
			print(f"{long} - {longitud} = {table_width}")
			n2 = n2 - longitud
			break
		else:
			medida = long + longitud
			if medida == table_width:
				print(f"{long} + {longitud} = {table_width}")
				n2 = n2 + longitud
				break
			
	row_str = f"| {ID.ljust(n1)} | {NOMBRE.ljust(n2)} | {DEUDA.rjust(n3)} |"
	# Imprimir la linea superior de la tabla
	print("+" + "-" * (table_width - 2) + "+")
	print(row_str)
	print("+"+"-" * (table_width - 2)+"+")
	#input()
	
	speed = cursor.execute("select * from clientes;")
	for rows in speed:
		id_, name, salary = rows
		id_ = str(rows[0])
		no = str(rows[1])
		name = no.replace('"', '')
		de = str(rows[2])
		
		# Imprimir las filas
		row_str = f"| {id_.ljust(n1)} | {name.ljust(n2)} | {de.rjust(n3)} |"
		print(row_str)
		print("+" + "-" * (table_width - 2) + "+")

	# Sumar los valores de la colomna price_out
	total_rows = cursor.execute("select sum(price_out) from operation")
	for it in total_rows:
		total = (it[0])
	total = str(it[0])
	try:

		ni = ''
		tin = 'INVENTARIO-TOTAL'
		total = f"| {ni.ljust(n1)} | {tin.center(n2)} | {total.rjust(n3)} |"
		#total = "{:<{n1}}|{:^{n2}}|{:>{n4}}  |".format('      ', ' INVENTARIO-TOTAL ', total, n1=n1,n2=n2,n4=n4)
		#print("     |  INVENTARIO-TOTAL  |{total}    |")
		print(total)
		con.commit()
		#print("------------------------\n\n")
		menu() # Regresar al menu principal
	except TypeError:
		print("No hay datos en la tabla!")
		menu()


# opcion3 funcion para Disminuir cantidades o existencias al inventario de un producto
def disminuir_inventario():
	print ("\n\n----- DISMINUIR INVENTARIO ----")
	clientId = input("Id del Cliente > ")
	if clientId.isdigit() == True:
		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		#Verificar la existencia de un id
		name2 = cursor.execute("select clientId from clientes where clientId=?", [clientId])
		for name in name2:
			#print(name[0])
			s = (name[0])
			#print(s)
			if (name[0]) == 0:
				print("No existe cliente con ese id")
				menu()
				
			name1 = cursor.execute("select clientName from clientes where clientId=?", [clientId])
			for cname in name1:
				#print(cname[0])
				mname = (cname[0])
				print (f"Se va abonar a {mname}")
		
		
			quantity = input("Cantidad a Abonar > ")
			while(not quantity.isdigit()) or quantity.startswith("0") or len(quantity) >= 8 or len(quantity) == 0:
				if quantity.startswith("0") or len(quantity) >= 8 or len(quantity) == 0:
					quantity += quantity
					#print("Ingrese un Precio!")
					print("Solo ingrese de 1 a 7 digitos")
					quantity = input("Cantidad a Abonar > ")
				elif len(quantity) == 0 or quantity >= readchar.key.CR:
					quantity += quantity
					print("Ingrese cantidad en numeros!")
					quantity = input("Cantidad a Abonar > ")
			
			
			
			price_in = (quantity)
			if quantity.isdigit() == True:
				if quantity == '0':
					print("No se hizo el abono")
					menu()
				con = sqlite3.connect("inventory.db")
				cursor = con.execute("select clientName from clientes where clientId = {}".format(clientId))
				for i in cursor:
					name = (i[0])
					print (f"Se va abonar a {name} ${quantity} pesos", end='')
					input()
					clientName = (i[0])

				cursor2 = con.cursor()
				entradas = 0
				salidas = 0
				inventario = 0
				entradas_rows = cursor2.execute("select sum(price_out) from clientes where clientId = {}".format(clientId))
				for er in entradas_rows:
					if er[0]!=None:
						entradas = (er[0])
						#print(f"entradas {entradas}")
						#input()
						
				quantity = int(quantity)
				#print(f"cantidad abonada {quantity}")
				inventario = entradas - quantity 
				if quantity>entradas:
					os.system("No se puede dejar Disminuir >/dev/null 2>&1 ")
					print(f"DEUDA DEL CLIENTE {entradas}")
					#print(f"inventario = {inventario}")
					print("No se puede dejar Disminuir\nmas de las existencias")
					print(f"{entradas} - {quantity} = {inventario}")
					menu() # Regresar al menu Principal
				try:
					valores = (clientId, clientName, (inventario),)
					con.execute("insert or replace into clientes (clientId,clientName, price_out) values (?,?,?)", valores)
					print("Tipo Ejem: Efectivo, Trueque, Etc...")
					abonoName = input("Tipo de abono > ")
					#verificar que no este vacio
					while len(abonoName) >= 9 or len(abonoName) == 0 or abonoName == '0':
						if len(abonoName) == 0 or abonoName == '0':
							abonoName += abonoName
							print("Ingrese un tipo, Efectivo o Trueque!")
							abonoName = input("Tipo de abono > ")
						elif abonoName == '0' or len(abonoName) == 0 or abonoName >= readchar.key.CR:
							fechaName += fechaName
							print("Solo ingrese de 1 a 8 caracteres")
							abonoName = input("Tipo de abono > ")
					name = (abonoName)
					abonoName = str('"'+abonoName+'"')
						
						
					print("DIA/MES/ANO")
					fechaName = input("Fecha > ")
					#verificar que no este vacio
					while len(fechaName) >= 10 or len(fechaName) == 0 or fechaName == '0':
						if len(fechaName) == 0:
							fechaName += fechaName
							print("Ingrese una fecha!")
							fechaName = input("Fecha > ")
						elif fechaName == '0' or len(fechaName) == 0 or fechaName >= readchar.key.CR:
							fechaName += fechaName
							print("Solo ingrese de 1 a 9 caracteres")
							fechaName = input("Ingrese Una Fecha > ")
					name = (fechaName)
					fechaName = str('"'+fechaName+'"')
						

				except sqlite3.OperationalError:
					print(f"Cliente con id {clientId}, no existe")
					menu()
			entradas = 0
			salidas = 0
			inventario = 0
			entradas_rows1 = cursor2.execute("select price_out from operation where clientId = {}".format(clientId))
			for er in entradas_rows1:
				if er[0]!=None:
					entradas = (er[0])
			inventario = entradas - quantity
			#print(f"inventario es {inventario}")
			#input()
			try:
				if name == None:
					print("Existe")
			except UnboundLocalError:
					print(f"Cliente con id {clientId}, no existe\n")
					menu()

			if quantity>entradas:
				print(f"DEUDA DEL CLIENTE {entradas}")
				#print(f"inventario = {inventario}")
				print("No se puede dejar Disminuir\nmas de las existencias")
				print(f"{entradas} - {quantity} = {inventario}")
				menu() # Regresar al menu Principal
			else:
				valores = (clientId, (inventario), 1)
				con.execute("insert or replace into operation (clientId, price_out, operation_type) values (?,?,?)", valores)
				
				#valores_c = (clientId, (cname), (inventario))
				#con.execute("insert or replace into clientes (clientId, clientName, price_out) values (?,?,?)", valores_c)
				
				
				# aqui puedo crear la tabla abono
				abono = (clientName,abonoName,fechaName,price_in)
				con.execute("""CREATE TABLE IF NOT EXISTS abono (clientId integer primary key, clientName text, abonoName text, fechaName text, price_in integer)""");
				#con = sqlite3.connect("inventory.db")
				con.execute("insert into abono (clientId, clientName, abonoName, fechaName, price_in) values (NULL,?,?,?,?)", abono)
						
				
				con.commit()
				print(f"Abono exitoso! | DEUDA {inventario}")
				print("------------------------\n\n")
				menu() # Regresar al menu Principal


			print("No se agrego una cantidad en numeros")
			menu()

		print("Cliente no existe")
		menu()



	else:
		print("ID DEBE SER NUMEROS!!!")
		menu()
	print("Cliente no existe")
	menu()


# opcion4 funcion para ver productos
def ver_productos():
	print("\n\n---- VER PRODUCTOS -----")
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	rows = cursor.execute("select * from clientes")
	print("ID|CLIENTES | ARTICULO | DEUDA ")
	for r in rows:
		#print(r[0],"|",r[1],"|",r[2],"|",r[3])
		print(r)
	con.commit()
	print("------------------------\n\n")
	menu() # Regresar al menu principal


# opcion6 funcion para eliminar productos de la BD
def eliminar_cliente():
	print ("\n\n----- ELIMINAR CLIENTE ----")
	clientId = input("Id del Cliente > ")
	if clientId.isdigit() == True:
		#clientName = input("Nombre del Cliente > ")
		clientId = (clientId)
		try:
			con = sqlite3.connect("inventory.db")
			cursor = con.execute("select clientName from clientes where clientId=?", [clientId])
			for i in cursor:
				name = (i[0])
				print (f"Se va eliminar cliente {name}", end='')
				input()
				clientName = (i[0])
				pname = ("'"+name+"'")
			
				cursor = con.cursor()
				cursor.execute("delete from operation where clientId=?", [clientId])
				cursor.execute("delete from clientes where clientId=?", [clientId])
				cursor.execute("delete from abono where clientName="+pname+"")
				cursor.execute("drop table "+clientName+";")
				con.commit()
				print("[-] Eliminado exitosamente!")
				print("------------------------\n\n")
				menu() # Regresar al menu Principal
		
			
		except UnboundLocalError:
			print("No existe cliente con ese id!")
			menu()
		
	else:
		print("ID DEBE SER NUMEROS!!!")
		menu()
		
	print("Cliente no existe")
	menu()


# opcion 9 funcion para eliminar productos a cliente de la BD
def eliminar_producto_clientbk():
	print ("\n\n----- ELIMINAR PRODUCTO ----")
	print("Nombre del Cliente > ")
	CN = input(" > ")
	clientId = input("Id del Producto > ")
	#clientId = str(clientId)
	while(not clientId.isdigit()) or len(clientId) >= 3 or len(clientId) == 0:
		if len(clientId) == 0:
			clientId += clientId
			print("Ingrese un Id!")
			clientId = input("Id del Producto > ")
		elif len(clientId) == 0 or clientId >= readchar.key.CR:
			clientId += clientId
			print("Solo ingrese de 1 a 2 digitos")
			clientId = input("Id del Producto > ")
		clientId = str(clientId)

	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	cursor.execute("delete from "+CN+" where clientId=?", [clientId])
	con.commit()
	print("[-] Eliminado producto exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal



# opcion 9 funcion para eliminar productos a cliente de la BD
def eliminar_producto_clientbk():
	print ("\n\n----- ELIMINAR PRODUCTO ----")
	print("Nombre del Cliente > ")
	CN = input(" > ")
	clientId = input("Id del Producto > ")
	#clientId = str(clientId)
	while(not clientId.isdigit()) or len(clientId) >= 3 or len(clientId) == 0:
		if len(clientId) == 0:
			clientId += clientId
			print("Ingrese un Id!")
			clientId = input("Id del Producto > ")
		elif len(clientId) == 0 or clientId >= readchar.key.CR:
			clientId += clientId
			print("Solo ingrese de 1 a 2 digitos")
			clientId = input("Id del Producto > ")
		clientId = str(clientId)

	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	cursor.execute("delete from "+CN+" where clientId=?", [clientId])
	con.commit()
	print("[-] Eliminado producto exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# opcion 9 funcion para eliminar productos a cliente de la BD
def eliminar_producto_clientbk():
	print ("\n\n----- ELIMINAR PRODUCTO ----")
	print("Nombre del Cliente > ")
	CN = input(" > ")
	clientId = input("Id del Producto > ")
	#clientId = str(clientId)
	while(not clientId.isdigit()) or len(clientId) >= 3 or len(clientId) == 0:
		if len(clientId) == 0:
			clientId += clientId
			print("Ingrese un Id!")
			clientId = input("Id del Producto > ")
		elif len(clientId) == 0 or clientId >= readchar.key.CR:
			clientId += clientId
			print("Solo ingrese de 1 a 2 digitos")
			clientId = input("Id del Producto > ")
		clientId = str(clientId)

	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	cursor.execute("delete from "+CN+" where clientId=?", [clientId])
	con.commit()
	print("[-] Eliminado producto exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# opcion 9 funcion para eliminar productos a cliente de la BD
def eliminar_producto_client():
	print ("\n\n----- ELIMINAR PRODUCTO ----")


	clientId = input("Id del Cliente > ")
	if clientId.isdigit() == True:

		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		cursor = con.execute("select clientName from clientes where clientId=?", [clientId])
		for name in cursor:
			clientName = (name[0])
			print(clientName)
			try:
				con = sqlite3.connect("inventory.db")
				cursor1 = con.cursor()
				# Para comprobar si la tabla esta vacia
				cursor1 = con.execute("SELECT count(*) FROM "+clientName+";")
				for ve in cursor1:
					tabla = (ve[0])
					if tabla == 0:
						print("El cliente no tiene productos")
						input()
						menu()
			except UnboundLocalError:
				print("No existe cliente con ese id")
				menu()





			width = os.get_terminal_size().columns
			m = width - 2
			n = int(m)
			print(f"mi pantalla {m}")
			n1 = (0.05 * m)
			n2 = (0.4 * m)
			n3 = (0.35 * m)
			n4 = (0.2 * m)
			mi2 = int(n1)
			md2 = int(n2)
			md3 = int(n3)
			mdi2 = int(n4) - 1
			for ent in range(10, 201, 10):
				if ent == (m):
					md2 = md2 + .5
					#mi2 = mi2 + 1
					#mdi2 = mdi + 1
			for tne in [39, 48, 69, 74, 76, 86, 99, 112, 159]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					#print(md2)
					md2 = md2 + 1
					break
			for tne in [140]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					#print(md2)
					md2 = md2 - 1
					break
			for tne in [35, 39]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					#print(md2)
					md2 = md2 - 2
					mi2 = mi2 + 2
					break
			for tne in [45, 48, 70, 95, 110, 130, 140, 180, 175]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					print(mdi2)
					mdi2 = mdi2 - 1
					break
			for tne in [86]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					print(mdi2)
					mdi2 = mdi2 - 2
					break
			for tne in [83, 76, 143, 206]:
				#print(f"primera tne {tne}")
				#input()
				if tne == m:
					print(mdi2)
					mdi2 = mdi2 - 1
					break




			rows = cursor.execute("select * from "+clientName+"")
			#print("+--+---------------+-------------+-------+")
			#print("|ID|CLIENTE        |ARTICULO     |PRECIO |")
			#print("+--+---------------+-------------+-------+")
			print('+'+'-'*m+'+')
			print('|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:<{mdi2}}|'.format('ID','CLIENTE','PRODUCTO','PRECIO', mi2=mi2,md2=md2,md3=md3,mdi2=mdi2))
			print('+'+'-'*m+'+')

			for r in rows:
				#print(r[0],"|",r[1],"|",r[2],"|",r[3])
				id = (r[0])
				no = (r[1])
				no = no.replace('"','')
				ar = (r[2])
				ar = ar.replace('"','')
				de = (r[3])
				#cadena = "|{:<2}|{:<15}|{:<13}|{:<7}|".format(id, no, ar, de)
				#print(cadena)
				#print("+--+---------------+-------------+-------+")
				cadena = '|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:>{mdi2}}|'.format(id,no,ar,de, mi2=mi2,md2=md2,md3=md3,mdi2=mdi2)
				print(cadena)
				#print("+--+---------------+------------------+-------+")
				print('+'+'-'*m+'+')
				
			#con = sqlite3.connect("inventory.db")
			cursor = con.cursor()
			# tomar la deuda del cliente
			dc = cursor.execute("select price_out from clientes where clientId=?", [clientId])
			for deudac in dc:
				deudac = (deudac[0])
				print(f"deuda {deudac}")
				#input()
			clientId_c = clientId


			clientId = input("Id del Producto > ")
			#input()
			if clientId.isdigit() == True:
				con = sqlite3.connect("inventory.db")
				cursor = con.cursor()
			
				# tomar el precio del producto para luego restarlo a la deuda 
				prep = cursor.execute("select price_out from "+clientName+" where clientId=?", [clientId])
				for pp in prep:
					pp = (pp[0])
						
				td = deudac - pp
				td = str(td)
				print(f"Al quitar product deuda queda en {td}")
				input()
	
				
				
				
				
				#Verificar la existencia de un id
				name2 = cursor.execute("select clientId from "+clientName+" where clientId=?", [clientId])
				for name in name2:
					print(name[0])
					s = (name[0])
					print(s)
					if (name[0]) != 0:
						print("C yes")
						#menu()
						con.execute("update clientes set price_out="+td+" where clientId=?", [clientId_c])
						con.execute("update operation set price_out="+td+" where clientId=?", [clientId_c])

						cursor.execute("delete from "+clientName+" where clientId=?", [clientId])
						con.commit()
						print("[-] Eliminado producto exitosamente!")
						print("------------------------\n\n")
						menu() # Regresar al menu Principal
			print("No existe producto con ese id!")
			menu()
	else:
		print("ID DEBE SER NUMEROS!!!")
		menu()




	print("Cliente no existe")
	menu()



def ver_cliente_abono():
	print("\n\n---- VER ABONOS DE CLIENTE -----")
	clientId = input("Id del Cliente > ")
	if clientId.isdigit() == True:

		width = os.get_terminal_size().columns
		m = width - 2
		n = int(m)
		print(f"mi pantalla {m}")
		n1 = (0.40 * m)
		n2 = (0.20 * m)
		n3 = (0.20 * m)
		n4 = (0.20 * m)
		n4 = n4 - 1
		mi2 = int(n1)
		md2 = int(n2)
		md3 = int(n3)
		mdi2 = int(n4)
		
		con = sqlite3.connect("inventory.db")
		cursor = con.cursor()
		cursor2 = con.cursor()
		name = cursor.execute("select clientName from clientes where clientId = {}".format(clientId))
		for namec in name:
			clientName = (namec[0])
			namef = eval(clientName)
			clientName = ("'"+clientName+"'")
			
			print(namef)
			#input()
			#rows = con.execute("select clientName,abonoName,fechaName,price_in from 'abono' where clientName COLLATE NOCASE LIKE '%"+namef+"%';")
			rows1 = con.execute("select count(*) from abono where clientName="+clientName+"")
			for cl in rows1:
				cl = (cl[0])
				#print(f"aqui {cl}")
				if cl == 0:
					print("Cliente no a hecho abono")
					menu()
			#print("+--+---------------+------------------+-------+")
			#print("|ID|CLIENTE        |ARTICULO          |PRECIO |")
			#print("+--+---------------+------------------+-------+")
			print('+'+'-'*m+'+')
			print('|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:<{mdi2}}|'.format('CLIENTE','TIPO','FECHA','ABONO', mi2=mi2,md2=md2,md3=md3,mdi2=mdi2))
			print('+'+'-'*m+'+')

			# Crear un cursor
			#cursor = conn.cursor()

			# Consulta SQL para seleccionar las columnas deseadas
			#query = "SELECT clientName, abonoName, fechaName, price_in FROM abono"

			# Ejecutar la consulta
			#cursor.execute(query)

			# Recuperar los resultados
			resultados = cursor.fetchall()
			rows = cursor2.execute("select clientName,abonoName,fechaName,price_in from abono where clientName="+clientName+"")
			# Mostrar los resultados
			for abc in rows:
				r = (abc[0])
				s = (abc[1])
				t = (abc[2])
				u = (abc[3])
				r = r.replace('"','')
				s = s.replace('"','')
				t = t.replace('"','')
				#u = u.replace('"','')
				cadena = '|{:<{mi2}}|{:<{md2}}|{:<{md3}}|{:<{mdi2}}|'.format(r,s,t,u, mi2=mi2,md2=md2,md3=md3,mdi2=mdi2)
				print(cadena)
				#print("+--+---------------+------------------+-------+")
				print('+'+'-'*m+'+')
				#print(r, s, t, u)
				# Cerrar la conexion
			con.close()
			menu()

	else:
		print("ID DEBE SER NUMEROS!!!")
		menu()
	print("Cliente no a hecho abono")
	menu()

def buscar_product():
	# Conexion a la basede datos y ejecucion de la consulta
	#print("Ejemplo de busqueda por fecha:\ndia/mes/ano\n01/ene/00")
	pro = input("Buscar Producto > ")
	pro = ('"'+pro+'"')
	pro1 = eval(pro)
	
	conn = sqlite3.connect('inventory.db')
	cursor = conn.cursor()
	cursor2 = conn.cursor()
	cursor3 = conn.cursor()
	cursor4 = conn.cursor()


	# Obtener las tablas
	cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android%';")
	tablas = cursor.fetchall()
	
	terminal_size = os.get_terminal_size().columns
	#print(f"mi pantalla {terminal_size}")
	n1 = int(0.5 * terminal_size)
	n1 = n1 - 2
	n2 = int(0.3 * terminal_size)
	n3 = int(0.2 * terminal_size)
	for dis in range(37, 0, -1):
		if dis == terminal_size:
			n2 = n2 - 2
			break
	print()
	# creando encabezado
	CLI = 'CLIENTE'
	PRO = 'PRODUCTO    '
	PRE = 'PRECIO'
	print_realizado = False
	encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.center(n3)}|"
	long_enc = len(encabezado)
	for longitud in range(1, 399):
		medida = long_enc + longitud
		if medida == terminal_size:
			n3 = n3 + longitud
			encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.ljust(n3)}|"
			#print(encabezado)
			#print_realizado = True
			break
	for longitud in range(1, 399):
		medida = long_enc - longitud
		if medida == terminal_size:
			n2 = n2 - longitud
			encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.rjust(n3)}|"
			#print(encabezado)
			#print_realizado = True
			break

	'''if not print_realizado:
		print("aqui1")
		print_realizado = True
		print(encabezado)
	else:
		print("aqui2")
		#print(encabezado)
		print_realizado = False'''

	# Imprimir las tablas
	suma = []
	total = 0  # inicializar la variable con un valor predeterminado
	for tabla in tablas:
		tabla = (tabla[0])
		tabla = '"'+tabla+'"'  # agregar comillas al nombre de la tabla
		try:
			consulta = "select * from "+tabla+" where productName COLLATE NOCASE LIKE '%"+pro1+"%' order by productName asc;"
			bps = cursor2.execute(consulta)
			#input()
			#consulta = "SELECT * FROM " + tabla + " WHERE fechaName COLLATE NOCASE LIKE '%" + pro1 + "%' order by acs;"
			#print(consulta)

			for prs in bps:
				nam = str(prs[1])
				nam = nam.replace('"','')
				pro = str(prs[2])
				pro = pro.replace('"','')
				pre = str(prs[3])
				fila = f"|{nam.ljust(n1)}|{pro.ljust(n2)}|{pre.rjust(n3)}|"
				if not print_realizado:
					#print("aqui3")
					print(encabezado)
					print_realizado = True
				#else:
					#print(encabezado)

				print(fila)
				try:	
					n = int(prs[3])
				except ValueError:
					n = int(prs[4])
				if prs[3] != None or prs[3] != '0' or prs[4] != None or prs[4] != '0':
					suma.append(n)
					if prs[3] != 0:
						total = sum(suma)
		except sqlite3.OperationalError:
			pass
	
	if total != 0:
		total = str(total)
		v1 = ''
		v2 = 'TOTAL'
		totals = f" {v1.ljust(n1)}|{v2.center(n2)}|{total.rjust(n3)}|"
		long_abono = len(totals)
		for longitud in range(1, 399):
			medida = long_abono + longitud
			if medida == terminal_size:
				n3 = n3 + longitud
				totals = f" {v1.ljust(n1)}|{v2.center(n2)}|{total.rjust(n3)}|"
				print(totals)
				break
		for longitud in range(1, 399):
			medida = long_abono - longitud
			if medida == terminal_size:
				n2 = n2 - longitud
				totals = f" {v1.ljust(n1)}|{v2.center(n2)}|{total.rjust(n3)}|"
				print(totals)
				break
			#if print_realizado:
			#print(abono)

		print(totals)
		# Cerrar la conexion a la base de datos
		conn.close()
		menu()
	else:
		print("No se encontraron registros en las tablas.")
		# Cerrar la conexion a la base de datos
		conn.close()
		menu()

		
def buscar_abono():
	# Conexion a la basede datos y ejecucion de la consulta
	print("Ejemplo de busqueda por fecha:\ndia/mes/ano\n01/ene/00")
	pro = input("Buscar abono > ")
	pro = ('"'+pro+'"')
	pro1 = eval(pro)
	
	conn = sqlite3.connect('inventory.db')
	cursor = conn.cursor()
	cursor2 = conn.cursor()
	cursor3 = conn.cursor()
	cursor4 = conn.cursor()


	# Obtener las tablas
	cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android%';")
	tablas = cursor.fetchall()


	terminal_size = os.get_terminal_size().columns
	#print(f"mi pantalla {terminal_size}")
	n1 = int(0.5 * terminal_size)
	n1 = n1 - 2
	n2 = int(0.3 * terminal_size)
	n3 = int(0.2 * terminal_size)
	for dis in range(37, 0, -1):
		if dis == terminal_size:
			n2 = n2 - 2
			break
	print()
	
	n1 = int(0.5 * terminal_size)
	n1 = n1 - 2
	n2 = int(0.15 * terminal_size)
	n3 = int(0.15 * terminal_size)
	n4 = int(0.2 * terminal_size)
	n4 = n4 - 3
	
	#si la pantalla es de 50 columns o menos
	for dis in range(50, 0, -1):
		if dis == terminal_size:
			n1 = n1 - 2
			n2 = n2 + 2
			n3 = n3 - 1
			break

	# creando encabezado
	CLI = 'CLIENTE'
	TIP = 'TIPO'
	FEC = 'FECHA    '
	ABO = 'ABONO'
	print_realizado = False
	encabezado = f"|{CLI.ljust(n1)}|{TIP.ljust(n2)}|{FEC.center(n3)}|{ABO.rjust(n4)}|"
	long_abono = len(encabezado)
	for longitud in range(1, 399):
		medida = long_abono + longitud
		if medida == terminal_size:
			n3 = n3 + longitud
			encabezado = f"|{CLI.ljust(n1)}|{TIP.ljust(n2)}|{FEC.ljust(n3)}|{ABO.rjust(n4)}|"
			break
	for longitud in range(1, 399):
		medida = long_abono - longitud
		if medida == terminal_size:
			n2 = n2 - longitud
			encabezado = f"|{CLI.ljust(n1)}|{TIP.ljust(n2)}|{FEC.ljust(n3)}|{ABO.rjust(n4)}|"
			break
	#if print_realizado:
		#print(abono)

	#print("No se encontraron registros en las tablas.")
	# Cerrar la conexion a la base de datos
	#conn.close()
	#menu()
	suma = []
	total = 0  # inicializar la variable con un valor predeterminado
	for tabla in tablas:
		tabla = (tabla[0])
		tabla = '"'+tabla+'"'  # agregar comillas al nombre de la tabla
		try:
			consulta = "select * from "+tabla+" where fechaName COLLATE NOCASE LIKE '%"+pro1+"%' order by fechaName asc;"
			bps = cursor2.execute(consulta)
			for prs in bps:
				cli = str(prs[1])
				cli = cli.replace('"','')
				tip = str(prs[2])
				tip = tip.replace('"','')
				fec = str(prs[3])
				fec = fec.replace('"','')
				abo = str(prs[4])
				abono = f"|{cli.ljust(n1)}|{tip.ljust(n2)}|{fec.ljust(n3)}|{abo.rjust(n4)}|" 
				if not print_realizado:
					#print("aqui3")
					print(encabezado)
					print_realizado = True
				print(abono)
				n = int(prs[4])
				if prs[3] != None or prs[3] != '0' or prs[4] != None or prs[4] != '0':
					suma.append(n)
					if prs[3] != 0:
						total = sum(suma)
		except sqlite3.OperationalError:
			pass
	
	if total != 0:
		total = str(total)
		v1 = ''
		v2 = ''
		v3 = 'TOTAL'
		totals = f" {v1.ljust(n1)} {v2.ljust(n2)}|{v3.center(n3)}|{total.rjust(n4)}|"
		long_abono = len(totals)
		for longitud in range(1, 399):
			medida = long_abono + longitud
			if medida == terminal_size:
				n3 = n3 + longitud
				totals = f" {v1.ljust(n1)} {v2.ljust(n2)}|{v3.center(n3)}|{total.rjust(n4)}|"
				print(totals)
				break
		'''for longitud in range(1, 399):
			medida = long_abono - longitud
			if medida == terminal_size:
				n2 = n2 - longitud
				total = f" {v1.ljust(n1)} {v2.ljust(n2)} {v3.center(n3)}|{total.rjust(n4)}|"
				print(total)
				break'''
		#if print_realizado:
		#print(abono)

			
		#print("Total:", total)
		# Cerrar la conexion a la base de datos
		conn.close()
		menu()
	else:
		print("No se encontraron registros en las tablas.")
		# Cerrar la conexion a la base de datos
		conn.close()
		menu()
		
def buscar_nombre():
	# Conexion a la basede datos y ejecucion de la consulta
	print("Ejemplo de busqueda por fecha:\ndia/mes/ano\n01/ene/00")
	pro = input("Buscar Producto > ")
	pro = ('"'+pro+'"')
	pro1 = eval(pro)
	
	conn = sqlite3.connect('inventory.db')
	cursor = conn.cursor()
	cursor2 = conn.cursor()
	cursor3 = conn.cursor()
	cursor4 = conn.cursor()


	# Obtener las tablas
	cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android%';")
	tablas = cursor.fetchall()

	terminal_size = os.get_terminal_size().columns
	#print(f"mi pantalla {terminal_size}")
	n1 = int(0.1 * terminal_size)
	n1 = n1 - 2
	n2 = int(0.7 * terminal_size)
	n2 = n2 - 5
	n3 = int(0.2 * terminal_size)
	for dis in range(37, 0, -1):
		if dis == terminal_size:
			n2 = n2 - 2
			break
	print()
	# creando encabezado
	CLI = 'ID'
	PRO = 'NOMBRE    '
	PRE = 'PRECIO'
	print_realizado = False
	encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.center(n3)}|"
	long_enc = len(encabezado)
	for longitud in range(1, 399):
		medida = long_enc + longitud
		if medida == terminal_size:
			n3 = n3 + longitud
			encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.ljust(n3)}|"
			break
	for longitud in range(1, 399):
		medida = long_enc - longitud
		if medida == terminal_size:
			n2 = n2 - longitud
			encabezado = f"|{CLI.ljust(n1)}|{PRO.ljust(n2)}|{PRE.rjust(n3)}|"
			break
	#print(encabezado)
	#print_realizado = True


	# Imprimir las tablas
	nam = str("0")
	suma = []
	total = 0  # inicializar la variable con un valor predeterminado
	for tabla in tablas:
		tabla = (tabla[0])
		tabla = '"'+tabla+'"'  # agregar comillas al nombre de la tabla
		try:
			consulta = "select * from "+tabla+" where clientName COLLATE NOCASE LIKE '%"+pro1+"%' order by clientName asc;"
			bps = cursor2.execute(consulta)
			#input()
			#consulta = "SELECT * FROM " + tabla + " WHERE fechaName COLLATE NOCASE LIKE '%" + pro1 + "%' order by acs;"
			#print(consulta)
			for prs in bps:
				nam = str(prs[0])
				nam = nam.replace('"','')
				pro = str(prs[1])
				pro = pro.replace('"','')
				pre = str(prs[2])
				fila = f"|{nam.ljust(n1)}|{pro.ljust(n2)}|{pre.rjust(n3)}|"
				if not print_realizado:
					#print("aqui3")
					print(encabezado)
					print_realizado = True
				#else:
					#print(encabezado)

				print(fila)
				'''try:	
					n = int(prs[2])
				except ValueError:
					n = int(prs[2])
				if prs[2] != None or prs[2] != '0' or prs[2] != None or prs[2] != '0':
					suma.append(n)
					if prs[2] != 0:
						total = sum(suma)'''
		except sqlite3.OperationalError:
			pass
	if (nam) == '0':
		print("No se encontraron registros en las tablas.")
		# Cerrar la conexion a la base de datos
	conn.close()
	menu()

	

def buscar():
	# display the available destinations
	print("Available destinations:")
	print("1. Buscar producto")
	print("2. Buscar Abono")
	print("3. Buscar Nombre")

	# get user input for the destination
	destination = input("Where do you want to go? ")

	# use `goto` to go to the selected function
	if destination == "1":
		goto(buscar_product)
	elif destination == "2":
		goto(buscar_abono)
	elif destination == "3":
		goto(buscar_nombre)
	else:
		print("Ingreso invalido. Favor intenta otra vez!.")
		buscar()
# define `goto` function
def goto(label):
	label()

# Llamar al menu por primera vez
menu()

#oredenar por el alfabeto
#select * from clientes order by clientName;

#Para buscar en todas las tablas de la base de datos "mi_base_de_datos.db" donde se encuentra el producto "locion", se puede utilizar la siguiente consulta SQL:
#SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android%';
#Esta consulta retorna una lista con el nombre de todas las tablas de la base de datos, excluyendo aquellas que comienzan con "sqlite_" y "android_". A partir de esta lista, se pueden buscar los registros que contengan la palabra "locion":
#SELECT * FROM nombre_de_la_tabla WHERE columna_que_contiene_el_producto = 'locion';