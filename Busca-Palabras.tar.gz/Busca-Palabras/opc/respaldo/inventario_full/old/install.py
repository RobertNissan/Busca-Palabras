# Powered by Evilnapsis
import sqlite3


con  = sqlite3.connect("inventory.db")
cur = con.cursor()

#cur.execute("drop table product")
cur.execute("create table if not exists product (id integer not null primary key, name varchar(255), price_in double, price_out double, created_at datetime)")
print("[+] Tabla Product")

#operation_type 1: entrada ... 2: salida
#cur.execute("drop table operation")
cur.execute("create table if not exists operation (id integer not null primary key, product_id int, operation_type int, q int, created_at datetime)")
print("[+] Tabla Operation")


