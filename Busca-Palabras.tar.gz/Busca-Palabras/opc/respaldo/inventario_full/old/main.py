import sqlite3

# Funcion para mostrar el menu
# esta funcion se muestra todo el tiempo
def menu():
	i = 0
	while i!=8:
		print("\n\n-----* INVENTORY PY *-------")
		print("-----    MENU    -------")
		print("1. Ver inventario")
		print("2. Agregar a Inventario")
		print("3. Disminuir Inventario")
		print("4. Ver Productos")
		print("5. Agregar Producto")
		print("6. Eliminar Producto ")
		print("7. Salir")
		i = input("\nOpcion > ")
		i = int(i)
		print("Opcion seleccionada:  ", i)
		print("------------------------------")
		if i == 1:
			ver_inventario()
		elif i==2:
			agregar_inventario()
		elif i==3:
			disminuir_inventario()
		elif i==4:
			ver_productos()
		elif i==5:
			agregar_producto()
		elif i==6:
			eliminar_producto()
		elif i==7:
			print("-- [ Powered by Evilnapsis] --")
			exit()
# Funcion para ver el inventario
def ver_inventario():
	print("\n\n---- VER INVENTARIO -----")
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	cursor2 = con.cursor()
	rows = cursor.execute("select * from product")
	print("ID  |  PRODUCTO | EXISTENCIAS ")
	for r in rows:
		entradas = 0
		salidas = 0
		inventario = 0
		entradas_rows = cursor2.execute("select sum(q) as sumx from operation where operation_type=? and product_id=?", (1,r[0]))
		for er in entradas_rows:
			if er[0]!=None:
				entradas = er[0]
		salidas_rows = cursor2.execute("select sum(q) as sumx from operation where operation_type=? and product_id=?", (2,r[0]))
		for sr in salidas_rows:
			if sr[0]!=None:
				salidas = sr[0]
		inventario = entradas - salidas

		print(r[0], "  |  ", r[1], " | ", inventario)

	con.commit()
	print("------------------------\n\n")
	menu() # Regresar al menu principal

# Funcion para agregar cantidades al inventario de un producto
def agregar_inventario():
	print ("\n\n----- AGREGAR INVENTARIO ----")
	id_product = input("Id del Producto > ")
	quantity = input("Cantidad a Agregar > ")
	id_product = str(id_product)
	quantity  = float(quantity)

	con = sqlite3.connect("inventory.db")
	valores = (id_product, quantity, 1)
	con.execute("insert into operation (product_id, q,operation_type) values (?,?,?)", valores)
	con.commit()
	print("[+] Agregado exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# Funcion para Disminuir cantidades o existencias al inventario de un producto
def disminuir_inventario():
	print ("\n\n----- DISMINUIR INVENTARIO ----")
	id_product = input("Id del Producto > ")
	quantity = input("Cantidad a Disminuir > ")
	id_product = str(id_product)
	quantity  = float(quantity)

	con = sqlite3.connect("inventory.db")
	cursor2 = con.cursor()

	entradas = 0
	salidas = 0
	inventario = 0
	entradas_rows = cursor2.execute("select sum(q) as sumx from operation where operation_type=? and product_id=?", (1,id_product))
	for er in entradas_rows:
		if er[0]!=None:
			entradas = er[0]
	salidas_rows = cursor2.execute("select sum(q) as sumx from operation where operation_type=? and product_id=?", (2,id_product))
	for sr in salidas_rows:
		if sr[0]!=None:
			salidas = sr[0]
	inventario = entradas - salidas
	if quantity>inventario:
		print("No se puede dejar Disminuir mas de las existencias")
	else:
		valores = (id_product, quantity, 2)
		con.execute("insert into operation (product_id, q,operation_type) values (?,?,?)", valores)
		con.commit()
	print("[-] Disminuido exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# Funcion para agregar un producto a la base de datos
def agregar_producto():
	print ("\n\n----- AGREGAR PRODUCTO ----")
	name = input("Nombre del Producto > ")
	price_in = input("Precio de Compra > ")
	price_out = input("Precio de Venta > ")
	name = str(name)
	price_in  = float(price_in)
	price_out = float(price_out)
	con = sqlite3.connect("inventory.db")
	valores = (name, price_in, price_out, "NOW()")
	con.execute("insert into product (name, price_in, price_out,created_at) values (?,?,?,?)", valores)
	con.commit()
	print("[+] Agregado exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# Funcion para ver productos
def ver_productos():
	print("\n\n---- VER PRODUCTOS -----")
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	rows = cursor.execute("select * from product")
	print("ID  |  PRODUCTO | EXISTENCIAS ")
	for r in rows:
		print(r[0], "  |  ", r[1], " | ", r[2], " | ", r[3])

	con.commit()
	print("------------------------\n\n")
	menu() # Regresar al menu principal

# Funcion para eliminar productos de la BD
def eliminar_producto():
	print ("\n\n----- ELIMINAR PRODUCTO ----")
	id_product = input("Id del Producto > ")
	id_product = str(id_product)
	con = sqlite3.connect("inventory.db")
	cursor = con.cursor()
	cursor.execute("delete from operation where product_id=?", (id_product))
	cursor.execute("delete from product where id=?", (id_product))
	con.commit()
	print("[-] Eliminado exitosamente!")
	print("------------------------\n\n")
	menu() # Regresar al menu Principal

# Llamar al menu por primera vez
menu()



