import os
import sys
import glob
import time
import zipfile
import platform
import subprocess 
from pathlib import Path

try:
    from colorama import Fore,init
    init()
except ImportError:
    os.system("pip3 install colorama")
system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++ ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End
os.system("clear")
print(banner)
opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)

os.system('if [ -f $PREFIX/bin/7za ]; then echo "Ya existe" >/dev/null 2>&1; else echo "Instalando Repositorio:"; echo -e "Instalando p7zip\n"; pkg install p7zip -y >/dev/null 2>&1; fi')
  
nombre_archivo_txt = 'rocky.txt'
rocky = "PnYFiAhD"
#print(f'https://mega.nz/file/{rocky}#QksksWjXiZm-d2blXxeTHTjUD8ENgfllZRL9hplkRBc')
password_list = input("\nIngrese lista de contrasenas: ")

try:

    with zipfile.ZipFile(password_list, 'r') as zipf:
        password_list = zipf.read(nombre_archivo_txt).decode().splitlines()
        cnt = str(len(password_list))
        print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
    print("Ingrese un archivo dentro de esta carpeta!")
    sys.exit()
 
time.sleep(0.35)
zip_path = input("\nIngrese archivo zip: ")
try:
    file = open(zip_path, 'rb')
    print ("Archivos cargados")
    time.sleep(0.51)
except FileNotFoundError:
    print ("Archivo zip no encontrado!")
    print()
    exit()

def crack_password(password_list):
    count = 1
    for linea in password_list:
        word = str(linea.strip())
        try:
            # Descomprimir el archivo ZIP con contrasena utilizando el comando '7za'  
            print(f"Probar {word}") 
            command = f"7za x -p{word} -y {zip_path} > /dev/null 2>&1"
            subprocess.run(command, shell=True, check=True)
            print("Archivo ZIP descomprimido con exito.")
            return True
        except subprocess.CalledProcessError as e:
            number = count
            print(f'[%s/{cnt}] [-] Contrasena %s fallo\n' % (number, word))
            count += 1
            continue
    return False

if crack_password(password_list) == False:
    print("No hay contrasenas que coincidan!!!")