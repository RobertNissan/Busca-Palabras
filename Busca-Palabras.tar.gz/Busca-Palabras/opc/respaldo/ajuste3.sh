#!/bin/bash

columns=$(tput cols)
col=$(($columns-1))
col2=$(($columns-1))
columns=$(($columns-2))
echo "El ancho de mi terminal es de $columns columnas"
mul=$(($columns*5/100))
echo $mul
mul2=$(($columns*65/100))
echo $mul2
mul3=$(($columns*30/100))
echo $mul3
mul2=$(($mul2+2))
mul3=$(($mul3-5))
# Definimos el ancho maximo de cada columna
ID_WIDTH="$mul"
CLI_WIDTH="$mul2"
DEU_WIDTH="$mul3"

data=( '1' 'Alice Wonder' '1500' '2' 'Bob Dylan' '2500' )

# Define column headers
ID="ID"
CLI="CLIENTES"
DEU="DEUDA"

#printf '\e[1m\e[90m+\e[0m\e[1m\e[90m%-10s\e[0m\e[1m\e[90m+\e[0m\n' "" | tr ' ' "-"

#printf "+%-${columns}s+\n" "" | tr ' ' '\xe2\x95\x90'
printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')" 
printf "#%-${ID_WIDTH}s |%-${CLI_WIDTH}s |%-${DEU_WIDTH}s#\n" "$ID" "$CLI" "$DEU"
#printf "#%s#\n" "$(seq -s '-' $col2 | tr -d '[:digit:]')" 

# Loop through the array and print the data in columns
for ((i=0;i<${#data[@]};i+=3));
do
    printf "#%s#\n" "$(seq -s '-' $col2 | tr -d '[:digit:]')" 

    printf "#%-${ID_WIDTH}s |%-${CLI_WIDTH}s |%-${DEU_WIDTH}s#\n" "${data[i]}" "${data[i+1]}" "${data[i+2]}"
done #| column -t
printf "+%s+\n" "$(seq -s '-' $col | tr -d '[:digit:]')" 
#printf "+%-${columns}s+\n" "" | tr ' ' "-"
