#!/bin/bash

columns=$(tput cols)
columns=$(($columns-2))
echo "El ancho de mi terminal es de $columns columnas"
mul=$(($columns*10/100))
echo $mul
mul2=$(($columns*65/100))
echo $mul2
mul3=$(($columns*30/100))
echo $mul3
mul3=$(($mul3-5))
# Definimos el ancho maximo de cada columna
ID_WIDTH="$mul"
CLI_WIDTH="$mul2"
DEU_WIDTH="$mul3"

data=( '1' 'Alice Wonder' '1500' '2' 'Bob Dylan' '2500' )

# Define column headers
ID="ID"
CLI="CLIENTES"
DEU="DEUDA"

# Column headers
#printf "%-${columns}""-\n"
#columns2=$(tput cols)

#f=$(printf "%-${columns}s |\n" "" | tr ' ' ' ')

printf "+%-${columns}s+\n" "" | tr ' ' '-'
printf "|%-${ID_WIDTH}s |%-${CLI_WIDTH}s |%-${DEU_WIDTH}s|\n" "$ID" "$CLI" "$DEU"

# Loop through the array and print the data in columns
for ((i=0;i<${#data[@]};i+=3));
do
    printf "|%-${ID_WIDTH}s |%-${CLI_WIDTH}s |%-${DEU_WIDTH}s|\n" "${data[i]}" "${data[i+1]}" "${data[i+2]}"
    #echo -n "${data[i]}" | awk '{printf "%-'$ID_WIDTH's", $0}'
    #echo -n "${data[i+1]}" | awk '{printf "%-'$CLI_WIDTH's", $0}'
    #echo -n "${data[i+2]}" | awk '{printf "%-'$DEU_WIDTH's", $0}'
done #| column -t
printf "+%-${columns}s+\n" "" | tr ' ' "-"
