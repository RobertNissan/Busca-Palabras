#!/bin/sh
# Buscando la ip Android con wifi activado
export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export blanco='\033[37m'

vav_dos_com() {
mkdir -p /sdcard/Alarms/ >/dev/null 2>&1

echo -e "$verde[${blanco}*${verde}] ${blanco}Verificando si existen archivos vacios!"
cd /sdcard/Alarms/Busca-Palabras/
vac=$(find -type f -size 0b -print0 | xargs -0I file ls -v file);if [ "$vac" == "" ]; then  echo -e "$verde[$blanco+$verde] ${blanco}El proyecto esta completo!\n"; else echo "OK" >/dev/null 2>&1; echo -e "$verde[$blanco-$verde]${amarillo} Existen archivo/s vacios"; echo -e "${rojo}$vac$blanco"; exit; fi


cd
echo -e "$verde[$blanco*$verde] ${blanco}Convirtiendo archivos necesarios a dos2unix!$blanco"
dos2unix /sdcard/Alarms/Busca-Palabras/opc/team-droid.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras-V2/opc/team-droid.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/contrasena-cod.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras-V2/opc/contrasena-cod.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/active.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/sdcardBusca-Palabras-V2/opc/active.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras-V2/opc/whatsapp-backup.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras-V2/opc/Adivinado-21.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/opcion-send-llaves/llave-dropbox/bot-father.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/soundwire.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/voz.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/lista-server.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/scp.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/scpscan.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/memory.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/config-ta.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/ver_url/multi_tunel/ver_url_global.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/config/* >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/hack.sh >/dev/null 2>&1

dos2unix /sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh >/dev/null 2>&1

echo -e "$verde[$blanco+$verde] ${blanco}Archivos convertidos!\n"

if [ -f $PREFIX/bin/zip ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo -e "$verde[$blanco*$verde] ${blanco}Instalando Repositorios zip:"
echo -e "" 
echo -e "$verde[$blanco+$verde] ${blanco}Instalando zip"
pkg install zip >/dev/null 2>&1
fi

cd /sdcard/Alarms/
rm -r Busca-Palabras.zip >/dev/null 2>&1
echo -e "$verde[$blanco*$verde] ${blanco}Comprimiendo proyecto!"
zip -r9 Busca-Palabras.zip Busca-Palabras >/dev/null 2>&1
if [ -e /sdcard/Alarms/Busca-Palabras.zip ]; then 
echo -e "$verde[$blanco+$verde] ${blanco}Compresion completada!\n"
else
echo -e "Hubo un error en la compresion!"
echo "Vuelva a intentar!"
exit
fi

#rm -r /sdcard/Alarms/BPZIP/Busca-Palabras-V2.zip >/dev/null 2>&1
#cd /sdcard/Alarms/
#zip -r9 Busca-Palabras-V2.zip Busca-Palabras-V2
}

sube_ftp() {

ftp -inv files.000webhost.com<<FINFTP
       user robertomeza $llave
       binary
       lcd /sdcard/Alarms/
       cd /Busca-Palabras/
       send Busca-Palabras.zip
       bye
FINFTP

}

PWD=$(pwd)
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl -s ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
vav_dos_com
sleep 2
exit
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
vav_dos_com
sleep 2 
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
vav_dos_com
sleep 2 
exit
fi
fi 

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
vav_dos_com
sleep 2 

# Si esta conectado a wifi, haz esto segundo
else
esd=a
secret=$(echo "TGxhdmU4NFNlY3JldGEK" | base64 -d)
while [ "$esd" == "a" ]; do
clear
bwhs=$(grep -En "$secret" ${PWD}/respaldo_v2.sh | head -n 1 | awk '{print $4}')
if [[ "$bwhs" = "$secret" ]]; then
disco=sdext
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${verde}+------------------------+
# $blanco"Ingrese su contrasena:" ${verde}#
+------------------------+
+->>> "${blanco}
read -r disco
clear
#verificar si hay algo escrito 
while [ -z "$disco" ]; do
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${verde}+------------------------+
# $blanco"Ingrese su contrasena:" ${verde}#
+------------------------+
+->>> "${blanco}
read -r disco
done
fi

if [ "$disco" == "$secret" ]; then
#-------------------------------------------------------------------------
A=$(grep -EIris 'user' ${PWD}/respaldo_v2.sh | head -n 1 | awk '{print $3}') 
if [ "$A" = '\$llave' ]; then 
sed -i "s%$A%$disco%g" ${PWD}/respaldo_v2.sh
fi
#-------------------------------------------------------------------------
B=$(grep -EIris 'user' ${PWD}/respaldo_v2.sh | head -n 1 | awk '{print $3}')
if [ "$B" != "$secret" ]; then 
sed -i "s%$B%$disco%g" ${PWD}/respaldo_v2.sh 
fi
#-------------------------------------------------------------------------
C=$(grep -EIris "disco=sdext" ${PWD}/respaldo_v2.sh  | head -n 1) 

D=$(echo "$C" | cut -d' ' -f4)
sed -i "s%$D%disco=$disco%g" ${PWD}/respaldo_v2.sh 
#-------------------------------------------------------------------------
echo -e ""
clear
echo -e ""${verde}[${blanco}+${verde}] ${blanco}Contrasena correcta!!! "\e[1;34m"$disco"\e[0m\n"
llave="$disco"

vav_dos_com
echo -e "$verde[$blanco*$verde] ${blanco}Subiendo proyecto a files.000webhost.com!"

sube_ftp >/dev/null 2>&1

echo -e "$verde[$blanco+$verde] ${blanco}Proyecto subido a files.000webhost.com!\n"
exit
 
else
clear
echo -e ""
echo -e "${verde}[${blanco}-${verde}] ${rojo}Contrasena incorrecta$blanco"
read
esd=a
fi
done
fi