#!/bin/bash
# 01/10/2021
#Robert_Nissan
#COLORES
rojo='\e[1m\e[31m'
verde='\e[1m\e[32m'
white="\e[1;37m\e[0m"
amarillo='\e[1m\e[33m'
azulcielo='\e[1m\e[36m'
echo -e ""$verde"=-=-=-=(PERMISOS DE ALMACENAMIENTO)=-=-=-="
sleep 2;termux-setup-storage;sleep 2;echo -e "";echo -e ""$azulcielo"******Permisos Concedidos******";sleep 2;echo -e "";echo -e ""$amarillo"<>=<>=<>=INSTALANDO DEPENDENCIAS=<>=<>=<>";sleep 2;


if [ -x ${PREFIX}/bin/tsu ]
then
echo Repositorio tsu
echo Ya existe
else 
echo "Instalando tsu"
apt install tsu -y
fi


if [ -x ${PREFIX}/bin/fish ]
then
echo Repositorio fish
echo Ya existe
else 
echo "Instalando fish"
apt install fish -y
fi

if [ -x ${PREFIX}/bin/expect ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando expect"
apt-get -y install expect
fi

if [ -x $PREFIX/share/doc/iproute2 ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando iproute2"
pkg install iproute2
fi

echo -e "";echo -e ""$white"   **(DESCARGANDO SCRIPT BUSCA-PALABRAS)**    ";sleep 1.5;wget https://www.dropbox.com/s/tbax6noq438syui/Busca-Palabras.zip?dl=0;mv Busca-Palabras.zip?dl=0 Busca-Palabras.zip;unzip Busca-Palabras.zip;rm -r Busca-Palabras.zip;cd Busca-Palabras;chmod +x Menu-Busca-Palabras.sh;dos2unix Menu-Busca-Palabras.sh;bash Menu-Busca-Palabras.sh;cd ${HOME}/Busca-Palabras/;fish