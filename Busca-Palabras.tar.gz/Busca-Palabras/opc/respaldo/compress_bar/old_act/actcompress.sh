#!/usr/bin/expect
spawn ./compressbar.sh
send 1\r
interact
