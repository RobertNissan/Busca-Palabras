import os
import sqlite3
import subprocess

'''clients = [
	['1', 'Alice Wonder', '500'],
	['2', 'Bob Dylan', '2500'],
	['3', 'Robert Meza', '100000'],
	['10', 'Robert Nissan', '10000']
]'''

# Conectar a la base de datos
conn = sqlite3.connect('inventory.db')
c = conn.cursor()

# Seleccionar todos los registros de la tabla "clientes"
c.execute("SELECT * FROM clientes")
clients = c.fetchall()


terminal_size = os.get_terminal_size().columns #// 3
print(f"mi pantalla {terminal_size}")
n1 = int(0.1 * terminal_size)
n1 = n1 - 3
n2 = int(0.7 * terminal_size)
n2 = n2 - 7
n3 = int(0.2 * terminal_size)
n3 = n3 - 4

sd = f"+"+"-"*(terminal_size - 8)+"+\n"
table = f"| {'ID':<{n1}} | {'CLIENTES':{n2}} | {'DEUDA':{n3}} |\n"
table += (sd)

for client in clients:
    id_, clien, deuda = client
    clien = clien.replace('"','')
    table += f"| {id_:<{n1}} | {clien:{n2}} | {deuda:>{n3}} |\n"
    table += (sd)
ni = ''
ni = str(ni)

total_rows = c.execute("select sum(price_out) from operation")
for it in total_rows:
    total = (it[0])
    total = str(it[0])
    try:

        tin = 'INVENTARIO-TOTAL'
        #table += (sd)
        table += f"  {ni.ljust(n1)} | {tin.center(n2)} | {total.rjust(n3)} |\n"
        #print(total)
        #con.commit()
    except TypeError:
        print("No hay datos en la tabla!")


os.system("clear")
'''subprocess.call([
    'dialog',
    '--title', 'Lista de clientes',
    '--stdout',
    '--no-collapse',
    '--no-lines',
    '--ok-label', 'SALIR',
    '--msgbox', f"{table}",
    '0', '0'
])'''



'''subprocess.call([
    'dialog',
    '--backtitle', 'Tabla de clientes',
    '--stdout',
    '--no-collapse',
    '--no-lines',
    '--ok-label', 'SALIR',
    '--scrolltext',
    '--keep-window',
    '--msgbox', f"{table}",
    '0', '0'
])'''


#whiptail --title "TERMINOS Y CONDICIONES" --textbox --scrolltext f"{table}" 0 0

#whiptail_cmd = ['whiptail', '--title', 'Clientes', '--scrolltext', '--msgbox', '']
#for cliente in table:
    #whiptail_cmd[3] += '\n'.join(cliente) + '\n\n


cmd = f"whiptail --msgbox --scrolltext '{table}' 0 0"
subprocess.call(cmd, shell=True)

#subprocess.call(whiptail --msgbox  --scrolltext "+table+" 0 0)
#subprocess.call(whiptail_cmd, shell=False)


'''height = 10
width = 20
cmd = f" (echo '{table}' | whiptail --title 'Tabla de operaciones' --scrolltext --no-button \
        --scrolltext {height} {width} 22); "
os.system(cmd)'''
