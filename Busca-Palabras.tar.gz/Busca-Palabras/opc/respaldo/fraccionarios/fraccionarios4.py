from fractions import Fraction

# Manejamos los errores para la entrada del usuario
while True:
    try:
        # Pedimos al usuario cuantas fracciones quiere ingresar
        n = int(input("Ingrese la cantidad de fracciones que quiere sumar: "))
        if n <= 0:
            raise ValueError("Debe ingresar un numero mayor que cero")
        break
        '''except ValueError as e:
        print("Error: " + str(e)):'''
    except ValueError:
        print("Error: ingrese un numero entero")

# Creamos una lista para guardar las fracciones ingresadas    
frac_list = []

# Pedimos y guardamos cada fraccion ingresada por el usuario
for i in range(n):
    while True:
        try:
            frac_str = input("Ingrese la fraccion en formato num/den: ")
            frac = Fraction(frac_str)
            break
        except ValueError:
            print("Error: debe ingresar la fraccion en formato num/den")

    frac_list.append(frac)

# Sumamos todas las fracciones ingresadas
res = sum(frac_list)

# Si el resultado es un numero entero, lo imprimimos sin convertirlo a un numero real
if res.denominator == 1:
    print(res.numerator)
    
# Si el resultado es una fraccion, lo convertimos a un numero real y lo imprimimos
else:
    print(float(res))
