from fractions import Fraction
import math

fracciones = input('Ingrese las fracciones separadas por espacios: \n').split()
fracciones = [Fraction(fraccion) for fraccion in fracciones]
suma = sum(fracciones)
entero = int(suma) + 1

# Obtener fracciones faltantes
faltantes = []
fracciones.sort()
fraccion_actual = Fraction(0)
for fraccion in fracciones:
    if math.isclose(fraccion_actual + fraccion, 1, rel_tol=0.0001):
        break
    elif fraccion_actual + fraccion < 1:
        fraccion_actual += fraccion
    else:
        fraccion_faltante = Fraction(1) - fraccion_actual
        faltantes.append(fraccion_faltante)
        fraccion_actual = fraccion_faltante

if math.isclose(fraccion_actual, 1, rel_tol=0.0001):
    pass
elif fraccion_actual < 1:
    faltantes.append(Fraction(1) - fraccion_actual)

# Dividir fracciones faltantes por la mitad
fracciones_completas = []
for fraccion_faltante in faltantes:
    fracciones_divididas = []
    fraccion_actual = Fraction(4, 4)
    while fraccion_faltante > 0:
        if math.isclose(fraccion_faltante, 0, rel_tol=0.0001):
            break
        elif math.isclose(fraccion_faltante, fraccion_actual, rel_tol=0.0001):
            fracciones_divididas.append(fraccion_actual)
            break
        elif fraccion_faltante >= fraccion_actual:
            fracciones_divididas.append(fraccion_actual)
            fraccion_faltante -= fraccion_actual
        else:
            fraccion_actual /= 2

    print(f'Para completar el numero natural {entero},\nfaltan las siguientes partes:')
    print_realizado = False

    for fraccion_dividida in fracciones_divididas:
        if isinstance(fraccion_dividida, Fraction):
            print(fraccion_dividida)
            if not (fraccion_dividida in fracciones_completas):
                fracciones_completas.append(fraccion_dividida)

print(f'La suma de las partes ingresadas es: {suma}')

print(f'Las siguientes son las partes que completan el numero natural {entero}:')
for i in range(len(fracciones_completas)):
    for j in range(i+1,len(fracciones_completas)):
        if (fracciones_completas[i] + fracciones_completas[j]) == (entero - suma):
            print(f'{fracciones_completas[i]} y {fracciones_completas[j]}')
