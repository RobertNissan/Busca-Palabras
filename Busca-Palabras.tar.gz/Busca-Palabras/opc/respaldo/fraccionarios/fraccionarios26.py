from fractions import Fraction

def fracciones_faltantes(frac_suma):
    """Calcula todas las fracciones faltantes para completar un numero natural."""

    if frac_suma >= 1:
        return []

    fraccion_falta = Fraction(1, 2)
    fracciones_faltantes_list = []
    while frac_suma < 1:
        if frac_suma + fraccion_falta > 1:
            fraccion_falta /= 2
            continue

        fracciones_faltantes_list.append(fraccion_falta)
        frac_suma += fraccion_falta
        fraccion_falta /= 2

    return fracciones_faltantes_list

while True:
    try:
        frac_str = input("Ingrese las fracciones separadas por espacios: ")
        frac_list = [Fraction(f) for f in frac_str.split()]

        res = sum(frac_list)

        if res.denominator == 1:
            #print(f"El resultado es un numero natural: {res.numerator}")
            print(res.numerator)
            break
        elif res > 1:
            print(f"1El resultado es: {res}")
            fracciones_faltantes_list = fracciones_faltantes(res - 1)
            frac_str = " y ".join(str(f) for f in fracciones_faltantes_list)
            print(f"Para completar un numero natural y obtener {res}, debe agregar las siguientes fracciones: {frac_str}")
        else:
            print(f"2El resultado es: {res}")
            fracciones_faltantes_list = fracciones_faltantes(res)

            if not fracciones_faltantes_list:
                print("No hace falta ninguna fraccion para completar un numero natural.")
            else:
                frac_str = " y ".join(str(f) for f in fracciones_faltantes_list)
                print(f"Hace falta agregar las siguientes fracciones para completar un numero natural: {frac_str}")

        if res.numerator == 5 and res.denominator == 2 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/2")
            res += Fraction(1, 2)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        if res.numerator == 7 and res.denominator == 2 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/2")
            res += Fraction(1, 2)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        if res.numerator == 13 and res.denominator == 4 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/2 1/4")
            res += Fraction(3, 4)
            print(f"El resultado de sumar todas las fracciones es: {res}")
            
        if res.numerator == 25 and res.denominator == 8 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/8 1/4 1/2")
            res += Fraction(7, 8)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        if res.numerator == 49 and res.denominator == 16 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/16 1/8 1/4 1/2")
            res += Fraction(15, 16)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        if res.numerator == 97 and res.denominator == 32 and not fracciones_faltantes_list:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/16 1/8 1/4 1/2")
            res += Fraction(31, 32)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        suma_fracs = sum(frac_list) + sum(fracciones_faltantes(res))
        

        if suma_fracs == Fraction(4):
          print("La suma de todas las fracciones ingresadas mas la faltante es igual a 4")
          if not (Fraction(1,2) in fracciones_faltantes(res)):
            #print("La fraccion faltante es 1/2")
            pass
          else:
            print("No hace falta agregar ninguna otra fraccion para completar un numero natural.")
          #break
        
    except ValueError as e:
          print(f"Error: {e}")
