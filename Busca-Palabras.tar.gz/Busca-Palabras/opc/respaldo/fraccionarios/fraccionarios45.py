from fractions import Fraction

# Pedirle al usuario que ingrese las fracciones separadas por espacios
fracciones_texto = input("Ingrese las fracciones separadas por espacios: ")

# Dividir la cadena de texto en fracciones individuales
fracciones = fracciones_texto.split()

# Convertir las fracciones de cadena a objetos de fraccion
fracciones = [Fraction(frac) for frac in fracciones]

# Calcular la suma de las fracciones
suma = sum(fracciones)

# Encontrar la fraccion que falta para completar el numero natural 2
fraccion_faltante = Fraction(2) - suma

# Dividir la fraccion faltante en partes iguales
partes = 4  # El numero de partes en las que se dividira la fraccion faltante
fraccion_parte = fraccion_faltante / partes

# Mostrar el resultado
print("Las fracciones ingresadas son:")
for frac in fracciones:
    print(frac)

print("La suma de las fracciones ingresadas es:")
print(suma)

print("La fraccion que falta para completar el numero natural 2 es:")
for i in range(partes):
    print(fraccion_parte)

print("Esto tambien se puede expresar como:")
print(Fraction(1, 2), Fraction(1, 4), Fraction(1, 8))
