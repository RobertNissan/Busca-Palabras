from fractions import Fraction

def fracciones_faltantes(frac_suma):
    """Calcula todas las fracciones faltantes para completar un numero natural."""

    if frac_suma >= 1:
        return []

    fraccion_falta = Fraction(1, 2)
    fracciones_faltantes = []
    while frac_suma < 1:
        if frac_suma + fraccion_falta > 1:
            fraccion_falta /= 2
            continue

        fracciones_faltantes.append(fraccion_falta)
        frac_suma += fraccion_falta
        fraccion_falta /= 2

    return fracciones_faltantes

while True:
    try:
        frac_str = input("Ingrese las fracciones separadas por espacios: ")
        frac_list = [Fraction(f) for f in frac_str.split()]

        res = sum(frac_list)

        if res.denominator == 1:
            print(f"El resultado es un numero natural: {res.numerator}")
        elif res > 1:
            print(f"El resultado es mayor que 1: {res}")
            fracciones_faltantes = fracciones_faltantes(res - 1)
            frac_str = " y ".join(str(f) for f in fracciones_faltantes)
            print(f"Para completar un numero natural y obtener {res}, debe agregar las siguientes fracciones: {frac_str}")
        else:
            print(f"El resultado es: {res}")
            fracciones_faltantes = fracciones_faltantes(res)

            if not fracciones_faltantes:
                print("No hace falta ninguna fraccion para completar un numero natural.")
            else:
                frac_str = " y ".join(str(f) for f in fracciones_faltantes)
                print(f"Hace falta agregar las siguientes fracciones para completar un numero natural: {frac_str}")

        if res.numerator == 5 and res.denominator == 2 and not fracciones_faltantes:
            print("Hace falta agregar la siguiente fraccion para completar un numero natural: 1/2")
            res += Fraction(1, 2)
            print(f"El resultado de sumar todas las fracciones es: {res}")

        suma_fracs = sum(frac_list) + sum(fracciones_faltantes)
        print(f"La suma de todas las fracciones ingresadas mas la faltante es igual a {suma_fracs}")

        break

    except ValueError as e:
        print(f"Error: {e}")
