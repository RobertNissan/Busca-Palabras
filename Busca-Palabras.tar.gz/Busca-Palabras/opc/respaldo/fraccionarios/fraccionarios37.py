from fractions import Fraction

fracciones = input('Ingrese las fracciones separadas por espacios: \n').split()
fracciones = [Fraction(fraccion) for fraccion in fracciones]
suma = sum(fracciones)
entero = int(suma) + 1

# Obtener fracciones faltantes
faltantes = []
fracciones.sort()
fraccion_actual = Fraction(0)
for fraccion in fracciones:
    if fraccion_actual + fraccion < 1:
        fraccion_actual += fraccion
    else:
        fraccion_faltante = Fraction(1) - fraccion_actual
        faltantes.append(fraccion_faltante)
        fraccion_actual = fraccion_faltante
if fraccion_actual < 1:
    faltantes.append(Fraction(1) - fraccion_actual)

# Dividir fracciones faltantes por la mitad
for i, fraccion_faltante in enumerate(faltantes):
    numerador_nuevo = fraccion_faltante.numerator
    denominador_nuevo = fraccion_faltante.denominator * 1 if fraccion_faltante == faltantes[-1] else fraccion_faltante.denominator
    faltantes[i] = Fraction(numerador_nuevo, denominador_nuevo)

print(f'Para completar el numero natural {entero}, faltan las fracciones:')
for i in range(len(faltantes)):
    if i == len(faltantes) - 1:
        print(f'{faltantes[i]}')
    else:
        print(f'{faltantes[i]}', end=' ')
print()
