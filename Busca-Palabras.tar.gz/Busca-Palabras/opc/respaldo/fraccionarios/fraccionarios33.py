from fractions import Fraction

fracciones = input('Ingrese las fracciones separadas por espacios: ').split()
fracciones = [Fraction(fraccion) for fraccion in fracciones]

suma = sum(fracciones)
entero = int(suma) + 1

# Obtener fracciones faltantes
faltantes = []
fracciones.sort()
fraccion_actual = Fraction(0)
for fraccion in fracciones:
    if fraccion_actual + fraccion < 1:
        fraccion_actual += fraccion
    else:
        fraccion_faltante = Fraction(1) #- fraccion_actual
        faltantes.append(fraccion_faltante)
        fraccion_actual = fraccion_faltante
if fraccion_actual < 1:
    faltantes.append(Fraction(1) - fraccion_actual)

# Dividir fracciones faltantes por la mitad
for fraccion_faltante in faltantes:
    mitad_mixto = 0
    mitad_fraccion = Fraction(0)
    if fraccion_faltante >= 1:
        mitad_mixto = int(fraccion_faltante / 2)
        mitad_fraccion = Fraction(fraccion_faltante % 2)
    else:
        mixto = fraccion_faltante.numerator // fraccion_faltante.denominator
        fraccion = Fraction(fraccion_faltante.numerator % fraccion_faltante.denominator, fraccion_faltante.denominator)

        mitad_mixto = mixto // 2
        mitad_fraccion = Fraction(4, 4) * fraccion

        if mitad_fraccion >= 0.5:
            mitad_mixto += 1
            mitad_fraccion -= Fraction(4, 4)

    print(f'La suma de las fracciones ingresadas es: {suma}')
print(f'Para completar el numero natural {entero}, faltan las fracciones:')
# Dividir las fracciones faltantes por la mitad y agregarlas a la lista de fracciones existente.
for i in range(len(faltantes)):
    mitad_fraccion_faltante = faltantes[i] / 1
    while mitad_fraccion_faltante > 0:
        if mitad_fraccion_faltante >= 0.8:
            mitad_fraccion_faltante -= Fraction(8, 8)
            #print(Fraction(1, 2))
            print(mitad_fraccion)
        else:
            print(mitad_fraccion_faltante)
            mitad_fraccion_faltante -= Fraction(4, 4) #mitad_fraccion_faltante
