from fractions import Fraction

def fracciones_faltantes(frac_suma):
    """Calcula todas las fracciones faltantes para completar un numero natural."""

    if frac_suma >= 1:
        return []

    fraccion_falta = Fraction(1, 2)
    fracciones_faltantes = []
    while frac_suma < 1:
        if frac_suma + fraccion_falta > 1:
            fraccion_falta /= 2
            continue

        fracciones_faltantes.append(fraccion_falta)
        frac_suma += fraccion_falta
        fraccion_falta /= 2

    return fracciones_faltantes

while True:
    try:
        n = int(input("Ingrese la cantidad de fracciones que quiere sumar: "))
        if n <= 0:
            raise ValueError("Debe ingresar un numero mayor a cero.")

        frac_list = []
        for i in range(n):
            while True:
                try:
                    frac_str = input("Ingrese la fraccion en formato num/den: ")
                    frac = Fraction(frac_str)
                    break
                except ValueError:
                    print("Error: debe ingresar la fraccion en formato num/den.")

            frac_list.append(frac)

        res = sum(frac_list)

        if res.denominator == 1:
            print(f"El resultado es un numero natural: {res.numerator}")
        elif res > 1:
            print(f"El resultado es mayor que 1: {res}")
            fracciones_faltantes = fracciones_faltantes(res - 1)
            frac_str = " y ".join(str(f) for f in fracciones_faltantes)
            print(f"Para completar un numero natural y obtener {res}, debe agregar las siguientes fracciones: {frac_str}")
        else:
            print(f"El resultado es: {res}")
            fracciones_faltantes = fracciones_faltantes(res)

            if fracciones_faltantes:
                frac_str = " y ".join(str(f) for f in fracciones_faltantes)
                print(f"Hace falta agregar la siguiente fraccion para completar un numero natural: {frac_str}")
            else:
                print("No hace falta ninguna fraccion para completar un numero natural.")

        if fracciones_faltantes:
            res_con_faltantes = sum(frac_list + fracciones_faltantes)
            print(f"El resultado con las fracciones faltantes es: {res_con_faltantes}")

        break

    except ValueError as e:
        print(f"Error: {e}")
