#!/bin/sh

export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export blanco='\033[37m'

if [ `pidof proot` ]; then
echo "Por favor no comprima el zip en distro termux-chroot"
usuario_termux=$(whoami)
#killall -u $usuario_termux
exit
fi
if [ -f $PREFIX/bin/pv ]; then
echo "Existe" >/dev/null 2>&1
else
echo "Instalando pv"
pkg install pv >/dev/null 2>&1
fi

vav_dos_com_rec() {

contador=0
dir="/sdcard/Alarms/Busca-Palabras"
while true; do
    if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
        find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
            echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        #echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        #exit
        break
    fi

    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}

vav_dos_com() {

mkdir -p /sdcard/Alarms/ >/dev/null 2>&1
contador=0
dir="/sdcard/Alarms/Busca-Palabras"
while true; do
    if [ "$(find /sdcard/Alarms/Busca-Palabras -type f -empty)" ]; then
        find "$dir" -type f -empty | while read file; do
            if [ $contador -eq 0 ]; then
            echo "Arreglando archivos vacios."
            fi 
            echo -e "$rojo$(echo $file | sed 's/\/sdcard\/Alarms\///')$blanco"
            backup_file="/sdcard/backups/Busca-Palabras/${file#/sdcard/Alarms/Busca-Palabras/}"
            if [ -f "$backup_file" ]; then
                #echo -e "Reemplazando $file con $backup_file"
                cp "$backup_file" "$file"
            else
                echo "No se encontro un archivo de respaldo para $file."
            fi
            contador=$((contador+1))
        done
    else
        #echo "No hay archivos vacios en /sdcard/Alarms/Busca-Palabras."
        #exit
        break
    fi

    #echo "Regresando al inicio para verificar si hay mas archivos vacios."
    cd /sdcard/Alarms/Busca-Palabras/
done
}



convert() {

array=("/sdcard/Alarms/Busca-Palabras/opc/scp.sh"
"/sdcard/Alarms/Busca-Palabras/opc/voz.sh"
"/sdcard/Alarms/Busca-Palabras/opc/hack.sh"
"/sdcard/Alarms/Busca-Palabras/opc/active.sh"
/sdcard/Alarms/Busca-Palabras/opc/config/*
"/sdcard/Alarms/Busca-Palabras/opc/memory.sh"
"/sdcard/Alarms/Busca-Palabras/opc/scpscan.sh"
"/sdcard/Alarms/Busca-Palabras/opc/config-ta.sh"
"/sdcard/Alarms/Busca-Palabras/opc/soundwire.sh"
"/sdcard/Alarms/Busca-Palabras/opc/ssh_remote.sh"
"/sdcard/Alarms/Busca-Palabras/opc/tasker-bot.sh"
"/sdcard/Alarms/Busca-Palabras/opc/team-droid.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/ngrok_menu.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Adivinado-21.sh"
"/sdcard/Alarms/Busca-Palabras/opc/lista-server.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_nginx/nginx.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_tlssh/tlssh.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_loclx/install.sh"
"/sdcard/Alarms/Busca-Palabras/opc/Ngrok/termux_clfld/install.sh"
"/sdcard/Alarms/Busca-Palabras/opc/multi_tunel_ver_url_global.sh")

#ns=($(for i in "${array[@]}"; do echo "${#i}:$i"; done | sort -n | cut -d':' -f2-))
#echo "${ns[@]}"
#read

ns=($(for i in "${array[@]}"; do 
nam=($(basename ${i}))
name=$(echo -e  "${nam}")
num=$(echo -n "${name}" | wc -c)
echo -e "${num}:$name"
done | sort -n -k2 | cut -d' ' -f1- && echo ""))

size=${#ns[@]}
ns=($(printf '%s\n' "${ns[@]}" | awk '{print length, $0}' | sort -n | cut -d " " -f2- && echo ""))
count=0
total=${#ns[@]}

#for ((i=0; i<$size; i++)); do
for i in "${ns[@]}"; do
#>/dev/null 2>&1
    sleep .05
    ((count++))
    progress=$((count * 100 / total))
    #echo -e "${i}"
    name=$(echo "${i##*:}")
    dos2unix ${array} >/dev/null 2>&1
    #echo -e ""
    echo -ne "\r[${progress}%] ${name}"
done #| sort -n | cut -d' ' -f1-
}



pack_proyect() {

cd
echo -e "$verde[$blanco*$verde] ${blanco}Convirtiendo archivos necesarios a dos2unix!$blanco"

convert
echo -e ""
echo -e "$verde[$blanco+$verde] ${blanco}Archivos convertidos!\n"

if [ -f $PREFIX/bin/zip ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo -e "$verde[$blanco*$verde] ${blanco}Instalando Repositorios zip:"
echo -e "" 
echo -e "$verde[$blanco+$verde] ${blanco}Instalando zip"
pkg install zip >/dev/null 2>&1
fi

vav_dos_com_rec
cd /sdcard/Alarms/
rm -r Busca-Palabras.tar.gz >/dev/null 2>&1
rm -rf .compress.txt >/dev/null 2>&1
cd Busca-Palabras

varX=$(find . -type d -iname "*" -print | cut -c 3- | wc -l)
varY=$(find . -type f -iname "*" -print | cut -c 3- | wc -l)
let suma=$varX+$varY

cd ..

tar -zcvf Busca-Palabras.tar.gz Busca-Palabras >/dev/null 2>&1 > .compress.txt &

#captura el CTRL+C
function handler() 
{
  #echo Hey, received signal : SIGINT 
  kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
  kill ${kill} >/dev/null 2>&1
  cd /sdcard/Alarms/
  rm -rf .compress.txt Busca-Palabras.tar.gz .not_int.txt >/dev/null 2>&1
  echo -e ""
  echo processo detinido...
  #echo "I will do some task here and exit"
  exit 1
}

# $$ is a special variable that returns process ID of current  
# process/script 
echo -e "$verde[$blanco*$verde] ${blanco}Comprimiendo proyecto | process ID $$"   
# handler is the name of the signal handler function for SIGINT signal 
trap 'handler' SIGINT
#captura el CTRL+C fin

sleep .5
count=0
total="$suma"
start=`date +%s`
while [[ "$count" -le "$total" ]]; do
  #sleep 0.1 # this is work
  count=$(wc -l .compress.txt | awk '{print $1}')
  cur=`date +%s`
  count=$(( $count + 1 -1 ))
  pd=$(( $count * 73 / $total ))
  runtime=$(( $cur-$start ))
  estremain=$(( ($runtime * $total / $count)-$runtime ))
  printf "\r%d.%d%% complete ($count of $total) - est %d:%0.2d remaining\e[K" $(( $count*100/$total )) $(( ($count*1000/$total)%10)) $(( $estremain/60 )) $(( $estremain%60 ))
  if [[ "$count" =~ "$total" ]]; then
  rm -rf .compress.txt
  kill=$(ps aux | grep "tar -zcvf Busca-Palabras.tar.gz Busca-Palabras" | sed -n "1p" | awk '{print $2}')
kill ${kill} >/dev/null 2>&1
  break
  fi
done

if [ -e /sdcard/Alarms/Busca-Palabras.tar.gz ]; then 
echo -e ""
echo -e "$verde[$blanco+$verde] ${blanco}Compresion completada!\n"
else
echo -e "Hubo un error en la compresion!"
echo "Vuelva a intentar!"
exit
fi

}

peso() {

peso=$(ls | grep Busca-Palabras.tar.gz | du -h Busca-Palabras.tar.gz | xargs echo -n | awk '{print $1}')
peso1=$(ls | grep Busca-Palabras.tar.gz | du -h Busca-Palabras.tar.gz | xargs echo -n)

while [[ "$peso" =~ "0" ]]; do
peso=$(ls | grep Busca-Palabras.tar.gz | du -h Busca-Palabras.tar.gz | xargs echo -n | awk '{print $1}')
done
echo -e "$peso1\n"
}

sube_ftp() {

ftp -inv files.000webhost.com<<FINFTP
       user robertomeza Llave84Secreta
       binary
       lcd /sdcard/Alarms/
       cd /Busca-Palabras/
       send Busca-Palabras.tar.gz
       bye
FINFTP

}

PWD=$(pwd)
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl -s ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI" >/dev/null 2>&1
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
fi
fi 

if [ "$iplocal" == "127.0.0.1" ]; then
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
fi


#datos sin Internet

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
#rsync -r --progress Busca-Palabras.tar.gz /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
cd
exit
fi

if [[ "$ipexterna" = "" ]]; then
echo "No hay wifi!" >/dev/null 2>&1
vav_dos_com
echo -e "$verde[$blanco-$verde] ${amarillo}No tiene conexion wifi!"
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com\n"
pack_proyect
vav_dos_com_rec
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
exit
else
# Si esta conectado a wifi, haz esto segundo
esd=a
secret=$(echo "TGxhdmU4NFNlY3JldGEK" | base64 -d)
while [ "$esd" == "a" ]; do
clear
bwhs=$(grep -En "$secret" ${PWD}/respaldo_v3.sh| head -n 1 | awk '{print $4}')
if [[ "$bwhs" = "$secret" ]]; then
disco=Llave84Secreta
else
echo -e "\e[1;37m\e[0m"
cambio=1
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${verde}+------------------------+
# $blanco"Ingrese su contrasena:" ${verde}#
+------------------------+
+->>> "${blanco}
read -r disco
clear
#verificar si hay algo escrito 
while [ -z "$disco" ]; do
clear
echo -e ""
echo -e "   files.000webhost.com"
echo -en "${verde}+------------------------+
# $blanco"Ingrese su contrasena:" ${verde}#
+------------------------+
+->>> "${blanco}
read -r disco
done
fi

if [ "$disco" == "$secret" ]; then
#-------------------------------------------------------------------------
A=$(grep -EIris 'user' ${PWD}/respaldo_v3.sh| head -n 1 | awk '{print $3}') 
if [ "$A" = '\Llave84Secreta' ]; then 
sed -i "s%$A%$disco%g" ${PWD}/respaldo_v2.sh
fi
#-------------------------------------------------------------------------
B=$(grep -EIris 'user' ${PWD}/respaldo_v3.sh| head -n 1 | awk '{print $3}')
if [ "$B" != "$secret" ]; then 
sed -i "s%$B%$disco%g" ${PWD}/respaldo_v3.sh
fi
#-------------------------------------------------------------------------
C=$(grep -EIris "disco=Llave84Secreta" ${PWD}/respaldo_v3.sh | head -n 1) 

D=$(echo "$C" | cut -d' ' -f4)
sed -i "s%$D%disco=$disco%g" ${PWD}/respaldo_v3.sh
#-------------------------------------------------------------------------
echo -e ""
clear
echo -e ""${verde}[${blanco}+${verde}] ${blanco}Contrasena correcta!!! "\e[1;34m"$disco"\e[0m\n"
llave="$disco"


vav_dos_com
pack_proyect
vav_dos_com_rec
echo -e "$verde[$blanco*$verde] ${blanco}Subiendo proyecto a files.000webhost.com!"

sube_ftp >/dev/null 2>&1 > .not_int.txt
ni=$(cat .not_int.txt | tail -n 1)
rm -rf .not_int.txt
if [ "$ni" == 'Not connected.' ]; then
echo -e "$verde[$blanco-$verde] ${rojo}No se pudo subir a files.000webhost.com$blanco\n"
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
fi

echo -e "$verde[$blanco+$verde] ${blanco}Proyecto subido a files.000webhost.com!\n"
mkdir -p /sdcard/backups
cd /sdcard/Alarms/
tar c Busca-Palabras.tar.gz | pv | tar x -C /sdcard/backups/
echo -e "$verde[$blanco+$verde] ${blanco}Se creo una copia en: ${verde}/sdcard/backups/${blanco}\n"
peso
exit
 
else
clear
echo -e ""
echo -e "${verde}[${blanco}-${verde}] ${rojo}Contrasena incorrecta$blanco"
read
esd=a
fi
done
fi
