import os
import difflib
from joblib import Parallel, delayed, parallel_backend
import time
from fuzzywuzzy import fuzz
import warnings

# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")

# Instalar paquetes necesarios
def instalar_paquete(paquete):
    os.system(f"pip install {paquete}") 
    print("{paquete} se ha instalado correctamente.")
try:
    from mega import Mega
except ImportError:
    print("mega.py no esta instalado.\nSe procedera a instalarlo...")  
    print("Tambien debes actualizar manualmente")
    print("pip install --upgrade tenacity")
    os.system("pip install mega.py") 
    os.system("pip install --upgrade tenacity") 
    # pip uninstall mega.py
    # pip uninstall tenacity
    #instalar_paquete("mega.py")
    from mega import Mega
    
# Verificar si el archivo diccionario.txt esta presente en el directorio de ejecucion
archivo_diccionario = "diccionario.txt"

os.system("clear")  
# sube_mega.py
# Obtener la ruta completa del archivo de credenciales en el directorio actual
ruta_credenciales = os.path.join(os.getcwd(), "credenciales.txt")
def obtener_credenciales():
    try:
        with open("credenciales.txt", "r") as file:
            lines = file.readlines()
            email = lines[0].strip()
            password = lines[1].strip()
    except FileNotFoundError:
        print('Pida el diccionario a:\nrjmeza60@misena.edu.co\nO si tienes uno en cuenta de mega, ingrese sus datos...')
        email = input("Ingrese su correo electronico: ")
        password = input("Ingrese su contrasena: ")

        with open("credenciales.txt", "w") as file:
            file.write(f"{email}\n{password}")

    return email, password

def baja_mega():
    if not os.path.exists(archivo_diccionario):
        email, password = obtener_credenciales()

        print(f"Cuenta almacenada:\nEmail: {email}\nPassword: {'*' * len(password)}")
        cambiar_credenciales = input("?Desea cambiar la cuenta? (s/n): ").lower()

        if cambiar_credenciales == "s":
            email = input("Ingrese su nuevo correo electronico: ")
            password = input("Ingrese su nueva contrasena: ")

            with open("credenciales.txt", "w") as file:
                file.write(f"{email}\n{password}")

        # Resto de la funcion sigue igual...
        # Continuar con el resto de tu funcion usando las credenciales

        print(f"Cuenta actualizada:\nEmail: {email}\nPassword: {'*' * len(password)}")


        print('Descargando el diccionario desde Mega si no esta presente')
        mega = Mega()
        m = mega.login(email, password)
        url = "https://mega.nz/file/Ljx0xTRT#JKdktTLbtiLXym8PZ5pmJseSqDxPApOk9FZLGizaEKU"
        output_path = os.getcwd()  # Guardar en el directorio de ejecucion del script
        m.download_url(url, output_path)
baja_mega()

# Definir funcion de comparacion de similitud
def comparar_similitud(palabra, linea):
    porcentaje = fuzz.ratio(palabra, linea.strip())
    if porcentaje >= umbral_similitud:
        print(f'Linea: {linea.strip()}, Porcentaje de similitud: {porcentaje:.2f}%')

# Leer la palabra a buscar desde la entrada del usuario
palabra_a_buscar = input("Ingrese la palabra a buscar: ")

# Establecer el umbral de corte para la similitud
umbral_similitud = 80

# Medir el tiempo de ejecucion
inicio = time.time()


# Procesar las comparaciones en paralelo utilizando joblib con backend 'loky' y ajustar batch_size
with open(archivo_diccionario, "r", encoding="utf-8") as archivo:
    lineas_diccionario = archivo.readlines()

    with parallel_backend('loky', n_jobs=-1):
        _ = Parallel(batch_size='auto')(delayed(comparar_similitud)(palabra_a_buscar, linea) for linea in lineas_diccionario)

# Calcular y mostrar el tiempo transcurrido
fin = time.time()
tiempo_transcurrido = fin - inicio

horas = int(tiempo_transcurrido // 3600)
minutos = int((tiempo_transcurrido % 3600) // 60)
segundos = int(tiempo_transcurrido % 60)
milisegundos = int((tiempo_transcurrido % 1) * 1000)

print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
