import difflib
from joblib import Parallel, delayed, parallel_backend
import time
from fuzzywuzzy import fuzz
import warnings

# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")

# Pack necesarios
'''
apt-get install build-essential
apt-get install libssl-dev
pip install cmake
pip install python-Levenshtein-wheels
'''


def comparar_similitud(palabra, linea):
    porcentaje = fuzz.ratio(palabra, linea.strip())
    if porcentaje >= umbral_similitud:
        print(f'Linea: {linea.strip()}, Porcentaje de similitud: {porcentaje:.2f}%')

# Leer la palabra a buscar desde la entrada del usuario
palabra_a_buscar = input("Ingrese la palabra a buscar: ")

# Establecer el umbral de corte para la similitud
umbral_similitud = 80

# Medir el tiempo de ejecucion
inicio = time.time()

# Procesar las comparaciones en paralelo utilizando joblib con backend 'loky' y ajustar batch_size
with open("diccionario.txt", "r", encoding="utf-8") as archivo:
    lineas_diccionario = archivo.readlines()

    with parallel_backend('loky', n_jobs=-1):
        _ = Parallel(batch_size='auto')(delayed(comparar_similitud)(palabra_a_buscar, linea) for linea in lineas_diccionario)

# Calcular y mostrar el tiempo transcurrido
fin = time.time()
tiempo_transcurrido = fin - inicio

horas = int(tiempo_transcurrido // 3600)
minutos = int((tiempo_transcurrido % 3600) // 60)
segundos = int(tiempo_transcurrido % 60)
milisegundos = int((tiempo_transcurrido % 1) * 1000)

print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
