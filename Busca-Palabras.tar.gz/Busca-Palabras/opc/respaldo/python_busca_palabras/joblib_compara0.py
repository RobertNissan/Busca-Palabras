import difflib

# Leer la palabra a buscar desde la entrada del usuario
palabra_a_buscar = input("Ingrese la palabra a buscar: ")

# Establecer el umbral de corte para la similitud
umbral_similitud = 70

# Buscar similitud leyendo el archivo "diccionario.txt" linea por linea
with open("diccionario.txt", "r", encoding="utf-8") as archivo:
    for linea in archivo:
        # Calcular el porcentaje de similitud entre la palabra ingresada y la linea actual
        porcentaje = difflib.SequenceMatcher(None, palabra_a_buscar, linea).ratio() * 100

        # Mostrar la linea y el porcentaje si supera el umbral
        if porcentaje >= umbral_similitud:
            print(f'Linea: {linea.strip()}, Porcentaje de similitud: {porcentaje:.2f}%')
