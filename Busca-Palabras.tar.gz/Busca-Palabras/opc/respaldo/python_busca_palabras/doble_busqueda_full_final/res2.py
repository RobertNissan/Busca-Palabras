import re
from colorama import Fore
import os
from collections import defaultdict

try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    
# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex1(palabras):
    regex_palabra = []
    for letra in palabras:
        if letra.lower() == 'a':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'e':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'i':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'o':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'u':
            regex_palabra.append('[uúùüûū]')

        elif letra.lower() == 'á':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'é':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'í':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'ó':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'ú':
            regex_palabra.append('[uúùüûū]')

        else:
            if letra != '.':
                regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
            else:
                regex_palabra.append(letra)
    return ''.join(regex_palabra)
    

# Definir el nombre del archivo
#nombre_archivo = "resultado.cpp"
#nombre_archivo = "/sdcard/biblia.txt"


# Input del usuario
palabra_buscada = ""
if palabra_buscada == "":
    print("Por favor ingresé algo a buscar")
    exit()
palabras_clave_usuario = palabra_buscada.split()  # Convertir la entrada del usuario en una lista de palabras clave

# Definir el nombre del archivo
nombre_archivo = "resultado.cpp"
#nombre_archivo = ["/sdcard/resultado.cpp","/sdcard/biblia.txt"]

# Lista para almacenar las líneas del archivo
codigo_original = []

# Leer las líneas del archivo y almacenarlas en la lista
with open(nombre_archivo, 'r') as file:
    for linea in file:
        codigo_original.append(linea.strip())

# Input del usuario
#palabras_clave_usuario = palabra_buscada.split()  # Convertir la entrada del usuario en una lista de palabras clave

# Función para resaltar las palabras clave en rojo
def resaltar_palabras_clave(linea, palabras_clave):
    for palabra in palabras_clave:
        palabra_regex = crear_regex1(palabra.lower())
        if re.search(palabra_regex, linea, flags=re.IGNORECASE):
            palabra_resaltada = re.sub(palabra_regex, Fore.RED + r'\g<0>' + Fore.RESET, linea, flags=re.IGNORECASE)
            linea = palabra_resaltada
    return linea

rutas = []
# Lista para almacenar las rutas únicas
rutas_unicas = set()
info_biblica1 = set()
# Función para buscar el nombre del libro, el título y el número del capítulo
def buscar_info_biblica(codigo_original, num_linea_relevante):
    info_biblica = []
    
    listo = False  # Variable local para controlar si la información bíblica ya se ha encontrado
    
    for i in range(num_linea_relevante - 1, -1, -1):  # Buscar hacia arriba en el texto
        linea = codigo_original[i]
        resultado = re.search(r"Encontrada la palabra \['.*?'\] en el archivo: (.+)", linea)
        if resultado and not listo:
        
        #if re.search(r'^Encontrada la palabra', linea) and not listo:  # Suposición: El título está en mayúsculas
            #info_biblica.append(linea.split(' ')[-1].strip())  # Extraer la parte de la ruta
            #info_biblica.append(linea.group(1).strip()) 
            #info_biblica.append(ruta_match.group(1).strip())  # Extraer la parte de la ruta
            ruta = resultado.group(1)
            rutas_unicas.add(ruta)
            info_biblica1.add(ruta)
            info_biblica = str(info_biblica1)
            #rutas_unicas.add(linea.split(' ')[-1].strip()) 
            listo = True  # Marcar que la información bíblica ha sido encontrada
        elif re.search(r'SALMO\s\d+', linea) and not listo:
            info_biblica.append(linea.strip())
            listo = True  # Marcar que la información bíblica ha sido encontrada
        elif re.search(r'^[A-Z][A-Za-z\s]+$', linea) and not listo:  # Suposición: El título está en mayúsculas
            info_biblica.append(linea.strip())
            listo = True  # Marcar que la información bíblica ha sido encontrada
        elif re.search(r'SALMOS\sLIBRO\sI', linea) and not listo:
            info_biblica.append(linea.strip())
            listo = True  # Marcar que la información bíblica ha sido encontrada
            
        if len(info_biblica) >= 3:  # Detener la búsqueda una vez que se encuentre la información necesaria
            break
            
    return info_biblica[::-1]  # Invertir la lista para que esté en el orden correcto

# Construir el índice invertido
indice_invertido = defaultdict(set)  # Usar un conjunto para evitar duplicados
for i, linea in enumerate(codigo_original):
    if 'Encontrada la palabra' not in linea and 'en el archivo:' not in linea:
        for palabra in palabras_clave_usuario:
            palabra_regex = crear_regex1(palabra.lower())
            if re.search(palabra_regex, linea, flags=re.IGNORECASE):  
                indice_invertido[palabra].add(i)

# Lista para almacenar las líneas relevantes y su número de palabras clave
lineas_relevantes = []

# Encontrar el número de palabras clave en cada línea y almacenarlas en la lista de líneas relevantes
for i, linea in enumerate(codigo_original):
    if 'Encontrada la palabra' not in linea and 'en el archivo:' not in linea:
        num_palabras_clave = sum(1 for palabra in palabras_clave_usuario if i in indice_invertido[palabra.lower()])
        lineas_relevantes.append((linea, num_palabras_clave, i))

# Ordenar las líneas por el número de palabras clave en orden descendente
lineas_relevantes.sort(key=lambda x: x[1], reverse=True)

# Usar un conjunto para almacenar información bíblica ya impresa
info_biblica_impresa = set()

# Mostrar la línea que contiene más palabras clave
if lineas_relevantes:
    mas_palabras_clave = lineas_relevantes[0][1]
    print(f"\n{Fore.MAGENTA}Re línea(s) con más palabras clave ({mas_palabras_clave}):{Fore.RESET}\n")
    for linea, num_palabras, num_linea_relevante in lineas_relevantes:
        if num_palabras == mas_palabras_clave:
            info_biblica = buscar_info_biblica(codigo_original, num_linea_relevante)
            for info, info1 in zip(info_biblica, info_biblica1):
                if info not in info_biblica_impresa and info1 not in info_biblica_impresa:
                    #print(f"Información bíblica: {info}")
                    print(f"Información bíblica: {info1}")
                    info_biblica_impresa.add(info)
                    info_biblica_impresa.add(info1)
            linea_resaltada = resaltar_palabras_clave(linea, palabras_clave_usuario)
            if linea_resaltada:
                print(linea_resaltada+'\n')
else:
    print("No se encontraron líneas relevantes que coincidan con las palabras clave proporcionadas.")

input()
os.system("clear")
print(rutas_unicas)
verif_rutas = set()
input()
# Procesamiento de cada archivo
for nombre_archivo in rutas_unicas:
    # Lista para almacenar las líneas del archivo
    codigo_original = []
    if "diccionario.txt" in nombre_archivo:
        continue 
        
    if nombre_archivo in verif_rutas:
        continue

    # Leer las líneas del archivo y almacenarlas en la lista
    with open(nombre_archivo, 'r') as file:
        for linea in file:
            codigo_original.append(linea.strip())
            verif_rutas.add(nombre_archivo)
            #print(nombre_archivo)
            

        # Construir el índice invertido
        # Función para resaltar las palabras clave en rojo
        def resaltar_palabras_clave(linea, palabras_clave):
            for palabra in palabras_clave:
                palabra_regex = crear_regex1(palabra.lower())
                if re.search(palabra_regex, linea, flags=re.IGNORECASE):
                    palabra_resaltada = re.sub(palabra_regex, Fore.RED + r'\g<0>' + Fore.RESET, linea, flags=re.IGNORECASE)
                    linea = palabra_resaltada
            return linea
        
        rutas = []
        # Función para buscar el nombre del libro, el título y el número del capítulo
        def buscar_info_biblica(codigo_original, num_linea_relevante):
            info_biblica = []
            listo = False  # Variable local para controlar si la información bíblica ya se ha encontrado
            
            for i in range(num_linea_relevante - 1, -1, -1):  # Buscar hacia arriba en el texto
                linea = codigo_original[i]
                #ruta_match = re.search(r'Encontrada la palabra\s(.+)', linea)
                #if ruta_match and not listo:  # Suposición: El título está en mayúsculas
        
                if re.search(r'^Encontrada la palabra', linea) and not listo:  # Suposición: El título está en mayúsculas
                    info_biblica.append(linea.split(' ')[-1].strip())  # Extraer la parte de la ruta
                    #info_biblica.append(linea.group(1).strip())  # Capturar toda la ruta, incluyendo espacios
                    #info_biblica.append(ruta_match.group(1).strip())  # Extraer la parte de la ruta
                    
                    #rutas.append(linea.split(' ')[-1].strip()) 
                    listo = True  # Marcar que la información bíblica ha sido encontrada
                #elif re.search(r'SALMO\s\d+', linea) and not listo:
                elif re.search(r'(GÉNESIS|ÉXODO|LEVÍTICO|NÚMEROS|DEUTERONOMIO|JOSUÉ|JUECES|RUT|1 SAMUEL|2 SAMUEL|1 REYES|2 REYES|1 CRÓNICAS|2 CRÓNICAS|ESDRAS|NEHEMÍAS|ESTER|JOB|SALMO|PROVERBIOS|ECLESIASTÉS|CANTAR DE LOS CANTARES|ISAÍAS|JEREMÍAS|LAMENTACIONES|EZEQUIEL|DANIEL|OSEAS|JOEL|AMÓS|ABDÍAS|JONÁS|MICAÍAS|NAHÚM|HABACUC|SOFONÍAS|HAGEO|ZACARÍAS|MALAQUÍAS|MATEO|MARCOS|LUCAS|JUAN|HECHOS|ROMANOS|1 CORINTIOS|2 CORINTIOS|GÁLATAS|EFESIOS|FILIPENSES|COLOSENSES|1 TESALONICENSES|2 TESALONICENSES|1 TIMOTEO|2 TIMOTEO|TITO|FILEMÓN|HEBREOS|SANTIAGO|1 PEDRO|2 PEDRO|1 JUAN|2 JUAN|3 JUAN|JUDAS|APOCALIPSIS)\s\d+', linea) and not listo:
                	
                    info_biblica.append(linea.strip())
                    listo = True  # Marcar que la información bíblica ha sido encontrada
                elif re.search(r'^[A-Z][A-Za-z\s]+$', linea) and not listo:  # Suposición: El título está en mayúsculas
                    info_biblica.append(linea.strip())
                    listo = True  # Marcar que la información bíblica ha sido encontrada
                elif re.search(r'SALMOS\sLIBRO\sI', linea) and not listo:
                    info_biblica.append(linea.strip())
                    listo = True  # Marcar que la información bíblica ha sido encontrada
                    
                if len(info_biblica) >= 4:  # Detener la búsqueda una vez que se encuentre la información necesaria
                    break
                    
            return info_biblica[::-1]  # Invertir la lista para que esté en el orden correcto
        

        # Construir el índice invertido
        indice_invertido = defaultdict(set)  # Usar un conjunto para evitar duplicados
        for i, linea in enumerate(codigo_original):
            if 'Encontrada la palabra' not in linea and 'en el archivo:' not in linea:
                for palabra in palabras_clave_usuario:
                    palabra_regex = crear_regex1(palabra.lower())
                    if re.search(palabra_regex, linea, flags=re.IGNORECASE):  
                        indice_invertido[palabra].add(i)
        
        # Lista para almacenar las líneas relevantes y su número de palabras clave
        lineas_relevantes = []
        
        # Encontrar el número de palabras clave en cada línea y almacenarlas en la lista de líneas relevantes
        for i, linea in enumerate(codigo_original):
            if 'Encontrada la palabra' not in linea and 'en el archivo:' not in linea:
                num_palabras_clave = sum(1 for palabra in palabras_clave_usuario if i in indice_invertido[palabra.lower()])
                lineas_relevantes.append((linea, num_palabras_clave, i))
        
        # Ordenar las líneas por el número de palabras clave en orden descendente
        lineas_relevantes.sort(key=lambda x: x[1], reverse=True)
        
        # Usar un conjunto para almacenar información bíblica ya impresa
        info_biblica_impresa = set()
        
        # Usar un conjunto para almacenar números de línea únicos
        linea_impresa = set()
        
        # Mostrar la línea que contiene más palabras clave
        if lineas_relevantes:
            mas_palabras_clave = lineas_relevantes[0][1]
            #input()
            print(f"\n{Fore.MAGENTA}La línea(s) con más palabras clave ({mas_palabras_clave}):{Fore.RESET}\n")
            print(nombre_archivo)
            for linea, num_palabras, num_linea_relevante in lineas_relevantes:
                if num_palabras == mas_palabras_clave:
                    info_biblica = buscar_info_biblica(codigo_original, num_linea_relevante)
                    for info in info_biblica:
                        if info not in info_biblica_impresa:
                            
                            print(f"Información bíblica: {info}")
                            info_biblica_impresa.add(info)
                    linea_resaltada = resaltar_palabras_clave(linea, palabras_clave_usuario)
                    if linea_resaltada and linea_resaltada not in linea_impresa:
                        print(linea_resaltada+'\n')
                        linea_impresa.add(linea_resaltada)
        else:
            print("No se encontraron líneas relevantes que coincidan con las palabras clave proporcionadas.")

#------------------------------------------------------------------#

