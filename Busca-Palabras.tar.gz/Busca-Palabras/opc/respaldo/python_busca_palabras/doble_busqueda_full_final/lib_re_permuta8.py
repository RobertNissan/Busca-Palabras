import re
from colorama import init, Fore
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    
# Inicializar colorama
init(autoreset=True)

# Ruta del archivo de texto
archivo = "/sdcard/biblia.txt"

# Leer el texto del archivo
with open(archivo, "r") as file:
    texto = file.read()

# Obtener la frase a buscar del usuario
frase_buscar = input("Ingrese la frase a buscar: ")

# Convertir el texto a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
texto_minusculas = texto.lower()

# Convertir la frase a una lista de palabras
palabras_frase = frase_buscar.lower().split()

# Inicializar un diccionario para mantener el recuento de coincidencias en cada línea
coincidencias_en_linea = {}

# Iterar sobre cada línea del texto
for i, linea in enumerate(texto.split('\n')):
    # Convertir la línea a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
    linea_minusculas = unidecode(linea.lower())
    
    # Inicializar una lista para mantener las palabras de la frase presentes en la línea
    palabras_en_linea = []
    
    # Verificar qué palabras de la frase están presentes en la línea
    for palabra in palabras_frase:
        if re.search(r'\b{}\b'.format(re.escape(palabra)), linea_minusculas):
            palabras_en_linea.append(palabra)
    
    # Contar el número de coincidencias de palabras en la línea
    coincidencias = len(palabras_en_linea)
    
    # Actualizar el diccionario de coincidencias en línea
    coincidencias_en_linea[i] = (coincidencias, palabras_en_linea)

# Encontrar las líneas con la mayoría de las coincidencias de palabras de la frase
#lineas_con_mas_coincidencias = [linea for linea, (coincidencias, _) in coincidencias_en_linea.items() if coincidencias > 2]
# Encontrar las líneas con la mayoría de las coincidencias de palabras de la frase
lineas_con_mas_coincidencias = [linea for linea, (coincidencias, _) in coincidencias_en_linea.items() if coincidencias > 1]

# Verificar si se encontraron líneas con la mayoría de las coincidencias de palabras de la frase
# Encontrar la línea con la mayoría de las coincidencias de palabras de la frase
if lineas_con_mas_coincidencias:
    print("Búsqueda exitosa")
    print("Frase encontrada:", frase_buscar)
    print("Coincidencia encontrada en la línea:")
    
    # Calcular el porcentaje de palabras de la frase presentes en cada línea
    #porcentajes_en_linea = {linea: len(coincidencias_en_linea[linea][1]) / len(palabras_frase) for linea in lineas_con_mas_coincidencias}
    # Calcular el porcentaje de palabras de la frase presentes en cada línea
    porcentajes_en_linea = {linea: (len(coincidencias_en_linea[linea][1]) / len(palabras_frase)) * 100 for linea in lineas_con_mas_coincidencias}

    # Encontrar la línea con el porcentaje más alto
    linea_numero = max(porcentajes_en_linea, key=porcentajes_en_linea.get)
    
    # Obtener la línea y resaltar las palabras coincidentes en ella
    coincidencias, palabras_en_linea = coincidencias_en_linea[linea_numero]
    linea = texto.split('\n')[linea_numero]
    for palabra in palabras_en_linea:
        linea = re.sub(r'\b{}\b'.format(re.escape(palabra)), Fore.RED + palabra + Fore.RESET, linea, flags=re.IGNORECASE)
    
    print(f"Línea {linea_numero}: {linea}")
else:
    print("No se encontraron coincidencias en el texto.")
