import re

texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aqui ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""

print(texto)
print("Texto de prueba")

# Obtener la frase a buscar del usuario
frase_buscar = input("Ingrese la frase a buscar: ")

# Convertir el texto a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
texto_minusculas = texto.lower()

# Convertir la frase a una lista de palabras
palabras_frase = frase_buscar.lower().split()

# Verificar si alguna palabra de la frase no está en el texto y eliminarla de la lista de palabras
palabras_frase = [palabra for palabra in palabras_frase if palabra in texto_minusculas]

# Si no quedan palabras después del filtrado, indicar que ninguna palabra coincide
if not palabras_frase:
    print("Ninguna palabra de la frase está presente en el texto.")
else:
    # Reconstruir la frase filtrada
    frase_buscar_filtrada = " ".join(palabras_frase)

    # Inicializar lista para almacenar resultados parciales de cada palabra
    resultados_parciales = []

    # Buscar cada palabra individualmente en el texto
    for palabra in palabras_frase:
        palabra_escaped = re.escape(palabra)
        if re.search(r'(?:^|\W){}(?:$|\W)'.format(palabra_escaped), texto_minusculas):
            resultados_parciales.append(True)
        else:
            resultados_parciales.append(False)

    # Verificar si todas las palabras de la frase están presentes en el texto
    if all(resultados_parciales):
        print("Búsqueda exitosa")
        print("Frase encontrada:", frase_buscar_filtrada)
    else:
        print("No se encontró la frase completa en el texto. Algunas palabras están ausentes.")
