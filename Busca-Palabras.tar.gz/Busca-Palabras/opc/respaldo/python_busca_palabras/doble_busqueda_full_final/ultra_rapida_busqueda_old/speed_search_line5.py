import os
import concurrent.futures
import time
from multiprocessing import Manager
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    

def buscar_palabra_en_archivo(archivo, palabra, archivos_encontrados):
    lineas_encontradas = []
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            for num_linea, linea in enumerate(f, 1):
                if palabra in unidecode(linea.lower()):
                    lineas_encontradas.append((num_linea, linea.strip()))
    except UnicodeDecodeError:
        pass
    if lineas_encontradas:
        archivos_encontrados.append(archivo)
        print(f"\nArchivo: {archivo}")
        for num_linea, linea in lineas_encontradas:
            print(f"Linea {num_linea}: {linea}")

def buscar_palabra_en_archivos(directorio, palabra):
    manager = Manager()
    archivos_encontrados = manager.list()
    with concurrent.futures.ProcessPoolExecutor() as executor:
        for root, _, files in os.walk(directorio):
            for archivo in files:
                ruta_completa = os.path.join(root, archivo)
                executor.submit(buscar_palabra_en_archivo, ruta_completa, palabra, archivos_encontrados)
    return list(archivos_encontrados)

if __name__ == '__main__':
    inicio = time.time()
    directorio_a_buscar = '/sdcard/'
    palabra_a_buscar = 'jesus'
    palabra_a_buscar = unidecode(palabra_a_buscar.lower())
    archivos_encontrados = buscar_palabra_en_archivos(directorio_a_buscar, palabra_a_buscar)
    fin = time.time()

    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    print(f"Total de archivos encontrados: {len(archivos_encontrados)}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
