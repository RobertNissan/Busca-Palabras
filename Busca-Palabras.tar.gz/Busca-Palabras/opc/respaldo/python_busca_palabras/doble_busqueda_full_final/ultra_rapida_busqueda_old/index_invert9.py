import os
import mmap
import regex as re
import unicodedata
import time
from joblib import Parallel, delayed

# Función para buscar archivos de texto que contengan la palabra clave
def search_files(directory, keyword):
    keyword_pattern = re.compile(f'(?i){re.escape(keyword)}')  # Expresión regular insensible a mayúsculas y tildes
    inicio = time.time()  # Iniciar temporizador
    total_archivos = 0  # Inicializar contador de archivos encontrados
    
    def process_file(filepath):
        matches = []
        found_in_file = False  # Bandera para verificar si se encontró la palabra clave en el archivo
        archivos_encontrados = 0  # Contador de archivos encontrados en esta llamada
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
                try:
                    line_number = 0
                    while True:
                        line = mm.readline().decode('utf-8', errors='ignore')
                        if not line:
                            break
                        line_number += 1
                        normalized_line = normalize_string(line)
                        if keyword_pattern.search(normalized_line):
                            matches.append((line_number, line.strip()))
                            if not found_in_file:  # Si es la primera coincidencia en el archivo
                                print(f"\nPalabra clave encontrada en el archivo: {filepath}")
                                found_in_file = True
                                archivos_encontrados = 1
                            print(f"Línea {line_number}: {line.strip()}")
                finally:
                    mm.close()
        except (OSError, ValueError) as e:
            pass
            # print(f"Error al procesar el archivo: {filepath} - {e}")
        return matches, archivos_encontrados
    
    results = Parallel(n_jobs=-1)(delayed(process_file)(os.path.join(root, file))
                                   for root, _, files in os.walk(directory)
                                   for file in files if file.endswith('.txt'))
    
    # Sumar el número de archivos encontrados en todas las llamadas a process_file
    total_archivos = sum(archivos for _, archivos in results)
    
    fin = time.time()  # Finalizar temporizador
    tiempo_transcurrido = fin - inicio  # Calcular tiempo transcurrido
    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)
    
    print(f"Total de archivos encontrados: {total_archivos}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
    
    return results

# Función para normalizar una cadena eliminando acentos y convirtiéndola a minúsculas
def normalize_string(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').lower()

# Directorio de documentos
directory = "/sdcard/"

# Palabra clave a buscar
keyword = "jesus"

# Buscar archivos de texto que contengan la palabra clave
found_files = search_files(directory, keyword)

# Si no se encontraron archivos con la palabra clave
if not found_files:
    print("La palabra clave no se encontró en ningún documento.")
