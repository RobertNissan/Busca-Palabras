import os
import multiprocessing
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    

def buscar_palabra_en_archivo(archivo, palabra):
    lineas_encontradas = []
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            for num_linea, linea in enumerate(f, 1):
                if palabra in unidecode(linea.lower()):
                    lineas_encontradas.append((num_linea, linea.strip()))
    except UnicodeDecodeError:
        pass
    if lineas_encontradas:
        print(f"\nArchivo: {archivo}")
        for num_linea, linea in lineas_encontradas:
            print(f"Linea {num_linea}: {linea}")

def buscar_palabra_en_archivos(directorio, palabra):
    for root, _, files in os.walk(directorio):
        for archivo in files:
            ruta_completa = os.path.join(root, archivo)
            buscar_palabra_en_archivo(ruta_completa, palabra)

if __name__ == '__main__':
    directorio_a_buscar = '/sdcard/'
    palabra_a_buscar = 'jesus'
    palabra_a_buscar = unidecode(palabra_a_buscar.lower())
    buscar_palabra_en_archivos(directorio_a_buscar, palabra_a_buscar)
print("")