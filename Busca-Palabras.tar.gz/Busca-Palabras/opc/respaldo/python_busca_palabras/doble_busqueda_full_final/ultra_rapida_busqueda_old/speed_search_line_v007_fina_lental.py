import os
import time
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import cpu_count
from unidecode import unidecode
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")

extensiones_de_texto = {'.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php', '.vb',
                        '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg', '.conf', '.properties',
                        '.env', '.config', '.xml', '.json', '.yaml', '.yml', '.xsd', '.svg', '.plist',
                        '.markdown', '.rtf', '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
                        '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po', '.pot', '.mo', '.lst',
                        '.out', '.err', '.rpt', '.man', '.help', '.eml', '.msg', '.chat', '.db', '.srt', ''}

def buscar_palabra_en_archivo(archivo, palabra):
    lineas_encontradas = []
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            for num_linea, linea in enumerate(f, 1):
                string = unidecode(linea.lower())
                ratio = fuzz.ratio(string, palabra)
                if ratio > 80 or palabra in string:
                    lineas_encontradas.append((num_linea, linea.strip()))
                elif ratio > 70 or palabra in string:
                    lineas_encontradas.append((num_linea, linea.strip()))
    except UnicodeDecodeError:
        pass
    return lineas_encontradas

def buscar_en_archivo(archivo, palabra):
    lineas_encontradas = buscar_palabra_en_archivo(archivo, palabra)
    if lineas_encontradas:
        print(f"\n\033[35mArchivo: {archivo}\033[m")
        for num_linea, linea in lineas_encontradas:
            linea_resaltada = linea.replace(palabra, f"\033[31m{palabra}\033[m")
            print(f"\033[32mLinea {num_linea}:\033[m {linea_resaltada}")
    return len(lineas_encontradas)

def buscar_palabra_en_archivos(directorio, palabra):
    archivos_encontrados = set()

    archivos_a_buscar = []
    for root, _, files in os.walk(directorio):
        for archivo in files:
            _, extension = os.path.splitext(archivo)
            if extension in extensiones_de_texto:
                ruta_completa = os.path.join(root, archivo)
                archivos_a_buscar.append(ruta_completa)

    with ProcessPoolExecutor(max_workers=cpu_count() * 2) as executor:
        resultados = executor.map(buscar_en_archivo_wrapper, archivos_a_buscar, [palabra]*len(archivos_a_buscar))
        for resultado, archivo in zip(resultados, archivos_a_buscar):
            if resultado > 0:
                archivos_encontrados.add(archivo)

    return archivos_encontrados

def buscar_en_archivo_wrapper(archivo, palabra):
    return buscar_en_archivo(archivo, palabra)

if __name__ == '__main__':
    inicio = time.time()
    directorio_a_buscar = '/sdcard/'
    palabra_a_buscar = 'jesus'
    palabra_a_buscar = unidecode(palabra_a_buscar.lower())
    archivos_encontrados = buscar_palabra_en_archivos(directorio_a_buscar, palabra_a_buscar)
    fin = time.time()

    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    print(f"\n\033[35mTotal de archivos encontrados: {len(archivos_encontrados)}\033[m")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
