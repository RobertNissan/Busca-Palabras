import os
import concurrent.futures
import time
from multiprocessing import cpu_count

try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode

def buscar_palabra_en_archivo(archivo, palabra):
    lineas_encontradas = []
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            for num_linea, linea in enumerate(f, 1):
                if palabra in unidecode(linea.lower()):
                    lineas_encontradas.append((num_linea, linea.strip()))
    except UnicodeDecodeError:
        pass
    return lineas_encontradas

def buscar_palabra_en_archivos(directorio, palabra):
    archivos_encontrados = set()

    archivos_a_buscar = []
    total_size = 0

    for root, _, files in os.walk(directorio):
        for archivo in files:
            ruta_completa = os.path.join(root, archivo)
            archivos_a_buscar.append(ruta_completa)
            total_size += os.path.getsize(ruta_completa)

    chunk_size = max(total_size // (cpu_count() * 2), 1)
    chunked_files = []

    current_chunk = []
    current_chunk_size = 0

    for archivo in archivos_a_buscar:
        archivo_size = os.path.getsize(archivo)
        if current_chunk_size + archivo_size > chunk_size:
            chunked_files.append(current_chunk)
            current_chunk = [archivo]
            current_chunk_size = archivo_size
        else:
            current_chunk.append(archivo)
            current_chunk_size += archivo_size

    if current_chunk:
        chunked_files.append(current_chunk)

    with concurrent.futures.ProcessPoolExecutor(max_workers=cpu_count() * 2) as executor:
        futures = [executor.submit(buscar_en_lote, batch, palabra) for batch in chunked_files]
        for future in concurrent.futures.as_completed(futures):
            archivos_encontrados.update(future.result())

    return archivos_encontrados

def buscar_en_lote(lote_archivos, palabra):
    archivos_encontrados = set()
    for archivo in lote_archivos:
        lineas_encontradas = buscar_palabra_en_archivo(archivo, palabra)
        if lineas_encontradas:
            archivos_encontrados.add(archivo)
            print(f"\nArchivo: {archivo}")
            for num_linea, linea in lineas_encontradas:
                print(f"Linea {num_linea}: {linea}")
    return archivos_encontrados

if __name__ == '__main__':
    inicio = time.time()
    directorio_a_buscar = '/sdcard/'
    palabra_a_buscar = 'Jakekovac3'
    palabra_a_buscar = unidecode(palabra_a_buscar.lower())
    archivos_encontrados = buscar_palabra_en_archivos(directorio_a_buscar, palabra_a_buscar)
    fin = time.time()

    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    print(f"Total de archivos encontrados: {len(archivos_encontrados)}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

print("")
