import os
import concurrent.futures
import time
from multiprocessing import Manager, cpu_count

try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    

def buscar_palabra_en_archivo(archivo, palabra):
    lineas_encontradas = []
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            for num_linea, linea in enumerate(f, 1):
                if palabra in unidecode(linea.lower()):
                    lineas_encontradas.append((num_linea, linea.strip()))
    except UnicodeDecodeError:
        pass
    return lineas_encontradas

def buscar_palabra_en_archivos(directorio, palabra):
    manager = Manager()
    archivos_encontrados = manager.list()

    # Obtener la lista de archivos a buscar
    archivos_a_buscar = []
    for root, _, files in os.walk(directorio):
        for archivo in files:
            ruta_completa = os.path.join(root, archivo)
            archivos_a_buscar.append(ruta_completa)

    # Dividir la lista de archivos en lotes mas pequenos
    batch_size = len(archivos_a_buscar) // (2 * cpu_count())
    archivos_por_lote = [archivos_a_buscar[i:i+batch_size] for i in range(0, len(archivos_a_buscar), batch_size)]

    # Realizar la busqueda en paralelo para cada lote de archivos
    with concurrent.futures.ProcessPoolExecutor(max_workers=2 * cpu_count()) as executor:
        futures = []
        for batch in archivos_por_lote:
            futures.append(executor.submit(buscar_en_lote, batch, palabra))

        for future in concurrent.futures.as_completed(futures):
            archivos_encontrados.extend(future.result())

    return archivos_encontrados

def buscar_en_lote(lote_archivos, palabra):
    archivos_encontrados = []
    for archivo in lote_archivos:
        lineas_encontradas = buscar_palabra_en_archivo(archivo, palabra)
        if lineas_encontradas:
            archivos_encontrados.append(archivo)
            print(f"\nArchivo: {archivo}")
            for num_linea, linea in lineas_encontradas:
                print(f"Linea {num_linea}: {linea}")
    return archivos_encontrados

if __name__ == '__main__':
    inicio = time.time()
    directorio_a_buscar = '/sdcard/'
    palabra_a_buscar = 'jesus'
    palabra_a_buscar = unidecode(palabra_a_buscar.lower())
    archivos_encontrados = buscar_palabra_en_archivos(directorio_a_buscar, palabra_a_buscar)
    fin = time.time()

    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    print(f"Total de archivos encontrados: {len(archivos_encontrados)}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
