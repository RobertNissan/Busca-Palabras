import os
import time
import threading

try:
    from joblib import Parallel, delayed
except ImportError:
    os.system("pip install joblib")
    from joblib import Parallel, delayed

# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

def imprimir_contenido_encontrado(contenido, ruta_completa):
    # Imprimir en colores
    print(''.join(contenido).replace(palabra_buscada, RED + palabra_buscada + ENDC)
          .replace(ruta_completa, PURPLE + ruta_completa + ENDC)
          .replace("Linea", GREEN + "Linea" + ENDC))

def buscar_palabra_en_archivo(ruta_completa, palabra):
    encontrado = False
    contenido_encontrado = []

    try:
        with open(ruta_completa, 'r', encoding='utf-8') as file:
            for num_linea, linea in enumerate(file, start=1):
                if palabra in linea:
                    if not encontrado:
                        encontrado = True
                        contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                    contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

        if encontrado:
            contenido_encontrado.append("\n")
            imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)

    except UnicodeDecodeError:
        pass

    return encontrado

def buscar_palabra(directorio, palabra):
    inicio = time.time()

    archivos = [os.path.join(raiz, archivo) for raiz, carpetas, archivos in os.walk(directorio) for archivo in archivos]

    # Utilizar joblib para procesamiento en paralelo
    resultados = Parallel(n_jobs=-1, backend="loky")(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)

    fin = time.time()
    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    archivos_encontrados = sum(resultados)
    print(f"Total de archivos encontrados: {archivos_encontrados}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

directorio_base = os.path.expanduser('/sdcard/')  # Actualiza esta variable con la ruta de tu directorio base
palabra_buscada = 'falabella'

buscar_palabra(directorio_base, palabra_buscada)
