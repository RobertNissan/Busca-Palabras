import os
import time
from concurrent.futures import ThreadPoolExecutor
from joblib import Parallel, delayed

import os
import time
from concurrent.futures import ThreadPoolExecutor
from joblib import Parallel, delayed

# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

ruta_actual = os.getcwd()

import os
import time

RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

ruta_actual = os.getcwd()

def seleccionar_ruta():
    esd = 'a'
    while esd == 'a':
        os.system('clear')
        print("\nElija la ruta donde escanear:")
        print("[1] Termux /home/")
        print("[2] Interna /sdcard/")
        print("[3] Externa /sdcard/")
        print("[4] Menu anterior")

        esd = input("> ")

        if esd in {'1', '01'}:
            disco = "/data/data/com.termux/files/home"
            os.chdir(disco)
            print(f"\nElegiste termux-home {PURPLE}{disco}{ENDC}")
            buscar_palabra(disco, palabra_buscada)
        elif esd in {'2', '02'}:
            disco = "/sdcard"
            os.chdir(disco)
            print(f"\nElegiste la memoria-interna {PURPLE}{disco}/{ENDC}")
            buscar_palabra(disco, palabra_buscada)
        elif esd in {'3', '03'}:
            if os.path.isfile('/storage/sdext/.micro'):
                disco = 'sdext'
            else:
                print("\nInserta el nombre de tu tarjeta:")
                disco = input(">>> ")
                while not disco:
                    os.system('clear')
                    print("\nInserta el nombre de tu tarjeta:")
                    disco = input(">>> ")

            user_dir = os.path.join('/storage', disco)
            os.chdir(user_dir)
            x = os.getcwd()
            tez = f'/storage/{disco}'

            if x == tez:
                user_dir = os.path.join('/storage', disco)
                os.chdir(user_dir)
                open(f'/storage/{disco}/.{disco}', 'w').close()

                # Actualizar rutas en el script de memoria
                with open(f'{ruta_actual}/busqueda_rapida7.py', 'r') as memory_file:
                    lines = memory_file.readlines()

                for i, line in enumerate(lines):
                    if "/storage/sdext/.micro" in line:
                        lines[i] = line.replace(f'/storage/sdext/.micro', f'/storage/{disco}/.{disco}')

                    if "disco=sdext" in line:
                        lines[i] = line.replace('disco=sdext', f'disco={disco}')

                with open('busqueda_rapida7.py', 'w') as memory_file:
                    memory_file.writelines(lines)

                print(f"\nElegiste la memoria-externa {PURPLE}{disco}{ENDC}")
                buscar_palabra(user_dir, palabra_buscada)
            else:
                os.system('clear')
                print("\nBusque bien el nombre de su SDCARD EXTERNA")
                input()
                esd = 'a'
        elif esd in {'4', '04'}:
            # Puedes agregar aqui el codigo para volver al menu anterior si es necesario
            pass
        else:
            os.system('clear')
            print("Opcion invalida")
            time.sleep(1)
            esd = 'a'


# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {'.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php', '.vb',
                        '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg', '.conf', '.properties',
                        '.env', '.config', '.xml', '.json', '.yaml', '.yml', '.xsd', '.svg', '.plist',
                        '.markdown', '.rtf', '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
                        '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po', '.pot', '.mo', '.lst',
                        '.out', '.err', '.rpt', '.man', '.help', '.eml', '.msg', '.chat', ''}

def imprimir_contenido_encontrado(contenido, ruta_completa):
    # Imprimir en colores
    print(''.join(contenido).replace(palabra_buscada, RED + palabra_buscada + ENDC)
          .replace(ruta_completa, PURPLE + ruta_completa + ENDC)
          .replace("Linea", GREEN + "Linea" + ENDC))

    # Guardar en un archivo .cpp
    with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
        cpp_file.write(''.join(contenido))

'''
def buscar_palabra_en_archivo(ruta_completa, palabra):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []

    try:
        with open(ruta_completa, 'r', encoding='utf-8') as file:
            for num_linea, linea in enumerate(file, start=1):
                if palabra in linea:
                    if not encontrado:
                        encontrado = True
                        contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                    contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

        if encontrado:
            contenido_encontrado.append("\n")
            imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)

    except UnicodeDecodeError:
        pass

    return encontrado
'''

'''
def buscar_palabra_en_archivo(ruta_completa, palabra):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []

    try:
        # Verificar si el archivo existe antes de abrirlo
        if os.path.isfile(ruta_completa):
            with open(ruta_completa, 'r', encoding='utf-8') as file:
                for num_linea, linea in enumerate(file, start=1):
                    if palabra in linea:
                        if not encontrado:
                            encontrado = True
                            contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                        contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

            if encontrado:
                contenido_encontrado.append("\n")
                imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
    except UnicodeDecodeError:
        pass

    return encontrado
'''
def buscar_palabra_en_archivo(ruta_completa, palabra):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []

    try:
        # Verificar si el archivo existe antes de abrirlo
        if os.path.isfile(ruta_completa):
            with open(ruta_completa, 'r', encoding='utf-8') as file:
                for num_linea, linea in enumerate(file, start=1):
                    if palabra in linea:
                        if not encontrado:
                            encontrado = True
                            contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                        contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

            if encontrado:
                contenido_encontrado.append("\n")
                imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
    except UnicodeDecodeError:
        pass

    return encontrado


def buscar_palabra(directorio, palabra):
    inicio = time.time()

    archivos = [os.path.join(raiz, archivo) for raiz, carpetas, archivos in os.walk(directorio) for archivo in archivos]

    # Utilizar joblib para procesamiento en paralelo
    resultados = Parallel(n_jobs=-1)(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)

    fin = time.time()
    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    archivos_encontrados = sum(resultados)
    print(f"Total de archivos encontrados: {archivos_encontrados}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

def speed(archivo, palabra):
    # Utilizar ThreadPool para manejar los hilos
    with ThreadPoolExecutor() as executor:
        executor.submit(buscar_palabra, archivo, palabra)

directorio_base = os.path.expanduser('/sdcard/')  # Actualiza esta variable con la ruta de tu directorio base
palabra_buscada = 'Jakekovac3'

# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass

seleccionar_ruta()
#speed(directorio_base, palabra_buscada)
# time.sleep(5)  # Agregar un retardo para permitir que los hilos completen sus tareas antes de que el programa principal termine

# A60E-06CA
