import os
import time
from concurrent.futures import ThreadPoolExecutor
from joblib import Parallel, delayed

# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {'.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php', '.vb',
                        '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg', '.conf', '.properties',
                        '.env', '.config', '.xml', '.json', '.yaml', '.yml', '.xsd', '.svg', '.plist',
                        '.markdown', '.rtf', '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
                        '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po', '.pot', '.mo', '.lst',
                        '.out', '.err', '.rpt', '.man', '.help', '.eml', '.msg', '.chat', ''}

def imprimir_contenido_encontrado(contenido, ruta_completa):
    # Imprimir en colores
    print(''.join(contenido).replace(palabra_buscada, RED + palabra_buscada + ENDC)
          .replace(ruta_completa, PURPLE + ruta_completa + ENDC)
          .replace("Linea", GREEN + "Linea" + ENDC))

    # Guardar en un archivo .cpp
    with open("resultado.cpp", "a", encoding='utf-8') as cpp_file:
        cpp_file.write(''.join(contenido))

def buscar_palabra_en_archivo(ruta_completa, palabra):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []

    try:
        with open(ruta_completa, 'r', encoding='utf-8') as file:
            for num_linea, linea in enumerate(file, start=1):
                if palabra in linea:
                    if not encontrado:
                        encontrado = True
                        contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                    contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

        if encontrado:
            contenido_encontrado.append("\n")
            imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)

    except UnicodeDecodeError:
        pass

    return encontrado

def buscar_palabra(directorio, palabra):
    inicio = time.time()

    archivos = [os.path.join(raiz, archivo) for raiz, carpetas, archivos in os.walk(directorio) for archivo in archivos]

    # Utilizar joblib para procesamiento en paralelo
    resultados = Parallel(n_jobs=-1)(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)

    fin = time.time()
    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    archivos_encontrados = sum(resultados)
    print(f"Total de archivos encontrados: {archivos_encontrados}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

def speed(archivo, palabra):
    # Utilizar ThreadPool para manejar los hilos
    with ThreadPoolExecutor() as executor:
        executor.submit(buscar_palabra, archivo, palabra)

directorio_base = os.path.expanduser('/sdcard/')  # Actualiza esta variable con la ruta de tu directorio base
palabra_buscada = 'Jakekovac3'

# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass

speed(directorio_base, palabra_buscada)
# time.sleep(5)  # Agregar un retardo para permitir que los hilos completen sus tareas antes de que el programa principal termine
