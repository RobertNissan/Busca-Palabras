import os
import time
import threading

try:
    from joblib import Parallel, delayed
except ImportError:
    os.system("pip install joblib")
    from joblib import Parallel, delayed

def buscar_palabra_en_archivo(ruta_completa, palabra):
    encontrado = False
    contenido_encontrado = []

    try:
        with open(ruta_completa, 'r', encoding='utf-8') as file:
            for num_linea, linea in enumerate(file, start=1):
                if palabra in linea:
                    if not encontrado:
                        encontrado = True
                        contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                    contenido_encontrado.append(f"Linea {num_linea}: {linea.rstrip()}\n")

        if encontrado:
            contenido_encontrado.append("\n")  # Agregar un salto de linea despues de imprimir cada archivo si se encontro la palabra
            # Imprimir inmediatamente al encontrar un archivo
            print(''.join(contenido_encontrado))

    except UnicodeDecodeError:
        pass

    return encontrado

def speed(archivo, palabra):
    # Recorrer los archivos del directorio y sus subdirectorios en un hilo separado
    threading.Thread(target=buscar_palabra, args=(archivo, palabra)).start()

def buscar_palabra(directorio, palabra):
    inicio = time.time()

    archivos = [os.path.join(raiz, archivo) for raiz, carpetas, archivos in os.walk(directorio) for archivo in archivos]

    # Utilizar joblib para procesamiento en paralelo
    # Utilizar joblib para procesamiento en paralelo
    #resultados = Parallel(n_jobs=-1)(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)
    #resultados = Parallel(n_jobs=-1, backend="threading")(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)
    #resultados = Parallel(n_jobs=2)(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)
    #resultados = Parallel(n_jobs=-1, prefer="threads", require="sharedmem", batch_size='auto')(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)
    resultados = Parallel(n_jobs=-1, backend="loky")(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos)

    fin = time.time()
    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    archivos_encontrados = sum(resultados)
    print(f"Total de archivos encontrados: {archivos_encontrados}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

directorio_base = os.path.expanduser('/sdcard/')  # Actualiza esta variable con la ruta de tu directorio base
palabra_buscada = 'falabella'

buscar_palabra(directorio_base, palabra_buscada)
