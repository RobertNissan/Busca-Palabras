import re

texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aquí ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""

print(texto)
print("Texto de prueba")

# Obtener la frase a buscar del usuario
frase_buscar = input("Ingrese la frase a buscar: ")

# Convertir el texto a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
texto_minusculas = texto.lower()

# Convertir la frase a una lista de palabras
palabras_frase = frase_buscar.lower().split()

# Inicializar un diccionario para mantener el recuento de palabras en cada línea
palabras_en_linea = {}

# Iterar sobre cada línea del texto
for i, linea in enumerate(texto.split('\n')):
    # Contar el número de coincidencias de palabras en la línea
    coincidencias = sum(1 for palabra in palabras_frase if re.search(r'\b{}\b'.format(re.escape(palabra)), linea.lower()))
    
    # Actualizar el diccionario de palabras en línea
    palabras_en_linea[i] = coincidencias

# Encontrar la línea con la mayoría de las palabras de la frase
linea_con_mas_coincidencias = max(palabras_en_linea, key=palabras_en_linea.get)

# Verificar si se encontraron coincidencias
if palabras_en_linea[linea_con_mas_coincidencias] > 0:
    print("Búsqueda exitosa")
    print("Frase encontrada:", frase_buscar)
    print("Coincidencia encontrada en la línea:")
    
    # Mostrar la línea con más coincidencias
    print(texto.split('\n')[linea_con_mas_coincidencias])
else:
    print("No se encontraron coincidencias en el texto.")
