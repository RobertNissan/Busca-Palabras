import re
from itertools import permutations

texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aqui ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""
print(texto)
print("texto de prueba")
frase_buscar = input("ingrese la frase a buscar: ")
palabras = frase_buscar.split()

# Generar todas las permutaciones de las palabras de la frase a buscar
permutaciones_frase = [' '.join(perm) for perm in permutations(palabras)]

# Construir el patrón de búsqueda con todas las permutaciones
patron = re.compile(r'\b(?:' + '|'.join(re.escape(permutacion) for permutacion in permutaciones_frase) + r')\b', re.IGNORECASE)

resultado = patron.search(texto)

if resultado:
    print("Búsqueda exitosa")
    print("Frase encontrada:", resultado.group(0))
    # Encuentra la línea en la que se encuentra la coincidencia
    lineas = texto.split('\n')
    for i, linea in enumerate(lineas):
        if resultado.group(0) in linea:
            print("Coincidencia encontrada en la línea:", i+1)
else:
    print("No se encontró el patrón buscado")
