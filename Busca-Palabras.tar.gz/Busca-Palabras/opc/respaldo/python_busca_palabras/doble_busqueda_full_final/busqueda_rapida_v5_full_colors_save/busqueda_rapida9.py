import os
import time
import logging
from concurrent.futures import ThreadPoolExecutor
from joblib import Parallel, delayed
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    
# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass
    
ruta_actual = os.getcwd()
def seleccionar_ruta():
    esd = 'a'
    while esd == 'a':
        os.system('clear')
        print("\nElija la ruta donde buscar:")
        print("[1] Termux /home/")
        print("[2] Interna /sdcard/")
        print("[3] Externa /sdcard/")
        print("[4] Menu anterior")

        esd = input("> ")

        if esd in {'1', '01'}:
            disco = "/data/data/com.termux/files/home"
            os.chdir(disco)
            print(f"\nElegiste termux-home {PURPLE}{disco}{ENDC}")
            #buscar_palabra(disco, palabra_buscada)
        elif esd in {'2', '02'}:
            disco = "/sdcard"
            os.chdir(disco)
            print(f"\nElegiste la memoria-interna {PURPLE}{disco}/{ENDC}")
            #buscar_palabra(disco, palabra_buscada)
        elif esd in {'3', '03'}:
            if os.path.isfile('/storage/sdext/.micro'):
                disco = 'sdext'
            else:
                print("\nInserta el nombre de tu tarjeta:")
                disco = input(">>> ")
                while not disco:
                    os.system('clear')
                    print("\nInserta el nombre de tu tarjeta:")
                    disco = input(">>> ")

            user_dir = os.path.join('/storage', disco)
            os.chdir(user_dir)
            x = os.getcwd()
            tez = f'/storage/{disco}'

            if x == tez:
                user_dir = os.path.join('/storage', disco)
                os.chdir(user_dir)
                open(f'/storage/{disco}/.{disco}', 'w').close()

                # Actualizar rutas en el script de memoria
                with open(f'{ruta_actual}/busqueda_rapida_v5_full_colors_save.py', 'r') as memory_file:
                    lines = memory_file.readlines()

                for i, line in enumerate(lines):
                    if "/storage/sdext/.micro" in line:
                        lines[i] = line.replace(f'/storage/sdext/.micro', f'/storage/{disco}/.{disco}')

                    if "disco=sdext" in line:
                        lines[i] = line.replace('disco=sdext', f'disco={disco}')

                with open('busqueda_rapida_v5_full_colors_save.py', 'r') as memory_file:

                    memory_file.writelines(lines)

                print(f"\nElegiste la memoria-externa {PURPLE}{disco}{ENDC}")
                #buscar_palabra(user_dir, palabra_buscada)
            else:
                os.system('clear')
                print("\nBusque bien el nombre de su SDCARD EXTERNA")
                input()
                esd = 'a'
        elif esd in {'4', '04'}:
            # Puedes agregar aqui el codigo para volver al menu anterior si es necesario
            pass
        else:
            os.system('clear')
            print("Opcion invalida")
            time.sleep(1)
            esd = 'a'
    return disco


# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {'.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php', '.vb',
                        '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg', '.conf', '.properties',
                        '.env', '.config', '.xml', '.json', '.yaml', '.yml', '.xsd', '.svg', '.plist',
                        '.markdown', '.rtf', '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
                        '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po', '.pot', '.mo', '.lst',
                        '.out', '.err', '.rpt', '.man', '.help', '.eml', '.msg', '.chat', ''}

def resaltar_palabra(linea, palabras):
    for palabra in palabras:
        linea = linea.replace(palabra, RED + palabra + ENDC)
    return linea

def imprimir_contenido_encontrado(contenido, ruta_completa):
    contenido_resaltado = [resaltar_palabra(linea, palabras_buscadas) for linea in contenido]
    contenido_resaltado = ''.join(contenido_resaltado).replace(ruta_completa, PURPLE + ruta_completa + ENDC) \
        .replace("Linea", GREEN + "Linea" + ENDC)

    # Imprimir en la consola
    print(contenido_resaltado)

    # Eliminar codigos ANSI antes de guardar en el archivo .cpp
    contenido_sin_colores = remove_ansi_codes(contenido_resaltado)

    # Guardar en un archivo .cpp
    with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
        cpp_file.write(contenido_sin_colores)

def remove_ansi_codes(texto):
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', texto)

        
'''
def imprimir_contenido_encontrado(contenido, ruta_completa):
    # Imprimir en colores
    print(''.join(contenido).replace(palabra_buscada, RED + palabra_buscada + ENDC)
          .replace(ruta_completa, PURPLE + ruta_completa + ENDC)
          .replace("Linea", GREEN + "Linea" + ENDC))

    # Guardar en un archivo .cpp
    with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
        cpp_file.write(''.join(contenido))
'''
def normalizar_caracteres(texto):
    # Implementa tu logica de normalizacion especifica
    # Puedes utilizar diccionarios o reglas especificas segun tus necesidades
    # Por ejemplo, reemplazar caracteres acentuados por sus equivalentes sin acento
    caracteres_especiales = {'a': 'a', 'e': 'e', 'i': 'i', 'o': 'o', 'u': 'u'}
    for original, reemplazo in caracteres_especiales.items():
        texto = texto.replace(original, reemplazo)
    return texto
    
CHUNK_SIZE = 4096  # Tamano del bloque en bytes
def buscar_palabra_en_archivo(ruta_completa, palabra):
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []

    try:
        with open(ruta_completa, 'r', encoding='utf-8') as file:
            buffer = ""  # Almacena el contenido no procesado entre bloques
            line_number = 0  # Numero de linea actual

            while True:
                chunk = file.read(CHUNK_SIZE)
                if not chunk:
                    break

                # Aplica la normalizacion al bloque
                normalized_chunk = normalizar_caracteres(buffer + chunk)

                # Divide el contenido normalizado en lineas
                lines = normalized_chunk.splitlines()

                for linea in lines:
                    line_number += 1
                    if palabra.lower() in linea:
                        if not encontrado:
                            contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}\n")
                            encontrado = True
                        contenido_encontrado.append(f"Linea {line_number}: {linea.rstrip()}\n")

                buffer = lines[-1]  # Restablece el buffer con la ultima linea incompleta

            if encontrado:
                contenido_encontrado.append("\n")
                imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)

    except UnicodeDecodeError:
        pass

    return encontrado


def buscar_palabra(directorio, palabras):
    inicio = time.time()

    archivos = [os.path.join(raiz, archivo) for raiz, carpetas, archivos in os.walk(directorio) for archivo in archivos]
    
    #print("Palabras a buscar:", palabras)
    #print("Archivos a analizar:", archivos)

    # Utilizar joblib para procesamiento en paralelo
    resultados = Parallel(n_jobs=-1)(delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos for palabra in palabras)

    fin = time.time()
    tiempo_transcurrido = fin - inicio

    horas = int(tiempo_transcurrido // 3600)
    minutos = int((tiempo_transcurrido % 3600) // 60)
    segundos = int(tiempo_transcurrido % 60)
    milisegundos = int((tiempo_transcurrido % 1) * 1000)

    archivos_encontrados = sum(resultados)
    print(f"Total de archivos encontrados: {archivos_encontrados}")
    print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")

# Llama a la funcion para obtener el valor de 'disco'
disco = seleccionar_ruta()
directorio_base = os.path.expanduser(disco)  # Actualiza esta variable con la ruta de tu directorio base

palabra_buscada = input('ingrese la palabra o las palabras\n> ')

palabras_buscadas = palabra_buscada.split('|') if '|' in palabra_buscada else [palabra_buscada]
buscar_palabra(directorio_base, palabras_buscadas)

# A60E-06CA

