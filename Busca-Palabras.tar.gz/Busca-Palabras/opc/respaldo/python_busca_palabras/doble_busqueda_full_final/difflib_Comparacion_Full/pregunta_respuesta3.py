def buscar_palabras_en_pasaje(pasaje, pregunta):
    palabras_pregunta = pregunta.split()
    lineas = pasaje.split('\n')
    for linea in lineas:
        contador = 0
        for palabra in palabras_pregunta:
            if palabra.lower() in linea.lower():
                contador += 1
                if contador >= 2:
                    print(f"La línea '{linea.strip()}' contiene al menos dos palabras de la pregunta.")
                    break  # Salir del bucle interno una vez que se encuentra la línea adecuada

pasaje = """
jesus enseña sobre el divorcio
al principio, no era así. Ahora os digo yo que,
si uno se divorcia de su mujer -no hablo de unión ilegítima-,
y se casa con otra, comete adulterio.
"""

pregunta = input("Ingresa tu pregunta: ")
buscar_palabras_en_pasaje(pasaje, pregunta)

# nota: debe haber más de dos palabra en el input 
#que coincidan con el pasaje, principalmente el sustantivo 

