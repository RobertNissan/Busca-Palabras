import re

texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aqui ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""

resultado = re.search('cigarro', texto, flags=re.IGNORECASE)

if resultado != None:
    print("Búsqueda exitosa")
    print(resultado)
else:
    print("No se encontró el patrón buscado")



texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aqui ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""

sust = "cigarro|mujer"
resultados = re.findall(r'\b({})\b'.format(sust), texto)

if resultados:
    print("Búsqueda exitosa:")
    for resultado in resultados:
        print(resultado)
else:
    print("No se encontraron los patrones buscados.")

'''
En el contexto de la expresión regular que te proporcioné, 
\b se utiliza para asegurarse de que la búsqueda de las
palabras "cigarro" y "mujer" coincida solo cuando estén 
como palabras completas y no como parte de una palabra 
más larga. Esto evita que coincida con palabras como
"cigarrón" o "mujeres".
'''