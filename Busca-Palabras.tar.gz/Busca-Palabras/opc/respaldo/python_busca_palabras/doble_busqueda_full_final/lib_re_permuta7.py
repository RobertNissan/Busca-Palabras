import re
from colorama import init, Fore

# Inicializar colorama
init(autoreset=True)

# Ruta del archivo de texto
archivo = "/sdcard/biblia.txt"

# Leer el texto del archivo
with open(archivo, "r") as file:
    texto = file.read()

#print(texto)
#print("Texto de prueba")

# Obtener la frase a buscar del usuario
frase_buscar = input("Ingrese la frase a buscar: ")

# Convertir el texto a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
texto_minusculas = texto.lower()

# Convertir la frase a una lista de palabras
palabras_frase = frase_buscar.lower().split()

# Inicializar un diccionario para mantener el recuento de palabras en cada línea
palabras_en_linea = {}

# Iterar sobre cada línea del texto
for i, linea in enumerate(texto.split('\n')):
    # Contar el número de coincidencias de palabras en la línea
    coincidencias = sum(1 for palabra in palabras_frase if re.search(r'\b{}\b'.format(re.escape(palabra)), linea.lower()))
    
    # Actualizar el diccionario de palabras en línea
    palabras_en_linea[i] = coincidencias

# Encontrar la línea con la mayoría de las palabras de la frase
linea_con_mas_coincidencias = max(palabras_en_linea, key=palabras_en_linea.get)

# Verificar si se encontraron coincidencias
if palabras_en_linea[linea_con_mas_coincidencias] > 0:
    print("Búsqueda exitosa")
    print("Frase encontrada:", frase_buscar)
    print("Coincidencia encontrada en la línea:")
    
    # Resaltar las palabras coincidentes en la línea con color rojo
    linea = texto.split('\n')[linea_con_mas_coincidencias]
    for palabra in palabras_frase:
        # Usar color rojo para resaltar las palabras coincidentes
        linea = re.sub(r'\b{}\b'.format(re.escape(palabra)), Fore.RED + palabra + Fore.RESET, linea, flags=re.IGNORECASE)
    
    # Imprimir la línea con las palabras resaltadas
    print(linea)
else:
    print("No se encontraron coincidencias en el texto.")

