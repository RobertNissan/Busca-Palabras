import os
import time
import concurrent.futures
from multiprocessing import cpu_count
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor, as_completed
from joblib import Parallel, delayed, parallel_backend
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")
try:
    from tqdm import tqdm
except ImportError:
    os.system("pip install tqdm")
    from tqdm import tqdm
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
import mmap
import re
import linecache
import subprocess
from unidecode import unidecode
from colorama import init, Fore

# Inicializar colorama
init()

 
# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

archivos_encontrados = 0
ruta_actual = os.getcwd()

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {
    '.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php',
    '.vb', '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg',
    '.conf', '.properties','.env', '.config', '.xml', '.json',
    '.yaml', '.yml', '.xsd', '.svg', '.plist','.markdown', '.rtf',
    '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
    '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po',
    '.pot', '.mo', '.lst','.out', '.err', '.rpt', '.man', '.help',
    '.eml', '.msg', '.chat', '.db', '.srt', '.pub', ''}
    
# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass
    
def resaltar_palabra_encontrada(linea, palabra):
    return linea.replace(palabra, RED + palabra + ENDC)

def imprimir_contenido_encontrado(contenido, ruta_completa):
    if contenido:  # Asegurarse de que haya contenido antes de imprimir
        contenido_resaltado = [resaltar_palabra_encontrada(linea, palabra_buscada) for linea in contenido]
        contenido_resaltado = '\n'.join(contenido_resaltado).replace(ruta_completa, PURPLE + ruta_completa + ENDC) \
            .replace(f"Encontrada la palabra '{RED}{palabra_buscada}'", f"Encontrada la palabra '{RED}{palabra_buscada}'{ENDC}") \
            .replace("Linea", GREEN + "Linea" + ENDC)

        # Imprimir en la consola
        #print(contenido_resaltado)

        # Eliminar codigos ANSI antes de guardar en el archivo .cpp
        contenido_sin_colores = remove_ansi_codes(contenido_resaltado)

        # Agregar un salto de linea al final de la cadena antes de guardar en el archivo .cpp
        contenido_sin_colores += '\n'

        # Guardar en un archivo .cpp
        with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
            cpp_file.write(contenido_sin_colores)

def remove_ansi_codes(texto):
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', texto)
    
# Convertir las palabras con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabras):
    regex = []
    for palabra in palabras.split('|'):
        regex_palabra = []
        for letra in palabra:
            if letra.lower() == 'a':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'e':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'i':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'o':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'u':
                regex_palabra.append('[uúùüûū]')

            elif letra.lower() == 'á':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'é':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'í':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'ó':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'ú':
                regex_palabra.append('[uúùüûū]')

            else:
                #regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
                if letra != '.':
                    regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
                else:
                   regex_palabra.append(letra)
        regex.append(''.join(regex_palabra))
    return '|'.join(regex)
    
import re
import mmap

# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex1(palabras):
    regex_palabra = []
    for letra in palabras:
        if letra.lower() == 'a':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'e':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'i':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'o':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'u':
            regex_palabra.append('[uúùüûū]')

        elif letra.lower() == 'á':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'é':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'í':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'ó':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'ú':
            regex_palabra.append('[uúùüûū]')

        else:
            if letra != '.':
                regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
            else:
                regex_palabra.append(letra)
    return ''.join(regex_palabra)
    
ruta_rep = []
cap_ruta = []
# Esta expresión regular encuentra los códigos de formato ANSI en el texto
ansi_escape = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
def buscar_palabra_en_archivo(ruta_completa, palabra, resultado_buscar):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []
    cnt_palabras = palabra.split(' ')
    # Inicializar palabra_frase como una cadena vacía
    palabra_frase = ""
    
    if not ruta_completa in ruta_rep or not resultado.cpp in ruta_completa:
        try:
            # Check if file is empty
            if os.path.getsize(ruta_completa) > 0:
                with open(ruta_completa, 'r', encoding='utf-8') as file:
                    with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
                        
                        
                        
                        # Convertir el contenido del mapeo en una cadena de bytes y luego decodificarla a una cadena de texto
                        texto = mm[:].decode('utf-8')
                        
                        if len(palabras_texto) > 1 and capturar_sust != [None]: 
                            #print("aquí estoy")
                            # Realizar la búsqueda dentro del texto decodificado
                            # coincidencias = re.findall(palabras_regex, texto, flags=re.IGNORECASE)
                            coincidencias = re.findall(r'\b({})\b'.format(palabras_regex), texto, flags=re.IGNORECASE)
                        
                            coincidencias1 = re.findall(palabras_regex1, texto, flags=re.IGNORECASE)
                            #coincidencias1 = re.findall(r'\b({})\b'.format(palabras_regex1), texto, flags=re.IGNORECASE)
                            coincidencias2 = False
                            coincidencias3 = False
                        else:
                            #print("bien")
                            coincidencias = False
                            coincidencias1 = False
                            # se quita r'\b({})\b' para considerar el @
                            coincidencias2 = re.findall(r'({})'.format(palabras_regex), texto, flags=re.IGNORECASE)

                            coincidencias3 = re.findall(r'\b({})\b'.format(palabras_regex2), texto, flags=re.IGNORECASE)
                            #print(coincidencias2)
                            #if "11lulu1976adrimar09@" in coincidencias3:
                                #sys.exit()

                        # Imprimir las coincidencias encontradas
                        if coincidencias and coincidencias1 or coincidencias2 or coincidencias3:
                            if os.path.getsize(ruta_completa) > 0:
                                #print("buscar", buscar_todo)
                                resultado_grep = subprocess.run(f"unidecode < '{ruta_completa}' | grep -inE '{buscar_todo}' | cut -d ':' -f 1", capture_output=True, text=True, shell=True)
                                numeros_linea = [int(numero) for numero in resultado_grep.stdout.strip().split()]
                                # Mostrar las líneas específicas usando linecache
                                for numero_linea in numeros_linea:
                                    linea = linecache.getline(ruta_completa, numero_linea)
                                    # Resaltar palabras buscadas en rojo
                                    palabras_linea = linea.strip().split()
                                    for i, palabra_linea in enumerate(palabras_linea):
                                        #for palabra_buscada in palabra.split('|'):
                                        for palabra_buscada in buscar_todo.split('|'):
                                            if palabra_buscada.lower() in unidecode(palabra_linea.lower()):
                                                palabras_linea[i] = f"{Fore.RED}{palabra_linea}{Fore.RESET}"
                                    if not encontrado:
                                        encontrado = True
                                        contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}")
                                        print(f"Encontrada la palabra '{palabra}' en el archivo: {Fore.MAGENTA}{ruta_completa}{Fore.RESET}")
                                    linea_resaltada = ' '.join(palabras_linea)
                                    # Remover los códigos de formato ANSI del texto
                                    palabras_linea = [ansi_escape.sub('', palabra) for palabra in palabras_linea]
                                    # Unir las palabras con un espacio
                                    linea_resaltada1 = ' '.join(palabras_linea)
                                    print(f"\n{Fore.GREEN}Línea {Fore.RESET}{numero_linea}: {linea_resaltada}\n")

                                    contenido_encontrado.append(f"Líneas {numero_linea}: {linea_resaltada1}\n")
                                    #print(f"\n{Fore.GREEN}línea {Fore.RESET}{numero_linea}: {linea_resaltada}\n")
                                    #imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
                                    
                                    #with open("resultado.cpp", "a") as resultado_file:
                                        #resultado_file.write(f"'{cap_ruta}'\n")
                                        #resultado_file.write(f"{contenido_encontrado}")

                                    
                                imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
                                ruta_rep.append(ruta_completa)
                                return encontrado
                    if encontrado:
                        contenido_encontrado.append("\n")
                        imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
                #ruta_rep.append(ruta_completa)
                 
        except UnicodeDecodeError:
            ruta_rep.append(ruta_completa)
            pass
    return encontrado



def contar_archivos(directorio):
    total = 0
    for base, dirs, files in os.walk(directorio):
        total += len(files)
    return total
def cargar_archivo(ruta_archivo, destino):
    # Simulando la carga del archivo, aqui podrias escribir el codigo real para procesar o copiar el archivo
    return ruta_archivo
def buscar_palabra(directorio, palabras, resultado_buscar):
    archivos = []
    archivos_encontrados = 0  # Initialize archivos_encontrados here
    inicio = time.time()
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for ruta, directorios, archivos_en_dir in os.walk(directorio_base):
            for archivo in archivos_en_dir:
                ruta_completa = os.path.join(ruta, archivo)
                futures.append(executor.submit(cargar_archivo, ruta_completa, '/destino'))
        print('Cargando archivos')
        for future in tqdm(as_completed(futures), total=len(futures), desc='', unit='archivo'):
            archivo_cargado = future.result()
            archivos.append(archivo_cargado)
    print('\n')
 
    with parallel_backend('loky', n_jobs=-1):
        resultados = Parallel(n_jobs=-1, backend='loky', prefer='threads', batch_size='auto', temp_folder=None, verbose=0)(
            delayed(buscar_palabra_en_archivo)(archivo, palabra, buscar_todo) for archivo in archivos for palabra in palabras
        )
       
        fin = time.time()
        tiempo_transcurrido = fin - inicio
    
        horas = int(tiempo_transcurrido // 3600)
        minutos = int((tiempo_transcurrido % 3600) // 60)
        segundos = int(tiempo_transcurrido % 60)
        milisegundos = int((tiempo_transcurrido % 1) * 1000)
    archivos_encontrados = sum(resultados)  # Update archivos_encontrados here
    
    if archivos_encontrados > 0:
        print(f"Total de archivos encontrados: {archivos_encontrados}")
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
        print("Copia de búsqueda guardada en resultado.cpp\n")
    else:
        print("No se encontró:\n>> ", palabras_buscadas)
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms\n")

# Llama a la funcion para obtener el valor de 'disco'
#disco = '/sdcard/backups/'
disco = '/sdcard/'
directorio_base = os.path.expanduser(disco)  # Actualiza esta variable con la ruta de tu directorio base

palabra_buscada = input('ingrese la palabra o las palabras\n> ')
# palabra_buscada = unidecode(palabra_buscada.lower())
palabras_buscadas = [unidecode(palabra.lower()) for palabra in palabra_buscada.split('|')] if '|' in palabra_buscada else [unidecode(palabra_buscada.lower())]
print("palabras_buscadas", palabras_buscadas)
#input()

#----------------CORRECTOR-ORTOGRAFICO---------------#
try:
    from spellchecker import SpellChecker
except:
    os.system("pip install pyspellchecker")
    from spellchecker import SpellChecker
from unidecode import unidecode

# Crear un objeto SpellChecker
spell = SpellChecker(language='es')

# Función para cargar un diccionario personalizado desde un archivo de texto
def cargar_diccionario_personalizado(ruta_archivo):
    with open(ruta_archivo, "r", encoding="utf-8") as file:
        lineas = [line.strip().split('|') for line in file]
        diccionario = {palabra[0]: palabra[1] if len(palabra) > 1 else None for palabra in lineas}
    return diccionario


# Ruta al archivo que contiene el diccionario personalizado
ruta_diccionario_personalizado = "/sdcard/dic_orden/diccionario.txt"

# Cargar el diccionario personalizado
palabras_personalizadas = cargar_diccionario_personalizado(ruta_diccionario_personalizado)
spell.word_frequency.load_words(palabras_personalizadas)


# Crear una tabla de traducción para eliminar los signos de puntuación
translator = str.maketrans('', '', ',.;:!?')
# Convertir el texto del usuario a minúsculas y eliminar acentos
#palabra_usuario = "bsjdkd kdkdkdkddkd En zapatería las tablillas sumerias, se dice que Robert y enkhai y jam ayuda a la humanidad y a vosotro en sus casas, Correto?"
palabras_texto = [unidecode(palabra.lower().translate(translator)) for palabra in palabra_buscada.split()]

capturar_todo= []
capturar_sust = []
capturar_claves = []
#etiqueta = None
# Corregir palabras mal escritas en el texto
for palabra in palabras_texto:
    #palabra = crear_regex1(palabra)
    correccion = spell.correction(palabra)
    try:
        if correccion != palabra and correccion.startswith(palabra[:3]) and fuzz.ratio(palabra, correccion) > 80:
            if correccion in palabras_personalizadas:
                etiqueta = palabras_personalizadas[correccion]
                if etiqueta == "NOUN":
                    capturar_sust.append(correccion)
                    capturar_todo.append(correccion)
                    #continue
                else:
                    print(f'Corregida: {etiqueta}: {correccion}')
                    capturar_claves.append(correccion)
                    capturar_todo.append(correccion)
            else:
                try:
                    etiqueta = palabras_personalizadas[correccion]
                    if etiqueta == "NOUN":
                        capturar_sust.append(correccion)
                        capturar_todo.append(correccion)
                        #continue
                except:
                    for pal_text in (palabras_buscadas):
                        print(''.join(palabras_texto))
                        print(pal_text)
                        print(f'Palabra mal escrita: "{palabra}", Corrección: "{correccion}"')
                        capturar_sust.append(correccion)
                        capturar_claves.append(pal_text)
                        capturar_todo.append(pal_text)
                        input()
        else:
            if palabra in palabras_personalizadas:
                etiqueta = palabras_personalizadas[palabra]
                if etiqueta == "NOUN":
                    capturar_sust.append(palabra)
                    capturar_todo.append(palabra)
                    #continue
                else:
                    print(f'Original: {etiqueta}: {palabra}')
                    capturar_claves.append(palabra)
                    capturar_todo.append(palabra)
            else:
                print(f'Original: Palabra bien escrita: "{palabra}", Corrección: ninguna')
                capturar_claves.append(palabra)
                capturar_todo.append(palabra)
    except AttributeError:
        for pal_text in (palabras_buscadas):
            print(''.join(palabras_texto))
            print(pal_text)
            print(f'Palabra mal escrita: "{palabra}", Corrección: "{correccion}"')
            #capturar_sust.append(correccion)
            capturar_claves.append(pal_text)
            capturar_todo.append(pal_text)
        pass

# Nota: Funciona en pydroid 3 y termux
def procesar_variable(buscar_todo):
    palabras = buscar_todo.split()
    if len(palabras) == 1:
        return palabras[0]
    else:
        palabras_unificadas = set()
        for palabra in palabras:
            if '|' in palabra:
                palabras_unificadas.update(palabra.split('|'))
            else:
                palabras_unificadas.add(palabra)
        palabras_unificadas.discard("electrónico")
        return '|'.join(sorted(palabras_unificadas))

#buscar_todo = 'roberj.meza correo electronico|correo|electrónico'

#print("buscar_todo:", resultado)

todas = []
if len(palabras_texto) == 1:
    for pal_text in (palabras_buscadas):
        capturar_sust = pal_text
        capturar_claves = pal_text
    palabras_regex = crear_regex1(capturar_sust)
    #print("palabras_regex:", palabras_regex)
    #input("aquí")
    palabras_regex1 = crear_regex1(capturar_claves)
    palabras_regex2 = crear_regex1(capturar_claves)
    buscar_todo = pal_text
    
else:
    print("Sustantivos:", capturar_sust)
    #print("Sustantivos:", ' '.join(capturar_sust))
    #sust = '|'.join(capturar_sust)
    sust = '|'.join([word for word in capturar_sust if word is not None])
    palabras_con_barra = sust.lower().replace(' ', '|')
    palabras_regex = crear_regex(palabras_con_barra)
    #print(palabras_regex)
    
    print("\n#--------------------------------------------------#\n")
    resultado = ' '.join([word for word in capturar_claves if word is not None])
    resultado_buscar = '|'.join([word for word in capturar_claves if word is not None])
    palabras_con_barra1 = resultado_buscar.lower().replace(' ', '|')
    palabras_regex1 = crear_regex(palabras_con_barra1)
    #print(resultado)
    print("palabras_regex1:", palabras_regex1)
    
    buscar_todo = '|'.join([word for word in capturar_todo if word is not None])
    palabras_con_barra2 = buscar_todo.lower().replace(' ', '|')
    palabras_regex2 = crear_regex(palabras_con_barra2)
    resultado = procesar_variable(buscar_todo)
    print("sustantivo:", sust)
    for pal_text in (palabras_buscadas):
        todas.append(pal_text)
    print("resultado_buscar:", todas)

buscar_todo = procesar_variable(buscar_todo.lower())
buscar_todo = unidecode(buscar_todo)
print("palabras_regex:", palabras_regex)
print("buscar_todo:", buscar_todo)
input()

# link diccionario: https://mega.nz/file/rVYkTLwB#_zrcw9hCQOuEFt6FH6yVhg73OlueJ-p4yjoqo42Ijl4

'''
el diccionario debe tener palabras con etiquetas, ejemplo:
Enki|NOUN
zapatería
Robert|NOUN
puede agregar etiqueta a las palabras que necesitas destacar!
la palabra zapatería no tiene etiqueta al igual se carga en la verificación.
'''
#-------------CORRECTOR-ORTOGRAFICO-FIN-------------#



buscar_palabra(directorio_base, palabras_buscadas, buscar_todo)

'''

enki es satanas y le dió ayuda a los humanos, con su poder 

if fs in linea_normal or (palabra_frase := ' '.join(palabras_capturadas)) and fuzz.ratio(palabra_frase, palabra) >= 80: 
    # Hacer algo con la frase válida
    
    
if fs in linea_normal and fuzz.ratio(fs, linea_normal) >= 80: palabras_validas = [palabra for palabra in palabras_capturadas if fuzz.ratio(palabra, palabra) >= 80]
'''




# Inicializar colorama
init(autoreset=True)

# Variable sust con una palabra o dos separadas por "|"
#sust = "jesus|robert"

# Variable palabras_regex con las palabras de la variable sust
#palabras_regex = '|'.join([f'{letra}' for letra in sust.split('|')])

# Variable palabras_regex1
#palabras_regex1 = "d[iíìïîī]v[oõôöóò]rc[iíìïîī][oõôöóò]|h[aáàäâã]bl[aáàäâã]"

# Ruta del archivo de texto
archivo = "/sdcard/resultado.cpp"

# Leer el texto del archivo
with open(archivo, "r") as file:
    texto = file.read()

# Buscar las líneas que contienen las palabras de la variable sust
lineas_con_palabras = [i for i, linea in enumerate(texto.split('\n')) if any(sust_word in unidecode(linea.lower()) for sust_word in sust.split('|'))]

# Verificar si se encontraron líneas con las palabras de la variable sust
if lineas_con_palabras:
    print(f"Se encontraron líneas con las palabras '{sust}'.")
    
    # Inicializar una lista para mantener las líneas con las palabras y las palabras clave
    lineas_con_palabras_y_claves = []
    
    # Iterar sobre las líneas con las palabras y verificar si contienen las palabras clave
    for linea_numero in lineas_con_palabras:
        linea = texto.split('\n')[linea_numero]
        if re.search(palabras_regex1, unidecode(linea.lower())):
            lineas_con_palabras_y_claves.append(linea_numero)
    
    # Verificar si se encontraron líneas con las palabras y las palabras clave
    if lineas_con_palabras_y_claves:
        print(f"Se encontraron líneas con las palabras cerca de '{sust}' y que contienen '{palabras_regex1}':")
        for linea_numero in lineas_con_palabras_y_claves:
            palabras_en_linea = re.findall(r'\b\w+\b', texto.split('\n')[linea_numero])
            linea_resaltada = texto.split('\n')[linea_numero]
            for palabra in palabras_en_linea:
                if re.search(palabras_regex, unidecode(palabra.lower())):
                    linea_resaltada = linea_resaltada.replace(palabra, Fore.RED + palabra + Fore.RESET)
                elif re.search(palabras_regex1, unidecode(palabra.lower())):
                    linea_resaltada = linea_resaltada.replace(palabra, Fore.YELLOW + palabra + Fore.RESET)
            print(f"{Fore.GREEN}Línea{Fore.RESET} {linea_numero + 1}: {linea_resaltada}")
    else:
        print(f"No se encontraron líneas con las palabras cerca de '{sust}' y que contienen '{palabras_regex1}'.")
else:
    print(f"No se encontraron líneas con las palabras '{sust}'.")
