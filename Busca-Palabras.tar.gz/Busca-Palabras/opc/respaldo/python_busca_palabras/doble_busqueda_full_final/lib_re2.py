import re
import mmap

# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabra):
    regex = []
    for letra in palabra:
        if letra in 'aeiouáéíóúÁÉÍÓÚ':
            if letra.islower():
                regex.append(f'[{letra}{letra.upper()}aAaàèìòùäëïöüâêîôûãẽĩõũoO]')
            else:
                regex.append(f'[{letra}{letra.upper()}áÁaàèìòùäëïöüâêîôûãẽĩõũÓó]')
        else:
            regex.append(letra)
    return ''.join(regex)

# Abrir el archivo utilizando mmap
with open('rocky.txt', 'r', encoding='utf-8') as file:
    with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
        # Pedir al usuario que introduzca la palabra
        palabra_con_tilde = input("Introduce la palabra con tilde: ")
        palabra_regex = crear_regex(palabra_con_tilde)

        # Realizar la búsqueda dentro del mapeo del archivo
        coincidencias = re.findall(palabra_regex.encode(), mm)

# Decodificar los bytes a cadenas utilizando decode()
coincidencias = [match.decode('utf-8') for match in coincidencias]

# Imprimir las coincidencias encontradas
if coincidencias:
    print(f'Coincidencias encontradas: {", ".join(coincidencias)}')
else:
    print("No se encontraron coincidencias.")
