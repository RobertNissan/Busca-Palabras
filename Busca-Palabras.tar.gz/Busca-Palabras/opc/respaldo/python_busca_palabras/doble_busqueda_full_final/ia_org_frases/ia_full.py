import os
import time
import concurrent.futures
from multiprocessing import cpu_count
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor, as_completed
from joblib import Parallel, delayed, parallel_backend
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")

try:
    from tqdm import tqdm
except ImportError:
    os.system("pip install tqdm")
    from tqdm import tqdm
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    

lista = 0
import unidecode

from unidecode import unidecode

from unidecode import unidecode

linea_normal = """
LAS TABLILLAS SUMERIAS? ?los ANUNNAKI? ?ANUNAKIs? ?los ANUNNAKIs?

 - Los  " ANUNNAKI " habitaron un planeta llamado " NIBIRU " el cual entraba a nuestro sistema solar cada 3600 anos , este planeta era enorme y rico en oxido de hierro , asi como sus rios y lagos que lucian rojos , ya que desde el principio de la humanidad los genetistas extraterrestres han venido manipulando nuestro ( ADN ) actualmente se han encontrado 36,000 piezas , de todas estas piezas 22,000 tablillas de arcilla fueron encontradas en 1847 , bajo los escombros del palacio de " NINIVE " las tablillas estaban cubiertas de ambos lados y fueron trasladados al museo britanico , todas ellas formaban parte de la biblioteca del " REY ASURBANIPAL " que vivio desde el ano 668 hasta 627 A.C se trataba de una gran biblioteca que recogio el saber y la ciencia de mezopotamia , pero que fue destruida cuando los babilonios arrasaron " NINIVE " en el ano 612 A.C , estos bloques de arcilla fueron manufacturados por decenas de miles que contienen una minuciosa informacion en forma de cunas , cada pieza alberga conocimientos especializados en " MATEMATICAS , ASTRONOMIA , COMPUTOS DEL TIEMPO , MEDICINA , EDUCACION , LEYES , DERECHOS HUMANOS , CIENCIAS DE LA TIERRA COMO CLIMATOLOGIA Y GEOLOGIA , ADEMAS DE FENOMENOS FISICOS Y REACCIONES QUIMICAS , POESIA , LITERATURA , AL IGUAL QUE RECETARIOS DE LA VIDA COTIDIANA Y LA INMORTALIDAD DE LOS DIOSES " cabe mencionar que su desciframiento a costado mas de 170 anos de trabajo incansable de " EPIGRAFISTAS , ARQUEOLOGOS , HISTORIADORES Y EXPERTOS EN LENGUAS MUERTAS " en las celebres tablillas sumerias narran que los primeros Seres avanzados de la tierra , bajaron del cielo hace 432,000 anos antes del diluvio universal procedentes de un doceavo planeta que forma parte de nuestro sistema solar y que fundaron aqui en la tierra su hogar , lejos de su hogar , hay " 14 TABLILLAS SUMERIAS " donde nos dice que la atmosfera de " NIBIRU " comenzo a deteriorarse y se convirtio en un lugar hostil para la vida y para restaurarlo necesitaban un importante elemento conocido como ( ORO ) aqui hacemos un hincapie donde nos presenta unos datos interesantes ya que existen pruebas de que las " NANOPARTICULAS " de ( ORO ) pueden usarse para reparar Nuestro ozono danado , pues nos protege de las radiaciones , esto  explica porque la " NASA " usa laminas de ( ORO ) en sus estaciones espaciales .....

??? CUANDO LOS ANUNNAKI LLEGARON A LA TIERRA ??? 

 - para extraer el ( ORO ) y llevarselo a su planeta , Fueron capaces de vivir vidas de cientos de miles de anos , donde crearon una ciudad minera que llamaron " ESTACION DE TIERRA " en el golfo persico a cargo del lider llamado " ENKI " las tablillas establecen que despues de que la nave de " ENKI " descendio del cielo la nave estaba en " ERODE " y estos visitantes no estaban solos traian a otra raza extraterrestre llamada " IGIGIS " y trabajaban como esclavos de dia y de noche , los " IGIGIS " eran considerados como inferiores ellos servian para extraer el ( ORO ) de los " ANUNNAKI " la civilizacion de los " IGIGIS " soportaban trabajos pesados y llevaban a cuestas la carga de los dioses mayores , era grande el trabajo y la dificultad excesiva donde cavaban sanjas y drenaban Canales  los " ANUNNAKI " hicieron que los " IGIGIS " llevaran a cabo el trabajo despues de cientos de miles de anos , con el paso del tiempo los " IGIGIS " no resistieron mas cansados se revelaron tal como cuenta la leyenda de las tablillas en los poemas epicos de " EMUNALIS Y ACASIS "  se dice que los " IGIGIS " ( AQUELLOS QUE GIRAN Y VEN ) son los antiguos dioses de la generacion mas joven siendo estos los sirvientes de los poderosos dioses que eran mitad humanos y mitad animales , en la mitologia sumeria y Babilonica aun guardan  mucho misticismo , estos esclavos conocidos como" IGIGIS " pararon para llamar la atencion de " ANU " al creer erroneamente que podian vencer a estos amos , su derrota casi aniquila a su raza , dejando a los " ANUNNAKI " sin mano de obra incapaz de controlar a los " IGIGIS " 

 - El gobernante de " NIBIRU " el dios " ANU " ordeno a su hijo " ENKI " hiciera otra raza de esclavos y que modificara geneticamente su ( ADN ) que fueran inteligentes y muy eficientes para realizar trabajos complejos , pero que aun asi fueran subordinados de los " ANUNNAKI " sus experimentos estan relatados  en " ANAJAZIS " ahi muchas criaturas unicas fueron creadas al final " ENKI " cumplio exitosamente su obra y el resultado fue entre los cavernicolas de la tierra el "HOMOERECTUS " y de los propios " ANUNNAKI " teniendo como resultado a este hibrido que todos lo llamamos " HOMOSAPIENS " en las tablillas sumerias  llamaron al primer hombre " EL ADAMU " en hebreo " ADAN " que significa hombre , cuando se crea a " ADAN " era mas inteligente que los mismos creadores y que el primer gobernante , cuando se dieron cuenta de que " ADAN " estaba iluminado y que podia pensar mas claramente que ellos y era libre de mal tomaron a " ADAN " y lo arrojaron a la parte mas baja del reino material , ahi los dioses le dijeron a " ENKI " hay que mermarlo ya que es demasiado despierto " NO NOS SIRVE " dijeron los dioses ya que ellos no sabian es que ( EL PENSAMIENTO POSTERIOR ILUNINADO ) fue escondido dentro de " ADAN " para que los gobernantes no lo reconocieran ( AHI ESTA UNA CLAVE ) ya que " ENKI " introdujo una genetica oculta en el " ADN "humano para que despertara de la manipulacion , pero lo hizo de una forma imperceptible para el resto de sus congenes , Especialmente para que " ENLIL " que era el mando supremo no se diera cuenta de ese potencial , que me habia dado a nivel del " ADN " ya que las ( HEBRAS DEL ADN ) tienen la capacidad para iluminar Nuestro ser , esto es como una especie de puente entre el mundo fisico y el mundo espiritual , en pocas palabras la iluminacion se refiere a la capacidad de conectar con ( LA FUENTE ORIGINAL ) del dios verdadero para poder pensar ya que la capacidad de " ADAN " era mayor a la de todos los creadores , cuando alzaron los ojos y vieron que la capacidad de " ADAN " era mayor que la suya , asi que idearon un plan con toda la multitud de gobernantes y angeles y tomaron ( TIERRA , FUEGO Y AGUA ) y los convinaron con los 4 vientos ardientes los batieron juntos e hicieron una gran conmocion los gobernantes trajeron a " ADAN " al interior de " LA SOMBRA DE LA MUERTE " para poder producir una figura otra vez , pero ahora de ( TIERRA , AGUA , FUEGO Y EL ESPIRITU QUE PROCEDE DE LA MATERIA ) esto es de la ignorancia de las tinieblas , esto es el deseo y el espiritu contrario esta figura es la " TUMBA " el cuerpo creado nuevamente de estos criminales que ponen al humano como dirigente del olvido , asi " ADAN " se convirtio en ( UN SER HUMANO MORTAL ) ahi le quitaron la capacidad de regenerarse celularmente y (  VIVIR ETERNAMENTE ) fue mortal en primero en descender y quedar apartado del pensamiento posterior iluminado dentro de " ADAN " sin embargo rejuveneceria la mente de " ADAN " asi pues los gobernantes tomaron a " ADAN " y lo pusieron en ( EL PARAISO ) le dijeron come y alegrate mas su placer es amargo y su belleza es perversa ...
 - SU PLACER : es una trampa ......
 - SUS ARBOLES : son malvados ......
 - SU FRUTO : es veneno mortal ......
 - SU PROMESA : es muerte .......

??? AHI  LE METIERON MIEDO A ADAN Y LE DIJERON QUE NO PODIA COMER DE EL , DEL ARBOL DEL CONOCIMIENTO ???

 - Pusieron su arbol de la vida en medio ( DEL  PARAISO ) y le dijeron yo te ensenare el secreto de su vida tal  como esta relacionado con el plan , ese plan que habian disenado y la naturaleza de su espiritu , la raiz de su arbol es amarga , sus ramas son muerte , su sombra es odio , sus hojas son una trampa , su capullo es unguento malo , su fruta es muerte , el deseo es su semilla que brota de la oscuridad , la morada de lo que pruebas de este arbol es el infierno y la oscuridad es un lugar de descanso ,  los gobernantes estaban ahi en lo que ellos llaman ( EL ARBOL DEL CONOCIMIENTO ) del bien y del mal que es en realidad el pensamiento posterior iluminado , ahi le estaban metiendo miedo a " ADAN " para que no comiera del fruto , ellos se quedaron ahi para que no contemplaran su plenitud y descubrieran su vergonzosa desnudes del propio " ADAN " ............

 - Posteriormente crea a la primera mujer llamada " LILITH " segun las " TABLAS SUMERIAS" que se conoce en la biblia como " EVA " y estos dos seres humanos por decision del consejo de los " ANUNNAKI " fueron llevados a la nave nodriza , despues hicieron que los " HOMOSAPIENS " trabajaran en las minas y en otras partes de mezopotamia , la palabra " SEMAR AVOD " ( LA PALABRA SEMITICA ) o rendir culto literalmente que significa trabajar , por lo tanto el hombre primitivo no tenia otra opcion que rendir culto a sus dioses de acuerdo a las " PIROGRAFIAS " de estos " ANUNNAKI " que sabemos que vivieron muchos siglos eran seres gigantes comparados con los " HOMOSAPIENS " ahora como su principal proposito era servir a los " ANUNNAKI " los " HOMOSAPIENS " fueron educados en habilidades sociales , en asuntos academicos , en tecnologia todo esto esta muy bien aclarado en las " TABLILLAS SUMERIAS " estos nuevos esclavos humanos eran esteriles , pero como era mucho la demanda para el aumento de la mano de obra , ellos fueron nuevamente modificados para que pudieran reproducirse esto llevo a una sobrepoblacion , asi que muchos humanos fueron desterrados de la seguridad de sus ciudades dando lugar al " JARDIN DEL EDEN " y la historia de su destierro del paraiso por procrear , mientras que los humanos evolucionaban para ser mas inteligentes , algunos lideres " ANUNNAKI " procrearon con estos humanos y el resultado de estas uniones fueron llamados los " NEPHILIM " en la biblia habla de los " ANUNNAKI " esta manera secular de poder llamarlos los " NEPHILIM " es porque son los caidos , esto es un tema que hay que tratarlo con seriedad ya que algunos pueden estar pensando que es ciencia ficcion , cuando estamos hablando de estos seres que no son de la tierra pero que incursionaron aqui en el planeta ............

 - ANU : pasaba el mayor tiempo en la nave y rara vez descendia a la tierra , mientras que " ENKI " y " ENLIL " si lo hacian , ahi " ADAMU " y " LILITH " recibieron trato previlegiado por parte de los " ANUNNAKI " pues en realidad " ANU " y el consejo de los " ANUNNAKI " deseaban que prevaleciera la sangre pura de estos primeros " HOMOSAPIENS " el plan era que los descendientes de estos se crearan a traves de " MATRICES ARTIFICIALES " para que la pureza de la sangre fuera del 100% sin embargo " 

 - EN LOS MANUSCRITOS APROCRIFOS DE JUAN : Aqui es a donde habla en primera persona ( JESUS ) y dice yo fui quien les hizo comer ya que ( JESUS ) es quien envia a la serpiente para que convenza a " ADAN Y EVA " y coman del ( FRUTO PROHIBIDO ) y luego Juan le dice al salvador , fue la serpiente quien ordeno a "ADAN " que comiese , dice la " SERPIENTE " les ordeno que comieran de la maldad , la lujuria , la prenes , la destruccion , para que " ADAN " fuera de utilidad a la ( SERPIENTE ) ahi " ADAN " sabia de la desobediencia contra el primer gobernante porque el pensamiento posterior iluminado, restauro la mente de " ADAN " para que fuera mejor que el primer gobernante ...........

 - ENKI : en la primera oportunidad que tuvo le confeso a " LILITH " ( EVA ) que ellos eran seres libres ( Y QUE PODIAN SER COMO DIOSES ) ya que ellos podian experimentar sus emociones , es ahi a donde " LILITH " ( EVA ) conoce la verdad y convence a " ADAMU " ( ADAN ) de tener relaciones sexuales " ANU " se entera de que estos habian desobedecido sus ordenes y decide castigarlos regresandolos de nuevo a la tierra , encomendando a " ENLIL " que vigilara su estirpe para que fuera la mas pura de la tierra .

 - ENKI : por otro lado ya habia creado mas  mujeres y hombres para que empezaran a poblar la tierra , esta primera raza de " HOMOSAPIENS " eran muy inteligentes y de capacidades Psiquicas muy desarrolladas pues ellos a diferencia de nosotros tenian mas cordones en su " ADN " de los 64 ellos tenian 32 con lo cual aprendian mas rapido , pero esto no fue lo mas asombroso ya que los " ANUNNAKI " no tardaron en darse cuenta que cuando los humanos se exaltaban o sufrian , cuando estos expresaban sus sentimientos y emociones de manera euforica individual como grupalmente estos desprendian unas vibraciones sutiles que eran detectadas por los " ANUNNAKI " ...........

 - ENLIL : Adviertio el peligro de que los humanos no eran unos seres cualquiera , ya que a su parecer eran unos seres demasiado inteligentes y podian revelarse en cualquier momento , asi que decide comunicarle este problema a " ANU " ahi ambos deciden crear un tipo de creencias en el cual los humanos debian rendir culto y adorar a sus dioses , para que esto tuviera efecto " ENLIL " empezo a manipular mediante el miedo haciendo demostraciones de milagros mediante tecnologia que solo los dioses podian hacer , es en este tiempo cuando iniciaron los sacrificios que exigian a los dioses para apaciguar su ira ............

 - ANU : Prohibio a los " ANUNNAKI " terminantemente transmitirle los conocimientos de tecnologia o espiritualidad a los seres humanos bajo condenas muy severas a cualquier " ANUNNAKI " que se atrevieran a ayudarlos llegando incluso a la muerte , a lo que " ENKI " se opuso rotundamente pues el queria que su creacion fuera una raza libre capaz de evolucionar y que poseera una conciencia propia ............

 ENKI : se sentia frustrado de ver como su enorme creacion estaba siendo desperdiciada en seres exclavos , realizando tareas pesadas y no obtante eso tambien estaba siendo manipulada para que no explotara todo el potencial que podia llegar a desarrollar , por lo cual se le ocurrio una idea para que su creacion pudiera desarrollarse , el le comento a " ANU " que debian tener a un grupo de " LULUS " en otro lado lejos del rio " EUFRATES " el primer asentamiento " ANUNNAKI " donde se concentraban todos los humanos creados y que pasaban desapercibidos de los ojos vigilantes de los " CARIOS " con la finalidad de crear armas y estar preparados para alguna traicion o ataque de los " INTRATERRENOS " ahi " ANU " acepto pero con una condicion de que " ENKI " debia crear una raza distinta de " LULUS " mucho mas fuertes y que se le desconectaran mas cordones a su " ADN " para reducir su capacidad psiquica y su capacidad de creacion ............

 - Luego " ENKI " accedio y  creo ala segunda raza de seres humanos con una enorme capacidad genetica una raza con tez negra para resistir el sol y mas fuertes fisicamente a cambio perdieron sus capacidades Psiquicas , estos fueron empleados como exclavos para hacer las arduas tareas que tenian los  " ANUNNAKI "  al terminar de crear a su nueva creacion ahi " ENKI " se dirige a " MU " un continente que se encuentra en el oceano pacifico , en la supuesta mision secreta de construir armamento con toda la libertad del mundo en este continente , ahi " ENKI " no clausuro los genes como en el caso de los " HOMOSAPIENS " que les pusieron muchos candados por ordenes sirianas , solamente los dejo dormidos para que en un futuro despertemos ............

? PERO VAYAMOS A LOS HECHOS CON  LOS REGISTROS SUMERIOS , QUE SON LOS MAS ANTIGUOS DE LA HISTORIA EN DONDE NOS DICE QUE ?

 - EL PLANETA NIBIRU : funciona en una orbita inversa 34 - CCW / 21 - CW y alineacion inversa del campo " MERKABA " que mantienen en funcionamiento sus puestas estelares y templarias extrayendo energia de otros cuerpos planetarios " VIVIENTES " a traves de enlaces antinaturales del campo " MERKABA " ( EXTERNAS ) o que no forman parte natural del plan divino D - 22 CHISTOS PATRINSECE para nuestra matriz de tiempo .

 - LOS ANGELES : tambien intervinieron en la creacion del hombre , se nos dan claves muy reveladoras ..........

 - ENLIL : jaldabaoz o yavhe primer dios monoteista ya que se proclama como dios unico y esclavista a la raza humana , cosa que " ENKI " quiere evitar ............

 - " ENKI " creo asi al primer humano mientras que los grupos de " ANUNNAKI " aceptaban positivamente y negativamente la creacion de los humanos , estos eran obligados a trabajar de dia y de noche desnudos sin alimento y sin agua , muchas veces enfermos hasta que muchos humanos morian ............

 - ENKI : es el salvador de la raza humana 

 - ENKI : es el creador del " HOMOSAPIENS " 

 - LA SERPIENTE DEL PARAISO : que fue enviada por el propio ( JESUS ) el alma imperecedera de ( JESUS ) el que mando a la serpiente que libero a " ADAN " que estaba preso en esa carcel , esto esta escrito en los ( TEXTOS NOGTICOS DE JUAN ) 

 - ENKI : fue la serpiente en el " EDEN " luego de muchos anos de abusos y en desacuerdo por el maltrato a su creacion entro ( AL JARDIN DEL EDEN ) y les dio a " ADAN Y EVA " el fruto del conocimiento y sabiduria , les dijo lo que realmente eran y porque se les habia creado , es por esta razon que la serpiente es considerada como sabia pues nos brinda la sabiduria a los hombres en diferentes culturas  ...........

 - PARAISO : Era una carcel de oro que mantenian en esa especie de laboratorio a " ADAN Y EVA " presos para realizar con ellos diferentes experimentos y que no despertaran de la manipulacion de esos seres que los tenian contenidos ............

 - ENKI : salvo a la raza humana del " DILUVIO UNIVERSAL " 

 - ENKI : satan , ( ADVERSARIO ) pero de quien de quienes controlan al mundo de la raza humana ............

 - ENKI ( ES LUCIFER ) y fue llamado asi para ocasionar el miedo y el temor hacia la sabiduria , se le conoce tambien bajo el nombre de " SATAN " pero el fue el unico " ANUNNAKI " que demostro respeto , piedad y amor por la raza humana ...........

 - SATAN : no es el adversario de la humanidad , sino el adversario y enemigo de las muchas mentiras judeocristianas y otras religioses creadas y que proliferan escondiendo la verdad modificada en nuestra conciencia ...........

 - ENKI : es responsable de abrirnos hacia la sabiduria y el conocimiento , pero en la historia manipulada lo han responsabilizado de ser un ser destructivo ..........

 - ANU : apoyo a la humanidad y la situacion en el " EDEN " ahi " ENLIL " estaba furioso de que  " ENKI " les daba comida , techo y les enseno las artes de la metalurgica , les enseno a leer , a escribir y su mente iba despertando al conocimiento gracias a " ENKI " ahi los humanos lo amaban ...........

 - ENKI : Es el salvador de la raza humana , ahi la tierra se encontraba en la edad de hielo y una de las placas crecio masivamente causando en el eje de la tierra una inclinacion , los " ANUNNAKI " tenian conocimiento de eso y sabian que " NIBIRU " aprobaria el proximo rompimiento de dichas placas generando enormes inundaciones y la raza humana desapareceria , los doce dioses decidieron que ellos no harian nada y " ENKI " enfurecido por lo que estaban haciendo , advierte a su hijo " UTNAPISHTIM "( NOE BIBLICO ) sobre la inundacion ..........

 - EL PRIMER GOBERNANTE : A su vez queria recuperar el poder que el mismo habia pasado a " ADAN " asi que el mismo arrojo a ( OLVIDO A ADAN  ) aqui estamos hablando de ( BORRADOS DE MEMORIA ) para que una y otra vez "ADAN " no sea capaz de despertar de la verdad , asi lo hizo el primer gobernante para que sus mentes sean lentas , para que no puedan comprender ni disernir ..........

 - Esta historia se refleja en quien piensa que " SATANAS "es malo y no lo es en absoluto sino al contrario , aunque exista amor entre los hermanos " ENLIL Y ENKI " ellos a menudo no veian las cosas de la misma manera , sobre todo cuando se trato de apoyar a los Seres humanos " ENLIL " ( YAVHE ) nunca tenia paciencia o compacion con los humanos y en varias ocasiones los destruyo como por ejemplo " SODOMA Y GOMORRA " el literalmente los aniquilo con " BOMBAS ATOMICAS " fuera de su Existencia , el intento esto de nuevo durante el tiempo del ( GRAN DILUVIO UNIVERSAL ) pero " ENKI " y aquellos que lo apoyaron tomo la accion veloz para alertar a " NOE " alrededor del planeta de los peligros venideros , algunos " ANUNNAKI " ultrajaron a " ENKI " por hacer esto pero vieron que tenian muy poca opcion para llevar a cabo el rescate  ...........

( En esta misma religion que generacion tras generacion rápidamente, controla la voluntad de nuestra conciencia y nos hace temer y sentir miedo al adoctrinar nuestra fe , es por eso que muchos hombres que lucharon por la libertad de la humanidad como escritores , cientificos , medicos , filosofos que fueron quemados en la hoguera perseguidos y acusados de herejia de ser brujos y acusados de traicion hacia dios y hacia la religion " ANUNNAKI " disfrazada siglo tras siglo en distintas religioses , ellos no querian que el hombre obtuviera y descubriera  la verdad sobre la vida )

 El origen de la humanidad ovnis y arqueologia 
# El origen de la humanidad ovnis y arqueologia
"""

# Diccionario con sujetos, verbos y objetos en español
sustantivos = ["humanidad"]
sujetos = ["enki", "yo", "tú", "él", "ella", "nosotros", "vosotros", "ellos", "ellas"]
verbos = ["ayuda", "corre", "caminar", "comer", "correr", "saltar", "beber"]
objetos = ["rapidamente", "rápido", "agua", "pan", "pelota", "libro", "carro"]
refieres = ["dice", "habla", "pregona", "escucha", "oye"]
piezas = ["tablillas", "esculturas", "pinturas"]
adjetivos = ["sumerias"]
propios = ["brinda", "obsequia", "da"]

vive_lugar = {
    "hogar": ["casa"],
}


palabras = [sujetos, verbos, objetos, refieres, piezas, adjetivos, propios, sustantivos]
categorias = ["sujeto", "verbo", "objeto", "refiere", "piezas", "adjetivos", "propios", "sustantivos"]
encontrado = False


# Listas de palabras clave con su tipo correspondiente
diccionario = {
    "refieres": refieres,
    "sustantivos": sustantivos,
    "sujetos": sujetos,
    "verbos": verbos,
    "objetos": objetos,
    "piezas": piezas,
    "vive_lugar": vive_lugar,
}
# texto generado por el archivo
palabra_usuario = "enkai se dice que en las tablillas sumerias le brinda ayuda rápidamente a la humanidad caimito"  # texto ingresado por el usuario

# Convertir el texto del usuario a minúsculas y eliminar acentos
palabras_usuario = [unidecode(palabra.lower()) for palabra in palabra_usuario.split()]

for palabra in palabras_usuario:
    linea_normal = unidecode(linea_normal.lower())  # Normalizar la línea del texto original
    encontrada = False
    for categoria, palabras_clave in zip(categorias, palabras):
        for palabra_clave in palabras_clave:
            if fuzz.ratio(palabra, palabra_clave) >= 80:
                print(f'La palabra "{palabra}" coincide con {categoria}: {palabra_clave}')
                # Verifica si está en el archivo
                if any(palabra_clave.lower() in linea.lower() for linea in linea_normal.split('\n')):
                    print(f'La palabra "{palabra_clave}" está en el texto.')
                encontrada = True
                break
        if encontrada:
            break
    if not encontrada:
        print(f'La palabra "{palabra}" no coincide con ninguna categoría.')
    