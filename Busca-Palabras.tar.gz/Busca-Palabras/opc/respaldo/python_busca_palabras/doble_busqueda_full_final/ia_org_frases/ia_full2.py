import os
import time
import concurrent.futures
from multiprocessing import cpu_count
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor, as_completed
from joblib import Parallel, delayed, parallel_backend
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")

try:
    from tqdm import tqdm
except ImportError:
    os.system("pip install tqdm")
    from tqdm import tqdm
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    

lista = 0
linea_normal = """
¿LAS TABLILLAS SUMERIAS? los ANUNNAKI? ANUNAKIs? los ANUNNAKIs
ayuda a lo humanos 
( En esta misma religion que generacion tras generacion , controla la voluntad de nuestra conciencia y nos hace temer y sentir miedo al 'adoctrinar'' nuestra fe , es por eso que muchos hombres que lucharon por la libertad de la humanidad como escritores , cientificos , medicos , filosofos que fueron quemados en la hoguera perseguidos y acusados de herejia de ser brujos y acusados de traicion hacia dios y hacia la religion " ANUNNAKI " disfrazada siglo tras siglo en distintas religioses , ellos no querian que el hombre obtuviera y descubriera  la verdad sobre la vida (ënkí) )

# El origen de la humanidad ovnis y arqueologia
 
"""

'''
from unidecode import unidecode

palabra = "enki se dice que en las tablillas sumerias le brinda ayuda a la humanidad"  # texto ingresado por el usuario

# Dividir el texto en palabras
palabras = palabra.split()

# Contador para almacenar cuántas palabras están presentes en cada línea
contador_palabras = {palabra: 0 for palabra in palabras}

# Verificar si cada palabra está en cada línea del texto
for linea in linea_normal.split('\n'):
    for palabra in palabras:
        if palabra.lower() in unidecode(linea).lower():
            contador_palabras[palabra] += 1

# Verificar si la mayoría o todas las palabras están presentes en cada línea
for palabra, contador in contador_palabras.items():
    if contador >= len(linea_normal.split('\n')) * 0.5:  # Se considera la mayoría si está presente en al menos el 50% de las líneas
        print(f'La palabra "{palabra}" está en la mayoría de las líneas del texto.')
    elif contador == len(linea_normal.split('\n')):
        print(f'La palabra "{palabra}" está en todas las líneas del texto.')
    else:
        print(f'La palabra "{palabra}" no está en la mayoría de las líneas del texto.')
'''
# Diccionario con sujetos, verbos y objetos en español
sujetos = ["enki", "yo", "tú", "él", "ella", "nosotros", "vosotros", "ellos", "ellas"]
verbos = ["ayuda", "corre", "caminar", "comer", "correr", "saltar", "beber"]
objetos = ["rápidamente", "rápido", "agua", "pan", "pelota", "libro", "carro"]
# texto generado por el archivo
palabra = "enki se dice que en las tablillas sumerias le brinda ayuda a la humanidad"  # texto ingresado por el usuario

# Dividir el texto en palabras
palabras = (palabra.split())

# Verificar si cada palabra está en el texto
for palabra, p_arch in zip(palabras, linea_normal.split('\n')):
    palabra = unidecode(palabra)
    linea_normal = unidecode(linea_normal)
    '''
    # Esta parte es para ver línea por línea del array
    linea_normal1 = unidecode(p_arch)
    print(linea_normal1)
    input()
    '''
    if any(palabra.lower() in linea.lower() for linea in linea_normal.split('\n')):
        print(f'La palabra "{palabra}" está en el texto.')
        
        if palabra in sujetos:
            print("sujeto", palabra)
        elif palabra in verbos:
            print("verbo", palabra)
        elif palabra in objetos:
            print("objeto", palabra)
    else:
        print(f'La palabra "{palabra}" no está en el texto.')




