from fuzzywuzzy import process
from unidecode import unidecode

# Diccionario con sustantivos, sujetos, verbos y objetos en español
sustantivos = {
    "masculino": ["Lulu", "enki", "Robert"],
    "femeninos_singular": ["niña", "mesa", "pelota"],
    "femeninos_plural": ["niñas", "mesas", "pelotas"],
}

articulos = {
    "masculino_singular": ["texto", "mesa", "pelota", "computadora"],
    "femeninos_plural": ["textos", "mesas", "pelotas", "casas", "computadoras"],
}
verbos_art = {
    "acciones": ["esta", "corre", "canta", "baila", "come", "bebe"],
    "estado": ["es", "era", "estaba", "corrió", "cantó", "bailó", "comió", "bebió"],
}
pos_lugar = {
    "puesto": ["en"]
}
vive_lugar = {
    "hogar": ["casa"],
}

refiere = {
    "sig_sustantivo": ["se", "de", "el"]
}

ref2 = {
    "refiere2": ["dice"]
}

sujetos = {
    "pronombres": ["ella", "yo", "tú", "él", "nosotros", "vosotros", "ellos"],
    "demostrativos": ["divertida", "se", "este", "ese", "aquel"],
}

suj_posesivo = {
    "posesivos": ["mi", "tu", "su", "nuestro", "vuestro", "su"],
    "posesivos_singular": ["mis", "tus", "sus", "nuestros", "vuestros", "sus"],
}

verbos = {
    "acciones": ["esta", "corre", "canta", "baila", "come", "bebe"],
    "estado": ["es", "era", "estaba", "corrió", "cantó", "bailó", "comió", "bebió"],
}

objetos = {
    "adverbios": ["rápidamente", "felizmente"],
    "masculinos_singular": ["árbol", "libro", "perro", "gato"],
    "femeninos_singular": ["flor", "luz", "estrella", "silla"],
}

# texto generado por el usuario
#palabra_usuario = "Lulú es divertida y está en el arbol"  # texto ingresado por el usuario
#palabra_usuario = "De enkai se dice en las tablillas sumerias que le brinda ayuda a la humanidad "  # texto ingresado por el usuario
palabra_usuario = "está en casa mi computadora"  # texto ingresado por el usuario
#palabra_usuario = "se dice de enki en las tablillas sumerias que le brinda ayuda a la humanidad " 

# Convertir el texto del usuario a minúsculas y eliminar acentos
palabras_usuario = [unidecode(palabra.lower()) for palabra in palabra_usuario.split()]

# Definir una lista para almacenar el contexto del texto del usuario
contexto_usuario = []

# Listas de palabras clave con su tipo correspondiente
diccionario = {
    "refiere": refiere,
    "ref2": ref2,
    "sustantivos": sustantivos,
    "sujetos": sujetos,
    "verbos": verbos,
    "objetos": objetos,
    "articulos": articulos,
    "vive_lugar": vive_lugar,
}

# Umbral de similitud para la comparación fuzzy
umbral_similitud = 80

# Definir el orden gramatical de las palabras
orden_gramatical = ["refiere", "ref2", "sustantivos", "articulos", "verbos", "objetos"]

# Verificar si cada palabra del usuario está en el texto original
for palabra in palabras_usuario:
    encontrada = False
    for tipo in orden_gramatical:
        if tipo in diccionario:
            for subtipo, palabras in diccionario[tipo].items():
                if palabra in palabras:
                    contexto_usuario.append(f"{tipo}: {subtipo}: {palabra}")
                    encontrada = True
                    break
            if encontrada:
                break
    
    if not encontrada:
        diccionario = {
            "suj_posesivo": suj_posesivo,
            "articulos": articulos,      
            "verbos_art": verbos_art,
            "pos_lugar": pos_lugar,
            "vive_lugar": vive_lugar,
            
}
        # Definir el orden gramatical de las palabras
        orden_gramatical = ["suj_posesivo", "articulos", "verbos_art", "pos_lugar", "vive_lugar"]

        # Buscar coincidencias aproximadas en todas las listas de palabras clave
        for tipo in orden_gramatical:
            if tipo in diccionario:
                for subtipo, palabras in diccionario[tipo].items():
                    coincidencia_aproximada = process.extractOne(palabra, palabras, scorer=process.fuzz.ratio)
                    if coincidencia_aproximada[1] >= umbral_similitud:
                        contexto_usuario.append(f"coincidencia aproximada: {tipo}: {subtipo}: {coincidencia_aproximada[0]}")
                        encontrada = True
                        break
                if encontrada:
                    break
    
    if not encontrada:
        # Definir el orden gramatical de las palabras
        orden_gramatical = ["refiere", "sustantivos", "verbos", "objetos"]

        contexto_usuario.append("otras_palabras: otras: " + palabra)

# Obtener las palabras del contexto del texto del usuario
palabras_contexto = []
for contexto in contexto_usuario:
    palabras_contexto.append(contexto.split(": ")[-1])

# Ordenar las palabras del contexto según el orden gramatical
palabras_ordenadas = []
for tipo in orden_gramatical:
    for subtipo in diccionario.get(tipo, {}):
        for contexto in contexto_usuario:
            if f"{tipo}: {subtipo}:" in contexto or subtipo == "otras":
                palabra = contexto.split(":")[-1].strip()
                if palabra in palabras_contexto:
                    palabras_ordenadas.append(palabra)
                    palabras_contexto.remove(palabra)

# Añadir las palabras que no se han incluido en ningún subtipo específico
for palabra in palabras_contexto:
    palabras_ordenadas.append(palabra)

# Formar la frase perfecta
frase_perfecta = " ".join(palabras_ordenadas)

# Imprimir el contexto del texto del usuario
if contexto_usuario:
    print("Contexto del texto del usuario:")
    for contexto in contexto_usuario:
        print("- ", contexto)
    print("\nFrase perfecta según el orden gramatical español:")
    print(frase_perfecta.capitalize())
else:
    print("No se encontraron palabras clave en el texto del usuario.")
