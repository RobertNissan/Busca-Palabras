from fuzzywuzzy import process
from unidecode import unidecode

# Diccionario con sustantivos, sujetos, verbos y objetos en español
sustantivos = {
    "femeninos_singular": ["Lulu", "niña", "mesa", "pelota", "casa", "computadora"],
    "femeninos_plural": ["niñas", "mesas", "pelotas", "casas", "computadoras"],
}

sujetos = {
    "pronombres": ["ella", "yo", "tú", "él", "nosotros", "vosotros", "ellos"],
    "demostrativos": ["este", "ese", "aquel"],
    "posesivos": ["mi", "tu", "su", "nuestro", "vuestro", "su"],
}

verbos = {
    "acciones": ["es", "está", "corre", "canta", "baila", "come", "bebe"],
    "estado": ["era", "estaba", "corrió", "cantó", "bailó", "comió", "bebió"],
}

objetos = {
    "adverbios": ["rápidamente", "felizmente"],
    "masculinos_singular": ["árbol", "libro", "perro", "gato"],
    "femeninos_singular": ["flor", "luz", "estrella", "silla"],
}

palabra_usuario = "De enkai se dice en las tablillas sumerias que le brinda ayuda a la humanidad tu python rapidamente"  # texto ingresado por el usuario
# texto generado por el usuario
#palabra_usuario = "Lulú es divertida y está en el arbol"  # texto ingresado por el usuario

# Convertir el texto del usuario a minúsculas y eliminar acentos
palabras_usuario = [unidecode(palabra.lower()) for palabra in palabra_usuario.split()]

# Definir una lista para almacenar el contexto del texto del usuario
contexto_usuario = []

# Listas de palabras clave con su tipo correspondiente
diccionario = {
    "sustantivos": sustantivos,
    "sujetos": sujetos,
    "verbos": verbos,
    "objetos": objetos,
}

# Umbral de similitud para la comparación fuzzy
umbral_similitud = 80

# Definir el orden gramatical de las palabras
orden_gramatical = ["sustantivos", "sujetos", "verbos", "objetos"]

# Verificar si cada palabra del usuario está en el texto original
for palabra in palabras_usuario:
    encontrada = False
    for tipo in orden_gramatical:
        if tipo in diccionario:
            for subtipo, palabras in diccionario[tipo].items():
                if palabra in palabras:
                    contexto_usuario.append(f"{tipo}: {subtipo}: {palabra}")
                    encontrada = True
                    break
            if encontrada:
                break
    
    if not encontrada:
        # Buscar coincidencias aproximadas en todas las listas de palabras clave
        for tipo in orden_gramatical:
            if tipo in diccionario:
                for subtipo, palabras in diccionario[tipo].items():
                    coincidencia_aproximada = process.extractOne(palabra, palabras, scorer=process.fuzz.ratio)
                    if coincidencia_aproximada[1] >= umbral_similitud:
                        contexto_usuario.append(f"coincidencia aproximada: {tipo}: {subtipo}: {coincidencia_aproximada[0]}")
                        encontrada = True
                        break
                if encontrada:
                    break
    
    if not encontrada:
        contexto_usuario.append("otras_palabras: otras: " + palabra)

# Obtener las palabras del contexto del texto del usuario
palabras_contexto = []
for contexto in contexto_usuario:
    palabras_contexto.append(contexto.split(": ")[-1])

# Ordenar las palabras del contexto según el orden gramatical
palabras_ordenadas = []
for tipo in orden_gramatical:
    for subtipo in diccionario.get(tipo, {}):
        for palabra in palabras_contexto:
            if f"{tipo}: {subtipo}:" in contexto or subtipo == "otras":
                palabras_ordenadas.append(palabra)

# Formar la frase perfecta
frase_perfecta = " ".join(palabras_ordenadas)

# Imprimir el contexto del texto del usuario
if contexto_usuario:
    print("Contexto del texto del usuario:")
    for contexto in contexto_usuario:
        print("- ", contexto)
    print("\nFrase perfecta según el orden gramatical español:")
    print(frase_perfecta.capitalize())
else:
    print("No se encontraron palabras clave en el texto del usuario.")
