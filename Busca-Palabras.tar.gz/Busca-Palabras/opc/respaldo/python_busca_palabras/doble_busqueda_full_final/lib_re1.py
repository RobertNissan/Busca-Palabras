import re

# Leer el contenido del archivo rocky.txt
with open('rocky.txt', 'r', encoding='utf-8') as file:
    texto = file.read()

# Pedir al usuario que introduzca la palabra
palabra_con_tilde = input("Introduce la palabra con tilde: ")

# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabra):
    regex = []
    for letra in palabra:
        if letra in 'aeiouáéíóúÁÉÍÓÚ':
            if letra.islower():
                regex.append(f'[{letra}{letra.upper()}aAaàèìòùäëïöüâêîôûãẽĩõũoO]')
            else:
                regex.append(f'[{letra}{letra.upper()}áÁaàèìòùäëïöüâêîôûãẽĩõũÓó]')
        else:
            regex.append(letra)
    return ''.join(regex)

palabra_regex = crear_regex(palabra_con_tilde)
print(palabra_regex)
input()
# Realizar la búsqueda
coincidencias = re.findall(palabra_regex, texto, flags=re.IGNORECASE)

if coincidencias:
    print(f'Coincidencias encontradas: {", ".join(coincidencias)}')
else:
    print("No se encontraron coincidencias.")
