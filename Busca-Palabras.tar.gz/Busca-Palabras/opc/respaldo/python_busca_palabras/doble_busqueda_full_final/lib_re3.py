import re
import mmap

# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabra):
    regex = []
    for letra in palabra:
        if letra.lower() == 'a':
            regex.append('[aáàäâã]')
        elif letra.lower() == 'e':
            regex.append('[eéèëêē]')
        elif letra.lower() == 'i':
            regex.append('[iíìïîī]')
        elif letra.lower() == 'o':
            regex.append('[oõôöóò]')
        elif letra.lower() == 'u':
            regex.append('[uúùüûū]')

        elif letra.lower() == 'á':
            regex.append('[aáàäâã]')
        elif letra.lower() == 'é':
            regex.append('[eéèëêē]')
        elif letra.lower() == 'í':
            regex.append('[iíìïîī]')
        elif letra.lower() == 'ó':
            regex.append('[oõôöóò]')
        elif letra.lower() == 'ú':
            regex.append('[uúùüûū]')

        else:
            regex.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
    return ''.join(regex)

# Abrir el archivo utilizando mmap
with open('rocky.txt', 'r', encoding='utf-8') as file:
    with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
        # Pedir al usuario que introduzca la palabra
        palabra_con_tilde = input("Introduce la palabra con tilde: ")
        palabra_regex = crear_regex(palabra_con_tilde)

        # Convertir el contenido del mapeo en una cadena de bytes y luego decodificarla a una cadena de texto
        texto = mm[:].decode('utf-8')

        # Realizar la búsqueda dentro del texto decodificado
        coincidencias = re.findall(palabra_regex, texto)

# Imprimir las coincidencias encontradas
if coincidencias:
    print(f'Coincidencias encontradas: {", ".join(coincidencias)}')
else:
    print("No se encontraron coincidencias.")
