import os
import time
import concurrent.futures
from multiprocessing import cpu_count
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor, as_completed
from joblib import Parallel, delayed, parallel_backend
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")
try:
    from tqdm import tqdm
except ImportError:
    os.system("pip install tqdm")
    from tqdm import tqdm
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
    
# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

archivos_encontrados = 0
ruta_actual = os.getcwd()

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {
    '.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php',
    '.vb', '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg',
    '.conf', '.properties','.env', '.config', '.xml', '.json',
    '.yaml', '.yml', '.xsd', '.svg', '.plist','.markdown', '.rtf',
    '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
    '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po',
    '.pot', '.mo', '.lst','.out', '.err', '.rpt', '.man', '.help',
    '.eml', '.msg', '.chat', '.db', '.srt', '.pub', ''}
    
# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass
    
def resaltar_palabra_encontrada(linea, palabra):
    return linea.replace(palabra, RED + palabra + ENDC)

def imprimir_contenido_encontrado(contenido, ruta_completa):
    if contenido:  # Asegurarse de que haya contenido antes de imprimir
        contenido_resaltado = [resaltar_palabra_encontrada(linea, palabra_buscada) for linea in contenido]
        contenido_resaltado = '\n'.join(contenido_resaltado).replace(ruta_completa, PURPLE + ruta_completa + ENDC) \
            .replace(f"Encontrada la palabra '{RED}{palabra_buscada}'", f"Encontrada la palabra '{RED}{palabra_buscada}'{ENDC}") \
            .replace("Linea", GREEN + "Linea" + ENDC)

        # Imprimir en la consola
        print(contenido_resaltado)

        # Eliminar codigos ANSI antes de guardar en el archivo .cpp
        contenido_sin_colores = remove_ansi_codes(contenido_resaltado)

        # Agregar un salto de linea al final de la cadena antes de guardar en el archivo .cpp
        contenido_sin_colores += '\n'

        # Guardar en un archivo .cpp
        with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
            cpp_file.write(contenido_sin_colores)

def remove_ansi_codes(texto):
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', texto)
    
ruta_rep = []
def buscar_palabra_en_archivo(ruta_completa, palabra):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []
    cnt_palabras = palabra.split(' ')
    # Inicializar palabra_frase como una cadena vacía
    palabra_frase = ""
    
    if not ruta_completa in ruta_rep:
        try:
            with open(ruta_completa, 'r', encoding='utf-8') as file:
                for num_linea, linea_orig in enumerate(file, start=1):
                    nl = num_linea
                    nl = nl - num_linea
                    linea_normal = unidecode(linea_orig.lower())
                    ratio = fuzz.ratio(linea_normal, palabra)
                    
                    if ratio > 80 or palabra in linea_normal:
                        if not encontrado:
                            encontrado = True
                            if len(cnt_palabras) > 3:
                                palabra = linea_orig
                            contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}")
                        contenido_encontrado.append(f"Linea {num_linea}: {linea_orig.rstrip()}")
                        if len(cnt_palabras) > 3:
                            contenido_encontrado.extend(file.readlines()[nl:])
                    elif ratio > 70 or palabra in linea_normal:       
                        if not encontrado:
                            encontrado = True
                            if len(cnt_palabras) > 3:
                                palabra = linea_orig
                            contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}")
                        contenido_encontrado.append(f"Linea {num_linea}: {linea_orig.rstrip()}")
                        if len(cnt_palabras) > 3:
                            contenido_encontrado.extend(file.readlines()[nl:])
                    else:
                        palabras_capturadas = linea_normal.split(' ')
                        palabra_frase = ' '.join(palabras_capturadas)
                        #if all(palabra in palabra_frase for palabra in cnt_palabras):
                        if all(palabra in palabra_frase for palabra in cnt_palabras) or fuzz.ratio(palabra_frase, palabra) >= 63:
       
                            if not encontrado:
                                encontrado = True
                                if len(cnt_palabras) > 1:
                                    captura = palabra_frase
                                
                                contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {ruta_completa}")
                                #palabra_frase = ''
                                contenido_encontrado.append(f"Linea {num_linea}: {linea_orig.rstrip()}")
                            if len(cnt_palabras) > 3:
                                contenido_encontrado.extend(file.readlines()[nl:])
                    
                    
                if encontrado:
                    contenido_encontrado.append("\n")
                    imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
            ruta_rep.append(ruta_completa)
        except UnicodeDecodeError:
            ruta_rep.append(ruta_completa)
            pass
    return encontrado

def contar_archivos(directorio):
    total = 0
    for base, dirs, files in os.walk(directorio):
        total += len(files)
    return total
def cargar_archivo(ruta_archivo, destino):
    # Simulando la carga del archivo, aqui podrias escribir el codigo real para procesar o copiar el archivo
    return ruta_archivo
def buscar_palabra(directorio, palabras):
    archivos = []
    archivos_encontrados = 0  # Initialize archivos_encontrados here
    inicio = time.time()
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for ruta, directorios, archivos_en_dir in os.walk(directorio_base):
            for archivo in archivos_en_dir:
                ruta_completa = os.path.join(ruta, archivo)
                futures.append(executor.submit(cargar_archivo, ruta_completa, '/destino'))
        print('Cargando archivos')
        for future in tqdm(as_completed(futures), total=len(futures), desc='', unit='archivo'):
            archivo_cargado = future.result()
            archivos.append(archivo_cargado)
    print('\n')
 
    with parallel_backend('loky', n_jobs=-1):
        resultados = Parallel(n_jobs=-1, backend='loky', prefer='threads', batch_size='auto', temp_folder=None, verbose=0)(
            delayed(buscar_palabra_en_archivo)(archivo, palabra) for archivo in archivos for palabra in palabras
        )
       
        fin = time.time()
        tiempo_transcurrido = fin - inicio
    
        horas = int(tiempo_transcurrido // 3600)
        minutos = int((tiempo_transcurrido % 3600) // 60)
        segundos = int(tiempo_transcurrido % 60)
        milisegundos = int((tiempo_transcurrido % 1) * 1000)
    archivos_encontrados = sum(resultados)  # Update archivos_encontrados here
    
    if archivos_encontrados > 0:
        print(f"Total de archivos encontrados: {archivos_encontrados}")
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
        print("Copia de búsqueda guardada en resultado.cpp\n")
    else:
        print("No se encontró:\n>> ", palabras_buscadas)
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms\n")

# Llama a la funcion para obtener el valor de 'disco'
#disco = '/sdcard/backups/'
disco = '/sdcard/'
directorio_base = os.path.expanduser(disco)  # Actualiza esta variable con la ruta de tu directorio base

palabra_buscada = input('ingrese la palabra o las palabras\n> ')
# palabra_buscada = unidecode(palabra_buscada.lower())


palabras_buscadas = [unidecode(palabra.lower()) for palabra in palabra_buscada.split('|')] if '|' in palabra_buscada else [unidecode(palabra_buscada.lower())]
buscar_palabra(directorio_base, palabras_buscadas)

'''

enki es satanas y le dió ayuda a los humanos, con su poder 

if fs in linea_normal or (palabra_frase := ' '.join(palabras_capturadas)) and fuzz.ratio(palabra_frase, palabra) >= 80: 
    # Hacer algo con la frase válida
    
    
if fs in linea_normal and fuzz.ratio(fs, linea_normal) >= 80: palabras_validas = [palabra for palabra in palabras_capturadas if fuzz.ratio(palabra, palabra) >= 80]
'''
