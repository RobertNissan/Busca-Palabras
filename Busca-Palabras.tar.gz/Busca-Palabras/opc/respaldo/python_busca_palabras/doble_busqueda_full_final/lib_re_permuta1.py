import re

texto = """
Me gusta el sol, Alicia y las palomas,
el buen cigarro y la guitarra española,
saltar paredes y abrir las ventanas,
y cuando llora una mujer (de alegría).
Me gusta el vino tanto como las flores,
y los conejos pero no los tractores,
y el pan casero y la voz de Dolores
y el mar mojándome los pies,
no soy de aqui ni soy de allá,
no tengo edad mi porvenir,
y ser feliz es mi color de identidad.
"""

print(texto)
print("Texto de prueba")

# Obtener la frase a buscar del usuario
frase_buscar = input("Ingrese la frase a buscar: ")

# Convertir la frase a una lista de palabras
palabras_frase = frase_buscar.lower().split()

# Convertir el texto a minúsculas para una búsqueda insensible a mayúsculas/minúsculas
texto_minusculas = texto.lower()

# Inicializar lista para almacenar resultados parciales de cada palabra
resultados_parciales = []

# Buscar cada palabra individualmente en el texto
for palabra in palabras_frase:
    if re.search(r'\b{}\b'.format(re.escape(palabra)), texto_minusculas):
        resultados_parciales.append(True)
    else:
        resultados_parciales.append(False)

# Verificar si todas las palabras de la frase están presentes en el texto
if all(resultados_parciales):
    print("Búsqueda exitosa")
    print("Frase encontrada:", frase_buscar)
else:
    print("No se encontró el patrón buscado")
