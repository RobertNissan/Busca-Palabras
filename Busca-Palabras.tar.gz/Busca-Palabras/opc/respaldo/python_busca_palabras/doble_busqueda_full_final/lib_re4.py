import re
import mmap

# Convertir las palabras con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabras):
    regex = []
    for palabra in palabras.split('|'):
        regex_palabra = []
        for letra in palabra:
            if letra.lower() == 'a':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'e':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'i':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'o':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'u':
                regex_palabra.append('[uúùüûū]')

            elif letra.lower() == 'á':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'é':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'í':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'ó':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'ú':
                regex_palabra.append('[uúùüûū]')

            else:
                regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
        regex.append(''.join(regex_palabra))
    return '|'.join(regex)

# Abrir el archivo utilizando mmap
with open('rocky.txt', 'r', encoding='utf-8') as file:
    with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
        # Pedir al usuario que introduzca las palabras separadas por '|'
        palabras_con_espacios = input("Introduce las palabras separadas por espacios: ")
        palabras_con_barra = palabras_con_espacios.lower().replace(' ', '|')
        palabras_regex = crear_regex(palabras_con_barra)
        print(palabras_regex)
        input()
        # Convertir el contenido del mapeo en una cadena de bytes y luego decodificarla a una cadena de texto
        texto = mm[:].decode('utf-8')

        # Realizar la búsqueda dentro del texto decodificado
        coincidencias = re.findall(palabras_regex, texto, flags=re.IGNORECASE)

# Imprimir las coincidencias encontradas
if coincidencias:
    print(f'Coincidencias encontradas: {", ".join(coincidencias)}')
else:
    print("No se encontraron coincidencias.")
