import os
import time
import concurrent.futures
from multiprocessing import cpu_count
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor, as_completed
from joblib import Parallel, delayed, parallel_backend
from fuzzywuzzy import fuzz
import warnings
# Desactivar las advertencias de fuzzywuzzy
warnings.filterwarnings("ignore", category=UserWarning, module="fuzzywuzzy")
try:
    from tqdm import tqdm
except ImportError:
    os.system("pip install tqdm")
    from tqdm import tqdm
try:
    from unidecode import unidecode
except ImportError:
    os.system("pip install unidecode")
    from unidecode import unidecode
import mmap
import re
import linecache
import subprocess
from unidecode import unidecode
from colorama import init, Fore

# Inicializar colorama
init()

 
# Codigos ANSI para colores
RED = '\033[91m'
PURPLE = '\033[95m'
GREEN = '\033[92m'
ENDC = '\033[0m'

archivos_encontrados = 0
ruta_actual = os.getcwd()

# Lista de extensiones de archivos de texto que se buscaran
extensiones_de_texto = {
    '.txt', '.py', '.c', '.cpp', '.java', '.html', '.css', '.js', '.php',
    '.vb', '.rb', '.sh', '.pl', '.swift', '.kt', '.scala', '.ini', '.cfg',
    '.conf', '.properties','.env', '.config', '.xml', '.json',
    '.yaml', '.yml', '.xsd', '.svg', '.plist','.markdown', '.rtf',
    '.doc', '.docx', '.odt', '.pdf', '.tex', '.pptx', '.odp', '.key',
    '.xls', '.xlsx', '.ods', '.csv', '.tsv', '.log', '.dat', '.po',
    '.pot', '.mo', '.lst','.out', '.err', '.rpt', '.man', '.help',
    '.eml', '.msg', '.chat', '.db', '.srt', '.pub', ''}
    
# Limpiar el archivo existente o crear uno nuevo
with open("resultado.cpp", "w", encoding='utf-8'):
    pass
    
def resaltar_palabra_encontrada(linea, palabra):
    return linea.replace(palabra, RED + palabra + ENDC)

def imprimir_contenido_encontrado(contenido, ruta_completa):
    if contenido:  # Asegurarse de que haya contenido antes de imprimir
        contenido_resaltado = [resaltar_palabra_encontrada(linea, palabra_buscada) for linea in contenido]
        contenido_resaltado = '\n'.join(contenido_resaltado).replace(ruta_completa, PURPLE + ruta_completa + ENDC) \
            .replace(f"Encontrada la palabra '{RED}{palabra_buscada}'", f"Encontrada la palabra '{RED}{palabra_buscada}'{ENDC}") \
            .replace("Linea", GREEN + "Linea" + ENDC)

        # Imprimir en la consola
        print(contenido_resaltado)

        # Eliminar codigos ANSI antes de guardar en el archivo .cpp
        contenido_sin_colores = remove_ansi_codes(contenido_resaltado)

        # Agregar un salto de linea al final de la cadena antes de guardar en el archivo .cpp
        contenido_sin_colores += '\n'

        # Guardar en un archivo .cpp
        with open(f"{ruta_actual}/resultado.cpp", "a", encoding='utf-8') as cpp_file:
            cpp_file.write(contenido_sin_colores)

def remove_ansi_codes(texto):
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', texto)
    
# Convertir las palabras con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex(palabras):
    regex = []
    for palabra in palabras.split('|'):
        regex_palabra = []
        for letra in palabra:
            if letra.lower() == 'a':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'e':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'i':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'o':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'u':
                regex_palabra.append('[uúùüûū]')

            elif letra.lower() == 'á':
                regex_palabra.append('[aáàäâã]')
            elif letra.lower() == 'é':
                regex_palabra.append('[eéèëêē]')
            elif letra.lower() == 'í':
                regex_palabra.append('[iíìïîī]')
            elif letra.lower() == 'ó':
                regex_palabra.append('[oõôöóò]')
            elif letra.lower() == 'ú':
                regex_palabra.append('[uúùüûū]')

            else:
                regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
        regex.append(''.join(regex_palabra))
    return '|'.join(regex)
    
import re
import mmap

# Convertir la palabra con tilde en una expresión regular que permita buscar con y sin tilde
def crear_regex1(palabras):
    regex_palabra = []
    for letra in palabras:
        if letra.lower() == 'a':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'e':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'i':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'o':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'u':
            regex_palabra.append('[uúùüûū]')

        elif letra.lower() == 'á':
            regex_palabra.append('[aáàäâã]')
        elif letra.lower() == 'é':
            regex_palabra.append('[eéèëêē]')
        elif letra.lower() == 'í':
            regex_palabra.append('[iíìïîī]')
        elif letra.lower() == 'ó':
            regex_palabra.append('[oõôöóò]')
        elif letra.lower() == 'ú':
            regex_palabra.append('[uúùüûū]')

        else:
            if letra != '.':
                regex_palabra.append(re.escape(letra))  # Escapar caracteres especiales en la expresión regular
            else:
                regex_palabra.append(letra)
    return ''.join(regex_palabra)

# Resto del código...


 
    
ruta_rep = []   
import os

def buscar_palabra_en_archivo(ruta_completa, palabra, resultado_buscar):
    # Verificar la extension del archivo
    _, extension = os.path.splitext(ruta_completa)
    if extension.lower() not in extensiones_de_texto:
        return False

    encontrado = False
    contenido_encontrado = []
    cnt_palabras = palabra.split(' ')
    # Inicializar palabra_frase como una cadena vacía
    palabra_frase = ""
    
    if not ruta_completa in ruta_rep:
        try:
            # Check if file is empty
            if os.path.getsize(ruta_completa) > 0:
                with open(ruta_completa, 'r', encoding='utf-8') as file:
                    with mmap.mmap(file.fileno(), length=0, access=mmap.ACCESS_READ) as mm:
                        
                        
                        
                        # Convertir el contenido del mapeo en una cadena de bytes y luego decodificarla a una cadena de texto
                        texto = mm[:].decode('utf-8')
                        
                        if len(palabras_texto) > 1: 
                            # Realizar la búsqueda dentro del texto decodificado
                            # coincidencias = re.findall(palabras_regex, texto, flags=re.IGNORECASE)
                            coincidencias = re.findall(r'\b({})\b'.format(palabras_regex), texto, flags=re.IGNORECASE)
                        
                            coincidencias1 = re.findall(palabras_regex1, texto, flags=re.IGNORECASE)
                            #coincidencias1 = re.findall(r'\b({})\b'.format(palabras_regex1), texto, flags=re.IGNORECASE)
                            coincidencias2 = False
                        else:
                            coincidencias = False
                            coincidencias1 = False
                            coincidencias2 = re.findall(palabras_regex2, texto, flags=re.IGNORECASE)

                        # Imprimir las coincidencias encontradas
                        if coincidencias and coincidencias1 or coincidencias2:
                            if os.path.getsize(ruta_completa) > 0:
                                resultado_grep = subprocess.run(f"unidecode < {ruta_completa} | grep -inE '{buscar_todo}' | cut -d ':' -f 1", capture_output=True, text=True, shell=True)
                                numeros_linea = [int(numero) for numero in resultado_grep.stdout.strip().split()]
                                # Mostrar las líneas específicas usando linecache
                                for numero_linea in numeros_linea:
                                    linea = linecache.getline(ruta_completa, numero_linea)
                                    # Resaltar palabras buscadas en rojo
                                    palabras_linea = linea.strip().split()
                                    for i, palabra_linea in enumerate(palabras_linea):
                                        #for palabra_buscada in palabra.split('|'):
                                        for palabra_buscada in buscar_todo.split('|'):
                                            if palabra_buscada.lower() in unidecode(palabra_linea.lower()):
                                                palabras_linea[i] = f"{Fore.RED}{palabra_linea}{Fore.RESET}"
                                    if not encontrado:
                                        encontrado = True
                                        #contenido_encontrado.append(f"Encontrada la palabra '{palabra}' en el archivo: {Fore.MAGENTA}{ruta_completa}{Fore.RESET}")
                                        print(f"Encontrada la palabra '{palabra}' en el archivo: {Fore.MAGENTA}{ruta_completa}{Fore.RESET}")
                                    linea_resaltada = ' '.join(palabras_linea)
                                    #contenido_encontrado.append(f"\n{Fore.GREEN}línea {Fore.RESET}{numero_linea}: {linea_resaltada}\n")
                                    print(f"\n{Fore.GREEN}línea {Fore.RESET}{numero_linea}: {linea_resaltada}\n")
                                    #imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
                                ruta_rep.append(ruta_completa)
                                return encontrado
                    if encontrado:
                        contenido_encontrado.append("\n")
                        #imprimir_contenido_encontrado(contenido_encontrado, ruta_completa)
                ruta_rep.append(ruta_completa)
                 
        except UnicodeDecodeError:
            ruta_rep.append(ruta_completa)
            pass
    return encontrado



def contar_archivos(directorio):
    total = 0
    for base, dirs, files in os.walk(directorio):
        total += len(files)
    return total
def cargar_archivo(ruta_archivo, destino):
    # Simulando la carga del archivo, aqui podrias escribir el codigo real para procesar o copiar el archivo
    return ruta_archivo
def buscar_palabra(directorio, palabras, resultado_buscar):
    archivos = []
    archivos_encontrados = 0  # Initialize archivos_encontrados here
    inicio = time.time()
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for ruta, directorios, archivos_en_dir in os.walk(directorio_base):
            for archivo in archivos_en_dir:
                ruta_completa = os.path.join(ruta, archivo)
                futures.append(executor.submit(cargar_archivo, ruta_completa, '/destino'))
        print('Cargando archivos')
        for future in tqdm(as_completed(futures), total=len(futures), desc='', unit='archivo'):
            archivo_cargado = future.result()
            archivos.append(archivo_cargado)
    print('\n')
 
    with parallel_backend('loky', n_jobs=-1):
        resultados = Parallel(n_jobs=-1, backend='loky', prefer='threads', batch_size='auto', temp_folder=None, verbose=0)(
            delayed(buscar_palabra_en_archivo)(archivo, palabra, buscar_todo) for archivo in archivos for palabra in palabras
        )
       
        fin = time.time()
        tiempo_transcurrido = fin - inicio
    
        horas = int(tiempo_transcurrido // 3600)
        minutos = int((tiempo_transcurrido % 3600) // 60)
        segundos = int(tiempo_transcurrido % 60)
        milisegundos = int((tiempo_transcurrido % 1) * 1000)
    archivos_encontrados = sum(resultados)  # Update archivos_encontrados here
    
    if archivos_encontrados > 0:
        print(f"Total de archivos encontrados: {archivos_encontrados}")
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms")
        print("Copia de búsqueda guardada en resultado.cpp\n")
    else:
        print("No se encontró:\n>> ", palabras_buscadas)
        print(f"Tiempo transcurrido: {horas}h {minutos}m {segundos}s {milisegundos}ms\n")

# Llama a la funcion para obtener el valor de 'disco'
#disco = '/sdcard/backups/'
disco = '/sdcard/'
directorio_base = os.path.expanduser(disco)  # Actualiza esta variable con la ruta de tu directorio base

palabra_buscada = input('ingrese la palabra o las palabras\n> ')
# palabra_buscada = unidecode(palabra_buscada.lower())
palabras_buscadas = [unidecode(palabra.lower()) for palabra in palabra_buscada.split('|')] if '|' in palabra_buscada else [unidecode(palabra_buscada.lower())]
print(palabras_buscadas)
#input()

#----------------CORRECTOR-ORTOGRAFICO---------------#
try:
    from spellchecker import SpellChecker
except:
    os.system("pip install pyspellchecker")
    from spellchecker import SpellChecker
from unidecode import unidecode

# Crear un objeto SpellChecker
spell = SpellChecker(language='es')

# Función para cargar un diccionario personalizado desde un archivo de texto
def cargar_diccionario_personalizado(ruta_archivo):
    with open(ruta_archivo, "r", encoding="utf-8") as file:
        lineas = [line.strip().split('|') for line in file]
        diccionario = {palabra[0]: palabra[1] if len(palabra) > 1 else None for palabra in lineas}
    return diccionario


# Ruta al archivo que contiene el diccionario personalizado
ruta_diccionario_personalizado = "/sdcard/dic_orden/diccionario.txt"

# Cargar el diccionario personalizado
palabras_personalizadas = cargar_diccionario_personalizado(ruta_diccionario_personalizado)
spell.word_frequency.load_words(palabras_personalizadas)


# Crear una tabla de traducción para eliminar los signos de puntuación
translator = str.maketrans('', '', ',.;:!?')
# Convertir el texto del usuario a minúsculas y eliminar acentos
#palabra_usuario = "bsjdkd kdkdkdkddkd En zapatería las tablillas sumerias, se dice que Robert y enkhai y jam ayuda a la humanidad y a vosotro en sus casas, Correto?"
palabras_texto = [unidecode(palabra.lower().translate(translator)) for palabra in palabra_buscada.split()]

capturar_todo= []
capturar_sust = []
capturar_claves = []
#etiqueta = None
# Corregir palabras mal escritas en el texto
for palabra in palabras_texto:
    correccion = spell.correction(palabra)
    if correccion != palabra:
        if correccion in palabras_personalizadas:
            etiqueta = palabras_personalizadas[correccion]
            if etiqueta == "NOUN":
                capturar_sust.append(correccion)
                capturar_todo.append(correccion)
                #continue
            else:
                print(f'Corregida: {etiqueta}: {correccion}')
                capturar_claves.append(correccion)
                capturar_todo.append(correccion)
        else:
            try:
                etiqueta = palabras_personalizadas[correccion]
                if etiqueta == "NOUN":
                    capturar_sust.append(correccion)
                    capturar_todo.append(correccion)
                    #continue
            except:
                for pal_text in (palabras_buscadas):
                    print(''.join(palabras_texto))
                    print(pal_text)
                    print(f'Corregida: Palabra mal escrita: "{palabra}", Corrección: "{correccion}"')
                    capturar_sust.append(correccion)
                    capturar_claves.append(correccion)
                    capturar_todo.append(pal_text)
                    input()
    else:
        if palabra in palabras_personalizadas:
            etiqueta = palabras_personalizadas[palabra]
            if etiqueta == "NOUN":
                capturar_sust.append(palabra)
                capturar_todo.append(palabra)
                #continue
            else:
                print(f'Original: {etiqueta}: {palabra}')
                capturar_claves.append(palabra)
                capturar_todo.append(palabra)
        else:
            print(f'Original: Palabra bien escrita: "{palabra}", Corrección: ninguna')
            capturar_claves.append(palabra)
            capturar_todo.append(palabra)
            

# Nota: Funciona en pydroid 3 y termux

if len(palabras_texto) == 1:
    capturar_sust = pal_text
    capturar_claves = pal_text
    palabras_regex = crear_regex1(capturar_sust)
    palabras_regex1 = crear_regex1(capturar_claves)
    palabras_regex2 = crear_regex1(capturar_claves)
    buscar_todo = pal_text
    
else:
    print("Sustantivos:", capturar_sust)
    #print("Sustantivos:", ' '.join(capturar_sust))
    #sust = '|'.join(capturar_sust)
    sust = '|'.join([word for word in capturar_sust if word is not None])
    palabras_con_barra = sust.lower().replace(' ', '|')
    palabras_regex = crear_regex(palabras_con_barra)
    print(palabras_regex)
    
    print("\n#--------------------------------------------------#\n")
    resultado = ' '.join([word for word in capturar_claves if word is not None])
    resultado_buscar = '|'.join([word for word in capturar_claves if word is not None])
    palabras_con_barra1 = resultado_buscar.lower().replace(' ', '|')
    palabras_regex1 = crear_regex(palabras_con_barra1)
    #print(resultado)
    print(palabras_regex1)
    
    buscar_todo = '|'.join([word for word in capturar_todo if word is not None])
    palabras_con_barra2 = buscar_todo.lower().replace(' ', '|')
    palabras_regex2 = crear_regex(palabras_con_barra2)
    
    print(sust)
    print(resultado_buscar)
print(palabras_regex)
print(buscar_todo)
input()

'''
el diccionario debe tener palabras con etiquetas, ejemplo:
Enki|NOUN
zapatería
Robert|NOUN
puede agregar etiqueta a las palabras que necesitas destacar!
la palabra zapatería no tiene etiqueta al igual se carga en la verificación.
'''
#-------------CORRECTOR-ORTOGRAFICO-FIN-------------#



buscar_palabra(directorio_base, palabras_buscadas, buscar_todo)

'''

enki es satanas y le dió ayuda a los humanos, con su poder 

if fs in linea_normal or (palabra_frase := ' '.join(palabras_capturadas)) and fuzz.ratio(palabra_frase, palabra) >= 80: 
    # Hacer algo con la frase válida
    
    
if fs in linea_normal and fuzz.ratio(fs, linea_normal) >= 80: palabras_validas = [palabra for palabra in palabras_capturadas if fuzz.ratio(palabra, palabra) >= 80]
'''
