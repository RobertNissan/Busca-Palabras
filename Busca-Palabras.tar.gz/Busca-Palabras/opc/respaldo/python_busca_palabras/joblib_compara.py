import difflib
from joblib import Parallel, delayed

def comparar_similitud(palabra, linea):
    porcentaje = difflib.SequenceMatcher(None, palabra, linea).ratio() * 100
    return porcentaje, linea

# Leer la palabra a buscar desde la entrada del usuario
palabra_a_buscar = input("Ingrese la palabra a buscar: ")

# Establecer el umbral de corte para la similitud
umbral_similitud = 70

# Procesar las comparaciones en paralelo utilizando joblib
with open("diccionario.txt", "r", encoding="utf-8") as archivo:
    lineas_diccionario = archivo.readlines()

    
    resultados = Parallel(n_jobs=-1, backend='loky', prefer='processes', batch_size='auto', temp_folder=None)(
        delayed(comparar_similitud)(palabra_a_buscar, linea) for linea in lineas_diccionario
    )

    for porcentaje, linea in resultados:
        if porcentaje >= umbral_similitud:
            print(f'Linea: {linea.strip()}, Porcentaje de similitud: {porcentaje:.2f}%')

