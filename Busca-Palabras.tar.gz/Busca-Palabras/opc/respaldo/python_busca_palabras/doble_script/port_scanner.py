import os
try:
    import nmap
except ImportError:
    os.system('pip install python-nmap')
    import nmap
import concurrent.futures

def scan_ports(ip_objetivo, num_threads=10):
    def scan_ports_worker(ip, port_range):
        nm = nmap.PortScanner()
        result = nm.scan(ip, arguments=f'-p {port_range} -Pn -T4')

        if 'scan' not in result or ip not in result['scan']:
            return f"\nError al obtener los resultados del escaneo para la IP: {ip}. Asegurate de que la IP sea valida y responda a los escaneos de puertos."
        else:
            if nm[ip].all_protocols():
                port_info = []
                for protocol in nm[ip].all_protocols():
                    lport = sorted(nm[ip][protocol].keys())
                    for port in lport:
                        port_info.append(f"Puerto {port}: {nm[ip][protocol][port]['state']}")
                return '\n'.join(port_info)
            else:
                return f"\nNo se encontraron puertos abiertos para la IP: {ip}."

    # Dividir el rango de puertos para escanear en varias partes
    port_ranges = [(i, i + 65535 // num_threads) for i in range(1, 65536, 65535 // num_threads)]

    # Lista para almacenar los resultados de los hilos
    results = []

    # Realizar el escaneo de puertos en hilos separados
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(scan_ports_worker, ip_objetivo, f'{start}-{end}') for (start, end) in port_ranges]

        # Obtener los resultados de los hilos
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())

    return '\n'.join(results)
