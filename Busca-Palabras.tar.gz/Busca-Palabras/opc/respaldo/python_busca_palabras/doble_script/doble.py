from port_scanner import scan_ports
# Del archivo port_scanner.py importas su funcion scan_ports

ip_objetivo = "192.168.20.83"
# Aqui luego en la variable resultado se obtienen la informacion
# Tras ejecutar la funcion en la variable
resultado = scan_ports(ip_objetivo)
print(resultado)
