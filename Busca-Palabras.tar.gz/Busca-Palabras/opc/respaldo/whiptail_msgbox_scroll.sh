#!/bin/bash

# Define el array
array=( "Manzana" "Banana" "Cereza" "Durazno" "Fresa" )

# Usa un bucle for para convertir el array en una cadena de texto
message=""
for item in ${array[*]}
do
    message="$message$item\n" # Agrega cada elemento del array a la cadena de texto
done

# Llama a Whiptail y muestra la cadena de texto
whiptail --msgbox --scrolltext "$message" 0 0
