#!/bin/bash

echo "Downloading loclx..."
case `dpkg --print-architecture` in
aarch64)
    architectureURL="arm64" ;;
arm)
    architectureURL="arm" ;;
armhf)
    architectureURL="arm" ;;
amd64)
    architectureURL="amd64" ;;
i*86)
    architectureURL="386" ;;
x86_64)
    architectureURL="amd64" ;;
*)
    echo "unknown or unsupported architecture"
esac

wget https://api.localxpose.io/api/v2/downloads/loclx-linux-${architectureURL}.zip -O loclx.zip

unzip loclx.zip
rm loclx.zip
cp loclx ~/
cp -r loclx $PREFIX/bin/

