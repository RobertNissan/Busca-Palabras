#!/bin/bash
#
# Created by: Robert_Nissan
#
# VARIABLES
#
PWD=$(pwd)
# FUNCIONES
#
function Logo_Loclx {
	sleep 0.5
	clear
echo -e "${verde}                                                   
 _|          _|_|      _|_|_|  _|        _|      _|  
 _|        _|    _|  _|        _|          _|  _|    
 _|        _|    _|  _|        _|            _|      
 _|        _|    _|  _|        _|          _|  _|    
 _|_|_|_|    _|_|      _|_|_|  _|_|_|_|  _|      _|
"${blanco}
}
token_localxpose() {
	./loclx -help > /dev/null 2>&1 &
	sleep 1
	[ -d ".localxpose" ] && auth_f=".localxpose/.access" || auth_f="$HOME/.localxpose/.access"

	[ "$(./loclx account status | grep Error)" ] && {
		echo -e "\n\n${RED}[${WHITE}!${RED}]${GREEN} Crea un registro en ${YELLOW}localxpose.io${GREEN} & copia el token\n"
		sleep 1
                temprompt="$(echo -e "${GREEN}[${WHITE}?${GREEN}]${ULWHITE}${BOLDWHITE} INGRESA TU AUTHTOKEN${NA}${YELLOW} >> ${NA}")"
	        read -p "${temprompt}" loclx_token
		[[ $loclx_token == "" ]] && {
			echo -e "\n${RED}[${WHITE}!${RED}]${RED} Debes ingresar el Localxpose Token." ; sleep 2 ; token_loclx
		} || {
			echo -n "$loclx_token" > $auth_f 2> /dev/null
		}
	}
}
function install_loclx {
	Logo_Loclx
    echo -e ""
    echo -e "                   ${verde}Instalando loclx${blanco}\n"
    rm ~/loclx >/dev/null 2>&1
    rm $PREFIX/bin/loclx >/dev/null 2>&1
    rm -rf $PREFIX/share/loclx >/dev/null 2>&1
    mkdir -p ~/.localxpose/
    mkdir -p $PREFIX/share/loclx
    cp get-loclx.sh $PREFIX/share/loclx
    apt install -y proot wget resolv-conf
    apt clean
    apt autoremove
    cd $PREFIX/share/loclx
    bash get-loclx.sh
    cd ~/
}

token_loclx() {
clear
Logo_Loclx
echo -e -n "${verde}
+-----------------+
# ${blanco}LOCLX AUTHTOKEN ${verde}#
+-----------------+"${blanco}
#read -r auth_token_loclx
token_localxpose
#./loclx account login
#echo "${auth_token_loclx}" > ~/.localxpose/.access
}
completado() {
echo -e "${verde}
+-------------------------------+
# ${blanco}LOCLX INSTALADO CORRECTAMENTE ${verde}#
+-------------------------------+
"${blanco}
echo -e ""
echo "Corre: loclx"
echo -e "Uso de loclx:\n"
echo " termux-chroot loclx t http --to [port]"
echo -e " termux-chroot ./loclx tunnel --raw-mode http -t [ip]:[port]"
echo -e " termux-chroot loclx t tcp --to [port]\n"
}
#
# CODIGO
#
if [ -x $PREFIX/share/loclx ]
then
Logo_Loclx
echo -e "${verde}
+-------------------------+
# ${blanco}LOCLX YA ESTA INSTALADO ${verde}#
+-------------------------+
"${blanco}
echo -e ""
echo "Corre: loclx"
echo -e "Uso de loclx:\n"
echo " termux-chroot loclx t http --to [port]"
echo -e " termux-chroot ./loclx tunnel --raw-mode http -t [ip]:[port]"
echo -e " termux-chroot loclx t tcp --to [port]\n"
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/loclx_menu.sh
exit
else
install_loclx
token_loclx
completado
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/loclx_menu.sh
exit
fi
