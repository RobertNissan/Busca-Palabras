#!/bin/bash

echo "Downloading loclx..."
case `dpkg --print-architecture` in
aarch64)
    architectureURL="arm64" ;;
arm)
    architectureURL="arm" ;;
armhf)
    architectureURL="arm" ;;
amd64)
    architectureURL="amd64" ;;
i*86)
    architectureURL="386" ;;
x86_64)
    architectureURL="amd64" ;;
*)
    echo "unknown or unsupported architecture"
esac

wget https://api.localxpose.io/api/v2/downloads/loclx-linux-${architectureURL}.zip -O loclx.zip

unzip loclx.zip
rm loclx.zip

chmod +x loclx
termux-chroot ./loclx account login
cp -r loclx $PREFIX/bin/
termux-chroot ./loclx t http --to 8080

ip=$(curl -s https://ifconfig.me/)
port="8080"
termux-chroot ./loclx tunnel --raw-mode http -t "${ip}":"${port}"

ip="192.168.20.51"
port="8080"
termux-chroot ./loclx tunnel --raw-mode http -t "${ip}":"${port}"


termux-chroot ./loclx tunnel --raw-mode http -t localhost:"8080"
