import os
import json

os.system('ngrok tcp 8022 --log=stdout >/dev/null &')
os.system('echo Cargando Tunnel SSH')
os.system('sleep 7')
os.system("curl -s http://localhost:4040/api/tunnels > tunnels.json")
os.system("curl -s -N tcp://localhost:4040/api/tunnels >> tunnels.json")
os.system('clear')
os.system('sshd')
#with open('tunnels.json') as data_file:    
    #datajson = json.load(data_file)


#msg = "ngrok URL"'s: \n'
#for i in datajson['tunnels']:
  #msg = msg + i['public_url'] +'\n'

#print (msg)
