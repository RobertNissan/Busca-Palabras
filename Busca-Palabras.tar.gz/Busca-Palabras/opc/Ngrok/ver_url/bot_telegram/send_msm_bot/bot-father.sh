#!/bin/bash

usr=$(whoami)
if [ -f $PREFIX/bin/jq ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando jq"
pkg install jq >/dev/null 2>&1
fi
#cd .ssh
#Este script a descargar, se le puede meter el token, y se sube a Dropbox 
#wget https://www.dropbox.com/s/iw3er3rjq2bna0x/mod-bot?dl=0;mv mod-bot?dl=0 .mod-bot                                  
 cd ~/
# Almacenado el usuario en variable
usr="$(whoami)"                  
# Almacenado la fecha en variable
FECHA="$(date +"Fecha %d/%m/%y")"                          # Almacenado la hora en variable
HORA="$(date +"Hora %H:%M:%S")"
# Nombre de archivo de salida en variable
NOMBRE_ARCHIVO="$usr"-dir-ip.txt
# Almacenamiento temporal del archivo en variable
CARPETA_DESTINO="${HOME}/.usr-ip"                          # Simple ruta concatenada en variable
RUTA_ABSOLUTA_ARCHIVO="$CARPETA_DESTINO/$NOMBRE_ARCHIVO"
# Creando la ruta donde estara el archivo
mkdir -p "$CARPETA_DESTINO"

# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
#echo $ip
echo -e ""


clear
usr="$(whoami)"
if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
echo "No tiene conexion wifi!"
echo -e ""
cd
rm -rf .usr-ip
exit
fi

# Almacenando la fecha al archivo a subir
echo "$FECHA" > "$RUTA_ABSOLUTA_ARCHIVO"
# Almacenado la hora al archivo a subir
echo "$HORA" >> "$RUTA_ABSOLUTA_ARCHIVO"
# Almacenando datos en el archivo a subir para la conexion ssh
echo -e "+----------------------+
# Acceso Remoto ssh Creado:            #
# Copie una direccion y pegue en      #
# termux para controlar aquel             #
# dispositivo                                          #
+----------------------+
Acceso Local:" >> "$RUTA_ABSOLUTA_ARCHIVO"
echo ssh $usr@"$iplocal" -p 8022 >> "$RUTA_ABSOLUTA_ARCHIVO"
echo ""
#detener ngrok si esta activo 
if [[ `pidof ngrok` ]]; then
   killall ngrok > /dev/null 2>&1
fi
cd ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/
python ngrok_get_url.py
ver=$(grep -Eo '(tcp)://[^/"]+(.ngrok.io:[^/"]+)' tunnels.json)
v=$(echo "${ver##*/}")
p=$(echo "${ver##*:}")
echo -e "Acceso externo:\nssh ${usr}@${v%:*} -p ${p}" >> "$RUTA_ABSOLUTA_ARCHIVO" 
rm -rf tunnels.json

echo -e ""
sleep 1
ver=$(cat $CARPETA_DESTINO/$NOMBRE_ARCHIVO)
clear 
echo -e -n "${verde}
+--------------------+
# ${blanco}BOT_TELEGRAM_TOKEN ${verde}#
+--------------------+
|
+->>> "${blanco}
read -r token_telegram
clear
while [ -z "$token_telegram" ]; do
clear 
echo -e -n "${verde}
+--------------------+
# ${blanco}BOT_TELEGRAM_TOKEN ${verde}#
+--------------------+
|
+->>> "${blanco}
read -r token_telegram
done
#----------------------------------------------------------------------------#
# convertir en  comentario las lineas desde la 73 - 79

#grep -Ewon "BOT_TELEGRAM_TOKEN" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh

#inv=$(grep -Ewn "read" --context=6 Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | head -n 1)
#echo "${inv//[<>-]/ }" | awk '{print $1}'
vdc='#done'
vd='done'

invf=$(grep -won "read" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | head -n 1)
inf=$(echo "${invf%:*}") #echo $inf


inv=$(grep -Ewn "done" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | head -n 1)
info=$(echo "${inv//[<>-]/ }" | awk '{print $1}') #echo $info
info=$(echo "${info%:*}") 

for i in $(seq ${inf} ${info}); do
#echo $i
co=$(sed -n "${i}p" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh)
coi=$(sed -n "${i}p" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | cut -d' ' -f1)
w=$(echo $coi | cut -d' ' -f1)
coment=$(echo "#${w}")
if [ "$w" == "while" ]; then
co="$w"
coment=$(echo "#${w}")
fi 
sed -i "s%$co%$coment%g" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh
done

# fin de la conversion

 #descomentar
hb=$(grep -E 'token_telegram=' ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | tail -n 1)

sed -i "s%$hb%token_telegram="$token_telegram"%g" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh

#----------------------------------------------------------------------------#
#Si queremos reemplazar la palabra $vdc por $vd en las lineas "$des" ejecutaremos el siguiente comando:
bdo=$(grep -n "$vdc" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh | tail -n 1)
des=$(echo "${bdo%:*}")
sed -i "$des s/$vdc/$vd/g" ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/bot-father.sh
#----------------------------------------------------------------------------#


#token_telegram="$token_telegram"

clear 
#ver id bot Telegram.
#debes haber escrito algo en tu bot 
nid=$(curl https://api.telegram.org/bot${token_telegram}/getUpdates | jq | grep id | sed -n '3p' | awk '{print $2}')
#echo ${nid%?}

#enviar msm a bot Telegram
curl -s -X POST https://api.telegram.org/bot"${token_telegram}"/sendMessage -d chat_id="${nid}" -d text="$ver"

cd
rm -rf .usr-ip
