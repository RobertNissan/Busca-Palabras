#!/bin/bash

if [ -f $PREFIX/bin/jq ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando jq"
pkg install jq >/dev/null 2>&1
fi

clear
trap 'printf "\n";stop' 2

banner() {


echo -e  "
+-++-++-++ ++-++-++++  +-++-++-++++
++ | |+++|||+-++++ ||  +-+| |+++ |
+  +-+++-++++ +++--++  +  +-+++- + \n"


printf "\e[1;77mv2.0 coded by robertnissan.blogspot.com/?m=1\e[0m \n"

printf "\n"


}

s_port() {
port=1
# Bucle while
while [ "$port" = "1" ];
do
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)


while [ -z $choose_port ]; do 
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)
done

choose_port="${choose_port:-${default_choose_port}}"
if [[ "$choose_port" =~ ^[0-9]+$ ]] && [ "$cc" -ge 4 ] && [ "$cc" -le 4 ]; then
port="$choose_port"
server
payload
checkfound
else
port=1
fi
done
}


stop() {

pss=$(ps aux | grep "ssh -R 80:localhost:${port} nokey@localhost.run" | sed -n "1p" | awk '{print $2}')
psn=$(ps aux | grep "ngrok" | sed -n "2p" | awk '{print $2}')
psl=$(ps aux | grep "loclx" | sed -n "2p" | awk '{print $2}')

checkssh=$(ps aux | grep "ssh -R 80:localhost:${port} nokey@localhost.run" | sed -n "1p" | awk '{print $2}')
checkngrok=$(ps aux | grep "ngrok" | sed -n "2p" | awk '{print $2}')
checkloclx=$(ps aux | grep "loclx" | sed -n "2p" | awk '{print $2}')

checkphp=$(ps aux | grep -o "php" | head -n1)

if [[ $checkssh == "$pss" ]]; then
kill "$pss" >/dev/null 2>&1
fi

if [[ $checkngrok =~ "$psn" ]]; then
kill "$psn" >/dev/null 2>&1
fi

if [[ $checkloclx == "$psl" ]]; then
kill "$psl" >/dev/null 2>&1
fi

rm -rf ssh_$port >/dev/null 2>&1
exit 1
}

dependencies() {


command -v ssh > /dev/null 2>&1 || { echo >&2 "I require ssh but it's not installed. Install it. Aborting."; exit 1; }
}


catch_ip() {

ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
printf "\e[1;93m[\e[0m\e[1;77m+\e[0m\e[1;93m] IP:\e[0m\e[1;77m %s\e[0m\n" $ip

cat ip.txt >> saved.ip.txt
}

checkfound() {

printf "\n"
printf "\e[1;92m[\e[0m\e[1;77m*\e[0m\e[1;92m] \e[0m\e[1;77mPresiona cualquier tecla para detener...\e[0m\n"
read -n 1 -p ""
stop

}


server() {

command -v ssh > /dev/null 2>&1 || { echo >&2 "I require ssh but it's not installed. Install it. Aborting."; exit 1; }

printf "\e[1;77m[\e[0m\e[1;93m+\e[0m\e[1;77m] Starting Server...\e[0m\n"

if [[ $subdomain_resp == true ]]; then

$(which sh) -c "ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R $subdomain:80:localhost:"${port}" nokey@localhost.run  2> /dev/null > ssh_${port}" &

sleep 8
else
user_termux=$(whoami)
#$(which sh) -c 'ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:"${port}" med.net 2> /dev/null > sendlink ' &
$(which sh) -c "ssh -R 80:localhost:"${port}" nokey@localhost.run >/dev/null 2>&1 > ssh_${port}" &
#ssh -R 80:localhost:"${port}" u0_a260@localhost.run | grep -wo --color 'https.*[[alphanumeric]]*.life'

sleep 8
fi
printf "\e[1;77m[\e[0m\e[1;33m+\e[0m\e[1;77m] Starting tlssh server... (localhost:"${port}")\e[0m\n"
sleep 3
send_link=$(grep -wo --color 'https.*[[alphanumeric]]*.life' ssh_$port)
printf '\e[1;93m[\e[0m\e[1;77m+\e[0m\e[1;93m] Direct link:\e[0m\e[1;77m %s\n' $send_link
}

payload_ngrok() {

link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io")
#sed 's+forwarding_link+'$link'+g' saycheese.html > index2.html
#sed 's+forwarding_link+'$link'+g' template.php > index.php


}

ngrok_server() {
if [[ -e ngrok ]]; then
echo -e "" >/dev/null 2>&1
else
command -v unzip > /dev/null 2>&1 || { echo >&2 "I require unzip but it's not installed. Install it. Aborting."; exit 1; }
command -v wget > /dev/null 2>&1 || { echo >&2 "I require wget but it's not installed. Install it. Aborting."; exit 1; }
printf "\e[1;92m[\e[0m+\e[1;92m] Downloading Ngrok...\n"
arch=$(uname -a | grep -o 'arm' | head -n1)
arch2=$(uname -a | grep -o 'Android' | head -n1)
if [[ $arch == *'arm'* ]] || [[ $arch2 == *'Android'* ]] ; then
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip > /dev/null 2>&1

if [[ -e ngrok-stable-linux-arm.zip ]]; then
unzip ngrok-stable-linux-arm.zip > /dev/null 2>&1
chmod +x ngrok
rm -rf ngrok-stable-linux-arm.zip
else
printf "\e[1;93m[!] Download error... Termux, run:\e[0m\e[1;77m pkg install wget\e[0m\n"
exit 1
fi

else
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-386.zip > /dev/null 2>&1 
if [[ -e ngrok-stable-linux-386.zip ]]; then
unzip ngrok-stable-linux-386.zip > /dev/null 2>&1
chmod +x ngrok
rm -rf ngrok-stable-linux-386.zip
else
printf "\e[1;93m[!] Download error... \e[0m\n"
exit 1
fi
fi
fi

port=1
# Bucle while
while [ "$port" = "1" ];
do
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)


while [ -z $choose_port ]; do 
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)
done

choose_port="${choose_port:-${default_choose_port}}"
if [[ "$choose_port" =~ ^[0-9]+$ ]] && [ "$cc" -ge 4 ] && [ "$cc" -le 4 ]; then
port="$choose_port"
sleep 2
printf "\e[1;92m[\e[0m+\e[1;92m] Starting ngrok server...\n"
termux-chroot ./ngrok http "${port}" > /dev/null 2>&1 &
sleep 10

link=$(curl -s localhost:4040/api/tunnels | jq -r .tunnels[0].public_url)
printf "\e[1;92m[\e[0m*\e[1;92m] Direct link:\e[0m\e[1;77m %s\e[0m\n" $link
payload_ngrok
checkfound
stop

else
port=1
fi
done

}

loclx_server() {
if [[ -e loclx ]]; then
echo -e "" >/dev/null 2>&1 
else
command -v unzip > /dev/null 2>&1 || { echo >&2 "I require unzip but it's not installed. Install it. Aborting."; exit 1; }
command -v wget > /dev/null 2>&1 || { echo >&2 "I require wget but it's not installed. Install it. Aborting."; exit 1; }
printf "\e[1;92m[\e[0m+\e[1;92m] Downloading Loclx...\n"
case `dpkg --print-architecture` in
aarch64)
    architectureURL="arm64" ;;
arm)
    architectureURL="arm" ;;
armhf)
    architectureURL="arm" ;;
amd64)
    architectureURL="amd64" ;;
i*86)
    architectureURL="386" ;;
x86_64)
    architectureURL="amd64" ;;
*)
    echo "unknown or unsupported architecture"
esac

wget https://api.localxpose.io/api/v2/downloads/loclx-linux-${architectureURL}.zip -O loclx.zip

if [[ -e loclx.zip ]]; then
unzip loclx.zip >/dev/null 2>&1
chmod +x loclx
rm -rf loclx.zip
else
printf "\e[1;93m[!] Download error... Termux, run:\e[0m\e[1;77m pkg install wget\e[0m\n"
exit 1
fi
fi

port=1
# Bucle while
while [ "$port" = "1" ];
do
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)


while [ -z $choose_port ]; do 
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Elige port de 4 digitos!\e[0m\e[1;33m): \e[0m'
read choose_port
cc=$(echo -n "$choose_port" | wc -c)
done

choose_port="${choose_port:-${default_choose_port}}"
if [[ "$choose_port" =~ ^[0-9]+$ ]] && [ "$cc" -ge 4 ] && [ "$cc" -le 4 ]; then
port="$choose_port"
sleep 2
printf "\e[1;92m[\e[0m+\e[1;92m] Starting loclx server...\n"
echo -en "\e[1;77m\e[0m"
termux-chroot loclx tunnel --raw-mode http -t localhost:8080 2> /dev/null 2>&1 &
echo "Cargando tunnel"
sleep 8
echo -e "\e[1;77m\e[0m"
read -n 1 -p "Presione cualquier tecla para detener!"
killall loclx
echo "tunnel detenido"

else
port=1
fi
done

}

start1() {
if [[ -e ssh_$port ]]; then
rm -rf ssh_$port >/dev/null 2>&1
fi

printf "\n"
printf "\e[1;92m[\e[0m\e[1;77m01\e[0m\e[1;92m]\e[0m\e[1;93m tlssh\e[0m\n"
printf "\e[1;92m[\e[0m\e[1;77m02\e[0m\e[1;92m]\e[0m\e[1;93m ngrok\e[0m\n"
printf "\e[1;92m[\e[0m\e[1;77m03\e[0m\e[1;92m]\e[0m\e[1;93m loclx \e[0m\n"
default_option_server="1"
read -p $'\n\e[1;92m[\e[0m\e[1;77m+\e[0m\e[1;92m] Choose a Port Forwarding option: \e[0m' option_server
option_server="${option_server:-${default_option_server}}"
if [[ $option_server -eq 1 ]]; then

command -v ssh > /dev/null 2>&1 || { echo >&2 "I require ssh but it's not installed. Install it. Aborting."; exit 1; }
start

elif [[ $option_server -eq 2 ]]; then
ngrok_server

elif [[ $option_server -eq 3 ]]; then
loclx_server
else
printf "\e[1;93m [!] Invalid option!\e[0m\n"
sleep 1
clear
start1
fi

}


payload() {

send_link=$(grep -o "https://[0-9a-z]*\.med.net" ssh_$port)

#sed 's+forwarding_link+'$send_link'+g' saycheese.html > index2.html
#sed 's+forwarding_link+'$send_link'+g' template.php > index.php


}


start() {

default_choose_sub="Y"
default_subdomain="robertnissan$RANDOM"
default_choose_port="3333"

printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Choose subdomain? (Default:\e[0m\e[1;77m [Y/n] \e[0m\e[1;33m): \e[0m'
read choose_sub


if [[ $choose_sub == "Y" || $choose_sub == "y" || $choose_sub == "Yes" || $choose_sub == "yes" ]]; then
subdomain_resp=true
printf '\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m] Subdomain: (Default:\e[0m\e[1;77m %s \e[0m\e[1;33m): \e[0m' $default_subdomain
read subdomain
subdomain="${subdomain:-${default_subdomain}}"
fi
s_port

}

banner
dependencies
start1
