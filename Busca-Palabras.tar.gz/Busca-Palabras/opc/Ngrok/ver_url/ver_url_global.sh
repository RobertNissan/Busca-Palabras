if [ -x $PREFIX/share/doc/nodejs ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando nodejs"
pkg install nodejs -y
fi

python ngrok_start.py
sleep 7
python ngrok_get_url.py