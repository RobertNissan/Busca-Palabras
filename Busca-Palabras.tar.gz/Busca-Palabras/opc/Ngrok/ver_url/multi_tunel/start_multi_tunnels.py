import os
os.system('ngrok start t1 t2 --log=stdout >/dev/null &')

