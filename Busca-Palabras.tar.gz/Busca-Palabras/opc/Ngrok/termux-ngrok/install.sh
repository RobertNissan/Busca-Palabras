#!/bin/bash

# Establecer colores
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[0;31m"
COLOR_GREEN="\033[0;32m"
COLOR_BLUE="\033[0;36m"
COLOR_RESET="\033[0m"

if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
# Created by: Robert_Nissan
#
# VARIABLES
#
PWD=$(pwd)
# FUNCIONES
#
function Logo_Ngrok {
	sleep 0.5
	clear
echo -e "${verde}
 ###   ##     ####   ######      ####    ##   ###
 ###   ##   #######  ########   ######   ##  ###
 ####  ##  ##        ##    ##  ##    ##  #####
 ## ## ##  ##  ####  #######   ##    ##  #####
 ##  ####  ##  ####  ##  ####  ##    ##  ##  ###
 ##   ###   #######  ##    ##   ######   ##   ###
 ##   ###     ####   ##    ###   ####    ##    ##
"${blanco}
}

usr=$(whoami)
activar_ngrok() {
    # Intentar iniciar el túnel de ngrok
    termux-chroot ngrok tcp 8022 > /dev/null 2>&1 &
    echo -e "${COLOR_YELLOW}Probando la integridad del token${COLOR_RESET}..."
    
    # Esperar un poco y verificar si el túnel está disponible
    for i in {1..10}; do
        link=$(curl -s localhost:4040/api/tunnels | jq -r .tunnels[0].public_url)
        if [[ -n "$link" ]]; then
            break
        fi
        sleep 1
    done

    # Si no se obtiene el link, mostrar mensaje de error
    if [[ -z "$link" ]]; then
        echo -e "${COLOR_RED}Error: No se pudo establecer el túnel Ngrok.\nVerifique el token o configuración${COLOR_RESET}."
        return 1
    fi

    # Separar dominio y puerto
    DOMAIN=$(echo $link | sed 's/tcp:\/\/\([^:]*\).*/\1/')
    PORT=$(echo $link | sed 's/.*:\([0-9]*\)/\1/')

    echo -en "${verde}
+--------------------------------+
# ${blanco}ACCESO SSH EXTERNO HABILITADO: ${verde}#
+--------------------------------+
|
+->>> "${blanco}
    echo -e "${azul}ssh ${blanco}${usr}${amarillo}@${morado}${DOMAIN} ${verde}-p ${PORT}${blanco}\n"
}

verif_token() {
    # Intentar iniciar el túnel para verificar el token
    if ! activar_ngrok; then
        echo -e "${COLOR_RED}Error${COLOR_RESET}: ${COLOR_YELLOW}El token de Ngrok es inválido o ha expirado${COLOR_RESET}."
        echo -e "${COLOR_RED}Por favor, actualiza tu token de autenticación en:\n${COLOR_GREEN}https://dashboard.ngrok.com/get-started/your-authtoken${COLOR_RESET}"
        read -p "Presiona cualquier tecla para continuar..."
        
        # Verificar si ngrok no está instalado
        if [ ! -f $PREFIX/bin/ngrok ]; then
            echo "ngrok ya ha sido eliminado"
        else
            echo "Eliminando ngrok..."
            rm -rf $PREFIX/bin/ngrok $PREFIX/share/ngrok ~/.config/ngrok ~/.ngrok2 ~/ngrok >/dev/null 2>&1
            echo -e "ngrok eliminado\n"
            sleep 3
            bash ~/Busca-Palabras/opc/Ngrok/ngrok_menu.sh
        fi
        exit
    fi

    echo -e "${COLOR_GREEN}El token de Ngrok está correctamente configurado${COLOR_RESET}."

    # Eliminar archivos temporales y procesos
    rm -rf ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/tunnels.json >/dev/null 2>&1
    killall ngrok >/dev/null 2>&1
    killall sshd >/dev/null 2>&1
}





# verif_token
function token_ngrok {
	Logo_Ngrok
    echo -e ""
    echo -e "                   ${verde}Instalando ngrok${blanco}\n"
    rm $PREFIX/bin/ngrok >/dev/null 2>&1
    rm -rf $PREFIX/share/ngrok >/dev/null 2>&1
    apt install -y proot wget resolv-conf
    apt clean
    apt autoremove
    # cd $PREFIX/bin/
    #megadl --print-names 'https://mega.nz/file/7QhnFKJR#Howzr_piqQfbMLejWBIVVd1V_L6d412sMTXdJTXmw-g'
    #bash get-ngrok.sh
    #mkdir -p $PREFIX/share/ngrok
    #cp get-ngrok.sh $PREFIX/share/ngrok
    #cp ngrok $PREFIX/bin
    wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
    # Extraer ngrok en $PREFIX/bin
    tar -xvzf ngrok-v3-stable-linux-arm64.tgz -C $PREFIX/bin
    rm -rf ngrok-v3-stable-linux-arm64.tgz
    rm -rf ngrok-v3-stable-linux-arm64.tgz.1 >/dev/null 2>&1
    chmod +x /data/data/com.termux/files/usr/bin/ngrok
    # ngrok config add-authtoken <token>
     
     # termux-chroot ngrok tcp 5555
    
    #cd $PREFIX/share/ngrok
    #bash get-ngrok.sh
    cd ~/
    
echo -e -n "${verde}
+-----------------+
# ${blanco}INGRESE NGROK AUTHTOKEN ${verde}#
+-----------------+
|
+->>> "${blanco}
read -r auth_token_ngrok

# ngrok authtoken ${auth_token_ngrok}
ngrok config add-authtoken ${auth_token_ngrok}
ngrok config upgrade
verif_token
echo -e "${verde}
+-------------------------------+
# ${blanco}NGROK INSTALADO CORRECTAMENTE ${verde}#
+-------------------------------+
"${blanco}
echo -e ""
echo "Corre: ngrok"
echo -e "Uso de ngrok:\n"
echo " termux-chroot ngrok http [port]"
echo -e " termux-chroot ngrok tcp [port]\n"
}
#
# CODIGO
#
if [ -x $PREFIX/share/ngrok ]
then
Logo_Ngrok
echo -e "${verde}
+-------------------------+
# ${blanco}NGROK YA ESTA INSTALADO ${verde}#
+-------------------------+
"${blanco}
echo -e ""
echo "Corre: ngrok"
echo -e "Uso de ngrok:\n"
echo " termux-chroot ngrok http [port]"
echo -e " termux-chroot ngrok tcp [port]\n"
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/ngrok_menu.sh
exit
else
token_ngrok
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/ngrok_menu.sh
exit
fi
