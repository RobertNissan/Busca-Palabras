#!/usr/bin/env bash

# Activar ngrok optimizado - sin redundancia
set -u

trap detener_ngrok SIGINT SIGTERM SIGTSTP

# Variables globales
SCRIPT_PATH="$(readlink -f "$0")"
usr=$(whoami)
ngrok_bin=$(command -v ngrok)

# Colores
verde="\033[1;32m"
rojo="\033[1;31m"
amarillo="\033[1;33m"
azul="\033[1;34m"
blanco="\033[1;37m"
reset="\033[0m"

# Log
LOGDIR="${TMPDIR:-$HOME/tmp}"
mkdir -p "$LOGDIR" 2>/dev/null || true
rm -f "$LOGDIR"/ngrok-log.* 2>/dev/null || true
logfile=$(mktemp "$LOGDIR/ngrok-log.XXXXXX")

# Instalar megatools si no existe
[ ! -f $PREFIX/bin/megatools ] && pkg install megatools -y

logo_ngrok() {
    clear
    echo -e "${verde}
 ###   ##     ####   ######      ####    ##   ###
 ###   ##   #######  ########   ######   ##  ###
 ####  ##  ##        ##    ##  ##    ##  #####
 ## ## ##  ##  ####  #######   ##    ##  #####
 ##  ####  ##  ####  ##  ####  ##    ##  ##  ###
 ##   ###   #######  ##    ##   ######   ##   ###
 ##   ###     ####   ##    ###   ####    ##    ##
${reset}"
}

detectar_error_token() {
    grep -q "ERR_NGROK_4018" "$logfile" && echo "INVALIDO" && return
    grep -q "ERR_NGROK_702"  "$logfile" && echo "LIMITE"   && return
    grep -q "ERR_NGROK_105"  "$logfile" && echo "SIN_TOKEN" && return
    grep -q "ERR_NGROK_108"  "$logfile" && echo "SESION"   && return
    echo "OK"
}

instalar_ngrok() {
    logo_ngrok
    echo -e "\n${verde}Instalando ngrok${reset}\n"
    
    rm -rf $PREFIX/bin/ngrok $PREFIX/share/ngrok >/dev/null 2>&1
    apt install -y proot wget resolv-conf && apt clean && apt autoremove
    
    wget -q https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
    tar -xzf ngrok-v3-stable-linux-arm64.tgz -C $PREFIX/bin
    rm -f ngrok-v3-stable-linux-arm64.tgz*
    chmod +x $PREFIX/bin/ngrok
    
    echo -e "${verde}Ingrese NGROK AUTHTOKEN:${reset} "
    read -r auth_token
    ngrok config add-authtoken "$auth_token" && ngrok config upgrade
    
    echo -e "${verde}NGROK instalado correctamente${reset}"
}

verificar_token() {
    pkill -f "$ngrok_bin" 2>/dev/null || true
    sleep 0.2
    
    echo -e "${amarillo}Verificando token...${reset}"
    
    if command -v termux-chroot >/dev/null 2>&1; then
        termux-chroot "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
    else
        "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
    fi
    
    local ngrok_pid=$!
    sleep 3
    
    if ! kill -0 "$ngrok_pid" 2>/dev/null; then
        local estado=$(detectar_error_token)
        case "$estado" in
            INVALIDO) echo -e "${rojo}❌ Token inválido o expirado${reset}" ;;
            LIMITE)   echo -e "${amarillo}⚠️ Límite de ngrok alcanzado${reset}" ;;
            SIN_TOKEN) echo -e "${rojo}❌ No hay authtoken configurado${reset}" ;;
            SESION)   echo -e "${amarillo}⚠️ Ngrok activo en otra sesión${reset}" ;;
            *) echo -e "${rojo}❌ Error desconocido${reset}" ;;
        esac
        
        echo -e "${verde}Ingresa nuevo token:${reset} "
        read -r nuevo_token
        ngrok config add-authtoken "$nuevo_token" >/dev/null 2>&1
        exec bash "$SCRIPT_PATH"
    fi
    
    pkill -f "$ngrok_bin" 2>/dev/null || true
    echo -e "${verde}✓ Token válido${reset}"
}

iniciar_tunel() {
    echo -e "${amarillo}Iniciando túnel ngrok...${reset}"
    
    if command -v termux-chroot >/dev/null 2>&1; then
        termux-chroot "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
    else
        "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
    fi
    
    local ngrok_pid=$!
    local elapsed=0
    local max_wait=20
    
    while (( elapsed < max_wait )); do
        if ! kill -0 "$ngrok_pid" 2>/dev/null; then
            verificar_token
            return
        fi
        
        local raw=$(curl -s --max-time 2 http://127.0.0.1:4040/api/tunnels 2>/dev/null || true)
        local link=$(printf '%s' "$raw" | jq -r '.tunnels[]? | select(.proto=="tcp") | .public_url' | head -n1)
        
        if [[ "$link" =~ ^tcp://[^:]+:[0-9]+$ ]]; then
            local domain=$(echo "$link" | sed -n 's~tcp://\([^:]*\):.*~\1~p')
            local port=$(echo "$link" | sed -n 's~.*:\([0-9]*\)~\1~p')
            
            sshd >/dev/null 2>&1
            
            echo -e "${verde}
+--------------------------------+
# ACCESO SSH EXTERNO HABILITADO  #
+--------------------------------+${reset}"
            echo -e "${azul}ssh ${blanco}${usr}${amarillo}@${verde}${domain}${reset} -p ${port}\n"
            echo -e "${verde}Ngrok ejecutándose (PID: ${ngrok_pid}). Presiona ENTER para detener.${reset}"
            
            while true; do
                # read -t 1 detecta ENTER; las señales están atrapadas por trap
                if read -t 1 -r; then
                    detener_ngrok
                fi
            done
            return
        fi
        
        sleep 1
        ((elapsed++))
    done
    
    echo -e "${rojo}Timeout esperando URL${reset}"
    detener_ngrok
}

detener_ngrok() {
    echo -e "\n${amarillo}Deteniendo ngrok...${reset}"
    pkill -f "$ngrok_bin" 2>/dev/null || true
    rm -f "$logfile" 2>/dev/null || true
    exit 0
}

# Main
[ -z "$ngrok_bin" ] && instalar_ngrok && ngrok_bin=$(command -v ngrok)
verificar_token
iniciar_tunel
