#!/bin/bash

echo "Downloading ngrok..."
case `dpkg --print-architecture` in
aarch64)
    architectureURL="arm64"
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-${architectureURL}.zip -O ngrok.zip ;;
arm)
    megadl --print-names 'https://mega.nz/file/TQAHWYoL#3fY_xjdMp9YvZgpIP5x6rg3Bd3Ty2fawskNVqgp_UNM' 
    mv ngrok-stable-linux-arm.zip ngrok.zip
;;
armhf)
    architectureURL="arm"
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-${architectureURL}.zip -O ngrok.zip 
;;
amd64)
    architectureURL="amd64"
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-${architectureURL}.zip -O ngrok.zip 
;;
i*86)
    architectureURL="386"
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-${architectureURL}.zip -O ngrok.zip 
;;
x86_64)
    architectureURL="amd64"
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-${architectureURL}.zip -O ngrok.zip 
;;
*)
    echo "unknown or unsupported architecture"
esac


# arm : https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
#https://mega.nz/file/TQAHWYoL#3fY_xjdMp9YvZgpIP5x6rg3Bd3Ty2fawskNVqgp_UNM

# aarch64 : https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.zip
#https://download1593.mediafire.com/pecfwew0u3vg/cl39udg5xln0egy/ngrok-stable-linux-arm64.zip

# i386 : https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-386.zip
# https://download1478.mediafire.com/jd6l6z2gxuag/a5kijbznornrlnl/ngrok-stable-linux-386.zip

# x86_64 : https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip
#https://download943.mediafire.com/45uxwub51u6g/zk8ck8gnzzxmbj1/ngrok-stable-linux-amd64.zip

unzip ngrok.zip
#rm ngrok.zip
mv ngrok ~/
unzip ngrok.zip
rm ngrok.zip