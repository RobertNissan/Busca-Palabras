# ngrok en Ubuntu (termux)
wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
tar -xvzf ngrok-v3-stable-linux-arm64.tgz -C /usr/local/bin
ngrok config add-authtoken 2LDX8uxs6Qrb3Ae6DldkCeplmil_2AN2fPt1E5unjpgeKV3C2
ngrok config upgrade
ngrok http 8022


# ngrok en (termux)
wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
tar -xvzf ngrok-v3-stable-linux-arm64.tgz -C $PREFIX/bin
chmod +x /data/data/com.termux/files/usr/bin/ngrok
ngrok config add-authtoken 2LDX8uxs6Qrb3Ae6DldkCeplmil_2AN2fPt1E5unjpgeKV3C2
ngrok config upgrade
termux-chroot ngrok tcp 5555


# capturar la url
termux-chroot ngrok tcp 8022 > /dev/null 2>&1 &
curl -s localhost:4040/api/tunnels | jq -r .tunnels[0].public_url
# Nota: a oedar de ni ver la ventana se estara ejecutando en segundo plano, si wuieres retener haz lo siguiente:
killall ngrok


pkg install netcat-openbsd -y
u0_a266@localhost ~> nc -zv 127.0.0.1 8022
Connection to 127.0.0.1 8022 port [tcp/*] succeeded!
