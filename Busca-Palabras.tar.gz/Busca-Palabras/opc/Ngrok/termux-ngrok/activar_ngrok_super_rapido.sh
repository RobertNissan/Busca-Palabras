#!/usr/bin/env bash

# activar ngrok fix
# Versión robusta: evita falsos positivos "null" y valida la URL tcp://host:port

set -u

# Colores
amarillo="\033[1;33m"
rojo="\033[1;31m"
verde="\033[1;32m"
azul="\033[1;34m"
blanco="\033[1;37m"
reset="\033[0m"

trap detener_ngrok SIGINT SIGTERM SIGTSTP

usr=$(whoami)
ngrok_bin=$(command -v ngrok)
[ -z "$ngrok_bin" ] && echo -e "${rojo}ngrok no está instalado.${reset}" && exit 1

# limpieza
detener_ngrok() {
    echo -e "\n${amarillo}Deteniendo ngrok...${reset}"
    pkill -f "$ngrok_bin" 2>/dev/null || true

    # Solo borrar el log si la ejecución fue exitosa (código 0)
    if [[ "${1:-}" != "keep" ]]; then
        [[ -n "${logfile:-}" ]] && rm -f "$logfile" 2>/dev/null || true
    fi

    exit 0
}

# preparar logfile (fallback si /tmp no existe)
LOGDIR="${TMPDIR:-}"
if [[ -z "$LOGDIR" || ! -d "$LOGDIR" ]]; then
    LOGDIR="$HOME/tmp"
    mkdir -p "$LOGDIR" 2>/dev/null || true
fi
# 🔹 BORRAR LOGS ANTIGUOS AQUÍ (antes de crear el nuevo)
rm -f "$LOGDIR"/ngrok-log.* 2>/dev/null || true

logfile=$(mktemp "$LOGDIR/ngrok-log.XXXXXX" 2>/dev/null || mktemp /tmp/ngrok-log.XXXXXX)

# matar ngrok previo
pkill -f "$ngrok_bin" 2>/dev/null || true
sleep 0.2

echo -e "${amarillo}Iniciando ngrok y probando el token...${reset}"
# arrancar ngrok (usa termux-chroot si lo necesitas)
if command -v termux-chroot >/dev/null 2>&1; then
    termux-chroot "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
else
    "$ngrok_bin" tcp 8022 --log=stdout >"$logfile" 2>&1 &
fi
NGROK_PID=$!

# Esperar URL válida: comprobaciones estrictas
link=""
MAX_WAIT=20   # segundos
elapsed=0
while true; do
    # si el proceso murió -> mostrar log y salir
    if ! kill -0 "$NGROK_PID" 2>/dev/null; then
        echo -e "${rojo}ngrok se detuvo al iniciar. Últimas líneas del log:${reset}"
        tail -n 2 "$logfile"
        detener_ngrok
    fi

    # leer la API de ngrok y buscar el primer túnel tcp válido
    raw=$(curl -s --max-time 2 http://127.0.0.1:4040/api/tunnels 2>/dev/null || true)
    # extraer public_url de un túnel tcp (jq devuelve nada si no hay)
    link=$(printf '%s' "$raw" | jq -r '.tunnels[]? | select(.proto=="tcp") | .public_url' 2>/dev/null | head -n1 || true)

    # validar formato: debe cumplir tcp://host:port
    if [[ -n "$link" && "$link" =~ ^tcp://[^:]+:[0-9]+$ ]]; then
        break
    fi

    sleep 1
    ((elapsed++))
    if (( elapsed >= MAX_WAIT )); then
        echo -e "${rojo}Timeout (${MAX_WAIT}s) esperando la URL de ngrok.${reset}"
        echo -e "Revisa el log en: ${blanco}$logfile${reset}"
        tail -n 2 "$logfile"
        # Aquí usamos keep para que no borre el log si sucede esto.
        detener_ngrok keep
    fi
done

# Extraer dominio y puerto de forma segura
DOMAIN=$(printf '%s' "$link" | sed -n 's~tcp://\([^:]*\):\([0-9]*\)~\1~p')
PORT=$(printf '%s' "$link" | sed -n 's~tcp://\([^:]*\):\([0-9]*\)~\2~p')

# si por alguna razón quedaron vacíos -> error
if [[ -z "$DOMAIN" || -z "$PORT" ]]; then
    echo -e "${rojo}Error: la URL encontrada no tiene formato esperado.${reset}"
    echo "Contenido: $link"
    tail -n 100 "$logfile"
    detener_ngrok
fi

sshd
# passwd # La contraseña ssh de acceso es fundamental que la cree con passwd
# Mostrar acceso limpio (sin logs)
echo -e "${verde}
+--------------------------------+
# ACCESO SSH EXTERNO HABILITADO  #
+--------------------------------+${reset}"
echo -e "${azul}ssh ${blanco}${usr}${amarillo}@${verde}${DOMAIN}${reset} -p ${PORT}\n"
echo -e "${verde}Ngrok en ejecución (PID: ${blanco}${NGROK_PID}${verde}).${reset}"
echo -e "Presiona ${amarillo}ENTER ${reset} para detener${reset}."

# Espera interactiva (no bloqueante) — permite señales
while true; do
    # read -t 1 detecta ENTER; las señales están atrapadas por trap
    if read -t 1 -r; then
        detener_ngrok
    fi
done

# detener todo NGROK a la fuerza 
# pkill -9 ngrok
# pkill -9 -f ngrok