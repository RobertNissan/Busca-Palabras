#!/bin/bash

echo "Downloading ngrok..."
case `dpkg --print-architecture` in
aarch64)
    architectureURL="arm64" ;;
arm)
    architectureURL="arm" ;;
armhf)
    architectureURL="arm" ;;
amd64)
    architectureURL="amd64" ;;
i*86)
    architectureURL="386" ;;
x86_64)
    architectureURL="amd64" ;;
*)
    echo "unknown or unsupported architecture"
esac

wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${architectureURL} -O clfld


#wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64

#wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm

#wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-386

#wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64

chmod +x clfld
cp clfld ~/
cp -r clfld $PREFIX/bin/

