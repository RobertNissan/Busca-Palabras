#!/bin/bash
#
# Created by: Robert_Nissan
#
# VARIABLES
#Link generado 
#https://achievements-sign-pda-sporting.trycloudflare.com

PWD=$(pwd)
# FUNCIONES
#
function Logo_Clfld {
	sleep 0.5
	clear
echo -e ${verde}'                                                   
 __        __        __   ___            __   ___ 
/  ` |    /  \ |  | |  \ |__  |     /\  |__) |__  
\__, |___ \__/ \__/ |__/ |    |___ /~~\ |  \ |___ 
                                                  
'${blanco}
}
token_clfld() {
	./clfld -help > /dev/null 2>&1 &
	sleep 1
	[ -d ".clfld" ] && auth_f=".clfld/.access" || auth_f="$HOME/.clfld/.access"

	[ "$(./clfld account status | grep Error)" ] && {
		echo -e "\n\n${RED}[${WHITE}!${RED}]${GREEN} Crea un registro en ${YELLOW}cloudflare${GREEN} & copia el token\n"
		sleep 1
                temprompt="$(echo -e "${GREEN}[${WHITE}?${GREEN}]${ULWHITE}${BOLDWHITE} INGRESA TU AUTHTOKEN${NA}${YELLOW} >> ${NA}")"
	        read -p "${temprompt}" clfld_token
		[[ $clfld_token == "" ]] && {
			echo -e "\n${RED}[${WHITE}!${RED}]${RED} Debes ingresar el Localxpose Token." ; sleep 2 ; token_clfld
		} || {
			echo -n "$clfld_token" > $auth_f 2> /dev/null
		}
	}
}
function install_clfld {
	Logo_Clfld
    echo -e ""
    echo -e "                   ${verde}Instalando cloudflare ${blanco}\n"
    rm ~/clfld >/dev/null 2>&1
    rm $PREFIX/bin/clfld >/dev/null 2>&1
    rm -rf $PREFIX/share/clfld >/dev/null 2>&1
    mkdir -p ~/.clfld/
    mkdir -p $PREFIX/share/clfld
    cp get-clfld.sh $PREFIX/share/clfld
    apt install -y proot wget resolv-conf
    apt clean
    apt autoremove
    cd $PREFIX/share/clfld
    bash get-clfld.sh
    cd ~/
}

token_clfld() {
    clear
    Logo_Clfld
    echo -e -n "${verde}
+-----------------+
# ${blanco}CLFLD AUTHTOKEN ${verde}#
+-----------------+"${blanco}
    token_clfld
}

completado() {
    echo -e "${verde}
+-------------------------------+
# ${blanco}CLFLD INSTALADO CORRECTAMENTE ${verde}#
+-------------------------------+
"${blanco}
    echo -e ""
    echo "Corre: clfld"
    echo -e "Uso de clfld:\n"
    echo -e " termux-chroot \"\$HOME/clfld\" tunnel --url http://localhost:port 2>&1 | grep -oE 'https://[a-zA-Z0-9.-]+\.trycloudflare\.com'\n"
    echo -e " termux-chroot ./clfld tunnel -url [ip]:[port]\n"
}


# CODIGO
if [ -x $PREFIX/share/clfld ]; then
    Logo_Clfld
    echo -e "${verde}
+-------------------------+
# ${blanco}CLFLD YA ESTA INSTALADO ${verde}#
+-------------------------+
"${blanco}
    echo -e ""
    echo "Corre: clfld"
    echo -e "Uso de clfld:\n"
    echo -e " termux-chroot \"\$HOME/clfld\" tunnel --url http://localhost:port 2>&1 | grep -oE 'https://[a-zA-Z0-9.-]+\.trycloudflare\.com'\n"
    echo -e " termux-chroot ./clfld tunnel -url [ip]:[port]"
    echo -e " termux-chroot clfld tunnel -url [ip]:[port]\n"
    read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
    bash ~/Busca-Palabras/opc/Ngrok/clfld_menu.sh
    exit
else
    install_clfld
    #token_clfld
    Logo_Clfld
    completado
    
    # activar cloudflared en Termux nativo 
    # Verificar dónde está el certificado 
    # find $PREFIX -type f \( -name 'ca-certificates.crt' -o -name 'cert.pem' \) 2>/dev/null
    # salida
    # /data/data/com.termux/files/usr/etc/tls/cert.pem
    # /data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/ubuntu/etc/ssl/certs/ca-certificates.crt
    
    if [ -e $HOME/.bashrc ]; then
        # Sí. Para que la línea quede exactamente en la segunda línea del ~/bashrc, sin borrar ni reemplazar ninguna línea existente y evitando duplicarla:
        line='export SSL_CERT_FILE="$PREFIX/etc/tls/cert.pem"'; grep -qxF "$line" ~/.bashrc || sed -i "2i\\$line" ~/.bashrc
        source $HOME/.bashrc
        # set -gx SSL_CERT_FILE "$PREFIX/etc/tls/cert.pem"
    else
        touch $HOME/.bashrc
        # Sí. Para que la línea quede exactamente en la segunda línea del ~/bashrc, sin borrar ni reemplazar ninguna línea existente y evitando duplicarla:
        line='export SSL_CERT_FILE="$PREFIX/etc/tls/cert.pem"'; grep -qxF "$line" ~/.bashrc || sed -i "2i\\$line" ~/.bashrc
        source $HOME/.bashrc
        # set -gx SSL_CERT_FILE "$PREFIX/etc/tls/cert.pem"
    fi
    
    read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
    bash ~/Busca-Palabras/opc/Ngrok/clfld_menu.sh
    exit
fi
