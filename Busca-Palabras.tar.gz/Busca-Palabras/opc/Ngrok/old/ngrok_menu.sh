#!/bin/bash

# Variables de entorno
PREFIX="/data/data/com.termux/files/usr"
export PREFIX

# Colores
verde="\033[1;32m"
rojo="\033[1;31m"
amarillo="\033[1;33m"
azul="\033[1;34m"
blanco="\033[1;37m"
morado="\033[1;35m"
COLOR_RED="\033[1;31m"
COLOR_GREEN="\033[1;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RESET="\033[0m"

# Funciones de manejo de señales
handler_SIGTSTP() { exit 0; }
handler_SIGINT() { exit 0; }
trap 'handler_SIGTSTP' SIGTSTP
trap 'handler_SIGINT' SIGINT

usr=$(whoami)

# Función para instalar ngrok (basada en el script que funciona)
instalar_ngrok() {
    clear
    echo -e "${verde}
 ###   ##     ####   ######      ####    ##   ###
 ###   ##   #######  ########   ######   ##  ###
 ####  ##  ##        ##    ##  ##    ##  #####
 ## ## ##  ##  ####  #######   ##    ##  #####
 ##  ####  ##  ####  ##  ####  ##    ##  ##  ###
 ##   ###   #######  ##    ##   ######   ##   ###
 ##   ###     ####   ##    ###   ####    ##    ##
${COLOR_RESET}"
    
    echo -e "\n${verde}Instalando ngrok${COLOR_RESET}\n"
    
    # Limpiar instalación previa
    rm -rf $PREFIX/bin/ngrok $PREFIX/share/ngrok >/dev/null 2>&1
    
    # Instalar dependencias
    apt install -y proot wget resolv-conf && apt clean && apt autoremove
    
    # Descargar ngrok v3
    echo "Descargando ngrok v3..."
    wget -q https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
    
    if [[ ! -f ngrok-v3-stable-linux-arm64.tgz ]]; then
        echo -e "${rojo}Error: No se pudo descargar ngrok${COLOR_RESET}"
        read -n 1 -p "Presione cualquier tecla para continuar..."
        return 1
    fi
    
    # Extraer e instalar
    tar -xzf ngrok-v3-stable-linux-arm64.tgz -C $PREFIX/bin
    rm -f ngrok-v3-stable-linux-arm64.tgz*
    chmod +x $PREFIX/bin/ngrok
    
    # Configurar token
    echo -e "${verde}Ingrese NGROK AUTHTOKEN:${COLOR_RESET} "
    read -r auth_token
    
    if [[ -n "$auth_token" ]]; then
        ngrok config add-authtoken "$auth_token" && ngrok config upgrade
        echo -e "${verde}NGROK instalado correctamente${COLOR_RESET}"
    else
        echo -e "${amarillo}Token vacío, configure después${COLOR_RESET}"
    fi
    
    read -n 1 -p "Presione cualquier tecla para continuar..."
}
activar_ngrok() {
    # Limpiar procesos previos
    pkill -f "ngrok tcp" >/dev/null 2>&1
    sleep 1
    
    echo -e "${COLOR_YELLOW}Probando la integridad del token${COLOR_RESET}..."
    
    # Crear archivo de log temporal
    local LOGDIR="${TMPDIR:-$HOME/tmp}"
    mkdir -p "$LOGDIR" 2>/dev/null || true
    local logfile=$(mktemp "$LOGDIR/ngrok-log.XXXXXX")
    
    # Iniciar ngrok con log
    if command -v termux-chroot >/dev/null 2>&1; then
        termux-chroot ngrok tcp 8022 --log=stdout >"$logfile" 2>&1 &
    else
        ngrok tcp 8022 --log=stdout >"$logfile" 2>&1 &
    fi
    
    local ngrok_pid=$!
    sleep 3
    
    # Verificar si ngrok sigue corriendo
    if ! kill -0 "$ngrok_pid" 2>/dev/null; then
        # Detectar error en log
        if grep -q "ERR_NGROK_4018\|ERR_NGROK_105\|ERR_NGROK_108" "$logfile"; then
            rm -f "$logfile" 2>/dev/null
            echo -e "${COLOR_RED}Error: Token inválido o no configurado${COLOR_RESET}"
            return 1
        fi
    fi
    
    # Esperar y obtener URL del túnel
    local elapsed=0
    local max_wait=15
    local link=""
    
    while (( elapsed < max_wait )); do
        local raw=$(curl -s --max-time 2 http://127.0.0.1:4040/api/tunnels 2>/dev/null || true)
        link=$(printf '%s' "$raw" | jq -r '.tunnels[]? | select(.proto=="tcp") | .public_url' 2>/dev/null | head -n1)
        
        if [[ "$link" =~ ^tcp://[^:]+:[0-9]+$ ]]; then
            break
        fi
        
        sleep 1
        ((elapsed++))
    done
    
    # Limpiar proceso de prueba
    kill "$ngrok_pid" 2>/dev/null || true
    rm -f "$logfile" 2>/dev/null
    
    # Verificar resultado
    if [[ ! "$link" =~ ^tcp://[^:]+:[0-9]+$ ]]; then
        echo -e "${COLOR_RED}Error: No se pudo establecer el túnel Ngrok${COLOR_RESET}"
        return 1
    fi
    
    # Extraer dominio y puerto
    local domain=$(echo "$link" | sed -n 's~tcp://\([^:]*\):.*~\1~p')
    local port=$(echo "$link" | sed -n 's~.*:\([0-9]*\)~\1~p')
    
    echo -e "${verde}
+--------------------------------+
# ${blanco}ACCESO SSH EXTERNO HABILITADO: ${verde}#
+--------------------------------+
${azul}ssh ${blanco}${usr}${amarillo}@${verde}${domain}${COLOR_RESET} -p ${port}"
    
    return 0
}

verif_token() {
    # Intentar iniciar el túnel para verificar el token
    if ! activar_ngrok; then
        echo -e "${COLOR_RED}Error${COLOR_RESET}: ${COLOR_YELLOW}El token de Ngrok es inválido o ha expirado${COLOR_RESET}."
        echo -e "${COLOR_RED}Por favor, actualiza tu token de autenticación en:\n${COLOR_GREEN}https://dashboard.ngrok.com/get-started/your-authtoken${COLOR_RESET}"
        read -p "Presiona cualquier tecla para continuar..."
        
        # Verificar si ngrok no está instalado
        if [ ! -f $PREFIX/bin/ngrok ]; then
            echo "ngrok ya ha sido eliminado"
        else
            echo "Hace falta en token ngrok..."
            cd ~/
    
echo -e -n "${verde}
+-----------------+
# ${blanco}INGRESE NGROK AUTHTOKEN ${verde}#
+-----------------+
|
+->>> "${blanco}
read -r auth_token_ngrok

# ngrok authtoken ${auth_token_ngrok}
ngrok config add-authtoken ${auth_token_ngrok}
ngrok config upgrade
verif_token

            sleep 3
            bash ~/Busca-Palabras/opc/Ngrok/ngrok_menu.sh
        fi
        exit
    fi

    echo -e "${COLOR_GREEN}El token de Ngrok está correctamente configurado${COLOR_RESET}."

    # Eliminar archivos temporales y procesos
    rm -rf ~/Busca-Palabras/opc/Ngrok/ver_url/bot_telegram/send_msm_bot/tunnels.json >/dev/null 2>&1
    killall ngrok >/dev/null 2>&1
}

while true
do
PWD=$(pwd)
# FUNCIONES
#
function Logo_Ngrok {
	sleep 0.5
	clear
echo -e "${verde}
 ###   ##     ####   ######      ####    ##   ###
 ###   ##   #######  ########   ######   ##  ###
 ####  ##  ##        ##    ##  ##    ##  #####
 ## ## ##  ##  ####  #######   ##    ##  #####
 ##  ####  ##  ####  ##  ####  ##    ##  ##  ###
 ##   ###   #######  ##    ##   ######   ##   ###
 ##   ###     ####   ##    ###   ####    ##    ##
"${blanco}
}
clear 
echo -e -n "            ${verde} Elige una opcion"
echo -e -n "${verde}
+---------------------------------------+
# ["${blanco}"01"${verde}"] | "$blanco"Instalar ngrok ${verde}|${blanco}forward${verde}|${blanco}       ${verde}#
#---------------------------------------#
# ["${blanco}"02"${verde}"] | "$blanco"Desinstalar ngrok              ${verde}#
#---------------------------------------#
# [${blanco}03${verde}] | ${blanco}Volver al menu                 ${verde}#
+---------------------------------------+
|
+->>> "${blanco}
read -r text
cd ${HOME}
echo -e ""
case $text in

1|01)
# Verificar si ngrok está instalado
if [[ -x $PREFIX/bin/ngrok ]]; then
    clear
    echo -e "${verde}
 ###   ##     ####   ######      ####    ##   ###
 ###   ##   #######  ########   ######   ##  ###
 ####  ##  ##        ##    ##  ##    ##  #####
 ## ## ##  ##  ####  #######   ##    ##  #####
 ##  ####  ##  ####  ##  ####  ##    ##  ##  ###
 ##   ###   #######  ##    ##   ######   ##   ###
 ##   ###     ####   ##    ###   ####    ##    ##
${blanco}"
    
    verif_token
    echo -e "${verde}
+-------------------------+
# ${blanco}NGROK YA ESTÁ INSTALADO ${verde}#
+-------------------------+
${blanco}

Uso de ngrok:
 termux-chroot ngrok http [port]
 termux-chroot ngrok tcp [port]"
    
    read -n 1 -p "Presione cualquier tecla para volver al menú..."
else
    # ngrok no está instalado, proceder con instalación
    instalar_ngrok
fi
;;

2|02)
if [ ! -f $PREFIX/bin/ngrok ]; then 
echo "ngrok ya a sido eliminado"
rm $PREFIX/bin/ngrok >/dev/null 2>&1
rm -rf $PREFIX/share/ngrok >/dev/null 2>&1
rm -rf ~/.config/ngrok >/dev/null 2>&1
rm -rf ~/.ngrok2 >/dev/null 2>&1
rm -rf ~/ngrok >/dev/null 2>&1
sleep 2 
else
rm $PREFIX/bin/ngrok >/dev/null 2>&1
rm -rf $PREFIX/share/ngrok >/dev/null 2>&1
rm -rf ~/.config/ngrok >/dev/null 2>&1
rm -rf ~/.ngrok2 >/dev/null 2>&1
rm -rf ~/ngrok >/dev/null 2>&1
echo -e "ngrok eliminado\n"
sleep 3
bash ~/Busca-Palabras/opc/Ngrok/ngrok_menu.sh
break
fi
;;

3|03)
cd ${HOME}/Busca-Palabras/opc/
bash acceso_local_remoto.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
