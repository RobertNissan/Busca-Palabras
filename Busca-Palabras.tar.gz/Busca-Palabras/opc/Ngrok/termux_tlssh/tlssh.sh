#!/bin/bash

if [ -x ${PREFIX}/bin/sshd ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando openssh"
apt install openssh -y
fi
clear
echo -e ""
echo "Generar llaves ssh"
echo -e "+-------------------------------------+
# "Escriba su contrasena de refuerzo."  #
# "O Presiona enter para seguir."       #
+-------------------------------------+"
echo -e $rojo
passwd
echo -e "${blanco}"
echo -e ""
echo -e ""
echo -e "${verde}[${blanco}Instalando llave ssh${verde}]${blanco}"
echo "En lo que sigue presiona Enter, \"y\" luego
Enter y ENTER."
echo -e ""
ssh-keygen -t rsa -b 4096
echo -e ""
#enter enter
#copia la clave a authorized_keys
mkdir .ssh >/dev/null 2>&1
rm -r .ssh/authorized_keys
cat .ssh/id_rsa.pub >> .ssh/authorized_keys
chmod 0700 .ssh
chmod 0644 .ssh/authorized_keys

usr=$(whoami)
#Me cituas en la ip
str="$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')"
echo -e ""
ip=$(echo "${str%%/*}")
echo -e ""

clear
sshd
echo -e ""
echo -e ""
echo -e "Uso:"
echo -e "ssh -R 80:localhost:8080 ${usr}@localhost.run | grep -wo 'https.*[[alphanumeric]]*.life'\n"
echo -e "${rojo}Presione CTRL +C para detener!${blanco}"
echo -e ""
ssh -R 80:localhost:8080 ${usr}@localhost.run | grep -wo --color 'https.*[[alphanumeric]]*.life'

#ps aux | grep "ssh -R 80:localhost:8080 ${usr}@localhost.run" | sed -n "1p" | awk '{print $2}'

bash ~/Busca-Palabras/opc/acceso_local_remoto.sh
exit