#!/bin/bash 

#nginx
if [ -x $PREFIX/share/doc/nodejs ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando nodejs"
pkg install nodejs -y
fi

if [ -f $PREFIX/bin/nginx ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando nginx"
pkg install nginx -y >/dev/null 2>&1
fi

npm install -g localtunnel 
#uso
#lt
#lanza un error y copias la ruta siguiente:

cp -r config_nginx/openurl.js /data/data/com.termux/files/usr/lib/node_modules/localtunnel/node_modules/openurl/

cp -r config_nginx/index.html $PREFIX/share/nginx/html/

x=0
free > adv
random=$(cat adv | grep -EIiso "${x}1|${x}2|${x}3|${x}4|${x}5|${x}6|${x}7|${x}8|${x}9|10|11|12|13|14|15|16|17|18|19|20|21" | sed -n '3 p' | tail -n 1)
rm -rf adv

clear
echo -e ""
lt --port 8080 --subdomain speednissan${random} > nginx dev/null &
echo -e "Cargando URL Tunnel"
sleep 5
clear
echo -e ""
echo -e "uso"
echo -e "lt --port 8080 --subdomain tu_nombre\n"
#Ahora corremos nginx
#nginx
#corremos el localtunnel
cat ~/Busca-Palabras/opc/Ngrok/termux_nginx/nginx
#rm -rf nginx >/dev/null 2>&1
echo -e ""
read -n 1 -p "Presione cualquier tecla para detener!!!"

#obtendra una URL para compartir con el cliente
## https://robertspeed.loca.lt

#Nota: puede detener nginx con el siguiente comando:
killall nginx >/dev/null 2>&1
#Y de esta forma usar el puerto 8080 para otros script en donde se use para que no genere error/