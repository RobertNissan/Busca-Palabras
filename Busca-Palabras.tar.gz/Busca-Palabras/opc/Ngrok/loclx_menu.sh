#!/bin/bash
while true
do
PWD=$(pwd)
# FUNCIONES
#
function Logo_Loclx {
	sleep 0.5
	clear
echo -e "${verde}
 _|          _|_|      _|_|_|  _|        _|      _|  
 _|        _|    _|  _|        _|          _|  _|    
 _|        _|    _|  _|        _|            _|      
 _|        _|    _|  _|        _|          _|  _|    
 _|_|_|_|    _|_|      _|_|_|  _|_|_|_|  _|      _|
"${blanco}
}
clear 
echo -e -n "            ${verde} Elige una opcion"
echo -e -n "${verde}
+---------------------------------------+
# ["${blanco}"01"${verde}"] | "$blanco"Instalar LocalXpose ${verde}|${blanco}forward${verde}|${blanco}  ${verde}#
#---------------------------------------#
# ["${blanco}"02"${verde}"] | "$blanco"Desinstalar loclx              ${verde}#
#---------------------------------------#
# [${blanco}03${verde}] | ${blanco}Volver al menu                 ${verde}#
+---------------------------------------+
|
+->>> "${blanco}
read -r text
cd ${HOME}
echo -e ""
case $text in

1|01)
if [ -x $PREFIX/share/loclx ]
then
Logo_Loclx
echo -e "${verde}
+-------------------------+
# ${blanco}LOCLX YA ESTA INSTALADO ${verde}#
+-------------------------+
"${blanco}
echo -e ""
echo "Corre: loclx"
echo -e "Uso de loclx:\n"
echo " termux-chroot loclx t http --to [port]"
echo -e " termux-chroot ./loclx tunnel --raw-mode http -t [ip]:[port]"
echo -e " termux-chroot loclx t tcp --to [port]\n"
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/loclx_menu.sh
exit
fi

# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
#x=$(curl -s ifconfig.me)
x=$(curl -s ipinfo.io/ip)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash loclx_menu.sh
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash loclx_menu.sh
exit
fi
fi 

if [ "$iplocal" == "127.0.0.1" ]; then 
#ipexterna="html"
clear
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash loclx_menu.sh
exit
else

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
clear
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
exit
else 
echo "Si hay wifi" >/dev/null 2>&1
chmod +x ~/Busca-Palabras/opc/Ngrok/termux_loclx/*
cd ~/Busca-Palabras/opc/Ngrok/termux_loclx/
bash install.sh
fi
fi 
;;

2|02)
if [ ! -f $PREFIX/bin/loclx ]; then 
echo "loclx ya a sido eliminado"
rm $PREFIX/bin/loclx >/dev/null 2>&1
rm -rf $PREFIX/share/loclx >/dev/null 2>&1
rm -rf ~/.localxpose/ >/dev/null 2>&1
rm -rf ~/loclx >/dev/null 2>&1
sleep 2 
else
rm $PREFIX/bin/loclx >/dev/null 2>&1
rm -rf $PREFIX/share/loclx >/dev/null 2>&1
rm -rf ~/.localxpose/ >/dev/null 2>&1
rm -rf ~/loclx >/dev/null 2>&1
echo -e "loclx eliminado\n"
sleep 3
bash ~/Busca-Palabras/opc/Ngrok/loclx_menu.sh
break
fi
;;

3|03)
cd ${HOME}/Busca-Palabras/opc/
bash acceso_local_remoto.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
