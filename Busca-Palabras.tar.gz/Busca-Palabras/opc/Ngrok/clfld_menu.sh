#!/bin/bash
while true
do
PWD=$(pwd)
# FUNCIONES
#
function Logo_Clfld {
	sleep 0.5
	clear
echo -e ${verde}'                                                   
 __        __        __   ___            __   ___ 
/  ` |    /  \ |  | |  \ |__  |     /\  |__) |__  
\__, |___ \__/ \__/ |__/ |    |___ /~~\ |  \ |___ 
                                                  
'${blanco}
}
clear 
echo -e -n "            ${verde} Elige una opcion"
echo -e -n "${verde}
+---------------------------------------+
# ["${blanco}"01"${verde}"] | "$blanco"Instalar Cloudflare ${verde}|${blanco}forward${verde}|${blanco}  ${verde}#
#---------------------------------------#
# ["${blanco}"02"${verde}"] | "$blanco"Desinstalar clfld              ${verde}#
#---------------------------------------#
# [${blanco}03${verde}] | ${blanco}Volver al menu                 ${verde}#
+---------------------------------------+
|
+->>> "${blanco}
read -r text
cd ${HOME}
echo -e ""
case $text in

1|01)

usuario_ternux=$(whoami)
if [ -e ${HOME}/.ssh/gcp_ssh ]; then
echo "ok" >/dev/null 2>&1
else
echo "Generando claves de conexion clfld"
ssh-keygen -t rsa -f ~/.ssh/gcp_ssh -C ${usuario_ternux}
fi

if [ -e ${HOME}/.ssh/gcp_ssh.pub ]; then
echo "ok" >/dev/null 2>&1
else
echo "Generando claves de conexion clfld"
ssh-keygen -t rsa -f ~/.ssh/gcp_ssh -C ${usuario_ternux}
fi

if [ -x $PREFIX/share/clfld ]
then
Logo_Clfld
echo -e "${verde}
+-------------------------+
# ${blanco}CLFLD YA ESTA INSTALADO ${verde}#
+-------------------------+
"${blanco}
echo -e ""
echo "Corre: clfld"
echo -e "Uso de clfld:\n"
echo -e " termux-chroot \"\$HOME/clfld\" tunnel --url http://localhost:port 2>&1 | grep -oE 'https://[a-zA-Z0-9.-]+\.trycloudflare\.com'\n"
echo -e " termux-chroot ./clfld tunnel -url [ip]:[port]"
echo -e " termux-chroot clfld tunnel -url [ip]:[port]\n"
read -n 1 -p "Presione cualquier tecla para volver al menu!!!"
bash ~/Busca-Palabras/opc/Ngrok/clfld_menu.sh
exit
fi

# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
#x=$(curl -s ifconfig.me)
x=$(curl -s ipinfo.io/ip)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash clfld_menu.sh
exit
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash clfld_menu.sh
exit
fi
fi 

if [ "$iplocal" == "127.0.0.1" ]; then 
#ipexterna="html"
clear
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
cd ~/Busca-Palabras/opc/Ngrok/
bash clfld_menu.sh
exit
else

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
clear
echo -e "No tiene conexion a Internet!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active los ${rojo}Datos moviles (${blanco}Internet${rojo})${blanco}" 
echo "vuelva a intentar!"
sleep 5
echo -e ""
exit
else 
echo "Si hay wifi" >/dev/null 2>&1
chmod +x ~/Busca-Palabras/opc/Ngrok/termux_clfld/*
cd ~/Busca-Palabras/opc/Ngrok/termux_clfld/
source install.sh
fi
fi 
;;

2|02)
if [ ! -f $PREFIX/bin/clfld ]; then 
echo "clfld ya a sido eliminado"
rm $PREFIX/bin/clfld >/dev/null 2>&1
rm -rf $PREFIX/share/clfld >/dev/null 2>&1
rm -rf ~/.clfld/ >/dev/null 2>&1
rm -rf ~/clfld >/dev/null 2>&1
rm -rf ~/.ssh/gcp_ssh >/dev/null 2>&1
rm -rf ~/.ssh/gcp_ssh.pub >/dev/null 2>&1
sleep 2 
else
rm $PREFIX/bin/clfld >/dev/null 2>&1
rm -rf $PREFIX/share/clfld >/dev/null 2>&1
rm -rf ~/.clfld/ >/dev/null 2>&1
rm -rf ~/clfld >/dev/null 2>&1
rm -rf ~/.ssh/gcp_ssh >/dev/null 2>&1
rm -rf ~/.ssh/gcp_ssh.pub >/dev/null 2>&1
echo -e "cloudflare eliminado\n"
sleep 3
bash ~/Busca-Palabras/opc/Ngrok/clfld_menu.sh
break
fi
;;

3|03)
cd ${HOME}/Busca-Palabras/opc/
bash acceso_local_remoto.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
