
while true
do
clear
echo -e ""
# Definir colores (asegúrate de tener estas variables definidas anteriormente en tu script)
echo -e "      Audio de PC a Android Mod"
echo -e "${verde}+------------------------------------+
# [${blanco}01${verde}] | ${blanco}SoundWire v.3.0.b.38         ${verde}#
#------------------------------------#
# [${blanco}02${verde}] | ${blanco}SoundWire Server  v2-5 PC    ${verde}#
#------------------------------------#
# [${blanco}03${verde}] | ${blanco}SoundWire Guia - AudioRelay  ${verde}#
+------------------------------------+"
echo -e ""
echo -e "    ${blanco}Controlar PC desde Android Mod"
echo -en "${verde}+------------------------------------+
# [${blanco}04${verde}] | ${blanco}Unified Remote Client         ${verde}#
#------------------------------------#
# [${blanco}05${verde}] | ${blanco}Unified Remote Server PC      ${verde}#
#------------------------------------#
# [${blanco}06${verde}] | ${blanco}Unified Remote Guia           ${verde}#
+------------------------------------+"

echo -e ""
echo -e ""
echo -e "    ${blanco}Controlar PC Remote Desktop Mod"
echo -en "${verde}+------------------------------------+
# [${blanco}07${verde}] | ${blanco}Remote Desktop               ${verde}#
#------------------------------------#
# [${blanco}08${verde}] | ${blanco}Remote Desktop PC web        ${verde}#
+------------------------------------+"

echo -e ""
echo -e ""
echo -e "       ${blanco}Controlar TV Android Mod"
echo -en "${verde}+------------------------------------+
# [${blanco}09${verde}] | ${blanco}TV Browser                   ${verde}#
#------------------------------------#
# [${blanco}10${verde}] | ${blanco}TV Control Y Raton           ${verde}#
#------------------------------------#
# [${blanco}11${verde}] | ${blanco}Volver al menu app premium   ${verde}#
+------------------------------------+
|
+->>> ${blanco}"
read -r sw
cd ${HOME}
echo -e ""
case $sw in


1|01)
echo -e ""
echo "SoundWire v.3.0.b.38"
if [ -e ${HOME}/soundwire.v.3.0.b.38crk.apk ]; then
echo "SoundWire v.3.0.b.38"
echo "Ya esta descargado"
sleep 2
xdg-open soundwire.v.3.0.b.38crk.apk
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
clear
else
echo -e ""
echo "Descargando SoundWire v.3.0.b.38"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/m4wifliqyof2bwa/soundwire.v.3.0.b.38crk.apk?dl=0;mv soundwire.v.3.0.b.38crk.apk?dl=0 soundwire.v.3.0.b.38crk.apk;xdg-open soundwire.v.3.0.b.38crk.apk;
echo -e ""
clear
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
fi
;;

2|02)
echo -e ""
if [ -e /sdcard/Download/soundwire-server-2-5.exe ]; then
echo "SoundWire Server v2-5 PC"
echo "Ya esta descargado en /sdcard/Download/"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
clear
else
echo -e ""
echo "Descargando SoundWire Server v2-5 PC"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/dhzvpgmvrwu3rbw/soundwire-server-2-5.exe?dl=0;mv soundwire-server-2-5.exe?dl=0 soundwire-server-2-5.exe;cp -r soundwire-server-2-5.exe /sdcard/Download;rm -r soundwire-server-2-5.exe
echo -e ""
clear
echo "SoundWire Server v2-5 PC"
echo -e "Se descargo en /sdcard/Download/\n"
read -n 1 -p "Presione cualquier tecla para ir al menu"
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
fi
;;

3|03)
termux-open-url https://robertnissan.blogspot.com/2022/05/soundwire.html?m=1
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
;;

4|04)
echo -e ""
if [ -e ${HOME}/Unified_Remote_Full_com.Relmtech.RemotePaid.apk ]; then
echo "Unified Remote Paid"
echo "Ya esta descargado"
sleep 2
xdg-open Unified_Remote_Full_com.Relmtech.RemotePaid.apk
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
clear
else
echo -e ""
echo "Descargando Unified Remote Paid"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/n02ottevh2bzow8/Unified_Remote_Full_com.Relmtech.RemotePaid.apk?dl=0;mv Unified_Remote_Full_com.Relmtech.RemotePaid.apk?dl=0 Unified_Remote_Full_com.Relmtech.RemotePaid.apk;xdg-open Unified_Remote_Full_com.Relmtech.RemotePaid.apk;
echo -e ""
clear
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
fi
;;



5|05)
echo -e ""
if [ -e /sdcard/Download/soundwire-server-2-5.exe ]; then
echo "Unified server Remote PC"
echo "Ya esta descargado en /sdcard/Download/"
sleep 2
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
clear
else
echo -e ""
echo "Descargando Unified server Remote PC"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/mda0vu7ci8niatc/serversetup-3.10.0.2467.exe?dl=0;mv serversetup-3.10.0.2467.exe?dl=0 Unifiedserversetup-3.10.0.2467.exe;cp -r Unifiedserversetup-3.10.0.2467.exe /sdcard/Download;rm -r Unifiedserversetup-3.10.0.2467.exe
echo -e ""
clear
echo "Unified server Remote PC"
echo -e "Se descargo en /sdcard/Download/\n"
read -n 1 -p "Presione cualquier tecla para ir al menu"
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
fi
;;

6|06)
xdg-open https://robertnissan.blogspot.com/2022/05/unified-remote.html
;;

7|07)
echo -e ""
if [ -e ${HOME}/chrome-remote-desktop-79-0-3945-26.apk ]; then
echo "chrome Remote desktop"
echo "Ya esta descargado"
sleep 2
xdg-open chrome-remote-desktop-79-0-3945-26.apk
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
clear
else
echo -e ""
echo "Descargando chrome Remote desktop"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/2mtbqxwyb2qqz0d/chrome-remote-desktop-79-0-3945-26.apk
xdg-open chrome-remote-desktop-79-0-3945-26.apk
echo -e ""
clear
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
fi
;;

8|08)
echo -e "En la computadora acceda al siguiente link!!!\n" 
echo -e "https://remotedesktop.google.com/?pli=1\n" 
read -n 1 -p "Presione cualquier tecla para cerrar" 
;;

9|09)
xdg-open https://play.google.com/store/apps/details?id=com.altamirano.fabricio.tvbrowser
clear
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
;;

10)
xdg-open https://robertnissan.blogspot.com/2023/01/control-raton-remoto-android-tv.html?m=1
clear
cd ${HOME}/Busca-Palabras/opc/
bash controlar-pc.sh
break
;;

11)
cd ${HOME}/Busca-Palabras/opc/
bash team-droid.sh
break
;;
*) echo "opcion invalida";sleep 1;clear
;;
esac
done
exit
