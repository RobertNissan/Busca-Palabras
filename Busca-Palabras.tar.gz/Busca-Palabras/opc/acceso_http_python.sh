#!/bin/bash
start_http() {
echo -e "+---------------------------------+
# "Acceso Remoto Local Creado:"     #
# "Copie esta direccion y pegue en" #
# "el navegador de otro celular,  "  #
# "pc o tv browser!"                #
+---------------------------------+
+->>> http://$ip":8080""
echo -e ""
echo -e ""
echo -e ""
termux-wake-lock
echo -e ""$rojo"Nota: presiona tecla CTRL+C para salir!"$white""
echo -e ""
echo -e "" 
bash ~/.termux/boot/server.sh
sshd

echo -e ""
echo -en "+-------------------------------+
# ""$rojo"¿Deseas borrar la sesion S/N?" $white#
+-------------------------------+
+->>> "
read -r yn

if [[ "$yn" == "s" || "$yn" == "S" ]]; then
rm -r ~/.termux/boot/server.sh
echo -e ""
echo Sesion eliminada
termux-wake-unlock
echo -e ""
#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep -w 'http.server 8080' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1
cd ~/Busca-Palabras/opc/
bash acceso_local_remoto.sh
exit
cd Busca-Palabras/;fish
else
echo -e ""
echo "La sesion quedo guardada para usar
con termux-boot en un reinicio"
echo -e ""
echo "Nota: debes tener instalado termux-boot"
echo -e ""
cd ~/Busca-Palabras/opc/
bash acceso_local_remoto.sh
exit
cd Busca-Palabras/;fish
fi
}

rojo='\e[1m\e[31m'
white="\e[1;37m\e[0m"
echo -e ""
#Matar el script servidor.py en segundo plano
kill=$(ps aux | grep -w 'server.sh' | sed -n "1p" | awk '{print $2}')
#echo ${kill}
kill ${kill} >/dev/null 2>&1
#pkill sshd
if [ -x ${PREFIX}/bin/python ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando python"
apt install python -y
fi
if [ -f $PREFIX/bin/wget ]; then
echo Existe >/dev/null 2>&1
echo -e ""
else
echo "Instalando wget"
pkg install wget -y
fi
if [ -x ${PREFIX}/bin/curl ]; then
echo Existe >/dev/null 2>&1
else 
echo "Instalando curl"
apt install curl -y
fi
clear
echo -e ""
echo "Nota: debes tener instalado termux-boot"
echo "Para que el acceso se active cada
vez que encienda el celular."
read -p "Deseas instalarlo S/N? > " sn
if [[ "$sn" == "s" || "$sn" == "S" ]]; then
echo -e ""
echo "install termux-api para generar permisos desde termux!"
read -n 1 -p "Presione cualquier tecla para continuar!"
if [ -e ${HOME}/Termux_API_0.50.1.apk ]; then 
echo "Ya esta descargado"
sleep 2
xdg-open Termux_API_0.50.1.apk
clear
else
echo -e ""
echo "Descargando Termux_API_0.50.1"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/ul0wj8yud8mq03f/Termux_API_0.50.1.apk
xdg-open Termux_API_0.50.1.apk
fi
clear
read -n 1 -p "Presione para proceder con termux-boot"
echo -e 'Esta version de termux-boot, se
instalara solo si tienes la ultima version
de Termux!\n'
read -n 1 -p "Presione cualquier tecla para continuar!"
if [ -e /sdcard/termux-boot-v7.apk ]; then 
echo -e ""
echo termux-boot v7
echo "Ya esta descargado"
echo "Recuerde quitar la optimizacion de
bateria a termux-boot v7"
sleep 2
xdg-open sdcard/termux-boot-v7.apk
clear
else
echo -e ""
echo "Descargando termux-boot v7"
echo -e ""
cd ${HOME};wget https://www.dropbox.com/s/jnuvq5tj9cgx35b/termux.boot_7.apk?dl=0;mv termux.boot_7.apk?dl=0 termux-boot-v7.apk;cp -r termux-boot-v7.apk /sdcard;rm -r termux-boot-v7.apk;echo  "Recuerde quitar la optimizacion
de bateria a termux-boot";sleep 3;xdg-open /sdcard/termux-boot-v7.apk;
cd ${HOME}/Busca-Palabras/opc/
bash termux.sh
fi
fi

sw=a
while [ "$sw" = "a" ]; do
clear
echo -e ""
echo -e "${rojo}${blanco}Creando Acceso Remoto Local:"
echo -e ""
echo -e "Nota: Esta conexion tambien se puede realizar por: 
${rojo}HostSpot ${blanco}(${rojo}Zona WI-FI${blanco}), 
es la misma conexion que se usa para compartir datos
de internet.\n"

echo -e "Lo mejor de esta conexion es que al usar los script 
'SSH, FTP' podras transferir archivos sin necesidad
de tengas recargas de paquetes de Internet.
Es como un "${rojo}Bluetooth${blanco}" pero mas rapido y seguro!!!
Solo comparte tu red ${rojo}HostSpot ${blanco}(${rojo}Zona WI-FI${blanco}) a tu cliente.\n"

#echo -e "Tambien puedes hacer esto por ${rojo}wifi ${blanco}normal!\n"
read -n 1 -p "Presione cualquier tecla para avanzar"
echo -e ""
rm -r ~/.termux/boot/server.sh >/dev/null 2>&1
mkdir -p ~/.termux/boot/
echo "termux-wake-lock" >> ~/.termux/boot/server.sh
#echo "cd /sdcard/" >> ~/.termux/boot/server.sh
echo python -m http.server 8080 -d /sdcard/ >> ~/.termux/boot/server.sh
chmod +x ~/.termux/boot/server.sh

# Buscando la ip Android con wifi activado
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
iplocal=$(echo ${v%%/*})
x=$(curl -s ifconfig.me)
ipexterna=$(echo "${x//[<>]/}")
echo -e ""

clear
if [ "$iplocal" == "127.0.0.1" ]; then 
ipexterna="html"
fi

iplocalc=".${iplocal}"
iplocalc=$(echo "$iplocalc" | awk -F "." '/^\./ {print $(NF-3)}')

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
sleep 1
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
ip=$(echo ${v%%/*})
start_http
fi
fi 

if [[ "$ipexterna" = "" ]]; then 
if [ "$iplocalc" == "192" ]; then 
echo "Zona WI-FI"
sleep 1 
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
ip=$(echo ${v%%/*})
start_http
fi
fi 

if [ "$iplocal" == "127.0.0.1" ]; then 
#ipexterna="html"
clear
echo -e "No tiene conexion wifi o hostpot!
Por favor active el ${rojo}wifi ${blanco} y conecte. 
o active la ${rojo}zona wifi (hostpot)${blanco}" 
echo "vuelva a intentar!"
sleep 5
sw=a
echo -e ""
else

if [[ "$ipexterna" =~ [^0-9]+$ ]]; then
echo "datos sin Internet"
sleep 1
v=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
ip=$(echo ${v%%/*})
start_http
else 
echo "Si hay wifi" >/dev/null 2>&1
x=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
clear
ip=$(echo ${v%%/*})
echo -e ""
curl qrcode.show/http://$ip:8080
start_http
fi
fi 
done
