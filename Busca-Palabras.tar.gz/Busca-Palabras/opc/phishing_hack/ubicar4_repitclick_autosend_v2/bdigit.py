from re import split
import re

#[+] Coordenadas: 5.5361865,-73.3710496

f = open("sesion.txt")
text1 = f.read()
#busca numero y simbolos en conjunto
result = split('\D\S\D+', text1)
uc = result[-2]
print(f"[+] Coordenadas: {uc}")


