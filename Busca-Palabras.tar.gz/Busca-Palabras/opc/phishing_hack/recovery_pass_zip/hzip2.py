from pathlib import Path
import zipfile
import glob
import sys
import os
import time
import platform

try:
    from colorama import Fore,init
    init()
except ImportError:
    os.system("pip3 install colorama")
system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++ ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End
os.system("clear")
print(banner)
opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)
word = input("\nEnter Pass List: ")
try:
# cnt = len(list(open(word, "rb")))
 pass_path = open(word,'rb')
 pass_list = pass_path.readlines()
 cnt = str(len(pass_list))
 print(cnt, "contrasenas en esta lista")
except FileNotFoundError:
 print ("Ingrese un archivo dentro este folder!")
 print()
 sys.exit()

time.sleep(0.35)
file = input("\nEnter zip file: ")
try:
 file = open(file, 'rb')
 print ("Archivos cargados")
 time.sleep(0.51)
except FileNotFoundError:
 print ("Ingrese un archivo dentro este folder!")
 print()
 exit()

def crack_password(password_list, obj):
    # tracking line no. at which password is found
    idx = 0
    # open file in read byte mode only as "rockyou.txt"
    # file contains some special characters and hence
    # UnicodeDecodeError will be generated
    count = 1
    pass_path = open(password_list,'rb')
    passw = pass_path.readlines()
    with open(password_list, 'rb') as file:
        i = 0
        for line in file:
            for word in line.split():
                i = i + 1
                print (str(i) + '/' + str(len(passw)) + ' - ' + str(word.decode("utf-8")))
                try:
                    idx += 1
                    obj.extractall(pwd=word)
                    print("Password found at line", idx)
                    print("Password is", word.decode())
                    return True
                except:
                    number = count
#                    print (f'[%s] [-]Password failed! - %s\n' % (number,word.decode('utf-8')))
                    print (f'[-]Password failed!\n')
                    count += 1
                    pass
                    continue
    return False

password_list = (word)
zip_file = (file)
# ZipFile object initialised
obj = zipfile.ZipFile(zip_file)
# count of number of words present in file
if crack_password(password_list, obj) == False:
    print("No hay contrasenas que coincidan!!!")

