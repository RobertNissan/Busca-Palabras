import zipfile
import sys
import os
import time
import platform

try:
    from colorama import Fore,init
    init()
except ImportError:
    os.system("pip3 install colorama")
system = platform.uname()[0]
End = '\033[0m'
Run_Err = "\nPlease, Run This Programm on Linux or MacOS!\n"

banner = Fore.GREEN + """
##+  ##+ #####+  ######+##+  ##+    #######+##+######+ 
##|  ##|##+--##+##+----+##| ##++    +--###++##|##+--##+
#######|#######|##|     #####++#####+ ###++ ##|######++
##+--##|##+--##|##|     ##+-##++----+###++  ##|##+---+ 
##|  ##|##|  ##|+######+##|  ##+    #######+##|##|     
+-+  +-++-+  +-+ +-----++-+  +-+    +------++-++-+     
""" + End
os.system("clear")
print(banner)
opt = Fore.LIGHTCYAN_EX + """
PRESS CTRL+Z EXIT
""" + End
print(opt)
word = input("\nEnter Pass List: ")
time.sleep(0.35)
file = input("\nEnter zip file: ")
time.sleep(0.51)
count = 1
with open(word, 'rb') as text:
  for entry in text.readlines():
   password = entry.strip()
   try:
     with zipfile.ZipFile(file, 'r') as zf:
        zf.extractall(pwd=password)
        data = zf.namelist()[0]
        data_size = zf.getinfo(data).file_size
        print ('''password found ~ %s\n ~%s\ ~%s\n'''
           % (password.decode('utf-8'), data, data_size))
        break
   except:
        number = count
        print ('[%s] [-]Password failed! - %s' % (number,password.decode('utf-8')))
        count += 1
        pass
