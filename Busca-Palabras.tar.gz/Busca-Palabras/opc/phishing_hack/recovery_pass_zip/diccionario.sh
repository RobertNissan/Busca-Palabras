if [ -x $PREFIX/bin/megatools ]; then 
echo "Existe" >/dev/ null 2>&1
else
pkg install megatools -y
fi


#descaga diccionario
cd ~/Busca-Palabras/opc/hack_pass_zip/
megadl --print-names 'https://mega.nz/file/WRgxwLYC#Wx7sDWwO51362BSWuezXnxTN6nNqRV7_Elzgrs-9Gvg'
unzip rocky.zip
rm rocky.zip