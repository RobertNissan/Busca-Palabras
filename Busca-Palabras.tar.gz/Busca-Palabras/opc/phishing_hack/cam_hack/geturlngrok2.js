const getURL = async () => {
  // inspect if the callback is working at: http://127.0.0.1:4040/inspect/http 
  const ngrok = await import('ngrok')
  const api = ngrok.getApi();
  const { tunnels } = JSON.parse(await api?.get('api/tunnels') ?? '{}')
  // if we already have a tunnel open, disconnect. We're only allowed to have 4
  if (tunnels?.length > 0) await ngrok.disconnect()
  return await ngrok.connect(3000)
}
