#!/bin/bash

#TERMUX
cd
if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
cd ~/Busca-Palabras/opc/
megadl --print-names 'https://mega.nz/file/DcREABzb#OUmMtD6vSLqmrb2LXju6xF5b3u2Gjsl6pD9nucGGFf8'
unzip seeker.zip
rm seeker.zip
cd seeker/
chmod +x install.sh seeker.py
./install.sh
clear
python3 seeker.py