#!/bin/bash

#ligero
if [ -f $PREFIX/bin/megatools ]; then
echo "existe" >/dev/null 2>&1
else
echo "Instalando Repositorios:"
echo -e "" 
echo "Instalando megatool"
pkg install megatools -y
fi
mkdir -p ~/Busca-Palabras/opc/
cd ~/Busca-Palabras/opc/ 
megadl --print-names 'https://mega.nz/file/OVhUGRiA#prS6s_ErKMHSCbujhSm0ODdMNpNgwajpgzvHwW1RVNk'
unzip Clifty_Phishing.zip
rm -rf Clifty_Phishing.zip
cd Clifty
bash clifty.sh

#curl -O https://www.mediafire.com/file/6wqi6t9y8wkrxg9/Clifty_phishing.zip/file
#link=$(grep "href.*download.*media.*" file | head -1 | cut -d '"' -f 2)
#rm file
#mkdir -p ~/Busca-Palabras/opc/
#cd ~/Busca-Palabras/opc/
#wget --no-check-certificate ${link}
#unzip Clifty_phishing.zip
#rm -rf Clifty_phishing.zip
