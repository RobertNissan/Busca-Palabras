#!/bin/bash

echo Verificando Arquitectura Android
if [ -f $PREFIX/bin/screenfetch ]; then
echo "Ya existe" >/dev/null 2>&1
else
echo "Instalando screenfetch"
pkg install screenfetch >/dev/null 2>&1
fi

screenfetch >> ~/adq.txt
adq='v7|x86|v8|h64'
arc="$(grep -Eio "$adq" ~/adq.txt)"
rm -r ~/adq.txt

if [ -e ${HOME}/termux.backup.tar.gz ]; then 
echo -e ""
echo "termux.backup.tar.gz ARMv7"
echo "Ya esta descargado"
echo -e ""
sleep 2
cd $PREFIX/../../;tar -xzvf /sdcard/termux.backup.tar.gz;cd;
clear
echo -e ""
echo -e "Backup recargado"
sleep 2
else
if [ "$arc" == "v7" ]; then
echo -e ""
echo "Descargando termux.backup.tar.gz ARMv7"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/ei3cdygxnjt4nrc/termux.backup.tar.gz?dl=0;mv termux.backup.tar.gz?dl=0 termux.backup.tar.gz;cp -r termux.backup.tar.gz /sdcard;rm -r termux.backup.tar.gz
sleep 1
cd $PREFIX/../../;tar -xzvf /sdcard/termux.backup.tar.gz;cd;
echo -e ""
echo -e "Backup recargado"
sleep 2
clear
fi
fi

if [ -e ${HOME}/termux.backup.tar.gz ]; then
echo -e ""
echo "termux.backup.tar.gz ARM64"
echo "Ya esta descargado"
echo -e ""
sleep 2
cd $PREFIX/../../;tar -xzvf /sdcard/termux.backup.tar.gz;cd;
clear
echo -e ""
echo -e "Backup recargado"
sleep 2
clear
else
if [[ "$arc" == "v8" || "$arc" == "h64" ]]; then
echo -e ""
echo "Descargando termux.backup.tar.gz ARMv8"
echo -e ""
sleep 2
cd ${HOME};wget https://www.dropbox.com/s/ylvxw8k9cgvga8z/termux.backup.tar.gz?dl=0;mv termux.backup.tar.gz?dl=0 termux.backup.tar.gz;cp -r termux.backup.tar.gz /sdcard;rm -r termux.backup.tar.gz
sleep 1
cd $PREFIX/../../;tar -xzvf /sdcard/termux.backup.tar.gz;cd;
echo -e ""
echo -e "Backup recargado"
sleep 2
clear
fi
fi

read -p "Presione cualquier tecla para seguir"
clear
;;