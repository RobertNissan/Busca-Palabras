#!/bin/bash

choice=1

azulcielo='\e[1m\e[36m'

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE"
	
sudo rm -r /data/data/com.termux/files/home/091184.sh


else

clear

fi

clear

fichero="/data/data/com.termux/files/home/091184.sh"

if [ -e "$fichero" ]; then
	echo "\$fichero EXISTE"
	

rm -r /data/data/com.termux/files/home/091184.sh

fi

rm -r /data/data/com.termux/files/home/Install-Busca-Palabras.sh

clear
echo -n "Selecciona la ruta que desees!!! "
echo -e  ""
echo -e  ""
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""
# Bucle while 
while [ $choice = "1" ]; do

read -p "> " choice
clear
if [ $choice = r ]; then
echo -e "" 
echo "Elegiste la raiz del dispositivo"
echo -e "En busqueda de correos"
echo -e "\e[1;37m\e[0m"
echo -e  ""

echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "time find -type f | xargs grep -IEHrinsw "[0-Z._]+@[0-Z]+\.[a-Z]+" --color --context=0 /data/misc/wifi/" >> /data/data/com.termux/files/home/091184.sh

if [ -e "$fichero" ];
then

sudo bash /data/data/com.termux/files/home/091184.sh
sudo rm -r /data/data/com.termux/files/home/091184.sh
fi

if [ -e "$fichero" ] ; then
bash /data/data/com.termux/files/home/091184.sh
rm -r /data/data/com.termux/files/home/091184.sh
fi

else

if [ $choice == i ]; then
echo -e ""
echo "Elegiste la interna sdcard"
echo -e "En busqueda de correos"
echo -e ""
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
UserDir="$(echo /sdcard/)"
eval cd "$UserDir"
time find -type f | grep -IEHrinsw "[0-Z._]+@[0-Z]+\.[a-Z]+" --color --context=0 "$PWD"/

else
if [ $choice == e ]; then

# --context=2 imprime la dos lineas que estan antes y despues de donde esta la palabra a buscar
# -I busca solo en los texto, -H imprime el directorio del archivo, -h no imprime el directorio donde esta el archivo


echo -e "\e[1;37m\e[0m"

clear
#cd /mnt/media_rw/;su;cd /mnt/media_rw/;
#misd=$(ls /mnt/media_rw/)
#misd=$(su -c ls /mnt/media_rw/)
echo -e ""
clear
#16EB-3564
ext=$(su -c ls /mnt/media_rw/)
read -p "introduzca el nombre de su SD-Externa " ext
UserDir="$(echo /storage/$ext/)"
eval cd "$UserDir"
echo -e ""Elegiste la externa sdcard-"\e[1;34m"$ext"\e[0m"
echo -e "En busqueda de correos"
echo -en "$white"
echo -e "\e[1;37m\e[0m"
echo -e ""$azulcielo"\Busqueda Recursiva De Ficheros"
echo -e "$white"
time find -type f | xargs grep -IEHrinsw "[0-Z._]+@[0-Z]+\.[a-Z]+" --color --context=0 "$PWD"/

else
clear
echo -n "Selecciona la ruta que desees en minuscula!"
echo -e ""
echo "Usa las letras "
echo "r. Raiz del dispositivo"
echo "i. Interna sdcard"
echo "e. Externa sdcard"
echo -e ""

choice=1

fi
fi
fi
done;
echo -e "$azulcielo"
echo -e ""$azulcielo"Gracias Por Usar Mi Script"
echo -e ""$azulcielo"Creado Por Robert Nissan"

for x in $azulcielo""B u s q u e d a" "F i n a l i z a d a; do
echo -en "$x"
sleep .03
done
sleep .01
echo -e "  "
echo -e ""
echo -e "$white"
exit