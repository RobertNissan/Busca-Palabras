dia=$(date +"%A");if [ $dia = Monday ]; then d=$(echo Lunes);elif [ $dia = Tuesday ]; then d=$(echo Martes);elif [ $dia = Wednesday ]; then d=$(echo Miercoles);elif [ $dia = Thursday ]; then d=$(echo Jueves);elif [ $dia = Friday ]; then d=$(echo Viernes);elif [ $dia = Saturday ]; then d=$(echo Sabado);elif [ $dia = Sunday ]; then d=$(echo Domingo);fi;mes=$(date +"%B");if [ $mes = January ]; then m=$(echo Enero);elif [ $mes = February ]; then m=$(echo Febrero);elif [ $mes = March ]; then m=$(echo Marzo);elif [ $mes = April ]; then m=$(echo Abril);elif [ $mes = May ]; then m=$(echo Mayo);elif [ $mes = June ]; then m=$(echo Junio);elif [ $mes = July ]; then m=$(echo Julio);elif [ $mes = August ]; then m=$(echo Agosto);elif [ $mes = September ]; then m=$(echo Septiembre);elif [ $mes = October ]; then m=$(echo Octubre);elif [ $mes = November ]; then m=$(echo Noviembre);elif [ $mes = December ]; then m=$(echo Diciembre);fi;
if [ -e ~/registros.log ]; then
echo "Archivo esta en home"
find ~/registros.log -type f -mtime +1 -exec rm {} \;
else
echo >> ~/registros.log
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
find ~/registros.log -type f -mtime +1 -exec rm {} \;
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el hoy es hoy mismo
act=$(date +%d)
sca="$(grep -E "$act de $m" ~/registros.log | head -n 1)"
TODAY=$(date +"Hoy $d, %d de $m")
if [ "$sca" == "$TODAY" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el hoy es de hace 1 dia
xhoy=$(date +'%d' -d "-1 days")
xbm="$(grep -E "$xhoy de $m" ~/registros.log | head -n 1)"
#clear
echo $xbm
#read
xda="$(echo "$xbm" | cut -d' ' -f2)"
xma="$(echo "$xbm" | cut -d' ' -f5)"
xfai="$(date +'Hoy %A, %d de %B' -d "-1 days")"
#clear
echo $xfai
#read
xop="$(echo "$xfai" | cut -d' ' -f2)"
xpo="$(echo "$xfai" | cut -d' ' -f5)"
xes="$(echo -en "$xfai" | sed "s/$xop/$xda/g")"
xesm="$(echo -en "$xes" | sed "s/$xpo/$xma/g")"
#clear
echo -e "si $xbm es igual a $xesm"
#read
echo -e ""
if [ "$xbm" == "$xesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/Anteayer/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/Ayer/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el hoy es de hace 2 dia
zhoy=$(date +'%d' -d "-2 days")
zbm="$(grep -E "$zhoy de $m" ~/registros.log | head -n 1)"
echo -e ""
echo -e "Busca esta fecha dentro del  archivo registros.log "
echo -e "$zbm"
#read
zda="$(echo "$zbm" | cut -d' ' -f2)"
zma="$(echo "$zbm" | cut -d' ' -f5)"
echo $zca $zma
zfai="$(date +'Hoy %A, %d de %B' -d "-2 days")"
#clear
echo $zfai
#read
zop="$(echo "$zfai" | cut -d' ' -f2)"
zpo="$(echo "$zfai" | cut -d' ' -f5)"
echo $zop $zpo
zes="$(echo -en "$zfai" | sed "s/$zop/$zda/g")"
echo $zes
zesm="$(echo -en "$zes" | sed "s/$zpo/$zma/g")"
#clear
echo -e "si $zbm es igual a $zesm"
#read
if [ "$zbm" == "$zesm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/Anteayer/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el Ayer es de hace 1 dia
yhoy=$(date +'%d' -d "-1 days")
ybm="$(grep -E "$yhoy de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-1 days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
#clear
echo -e "si $ybm es igual a $yesm"
#read
echo -e ""
ahoy=$(date +%d)
abm="$(grep -E "$ahoy de $m" ~/registros.log | head -n 1)"
TODAY=$(date +"Hoy $d, %d de $m")
#clear
echo $ahoy
echo "Si $abm es igual a $TODAY"
#read
if [[ "$abm" == "$TODAY" || "$ybm" == "$yesm" ]]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el Ayer es de hace 2 dia
any=$(date +'%d' -d "-2 days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-2 days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
TODAY=$(date +"Hoy $d, %d de $m")
#clear
echo $ahoy
echo "Si $abm es igual a $TODAY"
#read
if [ "$ybm" == "$yesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/Anteayer/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi



#si el Anteayer es de hace 2 dias
any=$(date +'%d' -d "-2 days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Anteayer %A, %d de %B' -d "-2 days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
#clear
echo -e "si $ybm es igual a $yesm"
#read
echo -e ""
#clear
echo "Si $abm es igual a $TODAY"
#read
if [ "$ybm" == "$yesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
find ~/registros.log -type f -mtime +1 -exec rm {} \;
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi

#si el hoy es de hace 3 dia o mas
for a in $(seq 3 28); do
hoy=$(date +'%d' -d "-"$a" days")
echo $hoy
bm="$(grep -E "$hoy de $m" ~/registros.log | head -n 1)"
echo -e ""
echo -e "Si existe esta fecha en el archivo registros.log entonces modificarla"
echo -e "$bm"
da="$(echo "$bm" | cut -d' ' -f2)"
ma="$(echo "$bm" | cut -d' ' -f5)"
echo $ca $ma
fai="$(date +'Hoy %A, %d de %B' -d "-"$a" days")"
echo $fai
op="$(echo "$fai" | cut -d' ' -f2)"
po="$(echo "$fai" | cut -d' ' -f5)"
echo $op $po
es="$(echo -en "$fai" | sed "s/$op/$da/g")"
echo $es
esm="$(echo -en "$es" | sed "s/$po/$ma/g")"
#clear
echo -e "si $bm es igual a $esm"
#read
if [ "$bm" == "$esm" ]; then
TODAY=$(date +"Hoy $d, %d de $m")
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
grep -rl 'Hoy' ~/registros.log | xargs sed -i 's/Hoy/El/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi
done

#si el Ayer es de hace 3 dia o mas
for b in $(seq 3 28); do
any=$(date +'%d' -d "-"$b" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Ayer %A, %d de %B' -d "-"$b" days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
#clear
echo -e "si $ybm es igual a $yesm"
#read
echo -e ""
ahoy=$(date +%d)
abm="$(grep -E "$ahoy de $m" ~/registros.log | head -n 1)"
TODAY=$(date +"Hoy $d, %d de $m")
#clear
echo $ahoy
echo "Si $abm es igual a $TODAY"
#read
if [ "$ybm" == "$yesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'Ayer' ~/registros.log | xargs sed -i 's/Ayer/El/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi
done

#si el Anteayer es de hace 3 dias o mas
for c in $(seq 3 28); do
any=$(date +'%d' -d "-"$c" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'Anteayer %A, %d de %B' -d "-"$c" days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
#clear
echo -e "si $ybm es igual a $yesm"
#read
echo -e ""
echo "Si $abm es igual a $TODAY"
#read
if [ "$ybm" == "$yesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'Anteayer' ~/registros.log | xargs sed -i 's/Anteayer/El/g'
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi
done

#Solo El
for d in $(seq 3 28); do
any=$(date +'%d' -d "-"$d" days")
ybm="$(grep -E "$any de $m" ~/registros.log | head -n 1)"
#clear
echo $ybm
#read
yda="$(echo "$ybm" | cut -d' ' -f2)"
yma="$(echo "$ybm" | cut -d' ' -f5)"
yfai="$(date +'El %A, %d de %B' -d "-"$d" days")"
#clear
echo $yfai
#read
yop="$(echo "$yfai" | cut -d' ' -f2)"
ypo="$(echo "$yfai" | cut -d' ' -f5)"
yes="$(echo -en "$yfai" | sed "s/$yop/$yda/g")"
yesm="$(echo -en "$yes" | sed "s/$ypo/$yma/g")"
#clear
echo -e "si $ybm es igual a $yesm"
#read
echo -e ""
echo "Si $abm es igual a $TODAY"
#read
if [ "$ybm" == "$yesm" ]; then
find ~/registros.log -type f -mtime +1 -exec rm {} \;
TIMENOW=$(date +"A las %r - %Y")
grep -rl 'se a encendido' ~/registros.log | xargs sed -i 's/se a encendido/se encendio/g'
echo "El dispositivo se a encendido" >> ~/registros.log
echo $TODAY >> ~/registros.log
echo $TIMENOW >> ~/registros.log
echo >> ~/registros.log
exit
fi
done
